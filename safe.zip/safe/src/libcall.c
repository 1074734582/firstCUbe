#include <stdio.h>
#include <stdint.h>
#include <dlfcn.h>
#include "libcall.h"

int32_t libso_call_uart_set(void *so_handler,char *name,int fd,int baude,int c_flow,int bits,char parity,int stop)
{
    int32_t (*sub_fun)(int fd,int baude,int c_flow,int bits,char parity,int stop);
    int32_t ret;

    sub_fun = dlsym(so_handler, name);
    if (!sub_fun) {
        fprintf(stderr, "%s \n",dlerror());
        return -1;
    }
    ret = sub_fun(fd,baude,c_flow,bits,parity,stop);

    return ret;
}

int32_t libso_call_uart_message(void *so_handler,char *name,int fd,uint8_t *message,uint32_t len)
{
    int32_t (*sub_fun)(int fd,uint8_t *message,uint32_t len);
    int32_t ret;

    sub_fun = dlsym(so_handler, name);
    if (!sub_fun) {
        fprintf(stderr, "%s \n",dlerror());
        return -1;
    }
    ret = sub_fun(fd,message,len);

    return ret;
}

int32_t libso_call_uart_hmac(void *so_handler,char *name,int fd,uint8_t *message,uint32_t len, uint8_t *hmac,uint32_t hmac_len)
{
    int32_t (*sub_fun)(int fd,uint8_t *message,uint32_t len,uint8_t *hmac,uint32_t hmac_len);
    int32_t ret;

    sub_fun = dlsym(so_handler, name);
    if (!sub_fun) {
        fprintf(stderr, "%s \n",dlerror());
        return -1;
    }
    ret = sub_fun(fd,message,len,hmac,hmac_len);

    return ret;
}

int32_t libso_call_uart_start(void *so_handler,char *name,int fd)
{
    int32_t (*sub_fun)(int fd);
    int32_t ret;

    sub_fun = dlsym(so_handler, name);
    if (!sub_fun) {
        fprintf(stderr, "%s \n",dlerror());
        return -1;
    }
    ret = sub_fun(fd);

    return ret;
}
