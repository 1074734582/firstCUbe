#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <dlfcn.h>
#include <assert.h>
#include <stdint.h>
#include <sys/time.h>
#include <signal.h>
#include <sys/shm.h>
#include <unistd.h>
#include <syslog.h>
#include <sys/ipc.h>
#include "libcall.h"

#define DEBUG 1
#define NO_DEBUG 2

#define LOG_PRINT(level,info,len,format,args...) \
{ \
    if(level>=log_level) \
    { \
        printf(format, ##args); \
        printf("\n"); \
        print_date(info,len);\
    } \
}

int shmid;
int shmid1;
void *so_uart;
int log_level = DEBUG;

int32_t print_date(uint8_t *message, int32_t len){
    int i;

    for(i =0;i<len;i++){
        printf("0x%02x ",message[i]);
    }
    printf("\n");
    return SUCCESS;
}

int32_t rev_uart_info(int32_t fifo_fd,int32_t fd,shm_safe_data_t *shm_data){
    int32_t ret=FAILD;
    int32_t shm_flag=SHM_NO_RESPONSE_FLAG,n_byte;
    uart_signal_head_t info;
    uint8_t *rev_msg=NULL;
    uint32_t rev_count=0,data_len;
    uint32_t flag=0;

    memcpy(&flag,shm_data->shm_data+UART_FLAG_SIZE,sizeof(uint32_t));


    ret = libso_call_uart_start(so_uart,"rev_uart_start",fd);
    printf("rev_uart_start ret=%d\n",ret);
    if(ret == SUCCESS){
        if(flag == UART_SPACE_GETINFO_POLICY){
            ret = libso_call_uart_message(so_uart,"uart_recv",fd, (uint8_t *)&info,sizeof(uart_signal_head_t));
            printf("uart_recv ret=%d\n",ret);
            if(ret > 0){
                data_len = info.size+BCC_SIZE+sizeof(uart_signal_head_t);
                rev_msg = malloc(data_len);
                memcpy(rev_msg,&info,sizeof(uart_signal_head_t));
                ret = libso_call_uart_message(so_uart,"uart_recv",fd, rev_msg+sizeof(uart_signal_head_t), info.size+BCC_SIZE);
                printf("libso_call_uart_message uart_recv ret=%d\n",ret);
                LOG_PRINT(DEBUG,rev_msg,data_len,"safe rev message:");
                if (ret > 0){
                    memcpy(shm_data->shm_data,rev_msg,data_len);
                    shm_data->shm_len = data_len;
                    LOG_PRINT(DEBUG,rev_msg,data_len,"safe rev message:");
                    shm_data->action_flag = SHM_RESPONSE_FLAG;
                    shm_flag = SHM_RESPONSE_FLAG;

                }else{
                    shm_data->action_flag = SHM_NO_RESPONSE_FLAG;
                    shm_flag = SHM_NO_RESPONSE_FLAG;
                }
                free(rev_msg);
            }else{
                shm_data->action_flag = SHM_NO_RESPONSE_FLAG;
                shm_flag = SHM_NO_RESPONSE_FLAG;
            }
        }else if(flag == UART_SPACE_REV_GROUND){
            printf("lkb enterv UART_SPACE_REV_GROUND\n");
            shm_data->shm_len = 0;
            rev_count = 0;
            while((ret = libso_call_uart_message(so_uart,"uart_recv",fd, (uint8_t *)&info,sizeof(uart_signal_head_t))) > 0){
                data_len = info.size+BCC_SIZE+sizeof(uart_signal_head_t);
                rev_msg = malloc(data_len);
                memcpy(rev_msg,&info,sizeof(uart_signal_head_t));
                ret = libso_call_uart_message(so_uart,"uart_recv",fd, rev_msg+sizeof(uart_signal_head_t), info.size+BCC_SIZE);
                if (ret > 0)
                {
                    memcpy(shm_data->shm_data+rev_count,rev_msg,data_len);
                    LOG_PRINT(DEBUG,rev_msg,data_len,"safe rev-cover message:");
                    rev_count+=data_len;
                }
                free(rev_msg);
            }
            if(rev_count > 0){
                shm_data->shm_len = rev_count;
                shm_data->action_flag = SHM_RESPONSE_FLAG;
                shm_flag = SHM_RESPONSE_FLAG;
            }else{
                shm_data->action_flag = SHM_NO_RESPONSE_FLAG;
                shm_flag = SHM_NO_RESPONSE_FLAG;
            }
        }
    }else{
        shm_data->action_flag = SHM_NO_RESPONSE_FLAG;
        shm_flag = SHM_NO_RESPONSE_FLAG;
    }

    n_byte = write(fifo_fd,&shm_flag,sizeof(uint32_t));
    if(n_byte > 0){
        ret = SUCCESS;
    }
    return ret;
}

int uart_open(char *pathname)
{
    int fd;
    assert(pathname); /*�򿪴���*/
    fd = open(pathname,O_RDWR|O_NOCTTY|O_NONBLOCK);
    if(fd == -1)
    {
        perror("Open UART failed!");
        return -1;
    }
    return fd;
}

int fifo_open(char *pathname_read,char *pathname_write, int *fd_read,int *fd_write)
{
    if(mkfifo(pathname_read,S_IFIFO|0666) < 0 && errno != EEXIST)
    {
        fprintf(stderr,"Fail to mkfifo %s : %s.\n",pathname_read,strerror(errno));
        return -1;
    }
    if(mkfifo(pathname_write,S_IFIFO|0666) < 0 && errno != EEXIST)
    {
        fprintf(stderr,"Fail to mkfifo %s : %s.\n",pathname_write,strerror(errno));
        return -1;
    }

    if((*fd_read = open(pathname_read,O_RDONLY)) < 0)
    {
        fprintf(stderr,"Fail to open %s : %s.\n",pathname_read,strerror(errno));
        return -1;
    }
    if((*fd_write = open(pathname_write,O_WRONLY)) < 0)
    {
        fprintf(stderr,"Fail to open %s : %s.\n",pathname_write,strerror(errno));
        return -1;
    }

    return 0;
}

int32_t shm_safe_init(void)
{
    int shm_safe_key;
    int shm_safe_key1;

    shm_safe_key = ftok(PATHNAME, IPC_EXCL);
    shm_safe_key1 = ftok(PATHNAME1, IPC_EXCL);
    printf("shm_safe_init1 shm_safe_key1 =%d shm_safe_key=%d\n",shm_safe_key1,shm_safe_key);
    shmid = shmget(shm_safe_key, sizeof(shm_safe_data_t), SHM_GLOBAL_COUNT_MODE);
    shmid1 = shmget(shm_safe_key1, sizeof(shm_safe_data_t1), SHM_GLOBAL_COUNT_MODE);
    printf("shm_safe_init1 shmid =%d shmid1=%d\n",shmid,shmid1);
    if(shmid < 0)
    {
        printf("ERROR: shm_safe_init: shmget failed. errno=%d.\n", errno);
        return -1;
    }

    if(shmid1 < 0)
     {
         printf("ERROR: shm_safe_init1: shmget1 failed. errno=%d.\n", errno);
         return -1;
     }

    printf("shm_safe_init1 successs =%d shmid=%d\n",shm_safe_key1,shmid1);
    return 0;
}

void *shm_safe_attach(void)
{
    void *shmptr;

    if((shmptr = shmat(shmid, 0, 0)) == (void *)-1)
    {
        printf("ERROR: shm_safe_attach: shmat failed. errno=%d.\n", errno);
        return NULL;
    }
    return shmptr;
}
void *shm_safe_attach1(void){
    void *shmptr1;

    if((shmptr1 = shmat(shmid1, 0, 0)) == (void *)-1)
     {
         printf("ERROR: shm_safe_attach: shmat1 failed. errno=%d.\n", errno);
         return NULL;
     }

    return shmptr1;
}

int32_t shm_safe_release(void)
{
    int ret;

    ret = shmctl(shmid, IPC_RMID, NULL);
    if(ret < 0)
    {
        printf("ERROR: shm_safe_release: shmat failed. errno=%d.\n", errno);
        return -1;
    }

    ret = shmctl(shmid1, IPC_RMID, NULL);
    if(ret < 0)
       {
           printf("ERROR: shm_safe_release: shmat1 failed. errno=%d.\n", errno);
           return -1;
       }
    return 0;
}

int32_t shm_safe_detach(void *shmptr)
{
    if(shmdt(shmptr) == -1)
    {
        printf("ERROR: shm_safe_detach: shmat failed. errno=%d.\n", errno);
        return -1;
    }

    return 0;
}

int32_t shm_safe_detach1(void *shmptr1)
{
if(shmdt(shmptr1) == -1)
{
    printf("ERROR: shm_safe_detach111: shmat1 failed. errno=%d.\n", errno);
    return -1;
}

    return 0;
}
int main (int argc, char **argv)
{
    int32_t ret=SUCCESS;
    uint32_t shm_flag;
    int32_t fd,n_byte;
    int32_t fifo_read,fifo_write;
    uint8_t hmac[HMAC_LEN];
    shm_safe_data_t *shm_data;
    shm_safe_data_t1 *shm_data1;

    fd = uart_open(TRUST_PORT);
    if(fd < 0){
        printf("init_uart_info failed\n");
        return -1;
    }

    so_uart = dlopen("libuart.so", RTLD_GLOBAL);
    if (!so_uart) {
        fprintf(stderr, "%s \n",dlerror());
        return -1;
    }

    libso_call_uart_set(so_uart,"uart_set",fd,115200,0,8,'N',1);

    ret = shm_safe_init();
    if(ret < 0){
        return -1;
    }

    ret = fifo_open(FIFO_READ,FIFO_WRITE,&fifo_read,&fifo_write);
    if(ret < 0){
        printf("fifo_open failed\n");
        return -1;
    }
    while(1)
    {
        n_byte = read(fifo_read,&shm_flag,sizeof(uint32_t));
        printf("shm_flag=%d\n",shm_flag);
        if(n_byte > 0){
            if(shm_flag == 10){
                break;
            }
            printf("before shm_data1\n");
            if(shm_flag==SHM_HEART_BEAT){
            shm_data1 = (shm_safe_data_t1 *)shm_safe_attach1();
            printf("11shm_data1->action_flag=%d\n",shm_data1->action_flag);
            printf("11shm_data1->heart_count=%d\n",shm_data1->heart_count);
                      printf("before shm_safe_detach1\n");
            shm_safe_detach1((void *)shm_data1);
            }
            printf("before shm_data\n");
            shm_data = (shm_safe_data_t *)shm_safe_attach();
            if(shm_data == NULL){
                shm_flag = SHM_NO_RESPONSE_FLAG;
                n_byte = write(fifo_write,&shm_flag,sizeof(uint32_t));
                continue;
            }
            if(shm_flag == SHM_REQUST_FLAG && shm_data->action_flag == SHM_REQUST_FLAG){
                if(shm_data->shm_len > 0){
                    LOG_PRINT(DEBUG,shm_data->shm_data, shm_data->shm_len,"safe send message:");
                    ret = libso_call_uart_message(so_uart,"uart_send",fd, shm_data->shm_data, shm_data->shm_len);
                    printf("libso_call_uart_message ret=%d\n",ret);
                    if (ret < 0)
                    {
                        shm_data->action_flag = SHM_NO_RESPONSE_FLAG;
                        n_byte = write(fifo_write,&shm_data->action_flag,sizeof(uint32_t));
                    }else{
                        printf("lkb safe rev_uart_info\n ");
                        rev_uart_info(fifo_write,fd,shm_data);
                    }
                }else{
                    shm_data->action_flag = SHM_NO_RESPONSE_FLAG;
                    n_byte = write(fifo_write,&shm_data->action_flag,sizeof(uint32_t));
                }
            }else if(shm_flag == SHM_SEND_CREDIBLE && shm_data->action_flag == SHM_SEND_CREDIBLE){
                LOG_PRINT(DEBUG,shm_data->shm_data, shm_data->shm_len,"safe credible data:");
                ret = libso_call_uart_hmac(so_uart,"uart_hmac",fd,shm_data->shm_data, shm_data->shm_len, hmac, HMAC_LEN);
                if (ret >= 0){
                    LOG_PRINT(DEBUG,hmac, HMAC_LEN,"safe hmac:");
                    //hmac��������ң�⣬���͵���
                }
                shm_data->action_flag = SHM_REST_FLAG;
                n_byte = write(fifo_write,&shm_data->action_flag,sizeof(uint32_t));
            }
            printf("before shm_safe_detach shm_data\n");
            shm_safe_detach((void *)shm_data);
        }
    }

    ret = shm_safe_release();
    if(ret < 0){
        return -1;
    }

    assert(fd);
    close(fd);
    close(fifo_read);
    close(fifo_write);
    dlclose(so_uart);
    return ret;
}
