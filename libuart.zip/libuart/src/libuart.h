#ifndef  _LIBUSART_H
#define  _LIBUSART_H
#include "hash.h"

#define UART_FLAG_SIZE 2
#define BCC_SIZE 2
#define SEND_CONTROL_SIZE 8
#define SEND_LEN_SIZE 2
#define NUMBER_SIZE 4
#define TIMER_SIZE 6

#define FAILD -1
#define SUCCESS 0

typedef struct uart_credible {
    uint8_t reserve[RANDOM_SIZE-NUMBER_SIZE];
    uint8_t number[NUMBER_SIZE];
    uint8_t random[RANDOM_SIZE];
    uint8_t key[HMAC_KEY_SIZE];
}uart_credible_t;

int uart_set(int fd,int baude,int c_flow,int bits,char parity,int stop);
int uart_send(int fd,uint8_t *w_buf,uint32_t len);
int uart_recv(int fd,uint8_t *r_buf,uint32_t len);
int32_t uart_hmac(int fd,uint8_t *message,uint32_t len, uint8_t *hmac,uint32_t hmac_len);
#endif
