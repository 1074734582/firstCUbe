/*
 * hash.h
 *
 *  Created on: Jun 5, 2023
 *      Author: lidp
 */

#ifndef __HASH_H__
#define __HASH_H__

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define ROTL(x,y)    ((((x)<<(y&(32-1))) | ((x)>>(32-(y&(32-1))))) & 0xffffffff)
#define HTOL(a) ((a&0x000000ff)<<24) | ((a&0x0000ff00)<< 8) | ((a&0x00ff0000)>>8) | ((a&0xff000000)>>24)

typedef struct sm3_ctx
{
    uint32_t h[8];
    uint8_t bb[64];
    uint64_t len;
} sm3_ctx_t;

#define HMAC_KEY_SIZE 64
#define HASH_SIZE 32
#define RANDOM_SIZE 16

int32_t sm3_final(struct sm3_ctx *ctx, uint8_t *hash);
int32_t sm3_update(struct sm3_ctx *ctx, const uint8_t *in, uint32_t inlen);
int32_t sm3_init(struct sm3_ctx *ctx, const uint8_t *in, uint32_t inlen);
int32_t sm3(const uint8_t *in, uint32_t inlen, uint8_t *hash);
int32_t sm3_hmac(const uint8_t *data, uint32_t len, const uint8_t *key, uint32_t len_key, uint8_t *out) ;
#endif


