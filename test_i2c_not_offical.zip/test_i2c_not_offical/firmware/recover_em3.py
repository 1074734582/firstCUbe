import re, hashlib

with open(r'z:\ccrc\test_i2c_not_offical\firmware\source\app\rsa_test_vectors.h', 'r', encoding='utf-8-sig') as f:
    src = f.read()

def extract_array(name):
    m = re.search(rf'static const uint8_t {name}\[\d+\] = \{{([^}}]+)\}};', src)
    vals = re.findall(r'0x([0-9A-Fa-f]+)', m.group(1))
    return bytes(int(v,16) for v in vals)

N = extract_array('TEST_N_256')
D = extract_array('TEST_D_256')
N_int = int.from_bytes(N, 'big')
D_int = int.from_bytes(D, 'big')
E_int = 65537

SHA256_TLV = bytes.fromhex('3031300D060960864801650304020105000420')

def pkcs1v15_pad(digest_bytes):
    assert len(digest_bytes) == 32
    em = bytearray(256)
    em[0]=0x00; em[1]=0x01
    for i in range(2, 2+202): em[i]=0xFF
    em[2+202]=0x00
    em[2+203:2+203+19] = SHA256_TLV
    em[2+203+19:2+203+19+32] = digest_bytes
    return bytes(em)

# ====== 原始数据 ======
msg = bytes(range(256))          # 0x00..0xFF
msg_rev = msg[::-1]              # 0xFF..0x00
zero = b'\x00' * 256
zero_rev = zero[::-1]            # 还是零

# ====== 已恢复的 HW sig 和 EM ======
hw_ramp_sig_hex = (
    '60ACE48DB52B45D3A645EA374B1218D9BDCA70F15E51FA69AB2683C295FD0376'
    'DDB492F57C107C8E8337AE9688B21B6BBB885E876C125C7FB702CAF6871B5E84'
    '983CBDE7DB62167DA7DC8F6481299276BF4FE4A4ABFC7FA24E4AEA638E37CF96'
    '64BF9C3D72213CE6166C22B3E41C0B93C13045D7F0CB12E2DCA7BB6269107CBA'
    '73BA2E3EECBD5F8AD8CE711D1D2E3EE3F32590A520B1AB4C44344F448B41761D'
    'BB5E9D39C380597A58349FA371B67428E8873D8734869541EDD6F97B0B9E0FCF'
    'A2E4D03AED719C0FD4D78D3D9A8F33E5673F6142FB156E517D839C836B17A421'
    '86700D983BFFA97DD9BD7544E39622D6D6273FD5D255AA2FD748889350EDFE49'
)
hw_zero_sig_hex = (
    'BF92E42B528B726F9DB3A43119C9A334B5D5FB6B7FEEB514F2A680E93ADD6297'
    'DABC0046D0FFEAD85C63D73ADE6A99A64BF8DA63F65BF1BD6D02E3CE2B378F40'
    'F0645070A77BFB14E1BA3B097B703252A4CB57E77EB318714620CAC69BBA700C'
    '9519DE882C8E432A7B2DAB59CB0A90E4F01D5E9463025E37232A0360A6641681'
    '1E4F3946DAD8B0D50D10E4E7CA786062A6FAFE08562D2E9DB5FA2B8AE392E101'
    'CBAFC28EBC6BA256716207EEE2343023F6BCCDF8C4A14A57208FE1BCB098DBAD'
    'FFECCCD2586D56BAA806D0B91ACF1045677799D58BE4C01C2E9BF22C6C397C12'
    '853AFA4BAA5E3E69BD88BA2B180B86C30CFAABFF7D546098CE9E6962DF288640'
)
sig_ramp = bytes.fromhex(hw_ramp_sig_hex)
sig_zero = bytes.fromhex(hw_zero_sig_hex)

print("===== Hypothesis: PADDING_EN=1 跳过 SHA-256, 直接用 msg 尾部 32B 当 digest =====")

# msg_rev 尾部 32B = 0xFF,0xFE,...,0xE0  (因为 256-32=224, msg_rev[224]=0xFF-224=0x1F, msg_rev[255]=0xFF-255=0x00)
ramp_digest_tail = msg_rev[224:256]  # = 0x1F, 0x1E, ..., 0x00
zero_digest_tail = zero_rev[224:256] # = 0x00 * 32

print(f'msg_rev[224:256] = {ramp_digest_tail.hex().upper()}')
print(f'zero_rev[224:256] = {zero_digest_tail.hex().upper()}')

# 如果硬件用这个当 digest + pkcs1v15 padding
em_ramp_tail = pkcs1v15_pad(ramp_digest_tail)
em_zero_tail = pkcs1v15_pad(zero_digest_tail)
sig_ramp_tail = pow(int.from_bytes(em_ramp_tail,'big'), D_int, N_int).to_bytes(256,'big')
sig_zero_tail = pow(int.from_bytes(em_zero_tail,'big'), D_int, N_int).to_bytes(256,'big')

print(f'\n如果用 msg_tail_32B 当 digest + pkcs1v15:')
print(f'  sig_ramp head  = {sig_ramp_tail[:8].hex().upper()} (HW: {sig_ramp[:8].hex().upper()})')
print(f'  sig_zero head  = {sig_zero_tail[:8].hex().upper()} (HW: {sig_zero[:8].hex().upper()})')
print(f'  match ramp? {sig_ramp_tail == sig_ramp}')
print(f'  match zero? {sig_zero_tail == sig_zero}')

# 如果硬件用 msg (big-endian) 尾部 32B 当 digest
ramp_digest_msg_tail = msg[224:256]  # = 0xE0, ..., 0xFF
em2 = pkcs1v15_pad(ramp_digest_msg_tail)
sig2 = pow(int.from_bytes(em2,'big'), D_int, N_int).to_bytes(256,'big')
print(f'\n如果用 msg(big-endian)[224:256] 当 digest:')
print(f'  sig head = {sig2[:8].hex().upper()}')

# ====== Hypothesis 2: 硬件 SHA-256 输入偏移不对 ======
# SHA-256 块可能从 IFIFO 头部取, 而不是尾部
# SHA256(N_rev) 或 SHA256(N) 或 SHA256(D_rev)
print("\n===== Hypothesis 2: SHA-256 从 IFIFO 头部 256B (N_rev) 取 =====")
N_rev = N[::-1]
for name, digest in [
    ('SHA256(N_rev)', hashlib.sha256(N_rev).digest()),
    ('SHA256(N)', hashlib.sha256(N).digest()),
    ('SHA256(D_rev)', hashlib.sha256(D[::-1]).digest()),
    ('SHA256(D)', hashlib.sha256(D).digest()),
    ('SHA256(msg_rev)', hashlib.sha256(msg_rev).digest()),
    ('SHA256(msg)', hashlib.sha256(msg).digest()),
]:
    em = pkcs1v15_pad(digest)
    sig = pow(int.from_bytes(em,'big'), D_int, N_int).to_bytes(256,'big')
    match_ramp = (sig == sig_ramp)
    match_zero = (sig == sig_zero)
    mtag = ' RAMP!' if match_ramp else (' ZERO!' if match_zero else '')
    print(f'  {name:20s} -> sig head {sig[:8].hex().upper()}{mtag}')

# ====== Hypothesis 3: 硬件 SHA-256 取前 256B (N_rev) 但只取前 PKG_LEN 字节 ======
# 这应该等于 SHA256(N_rev) 因为 PKG_LEN=256
# 但如果 SHA-256 块从 IFIFO offset 0 取 PKG_LEN=256B = N_rev -> 已经测过

# ====== Hypothesis 4: SHA-256 块取 D (中间 256B) ======
# 已测, SHA256(D_rev) 和 SHA256(D) 都不匹配

# ====== Hypothesis 5: 硬件不做 pkcs1v15, 直接 SHA256(msg) 当 EM ======
# 如果 padding 块有 bug, SHA-256 块输出 digest 后 padding 块没工作, 
# EM = digest (32B) + 填充? 或者 EM 就是原始 msg?
print("\n===== Hypothesis 5: 硬件不做 pkcs1v15, SHA-256 块正确 =====")
# EM 可能是 SHA256(msg_rev) 放在某个位置
# 或者 EM = SHA256(msg) + zero-pad to 256?
# 如果 EM 是 raw SHA-256 digest (放在高 32B, 其他清零)
digest_ramp_correct = hashlib.sha256(msg).digest()
em_raw = bytearray(256)
em_raw[224:256] = digest_ramp_correct
sig_raw = pow(int.from_bytes(em_raw,'big'), D_int, N_int).to_bytes(256,'big')
print(f'EM = correct_SHA256(msg) @ offset 224, rest zero -> sig head {sig_raw[:8].hex().upper()} (HW: {sig_ramp[:8].hex().upper()})')

# 如果 EM 是 SHA256(msg_rev) @ offset 0
digest_ramp_rev = hashlib.sha256(msg_rev).digest()
em_raw2 = bytearray(256)
em_raw2[0:32] = digest_ramp_rev
sig_raw2 = pow(int.from_bytes(em_raw2,'big'), D_int, N_int).to_bytes(256,'big')
print(f'EM = SHA256(msg_rev) @ offset 0, rest zero -> sig head {sig_raw2[:8].hex().upper()}')

# ====== 更极端的想法: 硬件 EM 根本不是我们想的那种格式 ======
# 让我看 HW EM 和 TEST_EM_256 有没有什么结构相似性
TEST_EM_256 = extract_array('TEST_EM_256')
print("\n===== HW EM vs TEST_EM_256 结构对比 =====")
print(f'TEST_EM_256[0..1] = 0x{TEST_EM_256[0]:02X} 0x{TEST_EM_256[1]:02X} (expect 00 01)')
print(f'HW EM_ramp[0..1]  = 0x{EM_ramp[0]:02X} 0x{EM_ramp[1]:02X}')
print(f'HW EM_zero[0..1]  = 0x{EM_zero[0]:02X} 0x{EM_zero[1]:02X}')
print()
print(f'TEST_EM_256[203]  = 0x{TEST_EM_256[203]:02X} (separator 0x00)')
print(f'HW EM_ramp[203]   = 0x{EM_ramp[203]:02X}')
print(f'HW EM_zero[203]   = 0x{EM_zero[203]:02X}')
print()
print(f'TEST_EM_256[204:223] = {TEST_EM_256[204:223].hex().upper()} (SHA256 TLV)')
print(f'HW EM_ramp[204:223]  = {EM_ramp[204:223].hex().upper()}')
print(f'HW EM_zero[204:223]  = {EM_zero[204:223].hex().upper()}')
print()
print(f'TEST_EM_256[224:256] = {TEST_EM_256[224:256].hex().upper()} (digest)')
print(f'HW EM_ramp[224:256]  = {EM_ramp[224:256].hex().upper()}')
print(f'HW EM_zero[224:256]  = {EM_zero[224:256].hex().upper()}')

# 更有希望的假设: 硬件 EM 就是 SHA-256 块输出的 digest 放在 offset 0 (或其他位置)
# 整体 padding 块完全没工作
print("\n===== Hypothesis 6: padding 块完全没工作, EM = SHA256(input) 放在 offset 0 =====")
inputs_all = {
    'msg': msg, 'msg_rev': msg_rev,
    'N': N, 'N_rev': N_rev,
    'D': D, 'D_rev': D[::-1],
}
for name, data in inputs_all.items():
    d = hashlib.sha256(data).digest()
    em_test = bytearray(256)
    em_test[0:32] = d
    sig_test = pow(int.from_bytes(bytes(em_test),'big'), D_int, N_int).to_bytes(256,'big')
    if sig_test == sig_ramp:
        print(f'  MATCH RAMP! SHA256({name}) @ offset 0, rest zero')
    if sig_test == sig_zero:
        print(f'  MATCH ZERO! SHA256({name}) @ offset 0, rest zero')
    # 也试 offset 224
    em_test2 = bytearray(256)
    em_test2[224:256] = d
    sig_test2 = pow(int.from_bytes(bytes(em_test2),'big'), D_int, N_int).to_bytes(256,'big')
    if sig_test2 == sig_ramp:
        print(f'  MATCH RAMP! SHA256({name}) @ offset 224, rest zero')
    if sig_test2 == sig_zero:
        print(f'  MATCH ZERO! SHA256({name}) @ offset 224, rest zero')
