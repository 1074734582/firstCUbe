
#include "rsp_hal_misc.h"
#include "rsp_hal_uart.h"

void rsp_hal_uart_init(rsp_uart_t* uart, rsp_uart_param_t* param)
{
    uint32_t baud = 0;
	
    /* Check parameters */
	
    baud = HSE_VALUE / param->baudrate / 16;     
	//baud = HSE_VALUE / param->baudrate / 16;

    uart->LCR |= UART_LCR_DLAB; /* Enable write DLH/DLL */
    uart->RBR_THR_DLL = baud & 0xff;
    uart->IER_DLH = (baud >> 8) & 0xff;	
    uart->LCR &= ~UART_LCR_DLAB; /* Disable write DLH/DLL */
	
    uart->LCR &= ~UART_LCR_DATA_BITS_MASK;
    uart->LCR |= param->databits;
	
    uart->LCR &= ~UART_LCR_STOP_BITS_MASK;
    uart->LCR |= param->stopbits;

    uart->LCR &= ~UART_LCR_PARITY_MASK;
    uart->LCR |= param->parity;
}

// void rsp_hal_uart_enable_interrupt(rsp_uart_t* uart, uint32_t flag)
// {
//     uart->IER_DLH |= flag;
// }

// void rsp_hal_uart_disable_interrupt(rsp_uart_t* uart, uint32_t flag)
// {
//     uart->IER_DLH &= ~flag;
// }

/*void rsp_hal_uart_enable_fifo(rsp_uart_t* uart)
{
    uart->FCR_IIR |= 0x1;
}*/

void rsp_hal_uart_send_data(rsp_uart_t* uart, uint32_t data)
{
    /* Wait transmitter fifo empty */
    while ((uart->LSR & UART_LSR_TEMT) == 0);
	  /* Write data */
    uart->RBR_THR_DLL = (data & 0xff);
}

RAMFUNC void rsp_hal_uart_send_data_ramfunc(rsp_uart_t* uart, uint32_t data)
{
    /* Wait transmitter fifo empty */
    while ((uart->LSR & UART_LSR_TEMT) == 0);
	  /* Write data */
    uart->RBR_THR_DLL = (data & 0xff);
}

uint32_t rsp_hal_uart_recv_data(rsp_uart_t* uart)
{
    /* Wait data ready */
    while (!(uart->LSR & UART_LSR_DR));
    /* Read data */
    return (uart->RBR_THR_DLL & 0xff);    
}

void rsp_hal_uart_recv_data_pqc(rsp_uart_t* uart,uint8_t *data, uint32_t size)
{
    uint32_t i;
    for(i = 0; i < size; i++)
    {
        data[i] = rsp_hal_uart_recv_data(uart);
    }
    return;
}

void rsp_hal_uart_send_data_pqc(rsp_uart_t* uart, uint8_t *data, uint32_t size)
{
    uint32_t i;
    for(i = 0; i < size; i++)
    {
        rsp_hal_uart_send_data(uart, data[i]);
    }
}

