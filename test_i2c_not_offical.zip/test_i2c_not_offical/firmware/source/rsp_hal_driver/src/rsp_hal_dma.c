/**
 ******************************************************************************
 * @file    rsp_hal_dma.c
 * @brief
 ******************************************************************************
 **/
#include "rsp_hal.h"
#include <stdio.h>

#define POW2(n) (1U << (n))
int rsp_hal_dma_enable_ch(int ch)
{
    uint32_t stat;

    DMA->DMA_CFG_L_REG = 0x1; // enable dma
    stat = DMA->DMA_CHAN_EN_L_REG;
    if ((stat & (1 << ch)) != 0)
    {
        printf("dma ch busy\n");
        return -1;
    }
    return 0;
}
// 封装的DMA传输函数(支持多次调用)
int dma_transfer(rsp_dma_transmit_t *ctx, uint32_t src, uint32_t dst, uint32_t size)
{
    uint32_t ch = ctx->ch_x;
        // 等待通道空闲
        while ((DMA->DMA_CHAN_EN_L_REG & (1 << ch)) != 0)
    {
        // 添加小延迟防止死循环
        for (volatile int i = 0; i < 100; i++)
            ;
    }

    // 清除所有DMA状态标志
    DMA->DMA_CLRAR_BLOCK_L_REG = 0xff;
    DMA->DMA_CLRAR_SRCTRAN_L_REG = 0xff;
    DMA->DMA_CLRAR_DSTRAN_L_REG = 0xff;
    DMA->DMA_CLRAR_ERR_L_REG = 0xff;

    // 确保通道被禁用
    DMA->DMA_CHAN_EN_L_REG &= ~((1 << (8 + ch)) | (1 << ch));

    // 等待状态稳定
    // for (volatile int i = 0; i < 5; i++)
    // 	;
    int ret = rsp_hal_dma_data_transmit(ctx, src, dst, size);
    rsp_hal_dma_start(ctx);
    rsp_hal_dma_done(ctx);
    return ret;
}

// DMA读取函数(从设备内存读取到本地缓冲区)
int rsp_hal_dma_read(rsp_dma_transmit_t *ctx, uint32_t src, uint32_t dst, uint32_t size)
{
    uint32_t ch = ctx->ch_x;

    // 等待通道空闲
    while ((DMA->DMA_CHAN_EN_L_REG & (1 << ch)) != 0)
    {
        for (volatile int i = 0; i < 100; i++)
            ;
    }

    // 清除所有DMA状态标志
    DMA->DMA_CLRAR_BLOCK_L_REG = 0xff;
    DMA->DMA_CLRAR_SRCTRAN_L_REG = 0xff;
    DMA->DMA_CLRAR_DSTRAN_L_REG = 0xff;
    DMA->DMA_CLRAR_ERR_L_REG = 0xff;

    // 确保通道被禁用
    DMA->DMA_CHAN_EN_L_REG &= ~((1 << (8 + ch)) | (1 << ch));

    // 等待状态稳定
    // for (volatile int i = 0; i < 20; i++)
    // 	;

    int ret = rsp_hal_dma_data_transmit(ctx, src, dst, size);
    rsp_hal_dma_start(ctx);
    rsp_hal_dma_done(ctx);
    return ret;
}

// 批量DMA传输函数
int dma_transfer_batch(rsp_dma_transmit_t *ctx, dma_transfer_t *transfers, int count)
{
    for (int i = 0; i < count; i++)
    {
        int ret = dma_transfer(ctx, transfers[i].src_addr, transfers[i].dst_addr, transfers[i].size);
        if (ret != 0)
        {
            printf("DMA transfer %d failed\n", i);
            return ret;
        }
    }
    return 0;
}
void rsp_hal_dma_disable_interupt()
{
    DMA->DMA_CLRAR_BLOCK_L_REG = 0xff;
    DMA->DMA_CLRAR_SRCTRAN_L_REG = 0xff;
    DMA->DMA_CLRAR_DSTRAN_L_REG = 0xff;
    DMA->DMA_CLRAR_ERR_L_REG = 0xff;
}

int rsp_hal_dma_init(rsp_dma_transmit_t *ctx, uint32_t ch, uint32_t trans_mode, int width_s, int width_d, uint32_t msize, uint8_t addrdir_s, uint8_t addrdir_d, uint8_t src_handshark, uint8_t dst_handshark, uint8_t src_req, uint8_t dst_req)
{
    int ret = 0;
    ctx->width_s = width_s;
    ctx->width_d = width_d;
    ctx->ch_x = ch;
    ctx->limit_brust = 0;
    ctx->msize = msize;
    ctx->addrdir_s = addrdir_s;
    ctx->addrdir_d = addrdir_d;
    ctx->trans_mode = trans_mode;

    ctx->handshark_softsrc = src_handshark;
    ctx->handshark_softdst = dst_handshark;
    ctx->src_req_hard = src_req;
    ctx->dst_req_hard = dst_req;
    ret = rsp_hal_dma_enable_ch(ch);

    rsp_hal_dma_disable_interupt();
    return ret;
}

int rsp_hal_dma_data_transmit(rsp_dma_transmit_t *ctx, uint32_t srcaddr, uint32_t dstaddr, uint32_t size)
{
    // uint32_t s_byte = pow(2,ctx->width_s);
    // uint32_t d_byte = pow(2,ctx->width_d);
    uint32_t s_byte = 1 << ctx->width_s;
    uint32_t d_byte = 1 << ctx->width_d;

    uint32_t dma_cnt = size / s_byte;
    uint32_t ch = ctx->ch_x;

    //    printf("srcaddr = %x, dstaddr =%x, s_byte = %d\n",srcaddr, dstaddr,s_byte);

    if (srcaddr % s_byte != 0 || dstaddr % d_byte != 0 || size % s_byte != 0 || size % d_byte != 0)
    {
        printf("data len no alian error\n");
        return -1;
    }

    // DMA->dma_channel[ch].DMA_CHANNEL_CFG_H_REG =  (0
    //         | (7 << _HI(43)) // DST_PER  ,ignored when #10 is 1
    //         | (0 << _HI(39)) // SRC_PER ignored when #11 is 1
    //         | (1 << _HI(34)) // protctl
    //         | (1 << _HI(33)) // FIFO-MODE: 0  1:data
    //         | (0 << _HI(32))); //Flow-Control-Mode: 0:src-pre-fetch enable 1:src-pre-fetch-disable,wait request

    // DMA->dma_channel[ch].DMA_CHANNEL_CFG_H_REG =  (0
    //     | (7 << _HI(43)) // DST_PER  ,ignored when #10 is 1
    //     | (0 << _HI(39)) // SRC_PER ignored when #11 is 1
    //     | (0 << _HI(34)) // protctl
    //     | (1 << _HI(33)) // FIFO-MODE: 0  1:data
    //     | (1 << _HI(32))); //Flow-Control-Mode: 0:src-pre-fetch enable 1:src-pre-fetch-disable,wait request

    DMA->dma_channel[ch].DMA_CHANNEL_CFG_H_REG = (0 | (ctx->dst_req_hard << _HI(43)) // DST_PER  ,ignored when #10 is 1
                                                  | (ctx->src_req_hard << _HI(39))   // SRC_PER ignored when #11 is 1
                                                  | (1 << _HI(34))                   // protctl
                                                  | (1 << _HI(33))                   // FIFO-MODE: 0  1:data
                                                  | (0 << _HI(32)));                 // Flow-Control-Mode: 0:src-pre-fetch enable 1:src-pre-fetch-disable,wait request

    DMA->dma_channel[ch].DMA_CHANNEL_CFG_L_REG = (0 | (ctx->limit_brust << 20) /// max_abrst
                                                  // | (1 << 19) // src_hs_pol
                                                  // | (1 << 9 ) //  R: only read
                                                  | (ctx->handshark_softsrc << 11)   // HS_SEL_SRC Handshack is software(1) hard-0 soft-1
                                                  | (ctx->handshark_softdst << 10)); // HS_SEL_DST Handack is software(1)

    DMA->dma_channel[ch].DMA_CHANNEL_CTL_H_REG = dma_cnt << _HI(32);
    //   DMA->dma_channel[ch].DMA_CHANNEL_CTL_L_REG = ( (TT_M2M_DFC <<20)
    //         | (ctx->msize << 14) // src-bst item cnt
    //         | (ctx->msize << 11) // dst-bst item cnt
    //         | (ctx->addrdir_s << 9) // saddr no change
    //         | (ctx->addrdir_d << 7) // daddr inc
    //         | (ctx->width_s << 4) // Src Transfer Width
    //         | (ctx->width_d << 1) // Dst Transfer Width
    //         | (1 << 0) //enable disable-irq
    //         );
    //   DMA->dma_channel[ch].DMA_CHANNEL_CTL_L_REG = ( (TT_M2P_DFC <<20)
    //         | (ctx->msize << 14) // src-bst item cnt
    //         | (ctx->msize << 11) // dst-bst item cnt
    //         | (ctx->addrdir_s << 9) // saddr no change
    //         | (ctx->addrdir_d << 7) // daddr inc
    //         | (ctx->width_s << 4) // Src Transfer Width
    //         | (ctx->width_d << 1) // Dst Transfer Width
    //         // | (1 << 0) //enable disable-irq
    //         );

    DMA->dma_channel[ch].DMA_CHANNEL_CTL_L_REG = ((ctx->trans_mode << 20) | (ctx->msize << 14) // src-bst item cnt
                                                  | (ctx->msize << 11)                         // dst-bst item cnt
                                                  | (ctx->addrdir_s << 9)                      // saddr no change
                                                  | (ctx->addrdir_d << 7)                      // daddr inc
                                                  | (ctx->width_s << 4)                        // Src Transfer Width
                                                  | (ctx->width_d << 1)                        // Dst Transfer Width
                                                  // | (1 << 0) //enable disable-irq
    );
    DMA->dma_channel[ch].DMA_CHANNEL_SAR_L_REG = srcaddr;
    DMA->dma_channel[ch].DMA_CHANNEL_DAR_L_REG = dstaddr;

    //  DMA->DMA_CHAN_EN_L_REG |= (1 << (8 + ch)) | (1<<ch);

    //  while((DMA->DMA_CHAN_EN_L_REG & (1<<ch)) != 0);
    return 0;
}

int rsp_hal_dma_start(rsp_dma_transmit_t *ctx)
{
    int ch = ctx->ch_x;
    DMA->DMA_CHAN_EN_L_REG |= (1 << (8 + ch)) | (1 << ch);
    return 0;
}

int rsp_hal_dma_done(rsp_dma_transmit_t *ctx)
{
    int ch = ctx->ch_x;
    while ((DMA->DMA_CHAN_EN_L_REG & (1 << ch)) != 0)
        ;
    return 0;
}

int rsp_hal_dma_stop(rsp_dma_transmit_t *ctx)
{
    int ch = ctx->ch_x;
    DMA->DMA_CHAN_EN_L_REG &= ~(1 << (8 + ch));
    return 0;
}

// int rsp_hal_dma_data_transmit_irq(rsp_dma_transmit_t *ctx)
// {
//     uint32_t ch = ctx->ch_x;
//     DMA->DMA_MASK_DSTRAN_L_REG  = (1<<(ch+8))|(1<<ch);
// }

/********dmax**********/

int rsp_hal_dmax_enable_ch(int ch)
{
    uint32_t stat;


    // enable dma
    DMAX->DMACX_CFG_L_REG = 0x1;

    stat = DMAX->DMACX_CHENA_L_REG;
    if ((stat & (1 << ch)) != 0)
    {
        printf("dma ch busy\n");
        return -1;
    }

    return 0;
}

int rsp_hal_dmax_init(rsp_dma_transmit_t *ctx, uint32_t ch, int width_s, int width_d, uint32_t msize, uint32_t trans_mode, uint8_t addrdir_s, uint8_t addrdir_d)
{
    int ret = 0;
    ctx->width_s = width_s;
    ctx->width_d = width_d;
    ctx->ch_x = ch;
    ctx->limit_brust = 3;
    ctx->burst_enable = 1;
    ctx->trans_mode = trans_mode;
    ctx->msize = msize;
    ctx->addrdir_s = addrdir_s;
    ctx->addrdir_d = addrdir_d;

    ret = rsp_hal_dmax_enable_ch(ch);
    return ret;
}

int rsp_hal_dmax_data_prepare(rsp_dma_transmit_t *ctx, uint32_t srcaddr, uint32_t dstaddr, uint32_t size)
{
    uint32_t s_byte = (1u << ctx->width_s);
    uint32_t d_byte = (1u << ctx->width_d);

    uint32_t dma_cnt = size / s_byte;
    uint32_t ch = ctx->ch_x;

    if (srcaddr % s_byte != 0 || dstaddr % d_byte != 0 || size % s_byte != 0 || size % d_byte != 0)
    {
        printf("data len no alian error\n");
        return -1;
    }

    DMAX->dmax_channel[ch].DMACX_CFG_H_REG = (0 | (16 << _HI(59))            /// Destination Outstanding Request Limit TODO
                                              | (16 << _HI(55))              /// Source Outstanding Request Limit TODO
                                              | (0 << _HI(49))               // Channel Priority
                                              | (0 << _HI(44))               // DST_PER  ,it was ignored  when HS_SEL_DST field is 1
                                              | (0 << _HI(39))               // SRC_PER  ,it was ignored  when HS_SEL_SRC field is 1
                                              | (1 << _HI(36))               // Destination Software or Hardware Handshaking Select.1:software 0:hardware
                                              | (1 << _HI(35))               // Source Software or Hardware Handshaking Select. 1:software 0:hardware
                                              | (ctx->trans_mode << _HI(32)) // 0x0:MEM2MEM 0x1:MEM2PER 0x2:PER2MEM 0x3:PER2PER 0x4:PER_TO_MEM_SRC 0x5:PER_TO_PER_SRC 0x6:MEM_TO_PER_DST 0x7:PER_TO_PER_DST
    );
    DMAX->dmax_channel[ch].DMACX_CFG_L_REG = 0;
    DMAX->dmax_channel[ch].DMACX_BLOCK_TS_L_REG = dma_cnt - 1; // zwd

    DMAX->dmax_channel[ch].DMACX_CTL_H_REG = (0 | (ctx->limit_brust << _HI(48)) // AWLEN  Destination Burst Length  DMAX_CHx_MAX_AMBA_BURST_LENGTH(in pqc) = 8 ;
                                              | (ctx->burst_enable << _HI(47))  // AWLEN_EN  Destination Burst Length Enable 0:disable 1:enable
                                              | (ctx->limit_brust << _HI(39))   // ARLEN   Source Burst Length ,DMAX_CHx_MAX_AMBA_BURST_LENGTH(in pqc) = 8 .
                                              | (ctx->burst_enable << _HI(38))  // ARLEN_EN Source Burst Length Enable
    );

    DMAX->dmax_channel[ch].DMACX_CTL_L_REG = (0 | (1 << 30)           // Non Posted Last Write Enable TODO  0:disable 1:enable
                                              | (1 << 26)             // AXI 'aw_cache' signal TODO
                                              | (1 << 22)             // AXI 'ar_cache' signal TODO
                                              | (ctx->msize << 18)    // DST_MSIZE
                                              | (ctx->msize << 14)    // SRC_MSIZE
                                              | (ctx->width_d << 11)  // DST_TR_WIDTH  Destination Transfer Width.
                                              | (ctx->width_s << 8)   // SRC_TR_WIDTH  Source Transfer Width.
                                              | (ctx->addrdir_d << 6) // Destination Address Increment. 0:increment 1: No Change
                                              | (ctx->addrdir_s << 4) // Source Address Increment.      0:increment 1: No Change
                                              | (0 << 2)              // DMS  Destination Master Select. 0: AXI master0 1:AXI master1(only master0 inpqc)
                                              | (0 << 0)              // SMS  Source Master Select.0: AXI master0 1:AXI master1 (only master0 inpqc)
    );

    DMAX->dmax_channel[ch].DMACX_SAR_L_REG = srcaddr;
    DMAX->dmax_channel[ch].DMACX_DAR_L_REG = dstaddr;

    return 0;
}

int rsp_hal_dmax_start(rsp_dma_transmit_t *ctx)

{
    int ch = ctx->ch_x;
    DMAX->DMACX_CHENA_L_REG |= ((1 << (8 + ch)) | (1 << ch));
    return 0;
}

int rsp_hal_dmax_done(rsp_dma_transmit_t *ctx)
{
    return 0;
}

int rsp_hal_dmax_start_done(int ch, uint32_t srcaddr, uint32_t dstaddr)
{
    DMAX->dmax_channel[ch].DMACX_SAR_L_REG = srcaddr;
    DMAX->dmax_channel[ch].DMACX_DAR_L_REG = dstaddr;
    DMAX->DMACX_CHENA_L_REG |= ((1 << (8 + ch)) | (1 << ch));
    while ((DMAX->DMACX_CHENA_L_REG & (1 << ch)) != 0)
        ;
    return 0;
}