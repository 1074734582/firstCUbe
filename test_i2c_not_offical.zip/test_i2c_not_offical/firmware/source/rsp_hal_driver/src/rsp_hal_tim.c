/**
  ******************************************************************************
  * @file    rsp_hal_tim.c
  * @author  Tsinghua University
  * @brief   
  ******************************************************************************
  */

#include "rsp_hal_tim.h"

RAMFUNC void rsp_hal_tim_enable(uint32_t tim)
{
    TIM->CR[tim] = ((TIM->CR[tim] | 0x1) & 0xfffffff3) | 0x4;
}

RAMFUNC void rsp_hal_tim_disable(uint32_t tim)
{
    TIM->CR[tim] &= 0xfffffffe;
}

RAMFUNC void rsp_hal_tim_enable_irq(uint32_t tim)
{	
    TIM->IER[tim] |= 1;
}

RAMFUNC void rsp_hal_tim_disable_irq(uint32_t tim)
{	
    TIM->IER[tim] &= 0xfffffffe;
}

RAMFUNC void rsp_hal_tim_set_load_counter(uint32_t tim, uint32_t value)
{
    TIM->LCR[tim] = value;
}

RAMFUNC void rsp_hal_tim_set_counter(uint32_t tim, uint32_t value)
{
    TIM->CCR[tim] = value;
}

RAMFUNC void rsp_hal_tim_set_div(uint32_t tim, uint32_t value)
{	
    TIM->TCDIV = (TIM->TCDIV & ~(0xf<<(tim<<2))) | ((value&0xf) << (tim<<2));
}

RAMFUNC void rsp_hal_tim_clear_interrupt_flag(uint32_t tim)
{
    TIM->FLAG[tim] = 1;
}

RAMFUNC void rsp_hal_tim_clear_interrupt_status(void)
{
    TIM->TISCR = 1;
}

RAMFUNC uint32_t rsp_hal_tim_get_counter(uint32_t tim)
{
    return TIM->CCR[tim];
}

RAMFUNC uint32_t rsp_hal_tim_get_interrupt_status(uint32_t tim)
{
    return TIM->ISR[tim];
}
