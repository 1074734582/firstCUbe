/**
  ******************************************************************************
  * @file    rsp_hal_nvic.c
  * @author  Tsinghua University
  * @brief   
  ******************************************************************************
  */

#if defined(__ICCARM__)
#include "iccarm_builtin.h"
#endif

#include "rsp_hal_nvic.h"

RAMFUNC void rsp_hal_nvic_enable_irq(uint32_t irq)
{
    NVIC->ISER[irq/32] = (1 << (irq % 32));
}

RAMFUNC void rsp_hal_nvic_disable_irq(uint32_t irq)
{
    NVIC->ICER[irq/32] = (1 << (irq % 32));
}

// void rsp_hal_nvic_set_priority(uint8_t irq, uint8_t priority)
// {
// 		NVIC->IP[irq] = priority;
// }

void rsp_hal_nvic_set_vector(uint32_t addr)
{
    SCB->VTOR  = addr;
}

RAMFUNC void rsp_hal_nvic_enable_all_irq_flag(void)
{
#if defined(__CC_ARM)
    __asm volatile ("cpsie i");
#elif defined(__ICCARM__)
    __iar_builtin_enable_interrupt();
#elif defined(__GNUC__)
    __asm volatile ("cpsie i" : : : "memory");
#endif	
    __asm volatile("cpsie i");
}

RAMFUNC void rsp_hal_nvic_disable_all_irq_flag(void)
{
#if defined(__CC_ARM)
    __asm volatile ("cpsid i");
#elif defined(__ICCARM__)
    __iar_builtin_disable_interrupt();
#elif defined(__GNUC__)
    __asm volatile ("cpsid i" : : : "memory");
#endif	
}
