#include "rsp_hal.h"
#include <stdio.h>

typedef struct {
    uint32_t min_lo_period;
    uint32_t min_hi_period;
} i2c_speed_t;

static i2c_speed_t s_i2c_speed_period[] = {
    {.min_lo_period = 4700, .min_hi_period = 4000},     /**< uint=ns 100Kps */
    {.min_lo_period = 1300, .min_hi_period = 1000},      /**< uint=ns 400Kps */
    {.min_lo_period = 500, .min_hi_period = 260},       /**< uint=ns 1Mbps */
    {.min_lo_period = 120, .min_hi_period = 60},        /**< uint=ns 3.4Mbps bus loading = 100pF */
    {.min_lo_period = 320, .min_hi_period = 160},       /**< uint=ns 3.4Mbps bus loading = 400pF */
};

static rsp_i2c_t *rsp_hal_get_iic_by_port(I2C_NUM_E port)
{
    switch(port)
    {
        case RSP_IIC_0:
            return (rsp_i2c_t *)I2C0;
        case RSP_IIC_1:
            return (rsp_i2c_t *)I2C1;
        default:
            return 0;
    }
}

int rsp_hal_i2c_dw_wait_idle(I2C_NUM_E port, uint32_t timeout)
{
    rsp_i2c_t *i2c = rsp_hal_get_iic_by_port(port);
    uint32_t int_val = 0;
    uint32_t txabrt_val = 0;
    uint32_t us = 0;

    while ((i2c->IC_STATUS & I2C_STATUS_MST_ACTIVITY_MASK))
    {
        // delta_tick = rt_tick_get() - start_tick;
        // us = delta_tick * 1000000 / RT_TICK_PER_SECOND;
        if ( (us)> (timeout))
        {
            int_val = i2c->IC_INTR_STAT;
            txabrt_val = i2c->IC_TX_ABRT_SOURCE;

            printf("i2c wait idle timeout! i2c->IC_STATUS: 0x%x IC_INTR_STAT: 0x%x IC_TX_ABRT_SOURCE: 0x%x\n", (unsigned)i2c->IC_STATUS, (unsigned)int_val, (unsigned)txabrt_val);
            return HAL_ETIME;
        }
    }
    
    return HAL_OK;
}

int rsp_hal_i2c_dw_wait_ic_en(I2C_NUM_E port, uint32_t timeout, uint32_t ic_en)
{
    rsp_i2c_t *i2c = rsp_hal_get_iic_by_port(port);
    uint32_t int_val = 0;
    uint32_t txabrt_val = 0;
    uint32_t us = 0;

    // start_tick = rt_tick_get();
    while ((i2c->IC_ENABLE_STATUS & I2C_ENABLE_ST_EN_MASK) != ic_en)
    {
        // delta_tick = rt_tick_get() - start_tick;
        // us = delta_tick * 1000000 / RT_TICK_PER_SECOND;
        if ( (us)> (timeout))
        {
            int_val = i2c->IC_INTR_STAT;
            txabrt_val = i2c->IC_TX_ABRT_SOURCE;

            printf("i2c wait ic_en timeout! IC_INTR_STAT:0x%x IC_TX_ABRT_SOURCE:0x%x\r\n", (unsigned)int_val, (unsigned)txabrt_val);
            return HAL_ETIME;
        }
    }
    
    return HAL_OK;
}

int rsp_hal_i2c_dw_wait_status(I2C_NUM_E port, uint32_t status, uint32_t timeout)
{
    rsp_i2c_t *i2c = rsp_hal_get_iic_by_port(port);
    uint32_t int_val = 0;
    uint32_t txabrt_val = 0;
    uint32_t us = 0;
    // rt_uint32_t start_tick, delta_tick;

    // start_tick = rt_tick_get();
    while ((i2c->IC_STATUS & status) == 0)
    { 
        // delta_tick = rt_tick_get() - start_tick;
        // us = delta_tick * 1000000 / RT_TICK_PER_SECOND;
        if ( (us)> (timeout))
        {
            int_val = i2c->IC_INTR_STAT;
            txabrt_val = i2c->IC_TX_ABRT_SOURCE;
            (void)int_val;
            (void)txabrt_val;

           // printf("i2c wait status %d timeout! IC_INTR_STAT:0x%x IC_TX_ABRT_SOURCE:0x%x\r\n", status, int_val, txabrt_val);
            return HAL_ETIME;
        }
    } 
    return HAL_OK;
}

/**
 * @brief 
 *
 * @param i2c_handle 
 * @return 
 */
int rsp_hal_i2c_dw_init(i2c_handle_t* i2c_handle)
{
    rsp_i2c_t *i2c = rsp_hal_get_iic_by_port(i2c_handle->port);
    rsp_i2c_param_t* param = i2c_handle->param;
    uint32_t apbclk = 0, speed = 0, addrbits = 0;

    apbclk = (uint32_t)(HSE_VALUE / 1000000);

    if(param->speed == I2C_SPEED_NORMAL_100K)
    {
        speed = I2C_CON_SPEED(1);
    }
    else if(param->speed == I2C_SPEED_FAST_400K || param->speed == I2C_SPEED_FAST_1000K)
    {
        speed = I2C_CON_SPEED(2);
    }
    else
    {
        speed = I2C_CON_SPEED(2);
    }

    if(param->address_bits == I2C_MASTER_ADDRESS_7BIT)
    {
        addrbits = I2C_CON_MASTER_ADDRESS_BIT(0);
    }
    else if(param->address_bits == I2C_MASTER_ADDRESS_10BIT)
    {
        addrbits = I2C_CON_MASTER_ADDRESS_BIT(1);
    }
    else if(param->address_bits == I2C_SLAVE_ADDRESS_10BIT)
    {
        addrbits = I2C_CON_SLAVE_ADDRESS_BIT(1);
    }
    else
    {
        addrbits = I2C_CON_SLAVE_ADDRESS_BIT(0);
    }

	if (rsp_hal_i2c_dw_wait_idle(i2c_handle->port, I2C_DELAY) != HAL_OK)
		return HAL_ETIME;

    i2c->IC_ENABLE = 0;

	if (rsp_hal_i2c_dw_wait_ic_en(i2c_handle->port, I2C_DELAY, 0) != HAL_OK)
		return HAL_ETIME;

    if (param->mode == I2C_MODE_MASTER)
    {
        i2c->IC_CON = I2C_CON_MASTER_EN_MASK 
                    | I2C_CON_SLAVE_DISABLE_MASK 
                    | speed 
                    | addrbits 
                    | I2C_CON_SLAVE_ADDRESS_BIT(0) 
                    | I2C_CON_RESTART_EN_MASK;
		i2c->IC_TAR = param->address;
		i2c->IC_SAR = 0;
		/* Interrupt setup */
		i2c->IC_INTR_MASK = 0;
    }
    else
    {
        i2c->IC_CON = speed 
                    | addrbits 
                    | I2C_CON_SLAVE_ADDRESS_BIT(0) 
                    | I2C_CON_RESTART_EN_MASK;
		i2c->IC_TAR = 0;
		i2c->IC_SAR = param->address;
		/* Interrupt setup */
		i2c->IC_INTR_MASK = 0xff;

		printf("[I2C] SLAVE init: IC_CON=0x%08lx IC_SAR=0x%08lx IC_TAR=0x%08lx\r\n",
		       (unsigned long)i2c->IC_CON,
		       (unsigned long)i2c->IC_SAR,
		       (unsigned long)i2c->IC_TAR);
    }

    /* Clock setup */
    switch (param->speed)
    {
    case I2C_SPEED_NORMAL_100K:
        i2c->IC_SS_SCL_HCNT = (s_i2c_speed_period[param->speed].min_hi_period * apbclk)/1000 + 1;
        i2c->IC_SS_SCL_LCNT = (s_i2c_speed_period[param->speed].min_lo_period * apbclk)/1000 + 1;
        break;
    case I2C_SPEED_FAST_400K:
    case I2C_SPEED_FAST_1000K:
        i2c->IC_FS_SCL_HCNT = (s_i2c_speed_period[param->speed].min_hi_period * apbclk)/1000 - 9;
        i2c->IC_FS_SCL_LCNT = (s_i2c_speed_period[param->speed].min_lo_period * apbclk)/1000 - 1;
        i2c->IC_FS_SPKLEN = 2;
        break;
	// must modify abp clk
    case I2C_SPEED_HIGH_3400K_400PF:
    case I2C_SPEED_HIGH_3400K_100PF:
        i2c->IC_HS_SCL_HCNT = (s_i2c_speed_period[param->speed].min_hi_period * apbclk)/1000 + 1;
        i2c->IC_HS_SCL_LCNT = (s_i2c_speed_period[param->speed].min_lo_period * apbclk)/1000 + 1;
        break;
    }

    i2c->IC_TX_TL = ((i2c->IC_COMP_PARAM_1 >> 16) & 0xff);
    i2c->IC_RX_TL = ((i2c->IC_COMP_PARAM_1 >> 8) & 0xff);
    printf("IC_TX_TL:0x%x IC_RX_TL:0x%x\r\n", (unsigned)i2c->IC_TX_TL, (unsigned)i2c->IC_RX_TL);
    i2c->IC_ACK_GENERAL_CALL = I2C_ACK_GENERAL_CALL(1);

    /* 清所有挂起的中断位, 防止从机启动前 RD_REQ/RX_FULL 残留
     * 导致 DW I2C 接收状态机不 ACK 后续数据字节 */
    i2c->IC_CLR_INTR = 0xFFFF;

    i2c->IC_INTR_MASK = I2C_INTR_RD_REQ_MASK;//不屏蔽


    i2c->IC_ENABLE = (I2C_ENABLE_MASK | I2C_ENABLE_ABORT_MASK);
	if (rsp_hal_i2c_dw_wait_ic_en(i2c_handle->port, I2C_DELAY, 1) != HAL_OK)
		return HAL_ETIME;



	printf("[I2C] SLAVE ENABLE ok: IC_ENABLE=0x%08lx EN_STATUS=0x%08lx\r\n",
	       (unsigned long)i2c->IC_ENABLE,
	       (unsigned long)i2c->IC_ENABLE_STATUS);
	printf("[I2C] IC_STATUS=0x%08lx RAW_INTR=0x%08lx\r\n",
	       (unsigned long)i2c->IC_STATUS,
	       (unsigned long)i2c->IC_RAW_INTR_STAT);

    return HAL_OK;
}

int rsp_hal_i2c_dw_master_transmit(I2C_NUM_E port, uint8_t *data, uint8_t len)
{
    uint32_t tx_fifo_depth, tx_fifo_left = 0;
    rsp_i2c_t *i2c = NULL;
    uint32_t delta_us = 0;
    uint8_t left_len = len;
    uint8_t send_one_time, i = 0;
 
    i2c = rsp_hal_get_iic_by_port(port);
    if (rsp_hal_i2c_dw_wait_idle(port, I2C_DELAY) != HAL_OK)
        return HAL_NOT_EXIST;
    
    tx_fifo_depth = (i2c->IC_COMP_PARAM_1 >> 16) & 0xFF;

    // start_tick = rt_tick_get();
    while(left_len > 0)
    {
        tx_fifo_left = tx_fifo_depth - i2c->IC_TXFLR;
        send_one_time = left_len > tx_fifo_left ? tx_fifo_left : left_len;
        for(i = 0; i < send_one_time; i++)
        {
            if (1 == left_len)
                i2c->IC_DATA_CMD = I2C_DATA_CMD_STOP(1) | I2C_DATA_CMD_CMD(0) | data[len - left_len];
            else
                i2c->IC_DATA_CMD = I2C_DATA_CMD_CMD(0) | data[len - left_len];
            
            left_len--;
        }

        /* wait tx fifo empty */
        if (rsp_hal_i2c_dw_wait_status(port, I2C_STATUS_TFE_MASK, I2C_DELAY) != HAL_OK)
            return HAL_ETIME;

        // delta_us = (rt_tick_get() - start_tick) * 1000000 / RT_TICK_PER_SECOND;
        if (delta_us > I2C_DELAY)
        {
            printf("i2c master transmit timeout! \r\n");
            return HAL_ETIME;
        }
    }

    return left_len;
}

int rsp_hal_i2c_dw_master_receive(I2C_NUM_E port, uint8_t *data, uint8_t len)
{
    uint32_t tx_fifo_depth, tx_fifo_left = 0;
    uint32_t rx_fifo_depth, rx_fifo_left = 0;
    rsp_i2c_t *i2c = NULL;
    uint8_t left_len = len;
    uint8_t send_one_time, i = 0, j =0;
    uint8_t rx_msg_num, index = 0;

    i2c = rsp_hal_get_iic_by_port(port);

    if (rsp_hal_i2c_dw_wait_idle(port, I2C_DELAY) != HAL_OK)
        return HAL_ETIME;

    tx_fifo_depth = (i2c->IC_COMP_PARAM_1 >> 16) & 0xFF;
    rx_fifo_depth = (i2c->IC_COMP_PARAM_1 >> 8) & 0xFF;
    while(left_len > 0)
    {
        tx_fifo_left = tx_fifo_depth - i2c->IC_TXFLR;
        rx_fifo_left = rx_fifo_depth - i2c->IC_RXFLR;

        send_one_time = (tx_fifo_left < rx_fifo_left) ? tx_fifo_left : rx_fifo_left;
        send_one_time = (send_one_time < left_len) ? send_one_time : left_len;
        for(i = 0; i < send_one_time; i++)
        {
            if (1 != left_len)
                i2c->IC_DATA_CMD = I2C_DATA_CMD_CMD(1); // continue acknowledging reads
            else
                i2c->IC_DATA_CMD = I2C_DATA_CMD_STOP(1) | I2C_DATA_CMD_CMD(1);
            
            left_len--;
        }

        for(i = 0; i < send_one_time; )
        {
            rx_msg_num = i2c->IC_RXFLR;
            for ( j = 0; j < rx_msg_num; i++, j ++)
                data[index++] = i2c->IC_DATA_CMD & I2C_DATA_CMD_DAT_MASK;

            // delta_us = (rt_tick_get() - start_tick) * 1000000 / RT_TICK_PER_SECOND;
            // if (delta_us > I2C_DELAY)
            // {
            //     printf("i2c master receive timeout! \r\n");
            //     return HAL_ETIME;
            // }
        }

        // delta_us = (rt_tick_get() - start_tick) * 1000000 / RT_TICK_PER_SECOND;
        // if (delta_us > I2C_DELAY)
        // {
        //     printf("i2c master receive timeout! \r\n");
        //     return HAL_ETIME;
        // }
    }

    return left_len;
}

extern uint32_t g_flag;
int rsp_hal_i2c_dw_slave_transmit(I2C_NUM_E port, uint8_t *data, uint8_t len)
{
    rsp_i2c_t *i2c = rsp_hal_get_iic_by_port(port);
    int i=0;
    int index=0;
    int once=0;
    int fifo_depth = 0;
    int fifo_level = 0;
    volatile int valid;
    uint32_t us = 0;

    // while((i2c->IC_RAW_INTR_STAT&0x20) != 0x20);
    // valid = i2c->IC_CLR_RD_REQ;
    while(g_flag == 0);
    
    fifo_depth = (i2c->IC_COMP_PARAM_1 >> 16) & 0xFF;
    //send data
    while(len > 0)
    {
        fifo_level = i2c->IC_TXFLR;
        valid = fifo_depth-fifo_level;
        once = len > valid? valid : len;
        for(i=0; i< once; i++)
            i2c->IC_DATA_CMD = I2C_DATA_CMD_CMD(0)|data[index++];
        len -= once;
        
        if(once == 0)
        {
            // delta_tick = rt_tick_get() - start_tick;
            // us = delta_tick * 1000000 / RT_TICK_PER_SECOND;
            if ( (us)> (I2C_DELAY))
            {
                us = i2c->IC_INTR_STAT;
                us = i2c->IC_TX_ABRT_SOURCE;
                printf("rsp_hal_i2c_dw_wait_idle timeout! \r\n");
                return HAL_ETIME;
            }
        }
    }
    
    // printf("rsp_hal_i2c_dw_slave_transmit\n");

    g_flag = 0;
    /* Wait TX fifo empty */
    if (rsp_hal_i2c_dw_wait_status(port, I2C_STATUS_TFE_MASK, I2C_DELAY) != HAL_OK)
        return HAL_ETIME;

    return i;
}

#if 1
int rsp_hal_i2c_dw_slave_transmit_ok(I2C_NUM_E port, uint8_t *data, uint8_t len)
{
    rsp_i2c_t *i2c = rsp_hal_get_iic_by_port(port);
    int i=0;
    int index=0;
    int once=0;
    int fifo_depth = 0;
    int fifo_level = 0;
    volatile int valid;
    uint32_t us=0;

    // start_tick = rt_tick_get();
    while((i2c->IC_RAW_INTR_STAT&0x20) != 0x20);
    
    valid = i2c->IC_CLR_RD_REQ;
    
    fifo_depth = (i2c->IC_COMP_PARAM_1 >> 16) & 0xFF;
    //send data
    while(len > 0)
    {
        fifo_level = i2c->IC_TXFLR;
        valid = fifo_depth-fifo_level;
        once = len > valid? valid : len;
        for(i=0; i< once; i++)
            i2c->IC_DATA_CMD = I2C_DATA_CMD_CMD(0)|data[index++];
        len -= once;
        
        if(once == 0)
        {
            // delta_tick = rt_tick_get() - start_tick;
            // us = delta_tick * 1000000 / RT_TICK_PER_SECOND;
            if ( (us)> (I2C_DELAY))
            {
                us = i2c->IC_INTR_STAT;
                us = i2c->IC_TX_ABRT_SOURCE;
                printf("rsp_hal_i2c_dw_wait_idle timeout! \r\n");
                return HAL_ETIME;
            }
        }
    }
    
    /* Wait TX fifo empty */
    if (rsp_hal_i2c_dw_wait_status(port, I2C_STATUS_TFE_MASK, I2C_DELAY) != HAL_OK)
        return HAL_ETIME;

    return i;

}
#endif
/**
 * @brief  从机持续接收主机写入的数据并实时打印(调试用, 不返回)
 * @note   死循环轮询接收 FIFO(IC_RXFLR), 每读到 1 字节按十六进制打印;
 *         每 16 字节换行, 便于阅读。主机连续写入时可持续输出。
 *         如需按 ASCII 显示, 将 printf("%02x ", ch) 改为 printf("%c", ch)。
 */
int rsp_hal_i2c_dw_slave_receive_temp_lkb(I2C_NUM_E port)
{
    rsp_i2c_t *i2c = rsp_hal_get_iic_by_port(port);
    uint32_t once;
    uint32_t i;
    uint32_t cnt = 0;
    uint8_t data[64];
  
    printf("i2c slave receive start (port=%d)...\r\n", (int)port);

    for (;;)
    {
        once = i2c->IC_RXFLR;   /* 当前接收 FIFO 中可读字节数 */

        for (i = 0; i < once; i++)
        {
            data[cnt++] = (uint8_t)(i2c->IC_DATA_CMD & I2C_DATA_CMD_DAT_MASK);
            // printf("%02x ", ch);
            // if ((++cnt % 16U) == 0U)
            //     printf("\r\n");
            
        }
        if(cnt>=64){
            for(i=0; i<cnt; i++)
                printf("%02x ", data[i]);
            printf("\r\n");
            break;
        }
    }

    return 0;                   /* 不会执行到这里 */
}
int rsp_hal_i2c_dw_slave_receive(I2C_NUM_E port, uint8_t *data, uint8_t len)
{
    rsp_i2c_t *i2c = rsp_hal_get_iic_by_port(port);
    int i=0;
    int index=0;
    int once=0;
 
    // start_tick = rt_tick_get();
    //send data
    while(len > 0)
    {
        once = i2c->IC_RXFLR;
        for(i=0; i< once; i++)
            data[index++] = i2c->IC_DATA_CMD & I2C_DATA_CMD_DAT_MASK;
        len -= once;
        
        // if(once == 0)
        // {
        //     // delta_tick = rt_tick_get() - start_tick;
        //     // us = delta_tick * 1000000 / RT_TICK_PER_SECOND;
        //     if ( (us)> (I2C_DELAY*10))//时间尽可能长一些，因为从机准备接受数据，但是不知道主机什么时候发送数据。
        //     {
        //         us = i2c->IC_INTR_STAT;
        //         us = i2c->IC_TX_ABRT_SOURCE;
        //         printf("rsp_hal_i2c_dw_wait_idle timeout! \r\n");
        //         return HAL_ETIME;
        //     }
        // }
    }

        // for(i=0; i<index; i++)
        //     printf("%02x ", data_temp[i]);
        // printf("\r\n");

    
    return HAL_OK;
}

int rsp_hal_i2c_dw_master_write(I2C_NUM_E port, uint8_t addr, uint8_t *data, uint8_t len)
{
    int i=0;
    rsp_i2c_t *i2c = rsp_hal_get_iic_by_port(port);
    if (rsp_hal_i2c_dw_wait_idle(port, I2C_DELAY) != HAL_OK)
        return HAL_NOT_EXIST;

    if (rsp_hal_i2c_dw_wait_status(port, I2C_STATUS_TFNF_MASK, I2C_DELAY) != HAL_OK)
        return HAL_ETIME;
    //send addr
    i2c->IC_DATA_CMD = I2C_DATA_CMD_CMD(0)|addr;
    if (rsp_hal_i2c_dw_wait_status(port, I2C_STATUS_TFNF_MASK, I2C_DELAY) != HAL_OK)
        return HAL_ETIME;
    //send data
    for(i=0; i< len; i++)
    {
        if (rsp_hal_i2c_dw_wait_status(port, I2C_STATUS_TFNF_MASK, I2C_DELAY) != HAL_OK)
            break;
        i2c->IC_DATA_CMD = I2C_DATA_CMD_CMD(0)|data[i];
    }
    /* Wait TX fifo empty */
    if (rsp_hal_i2c_dw_wait_status(port, I2C_STATUS_TFE_MASK, I2C_DELAY) != HAL_OK)
        return HAL_ETIME;

    return i;
}

int rsp_hal_i2c_dw_master_read(I2C_NUM_E port, uint8_t addr, uint8_t *data, uint8_t len)
{

    rsp_i2c_t *i2c = rsp_hal_get_iic_by_port(port);
    uint32_t i = 0;
    uint32_t cmd = 0;

    if (rsp_hal_i2c_dw_wait_idle(port, I2C_DELAY) != HAL_OK)
        return HAL_ETIME;

    if (rsp_hal_i2c_dw_wait_status(port, I2C_STATUS_TFNF_MASK, I2C_DELAY) != HAL_OK)
        return HAL_ETIME;
    
    i2c->IC_DATA_CMD = I2C_DATA_CMD_CMD(0)|addr;

    /* Wait TX fifo empty */
    if (rsp_hal_i2c_dw_wait_status(port, I2C_STATUS_TFE_MASK, I2C_DELAY) != HAL_OK)
    {
        return HAL_ETIME;
    }

	for (i = 0; i < len; i++)
	{
        cmd = I2C_DATA_CMD_CMD(1);
        if(i == 0)
            cmd |=I2C_DATA_CMD_RESTART(1);
        if(i == (len-1))
            cmd |=I2C_DATA_CMD_STOP(1);

        i2c->IC_DATA_CMD = cmd;

        if (rsp_hal_i2c_dw_wait_status(port, I2C_STATUS_RFNE_MASK, I2C_DELAY) != HAL_OK)
            break;
        data[i] = i2c->IC_DATA_CMD & I2C_DATA_CMD_DAT_MASK;
	}
	return i;
}
