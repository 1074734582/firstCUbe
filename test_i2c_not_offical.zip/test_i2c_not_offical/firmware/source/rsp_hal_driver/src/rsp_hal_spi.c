/**
  ******************************************************************************
  * @file    rsp_hal_spi.c
  * @author  Tsinghua University
  * @brief   
  ******************************************************************************
  */

#include <rsp_hal.h>
#include <string.h>

/* Struct pointer for SPI controller registers */
#define SSI SPI1   //md by tesla 20230410 : #define SSI SPI1

#define LEN_4K (4*1024)
#define min(a,b) ((a) > (b)?(b):(a))

#define FLASH_SIZE_32MB (256*1024*1024/8)

#define SPI_STATUS_BUSY          0x00000001
#define SPI_STATUS_TFNF          0x00000002
#define SPI_STATUS_TFE           0x00000004
#define SPI_STATUS_RFNE          0x00000008
#define SPI_STATUS_RFF           0x00000010
#define SPI_STATUS_TXE           0x00000020
#define SPI_STATUS_DCOL          0x00000040

#define SPI_CMD_PAGE_PROGRAM     0x02
#define SPI_CMD_READ_DATA        0x03
#define SPI_CMD_WRITE_DISABLE    0x04
#define SPI_CMD_READ_STATUS      0x05
#define SPI_CMD_WRITE_ENABLE     0x06
#define SPI_CMD_SECTOR_ERASE     0x20
#define SPI_CMD_JEDEC_ID         0x9f
#define SPI_CMD_WRITE_EAR        0xc5
#define SPI_CMD_CHIP_ERASE       0xc7

static uint32_t rsp_spi_rx_fifo_depth = 2;
static uint32_t rsp_spi_tx_fifo_depth = 2;
  
static void rsp_hal_spi_fifo_depth_detect(void)
{
    for (rsp_spi_tx_fifo_depth = 1; rsp_spi_tx_fifo_depth < 256; rsp_spi_tx_fifo_depth++) 
	{
        SSI->TXFTLR = rsp_spi_tx_fifo_depth;
        if(SSI->TXFTLR != rsp_spi_tx_fifo_depth)
            break;
    }
    SSI->TXFTLR = 0;
 
    for (rsp_spi_rx_fifo_depth = 1; rsp_spi_rx_fifo_depth < 256; rsp_spi_rx_fifo_depth++) 
	{
        SSI->RXFTLR = rsp_spi_rx_fifo_depth;
        if(SSI->RXFTLR != rsp_spi_rx_fifo_depth)
            break;
    }
	
    SSI->RXFTLR = 0x10;  //md 20230412
}
 
int32_t rsp_hal_spi_wait_status(uint32_t status, uint32_t value)
{
#if defined(CONFIG_ASIC) 
    uint32_t us = rsp_hal_get_us();
#endif
	
    while ((SSI->SR & status) == value)
	{
#if defined(CONFIG_ASIC)
	    if (rsp_hal_get_us_since(us) > (1000*1000))
			return HAL_ETIME;
#endif
	}

	return HAL_OK;
}

int32_t rsp_hal_spi_disable(void)
{	
	if (rsp_hal_spi_wait_status(SPI_STATUS_BUSY, SPI_STATUS_BUSY) < 0)
		return HAL_ETIME;
	
    SSI->SER = 0;
	
	if (rsp_hal_spi_wait_status(SPI_STATUS_BUSY, SPI_STATUS_BUSY) < 0)
		return HAL_ETIME;
	
	SSI->SSIENR = 0; 
	
	return HAL_OK;
}

int32_t rsp_hal_spi_slave_enable(void)
{	
	if (rsp_hal_spi_wait_status(SPI_STATUS_BUSY, SPI_STATUS_BUSY) < 0)
		return HAL_ETIME;
	
    SSI->SER = 1;
	
	if (rsp_hal_spi_wait_status(SPI_STATUS_BUSY, SPI_STATUS_BUSY) < 0)
		return HAL_ETIME;
	
	return HAL_OK;
}

int32_t rsp_hal_spi_flash_write_register(uint8_t cmd, uint8_t value)
{
	if (rsp_hal_spi_disable() < 0)
		return HAL_ETIME;
	
    SSI->SPI_CTRLR0 = 0
            | 0b00 <<  0  // trans_type=addr,data in the mode specified byCTRLR0.SPI_FRF
            | 0b10 <<  8  // 8bit cmd
            | 0 << 11     // wait 0cycle
            ;
 
    SSI->CTRLR0 =  0
        | (0<<4)  /*motolar spi*/
        | (0b01<<8) /*TMOD:tx+rx:00 01<--todev 10<--tohost*/
        | (0<<11) 
        | ((7) << 16) /*8bit data  */
        | (0b00 << 21) /*frf:normal format*/
        ;
    SSI->SSIENR = 1;
 
    SSI->DR[0] = SPI_CMD_WRITE_ENABLE;	
    if (rsp_hal_spi_slave_enable() < 0)
		return HAL_ETIME;
 
    SSI->SER = 0;
    SSI->DR[0] = cmd;
    SSI->DR[0] = value;
    if (rsp_hal_spi_slave_enable() < 0)
		return HAL_ETIME;
	
	return HAL_OK;
}
 
int32_t rsp_hal_spi_flash_read_register(uint8_t cmd, uint8_t *value, int32_t size)
{
	if (rsp_hal_spi_disable() < 0)
		return HAL_ETIME;
	
    SSI->CTRLR0 = 0 | 
                 (0 << 4) | /* motolar spi */
                 (0b11 << 8) | /* tx+rx:00 01<--todev 10<--tohost */
                 (0 << 11) | 
                 (7 << 16) | /* 8 bit data */
                 0b00 << 21; /* stand spi mode */
				 
    SSI->CTRLR1 = 2;
	
    SSI->SSIENR = 1;
 
    SSI->DR[0] = cmd;

    if (rsp_hal_spi_slave_enable() < 0)
		return HAL_ETIME;
 
	if (rsp_hal_spi_wait_status(SPI_STATUS_RFNE, 0) < 0)
		return HAL_ETIME;
		
	switch (size)
	{
	case 1:
	    value[0] = SSI->DR[0] & 0xff;
	    break;
	case 2:
	    value[1] = SSI->DR[0] & 0xff;
	    value[0] = SSI->DR[0] & 0xff;
	    break;
	case 3:
	    value[2] = SSI->DR[0] & 0xff;
	    value[1] = SSI->DR[0] & 0xff;
	    value[0] = SSI->DR[0] & 0xff;
	    break;
	case 4:
	    value[3] = SSI->DR[0] & 0xff;
	    value[2] = SSI->DR[0] & 0xff;
	    value[1] = SSI->DR[0] & 0xff;
	    value[0] = SSI->DR[0] & 0xff;
	    break;
	default:
	    return HAL_EINVAL;
	}
		
    return HAL_OK;
}
 
int32_t rsp_hal_spi_flash_wait_busy(uint32_t ms)
{
	uint8_t status = 0;
	
#if defined(CONFIG_ASIC) 
    uint32_t us = rsp_hal_get_us();
#endif
 
    while (1)
	{
		if (rsp_hal_spi_flash_read_register(SPI_CMD_READ_STATUS, &status, 1) < 0)
			return HAL_ETIME;
		
        if ((status & 0x1) == 0)
			break;
#if defined(CONFIG_ASIC) 
        if (rsp_hal_get_us_since(us) > (ms*1000))
			return HAL_ETIME;
#endif
    } 
	
	return HAL_OK;
}

int32_t rsp_hal_spi_flash_write_enable(void)
{
	if (rsp_hal_spi_disable() < 0)
		return HAL_ETIME;

    SSI->CTRLR0 =  0
        | (0<<4)  /*motolar spi*/
        | (0b01<<8) /*tx+rx:00 01<--todev 10<--tohost*/
        | (0<<11) 
        | 0b00 << 21 /*stand spi mode*/
        | (7 << 16) /* */
        ;    
    SSI->SSIENR = 1;
 
    SSI->DR[0] = SPI_CMD_WRITE_ENABLE;
	
    return rsp_hal_spi_slave_enable();
}

int32_t rsp_hal_spi_flash_erase(uint8_t cmd, uint32_t addr, uint32_t mask)
{
    uint32_t spi_ctrlr0;
    addr = addr & ~(mask); // 4k align
 
    if (addr >= (FLASH_SIZE_32MB)/2)
	{
        addr -= FLASH_SIZE_32MB/2;
        if (rsp_hal_spi_flash_write_register(SPI_CMD_WRITE_EAR, 0x1) < 0)
            return HAL_ETIME;			 
    } 
	else 
	{
        if (rsp_hal_spi_flash_write_register(SPI_CMD_WRITE_EAR, 0x0) < 0)
            return HAL_ETIME;	
    }
	
    if (rsp_hal_spi_flash_write_enable() < 0)
		return HAL_ETIME;
 
	if (rsp_hal_spi_disable() < 0)
		return HAL_ETIME;

    spi_ctrlr0 = SSI->SPI_CTRLR0;
 
    SSI->SPI_CTRLR0 = 0
            | 0b00 <<  0  // trans_type=addr,data by SPI_FRF 
            | 0b1000 << 2 // 32bit addr width
            | 0b10 <<  8 // 8bit cmd
            | 0 << 11  // wait 0cycle
            ;
    SSI->CTRLR0 =  0
            | (0<<4)  /*motolar spi*/
            | (0b01<<8) /*tx+rx:00 01<--todev 10<--tohost*/
            | (0<<11) 
            | (31 << 16) /* */
            | 0b00 << 21 /*stand spi mode*/
            ;    
    SSI->SSIENR = 1;
 
    /* erase cmd */
    SSI->DR[0] = cmd << 24 | addr;
    
	if (rsp_hal_spi_slave_enable() < 0)
		return HAL_ETIME;
 
	if (rsp_hal_spi_disable() < 0)
		return HAL_ETIME;

    SSI->SPI_CTRLR0 = spi_ctrlr0;
    
    return rsp_hal_spi_flash_wait_busy(1000);
}
 
 
int32_t rsp_hal_spi_flash_three_byte_address_read(uint32_t flashaddr, void *buf, int32_t *readbytes)
{
    int32_t frms_peer_loop,i;
    char *ptr = buf;
    int32_t MAX_FRMS_ONETIME = rsp_spi_rx_fifo_depth-2,frm_cnt=0;
    int32_t cntof4byte, less4byte,data;
    uint32_t dr_data;
    uint8_t k; 
 
    if (flashaddr >= (FLASH_SIZE_32MB/2)) 
	{
        flashaddr -= FLASH_SIZE_32MB/2;
        if (rsp_hal_spi_flash_write_register(SPI_CMD_WRITE_EAR, 0x1) < 0)
			return HAL_ETIME;
    }
	else
	{
        if ((flashaddr + *readbytes)>  FLASH_SIZE_32MB/2)
		{
            *readbytes = FLASH_SIZE_32MB/2 - flashaddr;
        }
        if (rsp_hal_spi_flash_write_register(SPI_CMD_WRITE_EAR, 0x0) < 0)
			return HAL_ETIME;
    }
 
    cntof4byte = *readbytes/sizeof(int32_t);
    less4byte = *readbytes%4;
 
	if (rsp_hal_spi_disable() < 0)
		return HAL_ETIME;

    SSI->SPI_CTRLR0 =  0
        | 0b00 <<  0    // trans_type=addr,data normal node
        | 0b1000 << 2   // 32bit addr width, valid on dual/qual mode
        | 0b10 <<  8    // 8bit cmd vaild on dual/qual mode
        | 0 << 11       // wait 0cycle
        ;
    SSI->CTRLR0 =  0
        | (0<<4)  /*motolar spi*/
        | (0b11<<8) /*tx+rx:00, 01<--todev, 10<--tohost,11<-eeprom read*/
        | (31 << 16) /* read 32bit onetime(rd) 32bit one frame */
        | 0b00 << 21 /*stand spi mode*/
        ;    
    SSI->CTRLR1 = 0;
    SSI->RX_SAMPLE_DLY = 0;
    SSI->SSIENR = 1;
 
    while (frm_cnt < cntof4byte)
	{
        // set regs
        frms_peer_loop = min(cntof4byte-frm_cnt, MAX_FRMS_ONETIME);

	    SSI->SER = 0;
	    SSI->SSIENR = 0;

        SSI->CTRLR1 = frms_peer_loop-1;
        SSI->SSIENR = 1;
 
        // send read cmd
        SSI->DR[0] = (SPI_CMD_READ_DATA << 24)|(flashaddr&0xFFFFFF);
        
		if (rsp_hal_spi_slave_enable() < 0)
			return HAL_ETIME;
 
        // read data
        for (i = 0; i < frms_peer_loop; i++) 
		{
		    if (rsp_hal_spi_wait_status(SPI_STATUS_TFE, 0) < 0)
			    return HAL_ETIME;
			
		    if (rsp_hal_spi_wait_status(SPI_STATUS_BUSY, SPI_STATUS_BUSY) < 0)
			    return HAL_ETIME;
			
		    if (rsp_hal_spi_wait_status(SPI_STATUS_RFNE, 0) < 0)
			    return HAL_ETIME;
 
            dr_data = __builtin_bswap32(SSI->DR[0]);
			
            for (k = 0; k < 4; k++)
            {
                *ptr = (dr_data >> k * 8) & 0xff;
                ptr++;
            }
        }
 
        flashaddr += sizeof(int32_t)*frms_peer_loop;
        frm_cnt += frms_peer_loop;
    }
 
    if (less4byte > 0)
	{
	    if (rsp_hal_spi_disable() < 0)
		    return HAL_ETIME;

        SSI->CTRLR1 = 0;
        SSI->SSIENR = 1;
 
        SSI->DR[0] = (SPI_CMD_READ_DATA << 24) | (flashaddr & 0xFFFFFF);
		
		if (rsp_hal_spi_slave_enable() < 0)
			return HAL_ETIME;
        
		if (rsp_hal_spi_wait_status(SPI_STATUS_RFNE, 0) < 0)
			return HAL_ETIME;

		if (rsp_hal_spi_wait_status(SPI_STATUS_BUSY, SPI_STATUS_BUSY) < 0)
			return HAL_ETIME;
		
        data = __builtin_bswap32(SSI->DR[0]);
 
        for (i = 0; i < less4byte; i++) 
		{
            ((uint8_t*)ptr)[i] =  (data >> ((i)*8)) & 0xff;// zk comment
        }
    }
	
    if (rsp_hal_spi_flash_write_register(SPI_CMD_WRITE_EAR, 0x0) < 0)
		return HAL_ETIME;
 
    return HAL_OK;
}

int32_t rsp_hal_spi_flash_read(uint32_t flashaddr, void *buf, int32_t readbytes)
{
    int32_t *ptr = (int32_t*)buf;
    int32_t real_read_cnt;
    uint32_t spi_ctrlr0;
    
	if (rsp_hal_spi_disable() < 0)
		return HAL_ETIME;

    spi_ctrlr0 = SSI->SPI_CTRLR0;
    SSI->SSIENR = 1;
  
    while (readbytes > 0)
	{
		real_read_cnt = readbytes;
		
        if (rsp_hal_spi_flash_three_byte_address_read(flashaddr, ptr, &real_read_cnt) != HAL_OK)
			return HAL_ETIME;
		
        readbytes -= real_read_cnt;
        ptr = (int32_t*)((char*)ptr + real_read_cnt);
        flashaddr += real_read_cnt;
    }
 
	if (rsp_hal_spi_disable() < 0)
		return HAL_ETIME;
	
    SSI->SPI_CTRLR0 = spi_ctrlr0;
 
    return HAL_OK;
}

int32_t rsp_hal_spi_flash_write_page(uint32_t flashaddr, void *buf, int32_t len)
{
    int32_t frms_peer_loop,i;
    int32_t writebytes=len;
    int32_t *ptr = (int32_t*)buf;
    int32_t MAX_FRMS_ONETIME = rsp_spi_tx_fifo_depth;
    int32_t cntof4byte = writebytes/sizeof(int32_t);
    int32_t less4byte = writebytes%4;
    int32_t frm_cnt = 0;
    uint8_t *ptr8;
	 
    if (flashaddr >= (FLASH_SIZE_32MB)/2)
	{
        flashaddr -= FLASH_SIZE_32MB/2;
        if (rsp_hal_spi_flash_write_register(SPI_CMD_WRITE_EAR, 0x1) < 0)
			return HAL_ETIME;
    }
	else
	{
        if (rsp_hal_spi_flash_write_register(SPI_CMD_WRITE_EAR, 0x0) < 0)
			return HAL_ETIME;
    }
    
	if (rsp_hal_spi_disable() < 0)
		return HAL_ETIME;

    SSI->CTRLR0 =  0
        | (0<<4)  /*motolar spi*/
        | (0b01<<8) /*tx+rx:00, 01<--todev, 10<--tohost,11<-eeprom read*/
        | (31 << 16) /* read 32bit onetime(rd) 32bit one frame */
        | 0b00 << 21 /*stand spi mode*/
        ;    
    SSI->SSIENR = 1;
 
    frm_cnt = 0;
    while (frm_cnt < cntof4byte)
	{
        // set regs
        frms_peer_loop = min(cntof4byte-frm_cnt, MAX_FRMS_ONETIME-2);

        if (rsp_hal_spi_flash_write_enable() < 0)
			return HAL_ETIME;
 
	    SSI->SER = 0;
	    SSI->SSIENR = 0;

        SSI->CTRLR0 =  0
            | (0<<4)  /*motolar spi*/
            | (0b01<<8) /*tx+rx:00, 01<--todev, 10<--tohost,11<-eeprom read*/
            | (31 << 16) /* read 32bit onetime(rd) 32bit one frame */
            | 0b00 << 21 /*stand spi mode*/
            ;    
        SSI->SSIENR = 1;
 
        SSI->SER = 0;
		
        SSI->DR[0] = (SPI_CMD_PAGE_PROGRAM << 24) | (flashaddr&0xFFFFFF);

        for (i = 0; i < frms_peer_loop; i++) 
		{
            SSI->DR[0] = __builtin_bswap32(*ptr);
            ptr++;
        }
		
        if (rsp_hal_spi_slave_enable() < 0)
			return HAL_ETIME;
		
        if (rsp_hal_spi_flash_wait_busy(1000) < 0)
			return HAL_ETIME;
 
        flashaddr += sizeof(int32_t) * frms_peer_loop;
		
        frm_cnt += frms_peer_loop;
    }
 
    // less than 4byte(32bit)
    if (less4byte > 0)
	{
        ptr8 = (uint8_t*)ptr;
 
        if (rsp_hal_spi_flash_write_enable() < 0)
			return HAL_ETIME;
 
	    if (rsp_hal_spi_disable() < 0)
		    return HAL_ETIME;

        SSI->CTRLR0 =  0
            | (0<<4)  /*motolar spi*/
            | (0b01<<8) /*tx+rx:00, 01<--todev, 10<--tohost,11<-eeprom read*/
            | (7 << 16) /*data width 8bit */
            | 0b00 << 21 /*normal spi mode*/
            ;    
        SSI->SSIENR = 1;

        SSI->DR[0] = SPI_CMD_PAGE_PROGRAM;
        SSI->DR[0] = (flashaddr>>16)&0xff;
        SSI->DR[0] = (flashaddr>>8)&0xff;
        SSI->DR[0] = flashaddr&0xff;
		
        for (i = 0; i < less4byte; i++) 
		{
            SSI->DR[0] = ptr8[i];
        }
		
        if (rsp_hal_spi_slave_enable() < 0)
			return HAL_ETIME;
		
        if (rsp_hal_spi_flash_wait_busy(1000) < 0)
			return HAL_ETIME;
    }
 
    return HAL_OK;
}
 
int32_t rsp_hal_spi_flash_write_sector(uint32_t flashaddr, void *buf)
{
    int32_t pagesize = 256, i;
 
    if ((flashaddr & 0xfff) != 0x0)
	{
		return HAL_EINVAL;
    }
    
	if (rsp_hal_spi_flash_erase(SPI_CMD_SECTOR_ERASE, flashaddr, 0xfff) < 0)
		return HAL_ETIME;
            
    /* write by page size */
    for (i = 0; i < LEN_4K; i += pagesize) 
	{
        if (rsp_hal_spi_flash_write_page(flashaddr+i, (char*)buf+i, pagesize) != HAL_OK)
			return HAL_ETIME;
    }

    return HAL_OK;
}
 
uint32_t rsp_hal_spi_read_id(void)
{
	uint32_t id = 0;
	int32_t ret = 0;

	if ((ret = rsp_hal_spi_flash_read_register(SPI_CMD_JEDEC_ID, (uint8_t*)&id, 3)) < 0)
        id = 0xffffffff;
	
	return id;
}

int32_t rsp_hal_spi_chip_erase(uint32_t timeout)
{
    uint32_t spi_ctrlr0 = 0;
       
    if (rsp_hal_spi_flash_write_enable() < 0)
		return HAL_ETIME;
    
	if (rsp_hal_spi_disable() < 0)
		return HAL_ETIME;

    spi_ctrlr0 = SSI->SPI_CTRLR0;
    
    SSI->SPI_CTRLR0 = 0
                      | 0b00 <<    0  // trans_type=addr,data by SPI_FRF 
                      | 0b1000 << 2 // 32bit addr width
                      | 0b10 <<    8 // 8bit cmd
                      | 0 << 11    // wait 0cycle
                      ;
    SSI->CTRLR0 = 0
                  | (0<<4)  /*motolar spi*/
                  | (0b01<<8) /*tx+rx:00 01<--todev 10<--tohost*/
                  | (0<<11) 
                  | (7 << 16) /* */
                  | 0b00 << 21 /*stand spi mode*/
                  ;        

    SSI->SSIENR = 1;
    
    SSI->DR[0] = SPI_CMD_CHIP_ERASE;
	
    if (rsp_hal_spi_slave_enable() < 0)
		return HAL_ETIME;
    
	if (rsp_hal_spi_disable() < 0)
		return HAL_ETIME;

    SSI->SPI_CTRLR0 = spi_ctrlr0;
         
    if (rsp_hal_spi_flash_wait_busy(timeout) < 0)
		return HAL_ETIME;
	
	return HAL_OK;
}
	
int32_t rsp_hal_spi_read(uint32_t addr, void *data, uint32_t size)
{
    uint32_t addr_4byte_align;
    char pbuf[8] = {0};
    int32_t morebyte;
    uint32_t i;
    uint32_t *ptr = (uint32_t*)data;
    uint8_t vaildata;
 
    if ((addr & 0x3) != 0) 
	{
        addr_4byte_align = (addr & 0xfffffffc);
 
        morebyte = addr - addr_4byte_align;
 
        if (rsp_hal_spi_flash_read(addr_4byte_align, pbuf, 4) != HAL_OK)
			return HAL_ETIME;
 
        vaildata = (4 -morebyte);
 
        if (size > vaildata) 
		{
            for( i =0;i<(4 - morebyte); i++) 
			{
                *((char*)ptr + i) = pbuf[morebyte + i];
            }
            ptr = (uint32_t*)((char*)ptr + (4- (addr - addr_4byte_align)));
            if (rsp_hal_spi_flash_read(addr_4byte_align + 4, ptr,size - (4 - morebyte)) != HAL_OK)
				return HAL_ETIME;
        } 
		else 
		{
            for (i = 0; i < size; i++) 
			{
                *((char*)ptr + i) = pbuf[morebyte + i];
            }
        }
    } 
	else 
	{
        if (rsp_hal_spi_flash_read(addr, ptr, size) != HAL_OK)
			return HAL_ETIME;
    }
 
    return HAL_OK;
}

int32_t rsp_hal_spi_write(uint32_t addr, void *data, uint32_t size)
{
    uint32_t addr_4k_align = addr & (~(0xfff));
    uint8_t* ptr = (uint8_t*)data;
    int32_t write_cnt = 0, bytes_left = size;
	uint8_t buffer[4096] = {0};
    
    while (bytes_left > 0)
	{
        /* Read 4kB data */
        if (rsp_hal_spi_flash_read(addr_4k_align, buffer, LEN_4K) != HAL_OK)
		{
			return HAL_EFAIL;
		}
		
        write_cnt = min(LEN_4K - (addr - addr_4k_align), bytes_left);
 
        // overwrite 
        memcpy(buffer + (addr - addr_4k_align), ptr, write_cnt);
        bytes_left -= write_cnt;
        ptr += write_cnt;
 
        /* Write 4KB data back */
        if (rsp_hal_spi_flash_write_sector(addr_4k_align, buffer) != HAL_OK)
			return HAL_EFAIL;
		
        addr_4k_align += LEN_4K;
        addr = addr_4k_align;
    }
	
    return HAL_OK;
}

int32_t rsp_hal_spi_init(void)
{
	uint32_t apbclk = HSE_VALUE;
	
    rsp_hal_spi_fifo_depth_detect();
 
	if (rsp_hal_spi_disable() < 0)
		return HAL_ETIME;

    SSI->SPI_CTRLR0 = 0 | 
                      0b00 << 0 | /* trans_type=addr,data in normal mode */
                      0b1000<< 2 | /* 4 bytes addr */
                      0b10 << 8 |  /* 8 bit cmd */
                      0 << 11;  /* wait 0 cycle */

    if (apbclk > 50000000)
	{
		SSI->BAUDR = apbclk / 25000000;
	}
	else
	{
		SSI->BAUDR = 2;
	}
	
    SSI->CTRLR0 = 0 |
                  (0 << 4) | /* motolar spi */
                  (0b00 << 8) | /* TMOD:tx+rx:00 01<--todev 10<--tohost */
                  (0 << 11) |
                  (31 << 16) | /* 32bit data: Multi of 2 if frf=01 */
                  (0b00 << 21); /* frf:normal spi format */
 
    SSI->DMACR = 0; /* disable dma */
    SSI->IMR = 0; /* disable irq */
    SSI->CTRLR1 = 0;
	
    SSI->SSIENR = 1;
 
    if (rsp_hal_spi_flash_write_register(SPI_CMD_WRITE_EAR, 0x0) < 0)
		return HAL_ETIME;
	
    return HAL_OK;
}
