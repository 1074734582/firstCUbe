#include <rsp_hal_misc.h>

/* cycles per microsecond */
static uint32_t us_ticks = 0;
static uint32_t us_modulo = 0;
static uint32_t delay_initialized = 0;
extern volatile uint32_t pkpu_intr_flag;

//RAMFUNC void rsp_hal_delay_init(void)
void rsp_hal_delay_init(void)
{
    /* compute the number of system clocks per microsecond */
    us_ticks = HSE_VALUE / 1000000;
//    us_ticks = HSE_VALUE / 1000000;
    /* assert(us_ticks > 1); */

    /* Split this into two steps to avoid 64bit maths */
    us_modulo = 0xffffffff / us_ticks;
    us_modulo += ((0xffffffff % us_ticks) + 1) / us_ticks;

    /*
     * ensure that the us_module is smaller than half of uint32_t
     * max to make modulo operation possible
     */

    /* assert(us_modulo < 0x80000000); */

    /* turn on access to the DWT registers */
    COREDBG->DEMCR |= RSP_CORE_DBG_DEMCR_TRCENA_MASK;

    /* enable the CPU cycle counter */
    DWT->CTRL |= RSP_DWT_CTRL_CYCCNTENA_MASK;
	
	delay_initialized = 1;
}

RAMFUNC void rsp_hal_delay_uninit(void)
{
    delay_initialized = 0;
}

RAMFUNC void rsp_hal_udelay(uint32_t us)
{
    uint32_t elapsed = 0;
    uint32_t last_count;

    if (!delay_initialized)
    {
		rsp_hal_delay_init();
    }
	
    /* turn on access to the DWT registers */
	COREDBG->DEMCR |= RSP_CORE_DBG_DEMCR_TRCENA_MASK;
    last_count = DWT->CYCCNT;

    for (;;)
    {
        uint32_t current_count;
        uint32_t elapsed_uS;

        /* turn on access to the DWT registers */
        COREDBG->DEMCR |= RSP_CORE_DBG_DEMCR_TRCENA_MASK;
        current_count = DWT->CYCCNT;

        /* measure the time elapsed since the last time we checked */
        elapsed += current_count - last_count;
        last_count = current_count;

        /* convert to microseconds */
        elapsed_uS = elapsed / us_ticks;
        if (elapsed_uS >= us)
            break;
        /* reduce the delay by the elapsed time */
        us -= elapsed_uS;

        /* keep fractional microseconds for the next iteration */
        elapsed %= us_ticks;
    }
}

RAMFUNC void rsp_hal_mdelay(uint32_t ms)
{
    while (ms--)
    {
        rsp_hal_udelay(1000);
    }
}

RAMFUNC uint32_t rsp_hal_get_us(void)
{
    if (!delay_initialized)
    {
            rsp_hal_delay_init();
    }
    
    /* turn on access to the DWT registers */
        COREDBG->DEMCR |= RSP_CORE_DBG_DEMCR_TRCENA_MASK;
    return DWT->CYCCNT / us_ticks;
}