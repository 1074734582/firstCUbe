/**
  ******************************************************************************
  * @file    rsp_hal_gpio.c
  * @author  Tsinghua University
  * @brief   
  ******************************************************************************
  */

#include "rsp_hal_gpio.h"

int32_t rsp_hal_gpio_set_dir(rsp_gpio_t *gpio, uint32_t pin, uint32_t dir)
{    
    if (!IS_GPIO_PORT(gpio))
		    return HAL_EINVAL;
    if (!IS_GPIO_PIN(pin))
		    return HAL_EINVAL;
    if (!IS_GPIO_DIR(dir))
		    return HAL_EINVAL;
		
    if (dir == RSP_GPIO_INPUT)
        gpio->DIR |= pin;
    else
        gpio->DIR &= ~pin;

    return HAL_OK;
}

//RAMFUNC int32_t rsp_hal_gpio_set_pin(rsp_gpio_t *gpio, uint32_t pin, uint32_t val)
RAMFUNC int32_t rsp_hal_gpio_set_pin(rsp_gpio_t *gpio, uint32_t pin, uint32_t val)
{
    if (!IS_GPIO_PORT(gpio))
		    return HAL_EINVAL;
    if (!IS_GPIO_PIN(pin))
		    return HAL_EINVAL;
    if (!IS_GPIO_VAL(val))
		    return HAL_EINVAL;

	if (val == RSP_GPIO_LOW)
		    gpio->DAT &= ~pin;
    else
		    gpio->DAT |= pin;
		
		return HAL_OK;
}

//add by tesla 20230508
RAMFUNC int32_t rsp_hal_gpio_set_all_pin_pull_up(rsp_gpio_t *gpio, uint32_t pin, uint32_t type)
{
    if (!IS_GPIO_PORT(gpio))
            return HAL_EINVAL;
    if (!IS_GPIO_PIN(pin))
            return HAL_EINVAL;
    if (!IS_GPIO_PULL(type))
            return HAL_EINVAL;

    gpio->PULLL = 0x55555555;
    gpio->PULLH = 0x55555555;

    return HAL_OK;
}

RAMFUNC int32_t rsp_hal_gpio_get_pin(rsp_gpio_t *gpio, uint32_t pin, uint32_t *val)
{
    if (!IS_GPIO_PORT(gpio))
		    return HAL_EINVAL;
    if (!IS_GPIO_PIN(pin))
		    return HAL_EINVAL;

    *val = (gpio->DAT & pin) ? 1 : 0;
		
    return HAL_OK;
}

RAMFUNC int32_t rsp_hal_gpio_get_dir(rsp_gpio_t *gpio, uint32_t pin, uint32_t *dir)
{
    if (!IS_GPIO_PORT(gpio))
		    return HAL_EINVAL;
    if (!IS_GPIO_PIN(pin))
		    return HAL_EINVAL;

    *dir = (gpio->DIR & pin) ? 0 : 1;
		
    return HAL_OK;
}

int32_t rsp_hal_gpio_enable_interrupt(rsp_gpio_t *gpio, uint32_t pin, uint32_t type)
{
    if (!IS_GPIO_PORT(gpio))
		    return HAL_EINVAL;
    if (!IS_GPIO_PIN(pin))
		    return HAL_EINVAL;

	switch (type)
	{
	case RSP_GPIO_INT_LOW:
        gpio->INTLEL |= pin;
        gpio->INTPOL |= ~pin;
        gpio->INTSEL |= pin;
        break;
	case RSP_GPIO_INT_HIGH:
        gpio->INTLEL |= pin;
        gpio->INTPOL &= ~pin;
        gpio->INTSEL |= pin;
        break;
	case RSP_GPIO_INT_RISING:
        gpio->INTLEL &= ~pin;
        gpio->INTPOL &= ~pin;
        gpio->INTSEL |= pin;
        break;
	case RSP_GPIO_INT_FALING:
        gpio->INTLEL &= ~pin;
        gpio->INTPOL |= pin;
        gpio->INTSEL |= pin;
        break;
	}

    return HAL_OK;
}


