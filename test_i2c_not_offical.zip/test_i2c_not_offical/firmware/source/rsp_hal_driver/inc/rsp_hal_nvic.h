/**
  ******************************************************************************
  * @file    rsp_hal_nvic.h
  * @author  Tsinghua University
  * @brief   
  ******************************************************************************
  */

#ifndef __RSP_HAL_NVIC_H__
#define __RSP_HAL_NVIC_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "rsp.h"

/**
 * @brief 使能指定模块中断
 * @param  irq 中断编号
 */
RAMFUNC void rsp_hal_nvic_enable_irq(uint32_t irq);

/**
 * @brief 关闭指定模块中断
 * @param  irq 中断编号
 */
void rsp_hal_nvic_disable_irq(uint32_t irq);

/**
 * @brief 设置中断向量表基地址
 * @param  addr 中断向量表所在地址
 */
void rsp_hal_nvic_set_vector(uint32_t addr);

/**
 * @brief 设置指定模块中断优先级
 * @param  irq 中断编号
 * @param  priority 优先级级别
 */
void rsp_hal_nvic_set_priority(uint8_t irq, uint8_t priority);

/**
 * @brief 使能CM3全局中断
 */
RAMFUNC void rsp_hal_nvic_enable_all_irq_flag(void);

/**
 * @brief 关闭CM3全局中断
 */
RAMFUNC void rsp_hal_nvic_disable_all_irq_flag(void);

#ifdef __cplusplus
}
#endif

#endif /* __RSP_HAL_NVIC_H__ */
