/**
  ******************************************************************************
  * @file    rsp_hal_uart.h
  * @author  Tsinghua University
  * @brief   
  ******************************************************************************
  */

#ifndef __RSP_HAL_UART_H__
#define __RSP_HAL_UART_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "rsp.h"

#define IS_UART(UART) (((UART) == UART1) || ((UART) == UART2))

typedef struct 
{
    uint32_t baudrate; //波特率
    uint32_t databits; //每个传输数据的比特数
    uint32_t stopbits; //停止位的数目
    uint32_t parity; //奇偶校验位使能
} rsp_uart_param_t;

/**
 * @brief 串口初始化
 * @param  uart 选择UART1/UART2其中一组寄存器
 * @param  param 需要配置的串口参数
 */
void rsp_hal_uart_init(rsp_uart_t* uart, rsp_uart_param_t* param);

/**
 * @brief 使能串口中断
 * @param  uart 选择UART1/UART2其中一组寄存器
 * @param  flag 选择中断UART_IER_RXNE/UART_IER_TXE/UART_IER_LSE/UART_IER_MSTAT
 */
//void rsp_hal_uart_enable_interrupt(rsp_uart_t* uart, uint32_t flag);

/**
 * @brief 关闭串口中断
 * @param  uart 选择UART1/UART2其中一组寄存器
 * @param  flag 选择中断UART_IER_RXNE/UART_IER_TXE/UART_IER_LSE/UART_IER_MSTAT
 */
//void rsp_hal_uart_disable_interrupt(rsp_uart_t* uart, uint32_t flag);

/**
 * @brief 使能串口FIFO
 * @param  uart 选择UART1/UART2其中一组寄存器
 */
//void rsp_hal_uart_enable_fifo(rsp_uart_t* uart);

/**
 * @brief 发送数据
 * @param  uart 选择UART1/UART2其中一组寄存器
 * @param  data 需要发送的数据（最低8位有效）
 */
void rsp_hal_uart_send_data(rsp_uart_t* uart, uint32_t data);

/**
 * @brief 发送数据(兼容RAMFUNC内部打印)
 * @param  uart 选择UART1/UART2其中一组寄存器
 * @param  data 需要发送的数据（最低8位有效）
 */
RAMFUNC void rsp_hal_uart_send_data_ramfunc(rsp_uart_t* uart, uint32_t data);

/**
 * @brief 接收数据
 * @param  uart 选择UART1/UART2其中一组寄存器
 * @return uint32_t 接收到的数据（最低8位有效）
 */
uint32_t rsp_hal_uart_recv_data(rsp_uart_t* uart);

#ifdef __cplusplus
}
#endif

#endif /* __RSP_HAL_UART_H__ */
