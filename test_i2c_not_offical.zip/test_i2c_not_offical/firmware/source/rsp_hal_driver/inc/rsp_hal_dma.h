/**
  ******************************************************************************
  * @file    rsp_hal_dma.h
  * @brief   
  ******************************************************************************
  */

#ifndef __RSP_HAL_DMA_H__
#define __RSP_HAL_DMA_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "rsp.h"
#define _HI(bits) ((bits)-32)

enum {
    DWIDTH_8 = 0,
    DWIDTH_16 = 1,
    DWIDTH_32 = 2,
    DWIDTH_64 = 3,
    DWIDTH_128 = 4,
};

enum TT {
    TT_M2M_DFC = 0x0, // Mem2Mem Dmac-do-flowControl
    TT_M2P_DFC = 0x1, //Mem2Peripheral Dmac-do-flowControl
    TT_P2M_DFC = 0x2, //Peripheral 2 Mem, Dmac-do-flowControl
    TT_P2P_DFC = 0x3, //Peripheral 2 Peripheral, Dmac-do-flowControl
    TT_P2M_PFC = 0x4, //Peripheral 2 Mem, Perilpheral-do-flowControl
    TT_P2P_SPFC = 0x5, //Peripheral 2 Perilpheral, Source-Perilpheral-do-flowControl
    TT_M2P_PFC = 0x6, //Mem 2 Perilpheral, Perilpheral-do-flowControl
    TT_P2P_DPFC = 0x7, //Peripheral 2 Perilpheral, Dst-Perilpheral-do-flowControl
};

enum ADDR_MOD{
    ADDR_INC = 0x0,
    ADDR_DEC = 0x1,
    ADDR_KEEP = 0x2,
};

enum MSIZE{
    MSIZE_1 = 0x0,
    MSIZE_4 = 0x1,
    MSIZE_8 = 0x2,
    MSIZE_16 = 0x3,
    MSIZE_32 = 0x4,
    MSIZE_64 = 0x5,
    MSIZE_128 = 0x6,
    MSIZE_256 = 0x7,
};

enum HANDSHANKE_HARDSOFT{
    HANDSHANKE_HARD = 0x0,
    HANDSHANKE_SOFT = 0x1,
};

enum HARDWARE_REQ{
    DMAC_REQ_DEFAULT = 0,
    DMAC_REQ_OSPIA_RX = 0x4,
    DMAC_REQ_OSPIA_TX = 0x5,
    DMAC_REQ_OSPIB_RX = 0x6,
    DMAC_REQ_OSPIB_TX = 0x7,
};

typedef struct rsp_dma_transmit_
{
    uint32_t width_s;    /* DWIDTH_8, DWIDTH_16, DWIDTH_32 */
    uint32_t width_d;    /* DWIDTH_8, DWIDTH_16, DWIDTH_32 */
    uint32_t ch_x;  /* 0~7 */
    uint32_t limit_brust;
    uint32_t burst_enable;
    uint32_t trans_mode;
    uint32_t msize;
    uint8_t addrdir_s;
    uint8_t addrdir_d;
    uint8_t src_req_hard;
    uint8_t dst_req_hard;

    uint8_t handshark_softsrc;
    uint8_t handshark_softdst;
} rsp_dma_transmit_t;

// DMA传输函数声明
int dma_transfer(rsp_dma_transmit_t *ctx, uint32_t src, uint32_t dst, uint32_t size);
int dma_read(rsp_dma_transmit_t *ctx, uint32_t src, uint32_t dst, uint32_t size);
int rsp_hal_dma_read(rsp_dma_transmit_t *ctx, uint32_t src, uint32_t dst, uint32_t size);
int dma_transfer_batch(rsp_dma_transmit_t *ctx, dma_transfer_t *transfers, int count);

/*************
 * ch: channel
 * width_s: source whith
 * width_d: dst whith
 * msize： one transmit dma cnt
 * addrdir_s: source addr direction
 * ************/
int rsp_hal_dma_init(rsp_dma_transmit_t *ctx, uint32_t ch, uint32_t trans_mode, int width_s, int width_d, uint32_t msize, uint8_t addrdir_s, uint8_t addrdir_d, uint8_t src_handshark,uint8_t dst_handshark,uint8_t tx_req,uint8_t rx_req);
int rsp_hal_dma_data_transmit(rsp_dma_transmit_t *ctx, uint32_t srcaddr, uint32_t dstaddr, uint32_t size);

int rsp_hal_dma_start(rsp_dma_transmit_t *ctx);
int rsp_hal_dma_done(rsp_dma_transmit_t *ctx);
int rsp_hal_dma_stop(rsp_dma_transmit_t *ctx);

#if 0
enum DMAX_ADDR_MOD{
    DMAX_ADDR_INC = 0x0,
    DMAX_ADDR_KEEP = 0x1,
};

int rsp_hal_dmax_init(rsp_dma_transmit_t *ctx, uint32_t ch, int width_s, int width_d, uint32_t msize, uint32_t trans_mode,uint8_t addrdir_s, uint8_t addrdir_d);
int rsp_hal_dmax_data_prepare(rsp_dma_transmit_t *ctx, uint32_t srcaddr, uint32_t dstaddr, uint32_t size);
int rsp_hal_dmax_start(rsp_dma_transmit_t *ctx);
int rsp_hal_dmax_done(rsp_dma_transmit_t *ctx);
#endif


#ifdef __cplusplus
}
#endif

#endif /* __rsp_hal_DMA_H__ */

