/**
  ******************************************************************************
  * @file    rsp_hal.h
  * @author  Tsinghua University
  * @brief   
  ******************************************************************************
  */

#ifndef __RSP_HAL_H__
#define __RSP_HAL_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "rsp.h"

#include "rsp_hal_misc.h"
#include "rsp_hal_nvic.h"
#include "rsp_hal_uart.h"
#include "rsp_hal_spi.h"
#include "rsp_hal_gpio.h"
#include "rsp_hal_tim.h"
#include "rsp_hal_dma.h"
#include "rsp_hal_i2c.h"

#ifdef __cplusplus
}
#endif

#endif /* __RSP_HAL_H__ */
