/**
  ******************************************************************************
  * @file    rsp.h
  * @author  Tsinghua University
  * @brief   
  ******************************************************************************
  */

#ifndef __RSP_H__
#define __RSP_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

/*---------------------------------------------------------------------------*/
/* Verify configuration                                                      */
/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/
/* Version                                                   */
/*---------------------------------------------------------------------------*/
#define RSP_HAL_VERSION_MAJOR 0
#define RSP_HAL_VERSION_MINOR 0
#define RSP_HAL_VERSION_DEBUG 1
/*---------------------------------------------------------------------------*/
/* Compiler related define                                                   */
/*---------------------------------------------------------------------------*/
#if defined(__ICCARM__)
#include "iccarm_builtin.h"
#endif

#if defined (__GNUC__) && !defined (__CC_ARM) /* GNU Compiler */
#ifndef __weak
#define __weak   __attribute__((weak))
#endif /* __weak */
#ifndef __packed
#define __packed __attribute__((__packed__))
#endif /* __packed */
#endif /* __GNUC__ */

#ifndef NO_RAMFUNC
#if defined(__CC_ARM)
#define RAMFUNC __attribute__((section(".ramfunc")))
#elif defined(__ICCARM__)
#define RAMFUNC __ramfunc
#elif defined(__GNUC__)
//#define RAMFUNC __attribute__((section(".ramfunc")))
#define RAMFUNC

#endif
#else
#define RAMFUNC
#endif

#ifndef NO_ASSERT
#define assert_param(expr) ((expr) ? (void)0U : assert_failed((uint8_t *)__FILE__, __LINE__))
void assert_failed(uint8_t* file, uint32_t line);
#else
#define assert_param(expr) ((void)0U)
#endif /* NO_ASSERT */

#ifndef ALIGNED
#define ALIGNED(x) __attribute__((aligned(x)))
#endif

#ifndef NULL
#define NULL (void*)0
#endif

#ifndef ALIGN
#define ALIGN(x, a) (((x) + ((a) - 1)) & ~((a) - 1))
#endif

#ifndef SWAP
#if defined(__CC_ARM)
#define SWAP __rev
#elif defined(__ICCARM__)
#define SWAP __iar_builtin_REV
#elif defined(__GNUC__)
#define SWAP __builtin_bswap32
#endif
#endif

/*---------------------------------------------------------------------------*/
/* Hardware related define                                                   */
/*---------------------------------------------------------------------------*/

#if !defined HSE_VALUE
#define HSE_VALUE          2500000
#endif

/* Return value */
enum
{
    HAL_NOT_EXIST     = -11, /* Device no exist*/
    HAL_KEY_ERR        = -10, /* Crypto key error */
    HAL_PARAMETER_ERR  = -9, /* Crypto parameter error */
    HAL_DATA_NOT_ALIGN = -8, /* Crypto data length not align */
    HAL_DATA_TOO_LONG  = -7, /* Crypto data too long */
    HAL_ETIME          = -6, /* Timer expired */
    HAL_EBUSY          = -5, /* Device or resource busy */
    HAL_EIO            = -4, /* I/O error */
    HAL_EINVAL         = -3, /* Invalid argument */
    HAL_EALIGN         = -2, /* Address align error */
    HAL_EFAIL          = -1, /* Function execute failed */
    HAL_OK             = 0,
};

/* Interrupt */
enum
{
    RSP_IRQ_TIME0 = 16,
    RSP_IRQ_TIME1 = 17,
    RSP_IRQ_TIME2 = 18,
    RSP_IRQ_TIME3 = 19,

    RSP_IRQ_FIPS203     = 24,
    RSP_IRQ_I2C         = 25,
    RSP_IRQ_ECDSA       = 26,
    RSP_IRQ_CHACHA20    = 27,
    RSP_IRQ_RSA         = 28,
    RSP_IRQ_SHA         = 29,  
    RSP_IRQ_DES         = 30,  
    RSP_IRQ_AES         = 31,
    RSP_IRQ_SM4         = 32,
    RSP_IRQ_SM3         = 33,
    RSP_IRQ_SM2         = 34,
    RSP_IRQ_SM1         = 35,
};

/* Cortex-M3 */
#define RSP_SCS_BASE       (0xE000E000UL) /*!< System Control Space Base Address */
#define RSP_CORE_DBG_BASE  (0xE000EDF0UL) /*!< Core Debug Base Address */
#define RSP_DWT_BASE       (0xE0001000UL) /*!< DWT Base Address */
#define RSP_NVIC_BASE      (RSP_SCS_BASE+0x0100UL) /*!< NVIC Base Address */
#define RSP_SCB_BASE       (RSP_SCS_BASE+0x0D00UL) /*!< System Control Block Base Address */

/* Register */

#define RSP_TIM_BASE       0x30001000
#define RSP_UART1_BASE     0x30002000
#define RSP_UART2_BASE     0x30003000
#define RSP_GPIO_BASE      0x30005000
#define RSP_SPI1_BASE      0x10006000 /* M0 */
#define RSP_I2C0_BASE      0x30004000
#define RSP_I2C1_BASE      0x30005000

#define RSP_DMAC_BASE      0x10031000
#define RSP_DMAX_BASE      0

/**
 * PKPU
 */

#define PQC0_BASE_ADDR   0x60000000
#define PQC0_MEM_ADDR    (PQC0_BASE_ADDR + 0x100000)
#define PQC0_TASK_ADDR   (PQC0_BASE_ADDR + 0x200000)

/* CM3 */
/**
  \brief  Structure type to access the System Control Block (SCB).
 */
typedef struct
{
    volatile const uint32_t CPUID; /*!< Offset: 0x000 (R/ )  CPUID Base Register */
    volatile uint32_t ICSR; /*!< Offset: 0x004 (R/W)  Interrupt Control and State Register */
    volatile uint32_t VTOR; /*!< Offset: 0x008 (R/W)  Vector Table Offset Register */
    volatile uint32_t AIRCR; /*!< Offset: 0x00C (R/W)  Application Interrupt and Reset Control Register */
    volatile uint32_t SCR; /*!< Offset: 0x010 (R/W)  System Control Register */
    volatile uint32_t CCR; /*!< Offset: 0x014 (R/W)  Configuration Control Register */
    volatile uint8_t  SHP[12U]; /*!< Offset: 0x018 (R/W)  System Handlers Priority Registers (4-7, 8-11, 12-15) */
    volatile uint32_t SHCSR; /*!< Offset: 0x024 (R/W)  System Handler Control and State Register */
    volatile uint32_t CFSR; /*!< Offset: 0x028 (R/W)  Configurable Fault Status Register */
    volatile uint32_t HFSR; /*!< Offset: 0x02C (R/W)  HardFault Status Register */
    volatile uint32_t DFSR; /*!< Offset: 0x030 (R/W)  Debug Fault Status Register */
    volatile uint32_t MMFAR; /*!< Offset: 0x034 (R/W)  MemManage Fault Address Register */
    volatile uint32_t BFAR; /*!< Offset: 0x038 (R/W)  BusFault Address Register */
    volatile uint32_t AFSR; /*!< Offset: 0x03C (R/W)  Auxiliary Fault Status Register */
    volatile const uint32_t PFR[2U]; /*!< Offset: 0x040 (R/ )  Processor Feature Register */
    volatile const uint32_t DFR; /*!< Offset: 0x048 (R/ )  Debug Feature Register */
    volatile const uint32_t ADR; /*!< Offset: 0x04C (R/ )  Auxiliary Feature Register */
    volatile const uint32_t MMFR[4U]; /*!< Offset: 0x050 (R/ )  Memory Model Feature Register */
    volatile const uint32_t ISAR[5U]; /*!< Offset: 0x060 (R/ )  Instruction Set Attributes Register */
    uint32_t RESERVED0[5U];
    volatile uint32_t CPACR; /*!< Offset: 0x088 (R/W)  Coprocessor Access Control Register */
} rsp_scb_t;

#define SCB ((rsp_scb_t *)RSP_SCB_BASE) /*!< SCB configuration struct */

/**
  \brief  Structure type to access the Nested Vectored Interrupt Controller (NVIC).
 */
typedef struct 
{
    volatile uint32_t ISER[8U]; /*!< Offset: 0x000 (R/W)  Interrupt Set Enable Register */
    uint32_t RESERVED0[24U];
    volatile uint32_t ICER[8U]; /*!< Offset: 0x080 (R/W)  Interrupt Clear Enable Register */
    uint32_t RESERVED1[24U];
    volatile uint32_t ISPR[8U]; /*!< Offset: 0x100 (R/W)  Interrupt Set Pending Register */
    uint32_t RESERVED2[24U];
    volatile uint32_t ICPR[8U]; /*!< Offset: 0x180 (R/W)  Interrupt Clear Pending Register */
    uint32_t RESERVED3[24U];
    volatile uint32_t IABR[8U]; /*!< Offset: 0x200 (R/W)  Interrupt Active bit Register */
    uint32_t RESERVED4[56U];
    volatile uint8_t  IP[240U]; /*!< Offset: 0x300 (R/W)  Interrupt Priority Register (8Bit wide) */
    uint32_t RESERVED5[644U];
    volatile  uint32_t STIR; /*!< Offset: 0xE00 ( /W)  Software Trigger Interrupt Register */
} rsp_nvic_t;

#define NVIC ((rsp_nvic_t *)RSP_NVIC_BASE)   /*!< NVIC configuration struct */

/**
  \brief  Structure type to access the Data Watchpoint and Trace Register (DWT).
 */
typedef struct
{ 
    volatile uint32_t CTRL;                   /*!< Offset: 0x000 (R/W)  Control Register */
    volatile uint32_t CYCCNT;                 /*!< Offset: 0x004 (R/W)  Cycle Count Register */
    volatile uint32_t CPICNT;                 /*!< Offset: 0x008 (R/W)  CPI Count Register */
    volatile uint32_t EXCCNT;                 /*!< Offset: 0x00C (R/W)  Exception Overhead Count Register */
    volatile uint32_t SLEEPCNT;               /*!< Offset: 0x010 (R/W)  Sleep Count Register */
    volatile uint32_t LSUCNT;                 /*!< Offset: 0x014 (R/W)  LSU Count Register */
    volatile uint32_t FOLDCNT;                /*!< Offset: 0x018 (R/W)  Folded-instruction Count Register */
    volatile const uint32_t PCSR;             /*!< Offset: 0x01C (R/ )  Program Counter Sample Register */
    volatile uint32_t COMP0;                  /*!< Offset: 0x020 (R/W)  Comparator Register 0 */
    volatile uint32_t MASK0;                  /*!< Offset: 0x024 (R/W)  Mask Register 0 */
    volatile uint32_t FUNCTION0;              /*!< Offset: 0x028 (R/W)  Function Register 0 */
    uint32_t RESERVED0[1U];
    volatile uint32_t COMP1;                  /*!< Offset: 0x030 (R/W)  Comparator Register 1 */
    volatile uint32_t MASK1;                  /*!< Offset: 0x034 (R/W)  Mask Register 1 */
    volatile uint32_t FUNCTION1;              /*!< Offset: 0x038 (R/W)  Function Register 1 */
    uint32_t RESERVED1[1U];
    volatile uint32_t COMP2;                  /*!< Offset: 0x040 (R/W)  Comparator Register 2 */
    volatile uint32_t MASK2;                  /*!< Offset: 0x044 (R/W)  Mask Register 2 */
    volatile uint32_t FUNCTION2;              /*!< Offset: 0x048 (R/W)  Function Register 2 */
    uint32_t RESERVED2[1U];
    volatile uint32_t COMP3;                  /*!< Offset: 0x050 (R/W)  Comparator Register 3 */
    volatile uint32_t MASK3;                  /*!< Offset: 0x054 (R/W)  Mask Register 3 */
    volatile uint32_t FUNCTION3;              /*!< Offset: 0x058 (R/W)  Function Register 3 */
} rsp_dwt_t;

#define DWT ((rsp_dwt_t *)RSP_DWT_BASE)      /*!< DWT configuration struct */

#define RSP_DWT_CTRL_CYCCNTENA_MASK  (0x1UL)

/**
  \brief  Structure type to access the Core Debug Register (CoreDebug).
 */
typedef struct
{
  volatile uint32_t DHCSR; /*!< Offset: 0x000 (R/W)  Debug Halting Control and Status Register */
  volatile uint32_t DCRSR; /*!< Offset: 0x004 ( /W)  Debug Core Register Selector Register */
  volatile uint32_t DCRDR; /*!< Offset: 0x008 (R/W)  Debug Core Register Data Register */
  volatile uint32_t DEMCR; /*!< Offset: 0x00C (R/W)  Debug Exception and Monitor Control Register */
} core_dbg_t;

#define COREDBG ((core_dbg_t *)RSP_CORE_DBG_BASE)   /*!< Core Debug configuration struct */

/* Debug Exception and Monitor Control Register */
#define RSP_CORE_DBG_DEMCR_TRCENA_MASK (1UL << 24)


/**
 * UART
 */
typedef struct
{
    volatile uint32_t RBR_THR_DLL; /* 0x00 */
    volatile uint32_t IER_DLH; /* 0x04 */
    volatile uint32_t FCR_IIR; /* 0x08 */
    volatile uint32_t LCR; /* 0x0c */
    volatile uint32_t MCR; /* 0x10 */
    volatile uint32_t LSR; /* 0x14 */
    volatile uint32_t MSR; /* 0x18 */
    volatile uint32_t SCR; /* 0x1c */
    uint32_t reserved1[(0x7c-0x1c)/4-1];
    volatile uint32_t USR; /* 0x7c */
    volatile uint32_t TFL; /* 0x80 */
    volatile uint32_t RFL; /* 0x84 */
} rsp_uart_t;

#define UART1 ((rsp_uart_t *)RSP_UART1_BASE)
#define UART2 ((rsp_uart_t *)RSP_UART2_BASE)

/* Interrupt Enable Register */
/* 0 - disabled */
/* 1 - enabled */
#define UART_IER_RXNE (0x1<<0) /* Enable Received Data Available Interrupt */
#define UART_IER_TXE (0x1<<1) /* Enable Transmit Holding Register Empty Interrupt */
#define UART_IER_LSE (0x1<<2) /* Enable Receiver Line Status Interrupt */
#define UART_IER_MSTAT (0x1<<3) /* Enable Modem Status Interrupt */
#define UART_IER_PTIME (0x1<<7) /* Enable THRE Interrupt Mode */

/* Interrupt Identity Register */
#define UART_IIR_FIFOSE_MASK (0x3<<6) /* FIFOs Enabled Mask Bit */
#define UART_IIR_FIFOSE_DISABLE (0x0<<6) /* FIFOs Enabled */
#define UART_IIR_FIFOSE_ENABLE (0x3<<6) /* FIFOs Enabled */
#define UART_IIR_IID_MASK (0xf<<0) /* Interrupt ID Mask Bit */
#define UART_IIR_IID_MSTAT (0x0<<0) /* Interrupt ID, modem status */
#define UART_IIR_IID_NONE (0x1<<0) /* Interrupt ID, no interrupt pending */
#define UART_IIR_IID_THRE (0x2<<0) /* Interrupt ID, THR empty */
#define UART_IIR_IID_RBRNE (0x4<<0) /* Interrupt ID, received data available */
#define UART_IIR_IID_LSTATUS (0x6<<0) /* Interrupt ID, receiver line status */
#define UART_IIR_IID_BUSY (0x7<<0) /* Interrupt ID, busy detect */
#define UART_IIR_IID_TIMEOUT (0xc<<0) /* Interrupt ID, character timeout */

/* FIFO Control Register */
#define UART_FCR_FIFO_DISABLE (0x0<<0)
#define UART_FCR_FIFO_ENABLE (0x1<<0)
#define UART_FCR_RX_FIFO_RESET (0x1<<1)
#define UART_FCR_TX_FIFO_RESET (0x1<<2)

/* Line Control Register */
#define UART_LCR_DLAB (0x1<<7)
#define UART_LCR_BREAK (0x1<<6)
#define UART_LCR_STICK_PARITY (0x1<<5)
#define UART_LCR_EPS (0x1<<4)

#define UART_LCR_PARITY_MASK (0x1<<3)
#define UART_LCR_PARITY_DISABLE (0x0<<3)
#define UART_LCR_PARITY_ENABLE (0x1<<3)

#define UART_LCR_STOP_BITS_MASK (0x1<<2)
#define UART_LCR_STOP_BITS_1 (0x0<<2)
#define UART_LCR_STOP_BITS_1_5 (0x1<<2)
#define UART_LCR_STOP_BITS_2 (0x1<<2)

#define UART_LCR_DATA_BITS_MASK (0x3<<0)
#define UART_LCR_DATA_BITS_5 (0x0<<0)
#define UART_LCR_DATA_BITS_6 (0x1<<0)
#define UART_LCR_DATA_BITS_7 (0x2<<0)
#define UART_LCR_DATA_BITS_8 (0x3<<0)

/* Modem Control Register */
#define UART_MCR_SIRE (0x1<<6) /* SIR Mode Enable */
#define UART_MCR_AFCE (0x1<<5) /* Auto Flow Control Enable */
#define UART_MCR_LB (0x1<<4) /* LoopBack Bit */
#define UART_MCR_RTS (0x1<<1) /* Request to Send */
#define UART_MCR_DTR (0x1<<0) /* Data Terminal Ready */

/* Line Status Register */
#define UART_LSR_RFE (0x1<<7) /* Receiver FIFO Error bit */
#define UART_LSR_TEMT (0x1<<6) /* Transmitter Empty bit */
#define UART_LSR_THRE (0x1<<5) /* Transmit Holding Register Empty bit */
#define UART_LSR_BI (0x1<<4) /* Break Interrupt bit */
#define UART_LSR_FE (0x1<<3) /* Framing Error bit */
#define UART_LSR_PE (0x1<<2) /* Parity Error bit */
#define UART_LSR_OE (0x1<<1) /* Overrun Error bit */
#define UART_LSR_DR (0x1<<0) /* Data Ready bit */

/**
 * GPIO
 */
typedef struct
{
    volatile uint32_t DIR;
    volatile uint32_t SEL;
    volatile uint32_t DAT;
    volatile uint32_t INTSEL;
    volatile uint32_t INTLEL;
    volatile uint32_t INTPOL;
    volatile uint32_t INTCLR;
    volatile uint32_t SECFUN;
    volatile uint32_t PULLL;
    volatile uint32_t PULLH;
} rsp_gpio_t;

#define GPIOA ((rsp_gpio_t *)RSP_GPIO_BASE)
#define GPIOB ((rsp_gpio_t *)RSP_GPIO_BASE+0x1000)

/**
 * SPI
 */
typedef struct
{
    volatile uint32_t CTRLR0; /* 0x000 */
    volatile uint32_t CTRLR1; /* 0x004 */
    volatile uint32_t SSIENR; /* 0x008 */
    volatile uint32_t MWCR; /* 0x00c */
    volatile uint32_t SER; /* 0x010 */
    volatile uint32_t BAUDR; /* 0x014 */
    volatile uint32_t TXFTLR; /* 0x018 */
    volatile uint32_t RXFTLR; /* 0x01c */
    volatile uint32_t TXFLR; /* 0x020 */
    volatile uint32_t RXFLR; /* 0x024 */
    volatile uint32_t SR; /* 0x028 */
    volatile uint32_t IMR; /* 0x02c */
    volatile uint32_t ISR; /* 0x030 */
    volatile uint32_t RISR; /* 0x034 */
    volatile uint32_t TXOICR; /* 0x038 */
    volatile uint32_t RXOICR; /* 0x03c */
    volatile uint32_t RXUICR; /* 0x040 */
    volatile uint32_t MSTICR; /* 0x044 */
    volatile uint32_t ICR; /* 0x048 */
    volatile uint32_t DMACR; /* 0x04c */
    volatile uint32_t DMATDLR; /* 0x050 */
    volatile uint32_t DMARDLR; /* 0x054 */
    volatile uint32_t IDR; /* 0x058 */
    volatile uint32_t VERSION; /* 0x05c */
    volatile uint32_t DR[36]; /* 0x060-0x0ec */
    volatile uint32_t RX_SAMPLE_DLY; /* 0x0f0 */
    volatile uint32_t SPI_CTRLR0;
} rsp_spi_t;

#define SPI1 ((rsp_spi_t *)RSP_SPI1_BASE)

/* SPI_CTRLR0 */
#define SPI_ADDR_BITS(x) (((x>>2)<<2) & 0x3c)
#define SPI_INST_BITS_4 (0x1UL << 8)  
#define SPI_INST_BITS_8 (0x2UL << 8)  
#define SPI_INST_BITS_16 (0x3UL << 8)  
/* CTRLR0 */
#define SPI_CTRLR0_FRF_SPI (0x0UL << 4)
#define SPI_CTRLR0_FRF_SSP (0x1UL << 4)
#define SPI_CTRLR0_FRF_MICROWIRE (0x2UL << 4)
#define SPI_CTRLR0_SCPH_LOW (0x0UL << 6)
#define SPI_CTRLR0_SCPH_HIGH (0x1UL << 6)
#define SPI_CTRLR0_SCPOL_LOW (0x0UL << 7)
#define SPI_CTRLR0_SCPOL_HIGH (0x1UL << 7)
#define SPI_CTRLR0_TMODE_TXRX (0x0UL << 8)
#define SPI_CTRLR0_TMODE_TX (0x1UL << 8)
#define SPI_CTRLR0_TMODE_RX (0x2UL << 8)
#define SPI_CTRLR0_TMODE_EEPROM (0x3UL << 8)
#define SPI_CTRLR0_DFS(x) (((x-1)<<16) & 0x1f0000)

/**
 * TIMER
 */
typedef struct
{
    volatile uint32_t LCR[8];
    volatile uint32_t CCR[8];
    volatile uint32_t CR[8];
    volatile uint32_t FLAG[8];
    volatile uint32_t IER[8];
    volatile uint32_t ISR[8];
    volatile uint32_t CAPR[8];
    volatile uint32_t CPR[8];
    volatile uint32_t TIFR;
    volatile uint32_t TISR;
    volatile uint32_t TISCR;
    volatile uint32_t TCDIV;
    volatile uint32_t TINDB;
    volatile uint32_t DBER;
    volatile uint32_t DBPR;
    volatile uint32_t reserved[2];
    volatile uint32_t D1LCR;
    volatile uint32_t D2LCR;
    volatile uint32_t D3LCR;
    volatile uint32_t D4LCR;
} rsp_tim_t;

#define TIM  ((rsp_tim_t *)RSP_TIM_BASE)


/**
* DMA
**/
// DMA传输描述符
typedef struct {
	uint32_t src_addr;    // 源地址
	uint32_t dst_addr;    // 目标地址
	uint32_t size;        // 传输大小(字节)
} dma_transfer_t;
typedef struct rsp_dma_channel_
{
    volatile uint32_t DMA_CHANNEL_SAR_L_REG;    
    volatile uint32_t DMA_CHANNEL_SAR_H_REG;    
    volatile uint32_t DMA_CHANNEL_DAR_L_REG;    
    volatile uint32_t DMA_CHANNEL_DAR_H_REG;    
    volatile uint32_t DMA_CHANNEL_LLP_L_REG;    
    volatile uint32_t DMA_CHANNEL_LLP_H_REG;    
    volatile uint32_t DMA_CHANNEL_CTL_L_REG;    
    volatile uint32_t DMA_CHANNEL_CTL_H_REG;    
    volatile uint32_t DMA_CHANNEL_SSTAT_L_REG;    
    volatile uint32_t DMA_CHANNEL_SSTAT_H_REG;    
    volatile uint32_t DMA_CHANNEL_DSTAT_L_REG;    
    volatile uint32_t DMA_CHANNEL_DSTAT_H_REG;    
    volatile uint32_t DMA_CHANNEL_SSTATAR_L_REG;    
    volatile uint32_t DMA_CHANNEL_SSTATAR_H_REG;    
    volatile uint32_t DMA_CHANNEL_DSTATAR_L_REG;    
    volatile uint32_t DMA_CHANNEL_DSTATAR_H_REG;    
    volatile uint32_t DMA_CHANNEL_CFG_L_REG;    
    volatile uint32_t DMA_CHANNEL_CFG_H_REG;    
    volatile uint32_t DMA_CHANNEL_SGR_L_REG;    
    volatile uint32_t DMA_CHANNEL_SGR_H_REG;    
    volatile uint32_t DMA_CHANNEL_DSR_L_REG;    
    volatile uint32_t DMA_CHANNEL_DSR_H_REG;    
} rsp_dma_channel_t;
typedef struct
{
    rsp_dma_channel_t  dma_channel[8];   
    volatile uint32_t DMA_RAW_TFR_L_REG;		/* 0x2c0 */			
    volatile uint32_t DMA_RAW_TFR_H_REG;					
    volatile uint32_t DMA_RAW_BLOCK_L_REG;					
    volatile uint32_t DMA_RAW_BLOCK_H_REG;			
    volatile uint32_t DMA_RAW_SRCTRAN_L_REG;			
    volatile uint32_t DMA_RAW_SRCTRAN_H_REG;			
    volatile uint32_t DMA_RAW_DSTRAN_L_REG;					
    volatile uint32_t DMA_RAW_DSTTRAN_H_REG;					
    volatile uint32_t DMA_RAW_ERR_L_REG;			
    volatile uint32_t DMA_RAW_ERR_H_REG;			

    volatile uint32_t DMA_STATUS_TFR_L_REG;					/* 0x2e8 */
    volatile uint32_t DMA_STATUS_TFR_H_REG;				
    volatile uint32_t DMA_STATUS_BLOCK_L_REG;		
    volatile uint32_t DMA_STATUS_BLOCK_H_REG;		
    volatile uint32_t DMA_STATUS_SRCTRAN_L_REG;				
    volatile uint32_t DMA_STATUS_SRCTRAN_H_REG;				
    volatile uint32_t DMA_STATUS_DSTRAN_L_REG;				
    volatile uint32_t DMA_STATUS_DSTRAN_H_REG;				
    volatile uint32_t DMA_STATUS_ERR_L_REG;			
    volatile uint32_t DMA_STATUS_ERR_H_REG;				

    volatile uint32_t DMA_MASK_TFR_L_REG;				/* 0x310 */
    volatile uint32_t DMA_MASK_TFR_H_REG;				
    volatile uint32_t DMA_MASK_BLOCK_L_REG;				
    volatile uint32_t DMA_MASK_BLOCK_H_REG;				
    volatile uint32_t DMA_MASK_SRCTRAN_L_REG;			
    volatile uint32_t DMA_MASK_SRCTRAN_H_REG;				
    volatile uint32_t DMA_MASK_DSTRAN_L_REG;			
    volatile uint32_t DMA_MASK_DSTRAN_H_REG;				
    volatile uint32_t DMA_MASK_ERR_L_REG;				
    volatile uint32_t DMA_MASK_ERR_H_REG;			

    volatile uint32_t DMA_CLRAR_TFR_L_REG;				/* 0x338 */
    volatile uint32_t DMA_CLRAR_TFR_H_REG;				
    volatile uint32_t DMA_CLRAR_BLOCK_L_REG;				
    volatile uint32_t DMA_CLRAR_BLOCK_H_REG;				
    volatile uint32_t DMA_CLRAR_SRCTRAN_L_REG;			
    volatile uint32_t DMA_CLRAR_SRCTRAN_H_REG;				
    volatile uint32_t DMA_CLRAR_DSTRAN_L_REG;				
    volatile uint32_t DMA_CLRAR_DSTRAN_H_REG;				
    volatile uint32_t DMA_CLRAR_ERR_L_REG;				
    volatile uint32_t DMA_CLRAR_ERR_H_REG;				

    volatile uint32_t DMA_STATUS_INT_L_REG;				/* 0x360 */
    volatile uint32_t DMA_STATUS_INT_H_REG;				
    uint32_t reserved0[12];									
    volatile uint32_t DMA_CFG_L_REG;				/* 0x398 */
    volatile uint32_t DMA_CFG_H_REG;				
    volatile uint32_t DMA_CHAN_EN_L_REG;			/* 0x3a0 */
    volatile uint32_t DMA_CHAN_EN_H_REG;			
} rsp_dma_t;
#define DMA     ((rsp_dma_t *)RSP_DMAC_BASE)

/**
* DMAX
**/
typedef struct rsp_dmax_channel_
{
	volatile uint32_t DMACX_SAR_L_REG;    
    volatile uint32_t DMACX_SAR_H_REG;    
    volatile uint32_t DMACX_DAR_L_REG;    
    volatile uint32_t DMACX_DAR_H_REG;    
    volatile uint32_t DMACX_BLOCK_TS_L_REG;    
    volatile uint32_t DMACX_BLOCK_TS_H_REG;    
    volatile uint32_t DMACX_CTL_L_REG;    
    volatile uint32_t DMACX_CTL_H_REG;    
    volatile uint32_t DMACX_CFG_L_REG;    
    volatile uint32_t DMACX_CFG_H_REG;    
    volatile uint32_t DMACX_LLP_L_REG;    
    volatile uint32_t DMACX_LLP_H_REG;    
    volatile uint32_t DMACX_STATUSR_L_REG;    
    volatile uint32_t DMACX_STATUSR_H_REG;    
    volatile uint32_t DMACX_SWHSSRC_L_REG;    
    volatile uint32_t DMACX_SWHSSRC_H_REG;    
    volatile uint32_t DMACX_SWHSDST_L_REG;    
    volatile uint32_t DMACX_SWHSDST_H_REG;    
    volatile uint32_t DMACX_BLK_TFR_L_REG;    
    volatile uint32_t DMACX_BLK_TFR_H_REG;    
    volatile uint32_t DMACX_AXI_ID_L_REG;    
    volatile uint32_t DMACX_AXI_ID_H_REG;    
    volatile uint32_t DMACX_AXI_QOS_L_REG;    
    volatile uint32_t DMACX_AXI_QOS_H_REG;				/* 0x338 */
    volatile uint32_t DMACX_SSTAT_L_REG;				
    volatile uint32_t DMACX_SSTAT_H_REG;				
    volatile uint32_t DMACX_DSTAT_L_REG;				
    volatile uint32_t DMACX_DSTAT_H_REG;			
    volatile uint32_t DMACX_SSTATAR_L_REG;				
    volatile uint32_t DMACX_SSTATAR_H_REG;				
    volatile uint32_t DMACX_DSTATAR_L_REG;				
    volatile uint32_t DMACX_DSTATAR_H_REG;				
    volatile uint32_t DMACX_INTSTATUS_EN_L_REG;		
    volatile uint32_t DMACX_INTSTATUS_EN_H_REG;				/* 0x338 */
    volatile uint32_t DMACX_INTSTATUS_L_REG;				
    volatile uint32_t DMACX_INTSTATUS_H_REG;				
    volatile uint32_t DMACX_INTSIGNAL_EN_L_REG;				
    volatile uint32_t DMACX_INTSIGNAL_EN_H_REG;			
    volatile uint32_t DMACX_INTCLEAR_L_REG;				
    volatile uint32_t DMACX_INTCLEAR_H_REG;	
    uint32_t reserved0[(0x100-0xa0)/4];									
}rsp_dmax_channel_t;

typedef struct
{
    volatile uint32_t DMACX_ID_L_REG;   
    volatile uint32_t DMACX_ID_H_REG;    
    volatile uint32_t DMACX_COMPVER_L_REG;    
    volatile uint32_t DMACX_COMPVER_H_REG;    
    volatile uint32_t DMACX_CFG_L_REG;    
    volatile uint32_t DMACX_CFG_H_REG;    
    volatile uint32_t DMACX_CHENA_L_REG;    
    volatile uint32_t DMACX_CHENA_H_REG;
    uint32_t reserved0[(0x30-0x18)/4];									
    volatile uint32_t DMACX_INTSTATUSR_L_REG;   
    volatile uint32_t DMACX_INTSTATUSR_H_REG;    
    volatile uint32_t DMACX_COM_INTCLEAR_L_REG;    
    volatile uint32_t DMACX_COM_INTCLEAR_H_REG;    
    volatile uint32_t DMACX_COM_INTSTATUS_EN_L_REG;    
    volatile uint32_t DMACX_COM_INTSTATUS_EN_H_REG;    
    volatile uint32_t DMACX_COM_INTSIGNAL_EN_L_REG;    
    volatile uint32_t DMACX_COM_INTSIGNAL_EN_H_REG;    
    volatile uint32_t DMACX_COM_INTSTATUS_L_REG;    
    volatile uint32_t DMACX_COM_INTSTATUS_H_REG;    
    uint32_t reserved1[(0x100-0x60)/4];									
   rsp_dmax_channel_t  dmax_channel[4];   
} rsp_dmax_t;

#define DMAX    ((rsp_dmax_t *)RSP_DMAX_BASE)

/**
 * I2C
 */
typedef struct {
    uint32_t IC_CON;               /**< Control register,  Address offset 0x00 */
    uint32_t IC_TAR;               /**< Target register,   Address offset 0x04 */
    uint32_t IC_SAR;               /**< Slave address,     Address offset 0x08 */
    uint32_t IC_HS_MADDR;          /**< HS Master mode code address, Address offset 0x0C */
    uint32_t IC_DATA_CMD;          /**< Rx/Tx Data Buffer and Command, Address offset 0x10 */
    uint32_t IC_SS_SCL_HCNT;       /**< Standard speed I2C Clock SCL High Count, Address offset 0x14 */
    uint32_t IC_SS_SCL_LCNT;       /**< Standard speed I2C Clock SCL Low Count, Address offset 0x18 */
    uint32_t IC_FS_SCL_HCNT;       /**< Fast Mode and Fast Mode Plus I2C Clock SCL High Count, Address offset 0x1C */
    uint32_t IC_FS_SCL_LCNT;       /**< Fast Mode and Fast Mode Plus I2C Clock SCL Low Count, Address offset 0x20 */
    uint32_t IC_HS_SCL_HCNT;       /**< High speed I2C Clock SCL High Count, Address offset 0x24 */
    uint32_t IC_HS_SCL_LCNT;       /**< High speed I2C Clock SCL Low Count, Address offset 0x28 */
    uint32_t IC_INTR_STAT;          /**< Interrupt Status, Address offset 0x2C */
    uint32_t IC_INTR_MASK;         /**< Interrupt Mask, Address offset 0x30 */
    uint32_t IC_RAW_INTR_STAT;      /**< Raw Interrupt Status, Address offset 0x34 */
    uint32_t IC_RX_TL;             /**< Receive FIFO Threshold, Address offset 0x38 */
    uint32_t IC_TX_TL;             /**< Transmit FIFO Threshold, Address offset 0x3C */
    uint32_t IC_CLR_INTR;           /**< Clear Combined and Individual Interrupts, Address offset 0x40 */
    uint32_t IC_CLR_RX_UNDER;       /**< Clear RX_UNDER Interrupt, Address offset 0x44 */
    uint32_t IC_CLR_RX_OVER;        /**< Clear RX_OVER Interrupt, Address offset 0x48 */
    uint32_t IC_CLR_TX_OVER;        /**< Clear TX_OVER Interrupt, Address offset 0x4C */
    uint32_t IC_CLR_RD_REQ;         /**< Clear RD_REQ Interrupt, Address offset 0x50 */
    uint32_t IC_CLR_TX_ABRT;        /**< Clear TX_ABRT Interrupt, Address offset 0x54 */
    uint32_t IC_CLR_RX_DONE;        /**< Clear RX_DONE Interrupt, Address offset 0x58 */
    uint32_t IC_CLR_ACTIVITY;       /**< Clear ACTIVITY Interrupt, Address offset 0x5C */
    uint32_t IC_CLR_STOP_DET;       /**< Clear STOP_DET Interrupt, Address offset 0x60 */
    uint32_t IC_CLR_START_DET;      /**< Clear START_DET Interrupt, Address offset 0x64 */
    uint32_t IC_CLR_GEN_CALL;       /**< Clear GEN_CALL Interrupt, Address offset 0x68 */
    uint32_t IC_ENABLE;            /**< I2C Enable,    Address offset 0x6C */
    uint32_t IC_STATUS;             /**< I2C Status register, Address offset 0x70 */
    uint32_t IC_TXFLR;              /**< Transmit FIFO Level register, Address offset 0x74 */
    uint32_t IC_RXFLR;              /**< Receive FIFO Level register, Address offset 0x78 */
    uint32_t IC_SDA_HOLD;          /**< SDA hold time length register, Address offset 0x7C */
    uint32_t IC_TX_ABRT_SOURCE;     /**< I2C Transmit Abort Status register, Address offset 0x80 */
    uint32_t IC_SLV_DATA_NACK_ONLY;/**< Generate SLV_DATA_NACK register, Address offset 0x84 */
    uint32_t IC_DMA_CR;            /**< DMA Control register for tx&rx handshaking interface, Address offset 0x88 */
    uint32_t IC_DMA_TDLR;          /**< DMA Transmit Data Level, Address offset 0x8C */
    uint32_t IC_DMA_RDLR;          /**< DMA Receive Data Level, Address offset 0x90 */
    uint32_t IC_SDA_SETUP;         /**< I2C SDA setup register, Address offset 0x94 */
    uint32_t IC_ACK_GENERAL_CALL;  /**< I2C ACK general call register, Address offset 0x98 */
    uint32_t IC_ENABLE_STATUS;      /**< I2C Enable status register, Address offset 0x9C */
    uint32_t IC_FS_SPKLEN;         /**< ISS and FS spike suppression limit, Address offset 0xA0 */
    uint32_t IC_HS_SPKLEN;         /**< HS spike suppression limit, Address offset 0xA4 */
    uint32_t IC_CLR_RESTART_DET;    /**< Clear RESTART_DET Interrupt, Address offset 0xA8 */
    uint32_t RSVD[(0xf4-0xa8)/4-1];
    uint32_t IC_COMP_PARAM_1;       /**< Component Parameter register, Address offset 0xF4 */
    uint32_t IC_COMP_VERSION;       /**< Component Version ID, Address offset 0xF8 */
    uint32_t IC_COMP_TYPE;          /**< DesignWare Component Type register, Address offset 0xFC */
}rsp_i2c_t;

#define I2C0 ((rsp_i2c_t *)RSP_I2C0_BASE)
#define I2C1 ((rsp_i2c_t *)RSP_I2C1_BASE)


/**
 * @name IC_CON - I2C Control Register
 * @{
 */
#define I2C_CON_STOP_DET_M_SHIFT                        (10U)
#define I2C_CON_STOP_DET_M_MASK                         (0x1U << I2C_CON_STOP_DET_M_SHIFT)
#define I2C_CON_STOP_DET_M(x)                           ((((uint32_t)(x)) << I2C_CON_STOP_DET_M_SHIFT) & I2C_CON_STOP_DET_M_MASK)
#define I2C_CON_RX_FIFO_FULL_HLD_SHIFT                  (9U)
#define I2C_CON_RX_FIFO_FULL_HLD_MASK                   (0x1U << I2C_CON_RX_FIFO_FULL_HLD_SHIFT)
#define I2C_CON_RX_FIFO_FULL_HLD(x)                     ((((uint32_t)(x)) << I2C_CON_RX_FIFO_FULL_HLD_SHIFT) & I2C_CON_RX_FIFO_FULL_HLD_MASK)
#define I2C_CON_TX_EMPTY_SHIFT                          (8U)
#define I2C_CON_TX_EMPTY_MASK                           (0x1U << I2C_CON_TX_EMPTY_SHIFT)
#define I2C_CON_TX_EMPTY(x)                             ((((uint32_t)(x)) << I2C_CON_TX_EMPTY_SHIFT) & I2C_CON_TX_EMPTY_MASK)
#define I2C_CON_STOP_DET_S_SHIFT                        (7U)
#define I2C_CON_STOP_DET_S_MASK                         (0x1U << I2C_CON_STOP_DET_S_SHIFT)
#define I2C_CON_STOP_DET_S(x)                           ((((uint32_t)(x)) << I2C_CON_STOP_DET_S_SHIFT) & I2C_CON_STOP_DET_S_MASK)
#define I2C_CON_SLAVE_DISABLE_SHIFT                     (6U)
#define I2C_CON_SLAVE_DISABLE_MASK                      (0x1U << I2C_CON_SLAVE_DISABLE_SHIFT)
#define I2C_CON_SLAVE_DISABLE(x)                        ((((uint32_t)(x)) << I2C_CON_SLAVE_DISABLE_SHIFT) & I2C_CON_SLAVE_DISABLE_MASK)
#define I2C_CON_RESTART_EN_SHIFT                        (5U)
#define I2C_CON_RESTART_EN_MASK                         (0x1U << I2C_CON_RESTART_EN_SHIFT)
#define I2C_CON_RESTART_EN(x)                           ((((uint32_t)(x)) << I2C_CON_RESTART_EN_SHIFT) & I2C_CON_RESTART_EN_MASK)
#define I2C_CON_MASTER_ADDRESS_BIT_SHIFT                (4U)
#define I2C_CON_MASTER_ADDRESS_BIT_MASK                 (0x1U << I2C_CON_MASTER_ADDRESS_BIT_SHIFT)
#define I2C_CON_MASTER_ADDRESS_BIT(x)                   ((((uint32_t)(x)) << I2C_CON_MASTER_ADDRESS_BIT_SHIFT) & I2C_CON_MASTER_ADDRESS_BIT_MASK)
#define I2C_CON_SLAVE_ADDRESS_BIT_SHIFT                 (3U)
#define I2C_CON_SLAVE_ADDRESS_BIT_MASK                  (0x1U << I2C_CON_SLAVE_ADDRESS_BIT_SHIFT)
#define I2C_CON_SLAVE_ADDRESS_BIT(x)                    ((((uint32_t)(x)) << I2C_CON_SLAVE_ADDRESS_BIT_SHIFT) & I2C_CON_SLAVE_ADDRESS_BIT_MASK)
#define I2C_CON_SPEED_SHIFT                             (1U)
#define I2C_CON_SPEED_MASK                              (0x3U << I2C_CON_SPEED_SHIFT)
#define I2C_CON_SPEED(x)                                ((((uint32_t)(x)) << I2C_CON_SPEED_SHIFT) & I2C_CON_SPEED_MASK)
#define I2C_CON_MASTER_EN_SHIFT                         (0U)
#define I2C_CON_MASTER_EN_MASK                          (0x1U << I2C_CON_MASTER_EN_SHIFT)
#define I2C_CON_MASTER_EN(x)                            ((((uint32_t)(x)) << I2C_CON_MASTER_EN_SHIFT) & I2C_CON_MASTER_EN_MASK)
/** @} */

/**
 * @name IC_TAR - I2C Target Address register 
 * @{
 */
#define I2C_TAR_MASTER_ADDRESS_BIT_SHIFT                (12U)
#define I2C_TAR_MASTER_ADDRESS_BIT_MASK                 (0x1U << I2C_TAR_MASTER_ADDRESS_BIT_SHIFT)
#define I2C_TAR_MASTER_ADDRESS_BIT(x)                   ((((uint32_t)(x)) << I2C_TAR_MASTER_ADDRESS_BIT_SHIFT) & I2C_TAR_MASTER_ADDRESS_BIT_MASK)
#define I2C_TAR_SPECIAL_SHIFT                           (11U)
#define I2C_TAR_SPECIAL_MASK                            (0x1U << I2C_TAR_SPECIAL_SHIFT)
#define I2C_TAR_SPECIAL(x)                              ((((uint32_t)(x)) << I2C_TAR_SPECIAL_SHIFT) & I2C_TAR_SPECIAL_MASK)
#define I2C_TAR_GC_OR_START_SHIFT                       (10U)
#define I2C_TAR_GC_OR_START_MASK                        (0x1U << I2C_TAR_GC_OR_START_SHIFT)
#define I2C_TAR_GC_OR_START(x)                          ((((uint32_t)(x)) << I2C_TAR_GC_OR_START_SHIFT) & I2C_TAR_GC_OR_START_MASK)
#define I2C_TAR_TAR_SHIFT                               (0U)
#define I2C_TAR_TAR_MASK                                (0x3FFU << I2C_TAR_TAR_SHIFT)
#define I2C_TAR_TAR(x)                                  ((((uint32_t)(x)) << I2C_TAR_TAR_SHIFT) & I2C_TAR_TAR_MASK)
/** @} */

/**
 * @name IC_SAR - I2C Slave Address register
 * @{
 */
#define I2C_SAR_SAR_SHIFT                               (0U)
#define I2C_SAR_SAR_MASK                                (0x3FFU << I2C_SAR_SAR_SHIFT)
#define I2C_SAR_SAR(x)                                  ((((uint32_t)(x)) << I2C_SAR_SAR_SHIFT) & I2C_SAR_SAR_MASK)
/** @} */

/**
 * @name IC_HS_MADDR - I2C High speed master mode code address register
 * @{
 */
#define I2C_HS_MAR_SHIFT                                (0U)
#define I2C_HS_MAR_MASK                                 (0x7U << I2C_HS_MAR_SHIFT)  
#define I2C_HS_MAR(x)                                   ((((uint32_t)(x)) << I2C_HS_MAR_SHIFT) & I2C_HS_MAR_MASK)                 
/** @} */

/**
 * @name IC_DATA_CMD - I2C Rx/Tx data buffer and command register
 * @{
 */
#define I2C_DATA_CMD_FIRST_BYTE_SHIFT                   (11U)
#define I2C_DATA_CMD_FIRST_BYTE_MASK                    (0x1U << I2C_DATA_CMD_FIRST_BYTE_SHIFT)
#define I2C_DATA_CMD_FIRST_BYYE(x)                      ((((uint32_t)(x)) << I2C_DATA_CMD_FIRST_BYTE_SHIFT) & I2C_DATA_CMD_FIRST_BYTE_MASK)
#define I2C_DATA_CMD_RESTART_SHIFT                      (10U)
#define I2C_DATA_CMD_RESTART_MASK                       (0x1U << I2C_DATA_CMD_RESTART_SHIFT)
#define I2C_DATA_CMD_RESTART(x)                         ((((uint32_t)(x)) << I2C_DATA_CMD_RESTART_SHIFT) & I2C_DATA_CMD_RESTART_MASK)
#define I2C_DATA_CMD_STOP_SHIFT                         (9U)
#define I2C_DATA_CMD_STOP_MASK                          (0x1U << I2C_DATA_CMD_STOP_SHIFT)
#define I2C_DATA_CMD_STOP(x)                            ((((uint32_t)(x)) << I2C_DATA_CMD_STOP_SHIFT) & I2C_DATA_CMD_STOP_MASK)
#define I2C_DATA_CMD_CMD_SHIFT                          (8U)
#define I2C_DATA_CMD_CMD_MASK                           (0x1U << I2C_DATA_CMD_CMD_SHIFT)
#define I2C_DATA_CMD_CMD(x)                             ((((uint32_t)(x)) << I2C_DATA_CMD_CMD_SHIFT) & I2C_DATA_CMD_CMD_MASK)
#define I2C_DATA_CMD_DAT_SHIFT                          (0U)
#define I2C_DATA_CMD_DAT_MASK                           (0xFFU << I2C_DATA_CMD_DAT_SHIFT)
#define I2C_DATA_CMD_DAT(x)                             ((((uint32_t)(x)) << I2C_DATA_CMD_DAT_SHIFT) & I2C_DATA_CMD_DAT_MASK)
/** @} */

/**
 * @name SS_SCL_HCNT - Standard Speed I2C Clock SCL High Count register
 * @{
 */
#define I2C_SS_SCL_HCNT_SHIFT                           (0U)
#define I2C_SS_SCL_HCNT_MASK                            (0xFFFFU << I2C_SS_SCL_HCNT_SHIFT)
#define I2C_SS_SCL_HCNT(x)                              ((((uint32_t)(x)) << I2C_SS_SCL_HCNT_SHIFT) & I2C_SS_SCL_HCNT_MASK)
/** @} */

/**
 * @name SS_SCL_LCNT - Standard Speed I2C Clock SCL Low Count register
 * @{
 */
#define I2C_SS_SCL_LCNT_SHIFT                           (0U)
#define I2C_SS_SCL_LCNT_MASK                            (0xFFFFU << I2C_SS_SCL_LCNT_SHIFT)
#define I2C_SS_SCL_LCNT(x)                              ((((uint32_t)(x)) << I2C_SS_SCL_LCNT_SHIFT) & I2C_SS_SCL_LCNT_MASK)
/** @} */

/**
 * @name FS_SCL_HCNT - Fast Mode or Fast Mode Plus I2C Clock SCL High Count register
 * @{
 */
#define I2C_FS_SCL_HCNT_SHIFT                           (0U)
#define I2C_FS_SCL_HCNT_MASK                            (0xFFFFU << I2C_FS_SCL_HCNT_SHIFT)
#define I2C_FS_SCL_HCNT(x)                              ((((uint32_t)(x)) << I2C_FS_SCL_HCNT_SHIFT) & I2C_FS_SCL_HCNT_MASK)
/** @} */

/**
 * @name FS_SCL_LCNT - Fast Mode or Fast Mode Plus I2C Clock SCL Low Count register
 * @{
 */
#define I2C_FS_SCL_LCNT_SHIFT                           (0U)
#define I2C_FS_SCL_LCNT_MASK                            (0xFFFFU << I2C_FS_SCL_LCNT_SHIFT)
#define I2C_FS_SCL_LCNT(x)                              ((((uint32_t)(x)) << I2C_FS_SCL_LCNT_SHIFT) & I2C_FS_SCL_LCNT_MASK)
/** @} */

/**
 * @name HS_SCL_HCNT - High Speed I2C Clock SCL High Count register
 * @{
 */
#define I2C_HS_SCL_HCNT_SHIFT                           (0U)
#define I2C_HS_SCL_HCNT_MASK                            (0xFFFFU << I2C_HS_SCL_HCNT_SHIFT)
#define I2C_HS_SCL_HCNT(x)                              ((((uint32_t)(x)) << I2C_HS_SCL_HCNT_SHIFT) & I2C_HS_SCL_HCNT_MASK)
/** @} */

/**
 * @name HS_SCL_LCNT - High Speed I2C Clock SCL Low Count register
 * @{
 */
#define I2C_HS_SCL_LCNT_SHIFT                           (0U)
#define I2C_HS_SCL_LCNT_MASK                            (0xFFFFU << I2C_HS_SCL_LCNT_SHIFT)
#define I2C_HS_SCL_LCNT(x)                              ((((uint32_t)(x)) << I2C_HS_SCL_LCNT_SHIFT) & I2C_HS_SCL_LCNT_MASK)
/** @} */

/**
 * @name INTR(Raw/Mask/Stat) - I2C (Raw) Interrupt Status/Mask register
 * @{
 */
#define I2C_INTR_MST_ON_HOLD_SHIFR                      (13U)
#define I2C_INTR_MST_ON_HOLD_MASK                       (0x1U << I2C_INTR_MST_ON_HOLD_SHIFR)
#define I2C_INTR_MST_ON_HOLD(x)                         ((((uint32_t)(x)) << I2C_INTR_MST_ON_HOLD_SHIFR) & I2C_INTR_MST_ON_HOLD_MASK)
#define I2C_INTR_RESTART_DET_SHIFT                      (12U)
#define I2C_INTR_RESTART_DET_MASK                       (0x1U << I2C_INTR_RESTART_DET_SHIFT)
#define I2C_INTR_RESTART_DET(x)                         ((((uint32_t)(x)) << I2C_INTR_RESTART_DET_SHIFT) & I2C_INTR_RESTART_DET_MASK)
#define I2C_INTR_GEN_CALL_SHIFT                         (11U)
#define I2C_INTR_GEN_CALL_MASK                          (0x1U << I2C_INTR_GEN_CALL_SHIFT)
#define I2C_INTR_GEN_CALL(x)                            ((((uint32_t)(x)) << I2C_INTR_GEN_CALL_SHIFT) & I2C_INTR_GEN_CALL_MASK)
#define I2C_INTR_START_DET_SHIFT                        (10U)
#define I2C_INTR_START_DET_MASK                         (0x1U << I2C_INTR_START_DET_SHIFT)
#define I2C_INTR_START_DET(x)                           ((((uint32_t)(x)) << I2C_INTR_START_DET_SHIFT) & I2C_INTR_START_DET_MASK)
#define I2C_INTR_STOP_DET_SHIFT                         (9U)
#define I2C_INTR_STOP_DET_MASK                          (0x1U << I2C_INTR_STOP_DET_SHIFT)
#define I2C_INTR_STOP_DET(x)                            ((((uint32_t)(x)) << I2C_INTR_STOP_DET_SHIFT) & I2C_INTR_STOP_DET_MASK)
#define I2C_INTR_ACTIVITY_SHIFT                         (8U)
#define I2C_INTR_ACTIVITY_MASK                          (0x1U << I2C_INTR_ACTIVITY_SHIFT)
#define I2C_INTR_ACTIVITY(x)                            ((((uint32_t)(x)) << I2C_INTR_ACTIVITY_SHIFT) & I2C_INTR_ACTIVITY_MASK)
#define I2C_INTR_RX_DONE_SHIFT                          (7U)
#define I2C_INTR_RX_DONE_MASK                           (0x1U << I2C_INTR_RX_DONE_SHIFT)
#define I2C_INTR_RX_DONE(x)                             ((((uint32_t)(x)) << I2C_INTR_RX_DONE_SHIFT) & I2C_INTR_RX_DONE_MASK)
#define I2C_INTR_TX_ABRT_SHIFT                          (6U)
#define I2C_INTR_TX_ABRT_MASK                           (0x1U << I2C_INTR_TX_ABRT_SHIFT)
#define I2C_INTR_TX_ABRT(x)                             ((((uint32_t)(x)) << I2C_INTR_TX_ABRT_SHIFT) & I2C_INTR_TX_ABRT_MASK)
#define I2C_INTR_RD_REQ_SHIFT                           (5U)
#define I2C_INTR_RD_REQ_MASK                            (0x1U << I2C_INTR_RD_REQ_SHIFT)
#define I2C_INTR_RD_REQ(x)                              ((((uint32_t)(x)) << I2C_INTR_RD_REQ_SHIFT) & I2C_INTR_RD_REQ_MASK)
#define I2C_INTR_TX_EMPTY_SHIFT                         (4U)
#define I2C_INTR_TX_EMPTY_MASK                          (0x1U << I2C_INTR_TX_EMPTY_SHIFT)
#define I2C_INTR_TX_EMPTY(x)                            ((((uint32_t)(x)) << I2C_INTR_TX_EMPTY_SHIFT) & I2C_INTR_TX_EMPTY_MASK)
#define I2C_INTR_TX_OVER_SHIFT                          (3U)
#define I2C_INTR_TX_OVER_MASK                           (0x1U << I2C_INTR_TX_OVER_SHIFT)
#define I2C_INTR_TX_OVER(x)                             ((((uint32_t)(x)) << I2C_INTR_TX_OVER_SHIFT) & I2C_INTR_TX_OVER_MASK)
#define I2C_INTR_RX_FULL_SHIFT                          (2U)
#define I2C_INTR_RX_FULL_MASK                           (0x1U << I2C_INTR_RX_FULL_SHIFT)
#define I2C_INTR_RX_FULL(x)                             ((((uint32_t)(x)) << I2C_INTR_RX_FULL_SHIFT) & I2C_INTR_RX_FULL_MASK)
#define I2C_INTR_RX_OVER_SHIFT                          (1U)
#define I2C_INTR_RX_OVER_MASK                           (0x1U << I2C_INTR_RX_OVER_SHIFT)
#define I2C_INTR_RX_OVER(x)                             ((((uint32_t)(x)) << I2C_INTR_RX_OVER_SHIFT) & I2C_INTR_RX_OVER_MASK)
#define I2C_INTR_RX_UNDER_SHIFT                         (0U)
#define I2C_INTR_RX_UNDER_MASK                          (0x1U << I2C_INTR_RX_UNDER_SHIFT)
#define I2C_INTR_RX_UNDER(x)                            ((((uint32_t)(x)) << I2C_INTR_RX_UNDER_SHIFT) & I2C_INTR_RX_UNDER_MASK)
/** @} */

/**
 * @name RX_TL - I2C Receive FIFO Threshold register
 * @{
 */
#define I2C_RX_TL_SHIFT                                 (0U)
#define I2C_RX_TL_MASK                                  (0xFFU << I2C_RX_TL_SHIFT)
#define I2C_RX_TL(x)                                    ((((uint32_t)(x)) << I2C_RX_TL_SHIFT) & I2C_RX_TL_MASK)
/** @} */

/**
 * @name TX_TL - I2C Transmit FIFO Threshold register
 * @{
 */
#define I2C_TX_TL_SHIFT                                 (0U)
#define I2C_TX_TL_MASK                                  (0xFFU << I2C_TX_TL_SHIFT)
#define I2C_TX_TL(x)                                    ((((uint32_t)(x)) << I2C_TX_TL_SHIFT) & I2C_TX_TL_MASK)
/** @} */

/**
 * @name CLR_INTR - Clear Combined and Individual Interrupt register
 * @{
 */
#define I2C_CLR_INTR_SHIFT                              (0U)
#define I2C_CLR_INTR_MASK                               (0x1U << I2C_CLR_INTR_SHIFT)
/** @} */

/**
 * @name CLR_RX_UNDER - Clear RX_UNDER Interrupt register
 * @{
 */
#define I2C_CLR_RX_UNDER_SHIFT                          (0U)
#define I2C_CLR_RX_UNDER_MASK                           (0x1U << I2C_CLR_RX_UNDER_SHIFT)
/** @} */

/**
 * @name CLR_RX_OVER - Clear RX_OVER Interrupt register
 * @{
 */
#define I2C_CLR_RX_OVER_SHIFT                           (0U)
#define I2C_CLR_RX_OVER_MASK                            (0x1U << I2C_CLR_RX_OVER_SHIFT)
/** @} */

/**
 * @name CLR_TX_OVER - Clear TX_OVER Interrupt register
 * @{
 */
#define I2C_CLR_TX_OVER_SHIFT                           (0U)
#define I2C_CLR_TX_OVER_MASK                            (0x1U << I2C_CLR_TX_OVER_SHIFT)
/** @} */

/**
 * @name CLR_RD_REQ - Clear RD_REQ Interrupt register
 * @{
 */
#define I2C_CLR_RD_REQ_SHIFT                            (0U)
#define I2C_CLR_RD_REQ_MASK                             (0x1U << I2C_CLR_RD_REQ_SHIFT)
/** @} */

/**
 * @name CLR_TX_ABRT - Clear TX_ABRT Interrupt register
 * @{
 */
#define I2C_CLR_TX_ABRT_SHIFT                           (0U)
#define I2C_CLR_TX_ABRT_MASK                            (0x1U << I2C_CLR_TX_ABRT_SHIFT)
/** @} */

/**
 * @name CLR_RX_DONE - Clear RX_DONE Interrupt register
 * @{
 */
#define I2C_CLR_RX_DONE_SHIFT                           (0U)
#define I2C_CLR_RX_DONE_MASK                            (0x1U << I2C_CLR_RX_DONE_SHIFT)
/** @} */

/**
 * @name CLR_ACTIVITY - Clear ACTIVITY Interrupt register
 * @{
 */
#define I2C_CLR_ACTIVITY_SHIFT                          (0U)
#define I2C_CLR_ACTIVITY_MASK                           (0x1U << I2C_CLR_ACTIVITY_SHIFT)
/** @} */

/**
 * @name CLR_STOP_DET - Clear STOP_DET Interrupt register
 * @{
 */
#define I2C_CLR_STOP_DET_SHIFT                          (0U)
#define I2C_CLR_STOP_DET_MASK                           (0x1U << I2C_CLR_STOP_DET_SHIFT)
/** @} */

/**
 * @name CLR_START_DET - Clear START_DET Interrupt register
 * @{
 */
#define I2C_CLR_START_DET_SHIFT                         (0U)
#define I2C_CLR_START_DET_MASK                          (0x1U << I2C_CLR_START_DET_SHIFT)
/** @} */

/**
 * @name CLR_GEN_CALL - Clear GEN_CALL Interrupt register
 * @{
 */
#define I2C_CLR_GEN_CALL_SHIFT                          (0U)
#define I2C_CLR_GEN_CALL_MASK                           (0x1U << I2C_CLR_GEN_CALL_SHIFT)
/** @} */

/**
 * @name ENABLE - I2C Enable register
 * @{
 */
#define I2C_ENABLE_TX_CMD_BLK_SHIFT                     (2U)
#define I2C_ENABLE_TX_CMD_BLK_MASK                      (0x1U << I2C_ENABLE_TX_CMD_BLK_SHIFT)
#define I2C_ENABLE_TX_CMD_BLK(x)                        ((((uint32_t)(x)) << I2C_ENABLE_TX_CMD_BLK_SHIFT) & I2C_ENABLE_TX_CMD_BLK_MASK)
#define I2C_ENABLE_ABORT_SHIFT                          (1U)
#define I2C_ENABLE_ABORT_MASK                           (0x1U << I2C_ENABLE_ABORT_SHIFT)
#define I2C_ENABLE_ABORT(x)                             ((((uint32_t)(x)) << I2C_ENABLE_ABORT_SHIFT) & I2C_ENABLE_ABORT_MASK)
#define I2C_ENABLE_SHIFT                                (0U)
#define I2C_ENABLE_MASK                                 (0x1U << I2C_ENABLE_SHIFT)
#define I2C_ENABLE(x)                                   ((((uint32_t)(x)) << I2C_ENABLE_SHIFT) & I2C_ENABLE_MASK)
/** @} */

/**
 * @name STATUS - I2C Status register
 * @{
 */
#define I2C_STATUS_SLV_HOLDRXFIFOFULL_SHIFT             (10U)
#define I2C_STATUS_SLV_HOLDRXFIFOFULL_MASK              (0x1U << I2C_STATUS_SLV_HOLDRXFIFOFULL_SHIFT)
#define I2C_STATUS_SLV_HOLDTXFIFOEMPTY_SHIFT            (9U)
#define I2C_STATUS_SLV_HOLDTXFIFOEMPTY_MASK             (0x1U << I2C_STATUS_SLV_HOLDTXFIFOEMPTY_SHIFT)
#define I2C_STATUS_MST_HOLDRXFIFOFULL_SHIFT             (8U)
#define I2C_STATUS_MST_HOLDRXFIFOFULL_MASK              (0x1U << I2C_STATUS_MST_HOLDRXFIFOFULL_SHIFT)
#define I2C_STATUS_MST_HOLDTXFIFOEMPTY_SHIFT            (7U)
#define I2C_STATUS_MST_HOLDTXFIFOEMPTY_MASK             (0x1U << I2C_STATUS_MST_HOLDTXFIFOEMPTY_SHIFT)
#define I2C_STATUS_SLV_ACTIVITY_SHIFT                   (6U)
#define I2C_STATUS_SLC_ACTIVITY_MASK                    (0x1U << I2C_STATUS_SLV_ACTIVITY_SHIFT)
#define I2C_STATUS_MST_ACTIVITY_SHIFT                   (5U)
#define I2C_STATUS_MST_ACTIVITY_MASK                    (0x1U << I2C_STATUS_MST_ACTIVITY_SHIFT)
#define I2C_STATUS_RFF_SHIFT                            (4U)
#define I2C_STATUS_RFF_MASK                             (0x1U << I2C_STATUS_RFF_SHIFT)
#define I2C_STATUS_RFNE_SHIFT                           (3U)
#define I2C_STATUS_RFNE_MASK                            (0x1U << I2C_STATUS_RFNE_SHIFT)
#define I2C_STATUS_TFE_SHIFT                            (2U)
#define I2C_STATUS_TFE_MASK                             (0x1U << I2C_STATUS_TFE_SHIFT)
#define I2C_STATUS_TFNF_SHIFT                           (1U)
#define I2C_STATUS_TFNF_MASK                            (0x1U << I2C_STATUS_TFNF_SHIFT)
#define I2C_STATUS_ACTIVITY_SHIFT                       (0U)
#define I2C_STATUS_ACTIVITY_MASK                        (0x1U << I2C_STATUS_ACTIVITY_SHIFT)
/** @} */

/**
 * @name SDA_HOLD - I2C SDA Hold Time Length register
 * @{
 */
#define I2C_SDA_RX_HOLD_SHIFT                           (16U)
#define I2C_SDA_RX_HOLD_MASK                            (0xFFU << I2C_SDA_RX_HOLD_SHIFT)
#define I2C_SDA_RX_HOLD(x)                              ((((uint32_t)(x)) << I2C_SDA_RX_HOLD_SHIFT) & I2C_SDA_RX_HOLD_MASK)
#define I2C_SDA_TX_HOLD_SHIFT                           (0U)
#define I2C_SDA_TX_HOLD_MASK                            (0xFFFFU << I2C_SDA_TX_HOLD_SHIFT)
#define I2C_SDA_TX_HOLD(x)                              ((((uint32_t)(x)) << I2C_SDA_TX_HOLD_SHIFT) & I2C_SDA_TX_HOLD_MASK)
/** @} */

/**
 * @name TX_ABRT_SOURCE - I2C Transmit Abort Source register
 * @{
 */
#define I2C_ABRT_TX_FLUSH_CNT_SHIFT                     (23U)
#define I2C_ABRT_TX_FLUSH_CNT_MASK                      (0x1FFU << I2C_ABRT_TX_FLUSH_CNT_SHIFT)
#define I2C_ABRT_USER_ABRT_SHIFT                        (16U)
#define I2C_ABRT_USER_ABRT_MASK                         (0x1U << I2C_ABRT_USER_ABRT_SHIFT)
#define I2C_ABRT_SLVRD_INTX_SHIFT                       (15U)
#define I2C_ABRT_SLVRD_INTX_MASK                        (0x1U << I2C_ABRT_SLVRD_INTX_SHIFT)
#define I2C_ABRT_SLV_ARBLOST_SHIFT                      (14U)
#define I2C_ABRT_SLV_ARBLOST_MASK                       (0x1U << I2C_ABRT_SLV_ARBLOST_SHIFT)
#define I2C_ABRT_SLVFLUSH_TXFIFO_SHIFT                  (13U)
#define I2C_ABRT_SLVFLUSH_TXFIFO_MASK                   (0x1U << I2C_ABRT_SLVFLUSH_TXFIFO_SHIFT)
#define I2C_ABRT_ARB_LOST_SHIFT                         (12U)
#define I2C_ABRT_ARB_LOST_MASK                          (0x1U << I2C_ABRT_ARB_LOST_SHIFT)
#define I2C_ABRT_MASTER_DIS_SHIFT                       (11U)
#define I2C_ABRT_MASTER_DIS_MASK                        (0x1U << I2C_ABRT_MASTER_DIS_SHIFT)
#define I2C_ABRT_10BRDNORSTRT_SHIFT                     (10U)
#define I2C_ABRT_10BRDNORSTRT_MASK                      (0x1U << I2C_ABRT_10BRDNORSTRT_SHIFT)
#define I2C_ABRT_SBYTENORSTRT_SHIFT                     (9U)
#define I2C_ABRT_SBYTENORSTRT_MASK                      (0x1U << I2C_ABRT_SBYTENORSTRT_SHIFT)
#define I2C_ABRT_HSNORSTRT_SHIFT                        (8U)
#define I2C_ABRT_HSNORSTRT_MASK                         (0x1U << I2C_ABRT_HSNORSTRT_SHIFT)
#define I2C_ABRT_SBYTE_ACKDET_SHIFT                     (7U)
#define I2C_ABRT_SBYTE_ACKDET_MASK                      (0x1U << I2C_ABRT_SBYTE_ACKDET_SHIFT)
#define I2C_ABRT_HSACKDET_SHIFT                         (6U)
#define I2C_ABRT_HSACKDET_MASK                          (0x1U << I2C_ABRT_HSACKDET_SHIFT)
#define I2C_ABRT_GCALL_READ_SHIFT                       (5U)
#define I2C_ABRT_GCALL_READ_MASK                        (0x1U << I2C_ABRT_GCALL_READ_SHIFT)
#define I2C_ABRT_GCALL_NOACK_SHIFT                      (4U)
#define I2C_ABRT_GCALL_NOACK_MASK                       (0x1U << I2C_ABRT_GCALL_NOACK_SHIFT)
#define I2C_ABRT_TXDATA_NOACK_SHIFT                     (3U)
#define I2C_ABRT_TXDATA_NOACK_MASK                      (0x1U << I2C_ABRT_TXDATA_NOACK_SHIFT)
#define I2C_ABRT_10ADDR2NOACK_SHIFT                     (2U)
#define I2C_ABRT_10ADDR2NOACK_MASK                      (0x1U << I2C_ABRT_10ADDR2NOACK_SHIFT)
#define I2C_ABRT_10ADDR1NOACK_SHIFT                     (1U)
#define I2C_ABRT_10ADDR1NOACK_MASK                      (0x1U << I2C_ABRT_10ADDR1NOACK_SHIFT)
#define I2C_ABRT_7ADDRNOACK_SHIFT                       (0U)
#define I2C_ABRT_7ADDRNOACK_MASK                        (0x1U << I2C_ABRT_7ADDRNOACK_SHIFT)
/** @} */

/**
 * @name SLV_DATA_NACK_ONLY - Generate Slave Data NACK register
 * @{
 */
#define I2C_SLV_DATA_NACK_SHIFT                         (0U)
#define I2C_SLV_DATA_NACK_MASK                          (0x1U << I2C_SLV_DATA_NACK_SHIFT)
#define I2C_SLV_DATA_NACK(x)                            ((((uint32_t)(x)) << I2C_SLV_DATA_NACK_SHIFT) & I2C_SLV_DATA_NACK_MASK)
/** @} */

/**
 * @name DMA_CR - DMA Control register
 * @{
 */
#define I2C_DMA_CR_TDMAE_SHIFT                          (1U)
#define I2C_DMA_CR_TDMAE_MASK                           (0x1U << I2C_DMA_CR_TDMAE_SHIFT)
#define I2C_DMA_CR_TDMAE(x)                             ((((uint32_t)(x)) << I2C_DMA_CR_TDMAE_SHIFT) & I2C_DMA_CR_TDMAE_MASK)
#define I2C_DMA_CR_RDMAE_SHIFT                          (0U)
#define I2C_DMA_CR_RDMAE_MASK                           (0x1U << I2C_DMA_CR_RDMAE_SHIFT)
#define I2C_DMA_CR_RDMAE(x)                             ((((uint32_t)(x)) << I2C_DMA_CR_RDMAE_SHIFT) & I2C_DMA_CR_RDMAE_MASK)
/** @} */

/**
 * @name DMA_SETUP - I2C SDA Setup register
 * @{
 */
#define I2C_SDA_SETUP_SHIFT                             (0U)
#define I2C_SDA_SETUP_MASK                              (0xFFU << I2C_SDA_SETUP_SHIFT)
#define I2C_SDA_SETUP(x)                                ((((uint32_t)(x)) << I2C_SDA_SETUP_SHIFT) & I2C_SDA_SETUP_MASK)
/** @} */

/**
 * @name ACK_GENERAL_CALL - ACK General Call register
 * @{
 */
#define I2C_ACK_GENERAL_CALL_SHIFT                      (0U)
#define I2C_ACK_GENERAL_CALL_MASK                       (0x1U << I2C_ACK_GENERAL_CALL_SHIFT)
#define I2C_ACK_GENERAL_CALL(x)                         ((((uint32_t)(x)) << I2C_ACK_GENERAL_CALL_SHIFT) & I2C_ACK_GENERAL_CALL_MASK)
/** @} */

/**
 * @name ENABLE_STATUS - I2C Enable Status register
 * @{
 */
#define I2C_ENABLE_ST_SLVRXDATALOST_SHIFT               (2U)
#define I2C_ENABLE_ST_SLVRXDATALOST_MASK                (0x1U << I2C_ENABLE_ST_SLVRXDATALOST_SHIFT)
#define I2C_ENABLE_ST_SLVDISABLEWHILEBUSY_SHIFT         (1U)
#define I2C_ENABLE_ST_SLVDISABLEWHILEBUSY_MASK          (0x1U << I2C_ENABLE_ST_SLVDISABLEWHILEBUSY_SHIFT)
#define I2C_ENABLE_ST_EN_SHIFT                          (0U)
#define I2C_ENABLE_ST_EN_MASK                           (0x1U << I2C_ENABLE_ST_EN_SHIFT)
/** @} */

/**
 * @name FS_SPKLEN - I2C SS and FS Spike Suppression Limit register
 * @{
 */
#define I2C_FS_SPKLEN_SHIFT                             (0U)
#define I2C_FS_SPKLEN_MASK                              (0xFFU << I2C_FS_SPKLEN_SHIFT)
#define I2C_FS_SPKLEN(x)                                ((((uint32_t)(x)) << I2C_FS_SPKLEN_SHIFT) & I2C_FS_SPKLEN_MASK)
/** @} */

/**
 * @name HS_SPKLEN - I2C HS Spike Suppression Limit register
 * @{
 */
#define I2C_HS_SPKLEN_SHIFT                             (0U)
#define I2C_HS_SPKLEN_MASK                              (0xFFU << I2C_HS_SPKLEN_SHIFT)
#define I2C_HS_SPKLEN(x)                                ((((uint32_t)(x)) << I2C_HS_SPKLEN_SHIFT) & I2C_HS_SPKLEN_MASK)
/** @} */

/**
 * @name CLR_RESTART_DET - Clear restart_det Interrupt register
 * @{
 */
#define I2C_CLR_RESTART_DET_SHIFT                       (0U)
#define I2C_CLR_RESTART_DET_MASK                        (0x1U << I2C_CLR_RESTART_DET_SHIFT)
/** @} */

/**
 * @name COMP_PARAM_1 - Component Parameter register 1
 * @{
 */
#define I2C_COMPPARAM_TXBUFFERDEPTH_SHIFT               (16U)
#define I2C_COMPPARAM_TXBUFFERDEPTH_MASK                (0xFFU << I2C_COMPPARAM_TXBUFFERDEPTH_SHIFT)
#define I2C_COMPPARAM_RXBUFFERDEPTH_SHIFT               (8U)
#define I2C_COMPPARAM_RXBUFFERDEPTH_MASK                (0xFFU << I2C_COMPPARAM_RXBUFFERDEPTH_SHIFT)
#define I2C_COMPPARAM_ADDENCODEDPARAMS_SHIFT            (7U)
#define I2C_COMPPARAM_ADDENCODEDPARAMS_MASK             (0x1U << I2C_COMPPARAM_ADDENCODEDPARAMS_SHIFT)
#define I2C_COMPPARAM_HASDMA_SHIFT                      (6U)
#define I2C_COMPPARAM_HASDMA_MASK                       (0x1U << I2C_COMPPARAM_HASDMA_SHIFT)
#define I2C_COMPPARAM_INTRIO_SHIFT                      (5U)
#define I2C_COMPPARAM_INTRIO_MASK                       (0x1U << I2C_COMPPARAM_INTRIO_SHIFT)
#define I2C_COMPPARAM_HCCOUNTVALUES_SHIFT               (4U)
#define I2C_COMPPARAM_HCCOUNTVALUES_MASK                (0x1U << I2C_COMPPARAM_HCCOUNTVALUES_SHIFT)
#define I2C_COMPPARAM_MAXSPEEDMODE_SHIFT                (2U)
#define I2C_COMPPARAM_MAXSPEEDMODE_MASK                 (0x3U << I2C_COMPPARAM_MAXSPEEDMODE_SHIFT)
#define I2C_COMPPARAM_APBDATAWIDTH_SHIFT                (0U)
#define I2C_COMPPARAM_APBDATAWIDTH_MASK                 (0x1U << I2C_COMPPARAM_APBDATAWIDTH_SHIFT)
/** @} */

/*---------------------------------------------------------------------------*/
/* Program related define                                                    */
/*---------------------------------------------------------------------------*/

#define rsp_writel(a, v)	   (*(volatile uint32_t *)(a) = (v))
#define rsp_readl(a)		   (*(volatile uint32_t *)(a))


#ifdef __cplusplus
}
#endif

#endif /* __RSP_H__ */
