/**
  ******************************************************************************
  * @file    rsp_hal_gpio.h
  * @author  Tsinghua University
  * @brief   
  ******************************************************************************
  */

#ifndef __RSP_HAL_GPIO_H__
#define __RSP_HAL_GPIO_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "rsp.h"

enum
{
    RSP_GPIO_INPUT = 0,
    RSP_GPIO_OUTPUT,
};

enum 
{
    RSP_GPIO_PIN_0   = 0x00000001,
    RSP_GPIO_PIN_1   = 0x00000002,
    RSP_GPIO_PIN_2   = 0x00000004,
    RSP_GPIO_PIN_3   = 0x00000008,
    RSP_GPIO_PIN_4   = 0x00000010,
    RSP_GPIO_PIN_5   = 0x00000020,
    RSP_GPIO_PIN_6   = 0x00000040,
    RSP_GPIO_PIN_7   = 0x00000080,
    RSP_GPIO_PIN_8   = 0x00000100,
    RSP_GPIO_PIN_9   = 0x00000200,
    RSP_GPIO_PIN_10  = 0x00000400,
    RSP_GPIO_PIN_11  = 0x00000800,
    RSP_GPIO_PIN_12  = 0x00001000,
    RSP_GPIO_PIN_13  = 0x00002000,
    RSP_GPIO_PIN_14  = 0x00004000,
    RSP_GPIO_PIN_15  = 0x00008000,
    RSP_GPIO_PIN_ALL = 0x0000ffff,
};

enum
{
	RSP_GPIO_INT_LOW = 0,
	RSP_GPIO_INT_HIGH,
	RSP_GPIO_INT_RISING,
	RSP_GPIO_INT_FALING,
};

enum
{
    RSP_GPIO_LOW = 0,
    RSP_GPIO_HIGH,
};

enum
{
    RSP_GPIO_PULL_NONE = 0,
    RSP_GPIO_PULL_UP,
    RSP_GPIO_PULL_DOWN,
};

#define IS_GPIO_PORT(PORT) (((PORT) == GPIOA) || ((PORT) == GPIOB))
#define IS_GPIO_PIN(PIN)  (((PIN) == RSP_GPIO_PIN_0) || \
                              ((PIN) == RSP_GPIO_PIN_1) || \
                              ((PIN) == RSP_GPIO_PIN_2) || \
                              ((PIN) == RSP_GPIO_PIN_3) || \
                              ((PIN) == RSP_GPIO_PIN_4) || \
                              ((PIN) == RSP_GPIO_PIN_5) || \
                              ((PIN) == RSP_GPIO_PIN_6) || \
                              ((PIN) == RSP_GPIO_PIN_7) || \
                              ((PIN) == RSP_GPIO_PIN_8) || \
                              ((PIN) == RSP_GPIO_PIN_9) || \
                              ((PIN) == RSP_GPIO_PIN_10) || \
                              ((PIN) == RSP_GPIO_PIN_11) || \
                              ((PIN) == RSP_GPIO_PIN_12) || \
                              ((PIN) == RSP_GPIO_PIN_13) || \
                              ((PIN) == RSP_GPIO_PIN_14) || \
                              ((PIN) == RSP_GPIO_PIN_15))
#define IS_GPIO_DIR(DIR) (((DIR) == RSP_GPIO_INPUT) || ((DIR) == RSP_GPIO_OUTPUT))
#define IS_GPIO_VAL(VAL) (((VAL) == RSP_GPIO_LOW) || ((VAL) == RSP_GPIO_HIGH))
#define IS_GPIO_PULL(TYPE) (((TYPE) == RSP_GPIO_PULL_NONE) || ((TYPE) == RSP_GPIO_PULL_UP) || ((TYPE) == RSP_GPIO_PULL_DOWN))

/**
 * @brief 设置GPIO输入输出方向
 * @param  gpio 设置A/B哪一组寄存器
 * @param  pin 设置的pin编号
 * @param  dir 选择输入/输出
 * @return int32_t 返回成功/失败
 */
int32_t rsp_hal_gpio_set_dir(rsp_gpio_t *gpio, uint32_t pin, uint32_t dir);

/**
 * @brief 设置GPIO输出电平
 * @param  gpio 设置A/B哪一组寄存器
 * @param  pin 设置的pin编号
 * @param  val 设置pin的电平高/低
 * @return RAMFUNC int32_t 返回成功/失败
 */
RAMFUNC int32_t rsp_hal_gpio_set_pin(rsp_gpio_t *gpio, uint32_t pin, uint32_t val);

RAMFUNC int32_t rsp_hal_gpio_set_all_pin_pull_up(rsp_gpio_t *gpio, uint32_t pin, uint32_t type);

/**
 * @brief 读取GPIO当前电平状态
 * @param  gpio 设置A/B哪一组寄存器
 * @param  pin 设置的pin编号
 * @param  val 读取pin的电平高/低
 * @return RAMFUNC int32_t 返回成功/失败
 */
RAMFUNC int32_t rsp_hal_gpio_get_pin(rsp_gpio_t *gpio, uint32_t pin, uint32_t *val);

/**
 * @brief 使能GPIO中断
 * @param  gpio 设置A/B哪一组寄存器
 * @param  pin 设置的pin编号
 * @param  type 设置中断触发类型
 * @return int32_t 返回成功/失败
 */
int32_t rsp_hal_gpio_enable_interrupt(rsp_gpio_t *gpio, uint32_t pin, uint32_t type);

#ifdef __cplusplus
}
#endif

#endif /* __RSP_HAL_GPIO_H__ */
