/**
  ******************************************************************************
  * @file    rsp_hal_tim.h
  * @author  Tsinghua University
  * @brief   
  ******************************************************************************
  */

#ifndef __RSP_HAL_TIM_H__
#define __RSP_HAL_TIM_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "rsp.h"

enum
{
    RSP_TIM_DIV_1 = 0,
    RSP_TIM_DIV_2,
    RSP_TIM_DIV_4,
    RSP_TIM_DIV_8,
    RSP_TIM_DIV_16,
    RSP_TIM_DIV_32,
    RSP_TIM_DIV_64,
    RSP_TIM_DIV_128,
};

enum
{
    RSP_TIM_0 = 0,
    RSP_TIM_1,
    RSP_TIM_2,
    RSP_TIM_3,
    RSP_TIM_MAX,
};

/**
 * @brief 使能定时器
 * @param  tim 定时器编号
 */
RAMFUNC void rsp_hal_tim_enable(uint32_t tim);

/**
 * @brief 关闭定时器
 * @param  tim 定时器编号
 */
RAMFUNC void rsp_hal_tim_disable(uint32_t tim);

/**
 * @brief 使能定时器中断
 * @param  tim 定时器编号
 */
RAMFUNC void rsp_hal_tim_enable_irq(uint32_t tim);

/**
 * @brief 关闭定时器中断
 * @param  tim 定时器编号
 */
RAMFUNC void rsp_hal_tim_disable_irq(uint32_t tim);

/**
 * @brief 设置定时器计数值
 * @param  tim 定时器编号
 * @param  value 需要设定的计数值（counter数一下的时间是apbclk一个周期）
 */
RAMFUNC void rsp_hal_tim_set_load_counter(uint32_t tim, uint32_t value);

/**
 * @brief 设置定时器当前计数值
 * @param  tim 定时器编号
 * @param  value 需要设定的当前计数值（counter数一下的时间是apbclk一个周期）
 */
RAMFUNC void rsp_hal_tim_set_counter(uint32_t tim, uint32_t value);

/**
 * @brief 设置定时器分频
 * @param  tim 定时器编号
 * @param  value 需要设置的分频值
 */
RAMFUNC void rsp_hal_tim_set_div(uint32_t tim, uint32_t value);

/**
 * @brief 清除定时器中断标志（不需要中断使能）
 * @param  tim 定时器编号
 */
RAMFUNC void rsp_hal_tim_clear_interrupt_flag(uint32_t tim);

/**
 * @brief 清除所有通道定时器中断状态（需要中断使能）
 */
RAMFUNC void rsp_hal_tim_clear_interrupt_status(void);

/**
 * @brief 读取定时器当前计数
 * @param  tim 定时器编号
 * @return RAMFUNC uint32_t 返回定时器当前计数值
 */
RAMFUNC uint32_t rsp_hal_tim_get_counter(uint32_t tim);

/**
 * @brief 读取定时器中断状态
 * @param  tim 定时器编号
 * @return RAMFUNC uint32_t 返回定时器中断状态值（bit0）
 */
RAMFUNC uint32_t rsp_hal_tim_get_interrupt_status(uint32_t tim);

#ifdef __cplusplus
}
#endif

#endif /* __RSP_HAL_TIM_H__ */
