#ifndef _RSP_HAL_I2C_H_
#define _RSP_HAL_I2C_H_

#ifdef __cplusplus
extern "C" {
#endif


/** @addtogroup RSP_HAL_Driver
 * @{
 */

/** @addtogroup I2C
 * @{ 
 */
 

#define I2C_DELAY (1000*10000)
#define RETRY_TIMES 10
#define IS_I2C(I2C) (((I2C) == I2C0) || ((I2C) == I2C1))

///IIC ID枚举值
typedef enum
{
    RSP_IIC_0       =0,
    RSP_IIC_1,
}I2C_NUM_E;

///IIC 模式枚举值
typedef enum
{
    I2C_MODE_MASTER = 0,
    I2C_MODE_SLAVE,
}IIC_MODE_E;

///IIC参数配置数据结构
typedef struct 
{
    uint32_t mode; //master or slave
    uint32_t speed; //standard or fast or high
    uint32_t address_bits; //7 or 10bit
    uint8_t  address; //address to write or read
} rsp_i2c_param_t;

///IIC句柄数据结构
typedef struct
{
    I2C_NUM_E                  port;
    rsp_i2c_param_t*            param;         /* SPI communication parameters */
}i2c_handle_t;

///IIC 速率枚举值
typedef enum {
    I2C_SPEED_NORMAL_100K       = 0,
    I2C_SPEED_FAST_400K         = 1,
    I2C_SPEED_FAST_1000K        = 2,
    I2C_SPEED_HIGH_3400K_400PF  = 3,
    I2C_SPEED_HIGH_3400K_100PF  = 4,
}I2C_SPEED;

///IIC地址枚举值
typedef enum {
    I2C_MASTER_ADDRESS_7BIT     = 1,
    I2C_MASTER_ADDRESS_10BIT    = 2,
    I2C_SLAVE_ADDRESS_7BIT      = 3,
    I2C_SLAVE_ADDRESS_10BIT     = 4,
}I2C_ADDRESS_BIT;

/**
 * @brief IIC初始化
 * @param  i2c
 * @return int32_t 
 */
int rsp_hal_i2c_dw_init(i2c_handle_t *i2c);

/**
 * @brief 等待I2C空闲
 * @param  port @ref I2C_NUM_E
 * @param  timeout 
 * @return int32_t 
 */
int rsp_hal_i2c_dw_wait_idle(I2C_NUM_E port, uint32_t timeout);

/**
 * @brief 
 * @param  port
 * @param  timeout 
 * @param  ic_en 
 * @return int32_t 
 */
int rsp_hal_i2c_dw_wait_ic_en(I2C_NUM_E port, uint32_t timeout, uint32_t ic_en);

/**
 * @brief  等I2C到status状态
 * @param  port 
 * @param  status 状态
 * @param  timeout 单位ms
 * @return int32_t
 */
int rsp_hal_i2c_dw_wait_status(I2C_NUM_E port, uint32_t status, uint32_t timeout);

/****************************polling mode****************/
/**
 * @brief  Master发送数据
 * @param  port 
 * @param  data 发送数据缓冲区
 * @param  len 发送数据长度，单位byte
 * @return int32_t
 */
int rsp_hal_i2c_dw_master_transmit(I2C_NUM_E port, uint8_t *data, uint8_t len);
/**
 * @brief  Master接受数据
 * @param  port 
 * @param  data 接收数据缓冲区
 * @param  len 接收数据长度，单位byte
 * @return int32_t
 */
int rsp_hal_i2c_dw_master_receive(I2C_NUM_E port, uint8_t *data, uint8_t len);
/**
 * @brief  Slave发送数据
 * @param  port 
 * @param  data 接收数据缓冲区
 * @param  len 接收数据长度，单位byte
 * @return int32_t
 */
int rsp_hal_i2c_dw_slave_transmit(I2C_NUM_E port, uint8_t *data, uint8_t len);
/**
 * @brief  Slave接收数据
 * @param  port 
 * @param  data 接收数据缓冲区
 * @param  len 接收数据长度，单位byte
 * @return int32_t
 */
int rsp_hal_i2c_dw_slave_receive(I2C_NUM_E port, uint8_t *data, uint8_t len);
int rsp_hal_i2c_dw_slave_transmit_ok(I2C_NUM_E port, uint8_t *data, uint8_t len);
int rsp_hal_i2c_dw_slave_receive_temp_lkb(I2C_NUM_E port);

int rsp_hal_i2c_dw_master_write(I2C_NUM_E port, uint8_t addr, uint8_t *data, uint8_t len);
int rsp_hal_i2c_dw_master_read(I2C_NUM_E port, uint8_t addr, uint8_t *data, uint8_t len);

/****************************INT mode****************/

/****************************DMA mode****************/

/** @} */

/** @} */
#ifdef __cplusplus
}
#endif


#endif//_RSP_IIC_H_
