/**
  ******************************************************************************
  * @file    rsp_hal_misc.h
  * @author  Tsinghua University
  * @brief   
  ******************************************************************************
  */

#ifndef __RSP_HAL_MISC_H__
#define __RSP_HAL_MISC_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "rsp.h"

#if 1
#define RSP_HAL_DEBUG_INFO(...)
#else
#define RSP_HAL_DEBUG_INFO printf
#endif

enum
{
	SENSOR_TEMP = 0,
	SENSOR_DVDD,
	SENSOR_AVDD,
};

extern uint32_t _sbss;
extern uint32_t _ebss;
extern uint32_t _sdata;
extern uint32_t _edata;
extern uint32_t __sidata;

/**
 * @brief 延时函数初始化
 */
RAMFUNC void rsp_hal_delay_init(void);

/**
 * @brief 设置延时函数为未初始化状态
 */
RAMFUNC void rsp_hal_delay_uninit(void);

/**
 * @brief 微秒延时
 * @param  us 设置延时时间
 */
RAMFUNC void rsp_hal_udelay(uint32_t us);

/**
 * @brief 毫秒延时
 * @param  ms 设置延时时间
 */
RAMFUNC void rsp_hal_mdelay(uint32_t ms);

/**
 * @brief 获取当前微秒计数
 * @return RAMFUNC uint32_t 返回当前微秒计数
 */
RAMFUNC uint32_t rsp_hal_get_us(void);

#ifdef __cplusplus
}
#endif

#endif /* __RSP_HAL_MISC_H__ */
