/**
  ******************************************************************************
  * @file    rsp_hal_spi.h
  * @author  Tsinghua University
  * @brief   
  ******************************************************************************
  */

#ifndef __RSP_HAL_SPI_H__
#define __RSP_HAL_SPI_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
  * @brief 读取flash JEDEC id
  * @return RAMFUNC uint32_t 返回读取的id值（1个byte厂商ID，2个byte设备id）
  */
uint32_t rsp_hal_spi_read_id(void);

/**
  * @brief 全flash芯片擦除
  * @return RAMFUNC int32_t 返回成功/失败
  */
int32_t rsp_hal_spi_chip_erase(uint32_t timeout);

/**
  * @brief 读取flash数据（起始地址+长度不能大于spi所挂载的flash容量）
  * @param address 输入要读取的地址
  * @param address 输入要读取的数据指针
  * @param address 输入要读取的长度（byte）
  * @return RAMFUNC int32_t 返回成功/失败
  */
int32_t rsp_hal_spi_read(uint32_t addr, void *data, uint32_t size);

/**
  * @brief 写入flash数据（起始地址+长度不能大于spi所挂载的flash容量）
  * @param address 输入要写入的地址
  * @param address 输入要写入的数据指针
  * @param address 输入要写入的长度（byte）
  * @return RAMFUNC int32_t 返回成功/失败
  */
int32_t rsp_hal_spi_write(uint32_t addr, void *data, uint32_t size);

/**
  * @brief 初始化spi模块
  * @return RAMFUNC int32_t 返回成功/失败
  */
int32_t rsp_hal_spi_init(void);

#ifdef __cplusplus
}
#endif

#endif /* __RSP_HAL_SPI_H__ */
