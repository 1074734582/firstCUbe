/*
*****************************************************************************
**
**  File        : PQC25_RAM.ld
**
**  Abstract    : Linker script for PQC25 Device 
**
**                Set heap size, stack size and stack location according
**                to application requirements.
**
**                Set memory bank area and size if external memory is used.
**
**  Target      : Tsinghua University
**
**
**  Distribution: The file is distributed as is, without any warranty
**                of any kind.
**
**  (c)Copyright Ac6.
**  You may use this file as-is or modify it according to the needs of your
**  project. Distribution of this file (unmodified or modified) is not
**  permitted. Ac6 permit registered System Workbench for MCU users the
**  rights to distribute the assembled, compiled & linked contents of this
**  file as part of an application binary file, provided that it is built
**  using the System Workbench for MCU toolchain.
**
*****************************************************************************
*/

OUTPUT_FORMAT("elf32-littlearm")
OUTPUT_ARCH(arm)

/* Entry Point */
ENTRY(Reset_Handler)

__estack = 0x20020000;   /* 64k end of RAM */
__vector = 0x20000000;
/* Generate a link error if heap and stack don't fit into RAM */
_Min_Heap_Size = 0x800;      /* required amount of heap  0x800 2KB*/
//_Min_Heap_Size = 0x00;      /* required amount of heap  0x800 2KB*/

_Min_Stack_Size = 0x800;     /* required amount of stack 0x800 2KB*/

/* Specify the memory areas */

MEMORY
{
    ROM (rx)       : ORIGIN = 0x00000000, LENGTH = 0x800         /* ROM 4KB  */
    RAM (xrw)      : ORIGIN = 0x20000000, LENGTH = 0x1F000       /* RAM 124KB */
}

/* Define output sections */
SECTIONS
{
    /* The startup code goes first into ROM */
    .isr_vector :
    {
        _svec = .;
        . = ALIGN(4);
        KEEP(*(.isr_vector)) /* Startup code */
        . = ALIGN(4);
    } >RAM

    /* The program code and other data goes into ROM */
    .text :
    {
	    _stext = .;
		
        . = ALIGN(4);
        *(.text)             /* .text sections (code) */
        *(.text*)            /* .text* sections (code) */
        *(.glue_7)           /* glue arm to thumb code */
        *(.glue_7t)          /* glue thumb to arm code */
        *(.eh_frame)

        libc.a (.text .text*)
        libgcc.a (.text .text*)
        libnosys.a (.text .text*)

        KEEP (*(.init))
        KEEP (*(.fini))

        . = ALIGN(4);
        __etext = .;          /* define a global symbols at end of code */
		
		_etext = .;
    } >RAM

    /* Constant data goes into ROM */
    .rodata :
    {
        . = ALIGN(4);
        *(.rodata)           /* .rodata sections (constants, strings, etc.) */
        *(.rodata*)          /* .rodata* sections (constants, strings, etc.) */
        . = ALIGN(4);
    } >RAM

    .ARM.extab : 
	{ 
        . = ALIGN(4);
        *(.ARM.extab* .gnu.linkonce.armextab.*)
        . = ALIGN(4);
    } >RAM
	
    .ARM : 
	{
        . = ALIGN(4);
        __exidx_start = .;
        *(.ARM.exidx*)
        __exidx_end = .;
        . = ALIGN(4);
    } >RAM

    .preinit_array :
    {
	    . = ALIGN(4);
        PROVIDE_HIDDEN (__preinit_array_start = .);
        KEEP (*(.preinit_array*))
        PROVIDE_HIDDEN (__preinit_array_end = .);
		. = ALIGN(4);
    } >RAM
  
    .init_array :
    {
	    . = ALIGN(4);
        PROVIDE_HIDDEN (__init_array_start = .);
        KEEP (*(SORT(.init_array.*)))
        KEEP (*(.init_array*))
        PROVIDE_HIDDEN (__init_array_end = .);
		. = ALIGN(4);
    } >RAM
	
    .fini_array :
    {
	    . = ALIGN(4);
        PROVIDE_HIDDEN (__fini_array_start = .);
        KEEP (*(SORT(.fini_array.*)))
        KEEP (*(.fini_array*))
        PROVIDE_HIDDEN (__fini_array_end = .);
		. = ALIGN(4);
    } >RAM
  
    __rom_end = .;

    /* used by the startup to initialize data */
	_sidata = LOADADDR(.data);
    __sidata = LOADADDR(.data);

    /* Initialized data sections goes into RAM, load LMA copy after code */
    .data : 
    {
        . = ALIGN(4);
		_sdata = .;   
        __sdata = .;          /* create a global symbol at data start */
        *(.data)             /* .data sections */
        *(.data*)            /* .data* sections */

        . = ALIGN(4);
        __rom2ram_start = .;
        *(.ramfunc);
        __rom2ram_end = .;

        . = ALIGN(4);
		_edata = .; 
        __edata = .;          /* define a global symbol at data end */
    } >RAM
  
    /* Uninitialized data section */
    . = ALIGN(4);
    .bss :
    {
        /* This is used by the startup in order to initialize the .bss secion */
		_sbss = .; 
        __sbss = .;           /* define a global symbol at bss start */
        __bss_start__ = __sbss;
        *(.bss)
        *(.bss*)
        *(COMMON)

        . = ALIGN(4);
		_ebss = .; 
        __ebss = .;           /* define a global symbol at bss end */
        __bss_end__ = __ebss;
    } >RAM

    ._user_heap_stack :
    {
        . = ALIGN(8);
        PROVIDE ( end = . ); /* In function `_sbrk': sbrk.c:(.text._sbrk+0x28): undefined reference to `end' */
        PROVIDE ( _end = . );
        PROVIDE ( __end__ = . );
        . = . + _Min_Heap_Size;
        . = . + _Min_Stack_Size;
        . = ALIGN(8);
    } >RAM
  
    .ARM.attributes 0 : 
	{ 
        *(.ARM.attributes) 
	}
}
