/**
  *************** (C) COPYRIGHT 2017 Tsinghua University ************************
  * @file      startup.s
  * @author    Tsinghua
  * @brief     
  ******************************************************************************
  */

    .syntax unified
    .arch   armv7-m
    .cpu    cortex-m3
    .fpu    softvfp
    .thumb

.global g_pfnVectors
.global Default_Handler

/* start address for the initialization values of the .data section.
defined in linker script */
.word __sidata
/* start address for the .data section. defined in linker script */
.word __sdata
/* end address for the .data section. defined in linker script */
.word __edata
/* start address for the .bss section. defined in linker script */
.word __sbss
/* end address for the .bss section. defined in linker script */
.word __ebss

/**
 * @brief  This is the code that gets called when the processor first
 *          starts execution following a reset event. Only the absolutely
 *          necessary set is performed, after which the application
 *          supplied main() routine is called.
 * @param  None
 * @retval : None
*/

    .section .text.Reset_Handler
    .weak Reset_Handler
    .type Reset_Handler, %function
	
Reset_Handler:
    cpsie i
    cpsie f
    ldr    r0, =__estack
    mov    sp, r0;

   
    /* Redirect isr_vector. */
    ldr    r0, =0xE000ED08;
    ldr    r1, =__vector;
    str    r1, [r0];

    /* Jump to c code */
    bl     main
    bx     lr

.size      Reset_Handler, .-Reset_Handler

/**
 * @brief  This is the code that gets called when the processor receives an
 *         unexpected interrupt.  This simply enters an infinite loop, preserving
 *         the system state for examination by a debugger.
 *
 * @param  None
 * @retval : None
*/
    .section .text.Default_Handler,"ax",%progbits
Default_Handler:
Infinite_Loop:
    b      Infinite_Loop
.size      Default_Handler, .-Default_Handler

/******************************************************************************
*
* The minimal vector table for a Cortex M3.  Note that the proper constructs
* must be placed on this to ensure that it ends up at physical address
* 0x0000.0000.
*
******************************************************************************/
    .section .isr_vector,"a",%progbits
    .type  g_pfnVectors, %object
    .size  g_pfnVectors, .-g_pfnVectors


g_pfnVectors:
    .word  __estack
    .word  Reset_Handler
    .word  NMI_Handler
    .word  HardFault_Handler
    .word  MemManage_Handler
    .word  BusFault_Handler
    .word  UsageFault_Handler
    .word  0
    .word  0
    .word  0
    .word  0
    .word  SVC_Handler
    .word  DebugMon_Handler
    .word  0
    .word  PendSV_Handler
    .word  SysTick_Handler
	
    .word  GPIO_0_IRQHandler /* 00 */
    .word  GPIO_1_IRQHandler /* 01 */
    .word  GPIO_2_IRQHandler /* 02 */
    .word  GPIO_3_IRQHandler /* 03 */
    .word  GPIO_4_IRQHandler /* 04 */
    .word  GPIO_5_IRQHandler /* 05 */
    .word  GPIO_6_IRQHandler /* 06 */
    .word  GPIO_7_IRQHandler /* 07 */
    .word  RESERVED_IRQHandler /* 08 */
    .word  RESERVED_IRQHandler /* 09 */
    .word  RESERVED_IRQHandler /* 10 */ 
    .word  RESERVED_IRQHandler /* 11 */
    .word  RESERVED_IRQHandler /* 12 */
    .word  RESERVED_IRQHandler /* 13 */
    .word  RESERVED_IRQHandler /* 14 */
    .word  RESERVED_IRQHandler /* 15 */
    .word  TIMER_0_IRQHandler /* 16 */
    .word  TIMER_1_IRQHandler /* 17 */
    .word  TIMER_2_IRQHandler /* 18 */
    .word  TIMER_3_IRQHandler /* 19 */
    .word  RESERVED_IRQHandler /* 20 */
    .word  RESERVED_IRQHandler /* 21 */
    .word  RESERVED_IRQHandler /* 22 */
    .word  RESERVED_IRQHandler /* 23 */
    .word  FIPS203_IRQHandler /* 24 */
    .word  I2C_IRQHandler /* 25 */
    .word  ECDSA_IRQHandler /* 26 */
    .word  CHACHA20_IRQHandler /* 27 */
    .word  RSA_IRQHandler /* 28 */
    .word  SHA_IRQHandler /* 29 */
    .word  DES_IRQHandler /* 30 */
    .word  AES_IRQHandler /* 31 */
    .word  SM4_IRQHandler /* 32 */
    .word  SM3_IRQHandler /* 33 */
    .word  SM2_IRQHandler /* 34 */
    .word  SM1_IRQHandler /* 35 */
    .word  RESERVED_IRQHandler /* 36 */
    .word  RESERVED_IRQHandler /* 37 */
    .word  RESERVED_IRQHandler /* 38 */
    .word  RESERVED_IRQHandler /* 39 */
    .word  RESERVED_IRQHandler /* 40 */
    .word  RESERVED_IRQHandler /* 41 */
    .word  RESERVED_IRQHandler /* 42 */
	.word  RESERVED_IRQHandler /* 43 */
    .word  TIMER_5_IRQHandler /* 44 */
    .word  TIMER_6_IRQHandler /* 45 */
    .word  TIMER_7_IRQHandler /* 46 */
    .word  TIMER_8_IRQHandler /* 47 */
    .word  RESERVED_IRQHandler /* 48 */
    .word  RESERVED_IRQHandler /* 49 */
    .word  RESERVED_IRQHandler /* 50 */
    .word  RESERVED_IRQHandler /* 51 */
    .word  RESERVED_IRQHandler /* 52 */
    .word  RESERVED_IRQHandler /* 53 */
    .word  RESERVED_IRQHandler /* 54 */
    .word  RESERVED_IRQHandler /* 55 */
    .word  RESERVED_IRQHandler /* 56 */
    .word  RESERVED_IRQHandler /* 57 */
    .word  RESERVED_IRQHandler /* 58 */
    .word  RESERVED_IRQHandler /* 59 */
    .word  RESERVED_IRQHandler /* 60 */
    .word  RESERVED_IRQHandler /* 61 */
    .word  RESERVED_IRQHandler /* 62 */
    .word  RESERVED_IRQHandler /* 63 */

/*******************************************************************************
*
* Provide weak aliases for each Exception handler to the Default_Handler.
* As they are weak aliases, any function with the same name will override
* this definition.
*
*******************************************************************************/

    .weak NMI_Handler
    .thumb_set NMI_Handler,Default_Handler

    .weak HardFault_Handler
    .thumb_set HardFault_Handler,Default_Handler

    .weak MemManage_Handler
    .thumb_set MemManage_Handler,Default_Handler

    .weak BusFault_Handler
    .thumb_set BusFault_Handler,Default_Handler

    .weak UsageFault_Handler
    .thumb_set UsageFault_Handler,Default_Handler

    .weak SVC_Handler
    .thumb_set SVC_Handler,Default_Handler

    .weak DebugMon_Handler
    .thumb_set DebugMon_Handler,Default_Handler

    .weak PendSV_Handler
    .thumb_set PendSV_Handler,Default_Handler

    .weak SysTick_Handler
    .thumb_set SysTick_Handler,Default_Handler

    .weak RESERVED_IRQHandler
    .thumb_set RESERVED_IRQHandler,Default_Handler

    /* 00 */
    .weak GPIO_0_IRQHandler
    .thumb_set GPIO_0_IRQHandler,Default_Handler
    /* 01 */
    .weak GPIO_1_IRQHandler
    .thumb_set GPIO_1_IRQHandler,Default_Handler	
    /* 02 */
    .weak GPIO_2_IRQHandler
    .thumb_set GPIO_2_IRQHandler,Default_Handler	
    /* 03 */
    .weak GPIO_3_IRQHandler
    .thumb_set GPIO_3_IRQHandler,Default_Handler	
    /* 04 */
    .weak GPIO_4_IRQHandler
    .thumb_set GPIO_4_IRQHandler,Default_Handler	
    /* 05 */
    .weak GPIO_5_IRQHandler
    .thumb_set GPIO_5_IRQHandler,Default_Handler	
    /* 06 */
    .weak GPIO_6_IRQHandler
    .thumb_set GPIO_6_IRQHandler,Default_Handler	
    /* 07 */
    .weak GPIO_7_IRQHandler
    .thumb_set GPIO_7_IRQHandler,Default_Handler	
    /* 08 */
    /* 09 */	
    /* 10 */
    /* 11 */	
    /* 12 */	
    /* 13 */	
    /* 14 */	
    /* 15 */	
    /* 16 */

    .weak TIMER_0_IRQHandler
    .thumb_set TIMER_0_IRQHandler,Default_Handler	
    

    .weak PQC_IRQHandler
    .thumb_set PQC_IRQHandler,Default_Handler	
    /* 17 */
    .weak GMII_1_N_IRQHandler
    .thumb_set GMII_1_N_IRQHandler,Default_Handler
    /* 18 */
    .weak DMAC_X_IRQHandler
    .thumb_set DMAC_X_IRQHandler,Default_Handler    
    /* 19 */
    /* 20 */
    /* 21 */
    /* 22 */
    /* 23 */
    /* 24 */
    .weak  FIPS203_IRQHandler /* 24 */
    .thumb_set FIPS203_IRQHandler,Default_Handler   
    .weak  I2C_IRQHandler /* 25 */
    .thumb_set I2C_IRQHandler,Default_Handler   
    .weak  ECDSA_IRQHandler /* 26 */
    .thumb_set ECDSA_IRQHandler,Default_Handler   
    .weak  CHACHA20_IRQHandler /* 27 */
    .thumb_set CHACHA20_IRQHandler,Default_Handler   
    .weak  RSA_IRQHandler /* 28 */
    .thumb_set RSA_IRQHandler,Default_Handler   
    .weak  SHA_IRQHandler /* 29 */
    .thumb_set SHA_IRQHandler,Default_Handler   
    .weak  DES_IRQHandler /* 30 */
    .thumb_set DES_IRQHandler,Default_Handler   
    .weak  AES_IRQHandler /* 31 */
    .thumb_set AES_IRQHandler,Default_Handler   
    .weak  SM4_IRQHandler /* 32 */
    .thumb_set SM4_IRQHandler,Default_Handler   
    .weak  SM3_IRQHandler /* 33 */
    .thumb_set SM3_IRQHandler,Default_Handler   
    .weak  SM2_IRQHandler /* 34 */
    .thumb_set SM2_IRQHandler,Default_Handler   
    .weak  SM1_IRQHandler /* 35 */
    .thumb_set SM1_IRQHandler,Default_Handler   
    /* 36 */
    /* 37 */
    /* 38 */
    /* 39 */
    /* 40 */
    .weak TIMER_1_IRQHandler
    .thumb_set TIMER_1_IRQHandler,Default_Handler   	
    /* 41 */
    .weak TIMER_2_IRQHandler
    .thumb_set TIMER_2_IRQHandler,Default_Handler
    /* 42 */
    .weak TIMER_3_IRQHandler
    .thumb_set TIMER_3_IRQHandler,Default_Handler	
    /* 43 */
    .weak TIMER_4_IRQHandler
    .thumb_set TIMER_4_IRQHandler,Default_Handler	
    /* 44 */
    .weak TIMER_5_IRQHandler
    .thumb_set TIMER_5_IRQHandler,Default_Handler	
    /* 45 */
    .weak TIMER_6_IRQHandler
    .thumb_set TIMER_6_IRQHandler,Default_Handler   
    /* 46 */
    .weak TIMER_7_IRQHandler
    .thumb_set TIMER_7_IRQHandler,Default_Handler   	
    /* 47 */
    .weak TIMER_8_IRQHandler
    .thumb_set TIMER_8_IRQHandler,Default_Handler	
    /* 48 */
    /* 49 */
    /* 50 */
    /* 51 */
    /* 52 */
    /* 53 */
    /* 54 */
    /* 55 */
    /* 56 */
    /* 57 */
    /* 58 */
    /* 59 */
    /* 60 */
    /* 61 */
    /* 62 */
    /* 63 */
