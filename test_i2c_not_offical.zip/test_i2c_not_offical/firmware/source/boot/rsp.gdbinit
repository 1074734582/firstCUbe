monitor reset
load
b main
c
