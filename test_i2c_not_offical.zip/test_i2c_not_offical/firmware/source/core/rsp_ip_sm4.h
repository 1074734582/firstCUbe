/**
 * @file rsp_ip_sm4.h
 * @brief SM4 hardware driver (based on sm4.xlsx register map)
 *        Support ECB / CBC / CTR / GCM
 */
#ifndef __RSP_IP_SM4_H__
#define __RSP_IP_SM4_H__

#include "rsp_ip_common.h"
#include <stdint.h>

#define SM4_TEST_LOOP (1)
#define SM4_TEST_MSG_LEN (16)
#define SM4_TEST_LEN (SM4_TEST_LOOP*SM4_TEST_MSG_LEN)
/* ========== 基地址 ========== */
#define SM4_IP_BASE  (0x80030000UL)
#define SM4_IP       ((SM4_TypeDef *)SM4_IP_BASE)

/* ========== 寄存器结构体（sm4.xlsx + 2026-09-18 实测探针修正）==========
 *
 *  偏移    寄存器          宽度     说明
 *  0x00    STATE           32bit    RO  状态/中断标志
 *  0x04    INTR            32bit    RW  中断使能/屏蔽/阈值
 *  0x08    CFG             32bit    RW  配置寄存器
 *  0x0C    PKG_LEN_ALL     32bit    RW  数据总包长度（含KEY+IV+AAD）
 *  0x10    PKG_LEN_CUR     32bit    RW  当前包长度（含KEY+IV+AAD）
 *                                     经sm4.xlsx和ECB实测确认：必须与PKG_LEN_ALL
 *                                     一致(均含key长度)，否则硬件用key当message
 *  0x14    AAD_LEN         32bit    WO  GCM/CCM附加认证数据长度(实测读0)
 *  0x18    PKG_POS         32bit    RW  GCM首字节在总包中序号(单位16B)
 *  0x1C    ENABLE          32bit    W1SC 算核使能(写1自清, 读0)
 *  0x20~   IFIFO           128bit   WO  输入FIFO, 深度8, 8×128bit=128B
 *  0x9F                          必须stmia INCR4 128bit突发写
 *  0xA0~   OFIFO           128bit   RO  输出FIFO, 深度8, 8×128bit=128B
 *  0x11F                         必须ldmia INCR4 128bit突发读
 */
typedef struct
{
    __I  uint32_t STATE;         /*!< 0x00 RO  状态/中断标志                */
    __IO uint32_t INTR;          /*!< 0x04 RW  中断使能/屏蔽/阈值           */
    __IO uint32_t CFG;           /*!< 0x08 RW  配置寄存器                    */
    __IO uint32_t PKG_LEN_ALL;   /*!< 0x0C RW  数据总包长度（含KEY+IV+AAD） */
    __IO uint32_t PKG_LEN_CUR;   /*!< 0x10 RW  当前包长度（含KEY+IV+AAD）  */
    __O  uint32_t AAD_LEN;       /*!< 0x14 WO  GCM/CCM AAD长度              */
    __IO uint32_t PKG_POS;       /*!< 0x18 RW  GCM首字节序号(单位16B)       */
    __O  uint32_t ENABLE;        /*!< 0x1C W1SC 算核使能(写1自清)           */
    __O  uint32_t IFIFO[32];     /*!< 0x20~0x9F WO  输入FIFO 128bit×8深     */
    __I  uint32_t OFIFO[32];     /*!< 0xA0~0x11F RO 输出FIFO 128bit×8深     */
} SM4_TypeDef;

/* IFIFO/OFIFO 窗口基址（DMA等场景使用）*/
#define SM4_IP_IFIFO_BASE  (SM4_IP_BASE + 0x20U)
#define SM4_IP_OFIFO_BASE  (SM4_IP_BASE + 0xA0U)

/* ============================================================
 *  STATE 寄存器 (0x00) 位定义 (RO)
 * ============================================================ */
#define SM4_STATE_IFIFO_FULL          (1U << 0U)   /*!< bit0 IFIFO满            */
#define SM4_STATE_IFIFO_EMPTY         (1U << 1U)   /*!< bit1 IFIFO空            */
#define SM4_STATE_IFIFO_PROG_FULL     (1U << 2U)   /*!< bit2 IFIFO阈满          */
#define SM4_STATE_IFIFO_PROG_EMPTY    (1U << 3U)   /*!< bit3 IFIFO阈空          */
#define SM4_STATE_OFIFO_FULL          (1U << 4U)   /*!< bit4 OFIFO满            */
#define SM4_STATE_OFIFO_EMPTY         (1U << 5U)   /*!< bit5 OFIFO空            */
#define SM4_STATE_OFIFO_PROG_FULL     (1U << 6U)   /*!< bit6 OFIFO阈满          */
#define SM4_STATE_OFIFO_PROG_EMPTY    (1U << 7U)   /*!< bit7 OFIFO阈空          */
#define SM4_STATE_IFIFO_CNT_Pos       (8U)
#define SM4_STATE_IFIFO_CNT_Msk       (0xFFU << 8U)  /*!< bit[15:8] IFIFO深度  */
#define SM4_STATE_OFIFO_CNT_Pos       (16U)
#define SM4_STATE_OFIFO_CNT_Msk       (0xFFU << 16U) /*!< bit[23:16] OFIFO深度 */

/* 中断标志位 (RO) bit[31:24] */
#define SM4_STATE_IFIFO_FULL_INTR_FLAG         (1U << 24U)
#define SM4_STATE_IFIFO_EMPTY_INTR_FLAG        (1U << 25U)
#define SM4_STATE_IFIFO_PROG_FULL_INTR_FLAG    (1U << 26U)
#define SM4_STATE_IFIFO_PROG_EMPTY_INTR_FLAG   (1U << 27U)
#define SM4_STATE_OFIFO_FULL_INTR_FLAG         (1U << 28U)
#define SM4_STATE_OFIFO_EMPTY_INTR_FLAG        (1U << 29U)
#define SM4_STATE_OFIFO_PROG_FULL_INTR_FLAG    (1U << 30U)
#define SM4_STATE_OFIFO_PROG_EMPTY_INTR_FLAG   (1U << 31U)

/* ============================================================
 *  INTR 寄存器 (0x04) 位定义 (RW)
 * ============================================================ */
#define SM4_INTR_EN                   (1U << 0U)   /*!< bit0 全局中断使能        */
#define SM4_INTR_MASK_Pos             (8U)
#define SM4_INTR_MASK_Msk             (0xFFU << 8U) /*!< bit[15:8] 中断屏蔽(低有效)*/
#define SM4_INTR_CLRER                (1U << 16U)  /*!< bit16 W1SC 清中断        */
#define SM4_INTR_IFIFO_PROG_FULL_THRESH_Pos   (20U)
#define SM4_INTR_IFIFO_PROG_FULL_THRESH_Msk   (0x7U << 20U)
#define SM4_INTR_IFIFO_PROG_EMPTY_THRESH_Pos  (23U)
#define SM4_INTR_IFIFO_PROG_EMPTY_THRESH_Msk  (0x7U << 23U)
#define SM4_INTR_OFIFO_PROG_FULL_THRESH_Pos   (26U)
#define SM4_INTR_OFIFO_PROG_FULL_THRESH_Msk   (0x7U << 26U)
#define SM4_INTR_OFIFO_PROG_EMPTY_THRESH_Pos  (29U)
#define SM4_INTR_OFIFO_PROG_EMPTY_THRESH_Msk  (0x7U << 29U)

/* ============================================================
 *  CFG 寄存器 (0x08) 位定义 (RW)
 * ============================================================ */
#define SM4_CFG_ENCDEC          (1U << 0U)   /*!< bit0  0:加密 1:解密          */

#define SM4_CFG_SER_TYPE_Pos    (4U)
#define SM4_SER_TYPE_ECB        (0U  << SM4_CFG_SER_TYPE_Pos) /*!< 0:ECB     */
#define SM4_SER_TYPE_CBC        (1U  << SM4_CFG_SER_TYPE_Pos) /*!< 1:CBC     */
#define SM4_SER_TYPE_CTR        (4U  << SM4_CFG_SER_TYPE_Pos) /*!< 4:CTR     */
#define SM4_SER_TYPE_GCM        (9U  << SM4_CFG_SER_TYPE_Pos) /*!< 9:GCM     */

#define SM4_CFG_KEY_LEN_Pos     (8U)
#define SM4_CFG_KEY_LEN_Msk     (0xFFU << 8U)  /*!< bit[15:8] KEY长度(字节)    */

#define SM4_CFG_TAG_LEN_Pos     (16U)
#define SM4_CFG_TAG_LEN_Msk     (0xFU << 16U)  /*!< bit[19:16] TAG长度(字节)   */

#define SM4_CFG_HEADER_Pos      (24U)
#define SM4_CFG_HEADER_Msk      (0x7U << 24U)  /*!< bit[26:24] 包标识          */
#define SM4_PKG_FULL            (0x5U << SM4_CFG_HEADER_Pos)  /*!< 3'b101 整包 */
#define SM4_PKG_HEAD            (0x1U << SM4_CFG_HEADER_Pos)  /*!< 3'b001 首包 */
#define SM4_PKG_MID             (0x2U << SM4_CFG_HEADER_Pos)  /*!< 3'b010 中间包 */
#define SM4_PKG_TAIL            (0x4U << SM4_CFG_HEADER_Pos)  /*!< 3'b100 尾包 */

#define SM4_CFG_GCM_TAG_HEARD   (1U << 27U)  /*!< bit27 GCM认证标签包标识    */
#define SM4_CFG_FIFO_STATE_CLEAR (1U << 28U) /*!< bit28 W1SC FIFO状态清零    */

/* ============================================================
 *  ENABLE 寄存器 (0x1C)
 * ============================================================ */
#define SM4_ENABLE              (1U << 0U)   /*!< bit0 W1SC 算核使能           */

/* ============================================================
 *  常量定义
 * ============================================================ */
#define SM4_BLOCK_BYTE_LEN      (16U)  /* SM4分组大小128bit = 16字节   */
#define SM4_KEY_BYTE_LEN        (16U)  /* SM4密钥128bit = 16字节       */
#define SM4_IV_BYTE_LEN         (16U)  /* IV 16字节(GCM实际12B补0到16) */
#define SM4_TAG_BYTE_LEN        (16U)  /* GCM TAG 16字节               */
#define SM4_IFIFO_DATA_WIDTH    (16U)  /* IFIFO 128bit = 16字节        */
#define SM4_IFIFO_DEPTH         (8U)   /* IFIFO深度8                   */
#define SM4_POLL_TIMEOUT        (1000000U) /* 轮询超时值               */

/* ============================================================
 *  SM4工作模式
 * ============================================================ */
typedef enum
{
    SM4_MODE_ECB = 0,
    SM4_MODE_CBC,
    SM4_MODE_CTR,
    SM4_MODE_GCM
} sm4_mode_t;

/* ============================================================
 *  SM4统一上下文
 * ============================================================ */
typedef struct
{
    sm4_mode_t      mode;
    uint8_t         is_encrypt;     /* 1:加密 0:解密 */

    const uint8_t  *key;            /* 16字节密钥 */
    const uint8_t  *iv;             /* 16字节IV/nonce(ECB可NULL, GCM 12B) */

    /* GCM only */
    const uint8_t  *aad;
    uint32_t        aad_len;
    const uint8_t  *tag_in;        /* GCM解密输入tag(验证用) */
    uint8_t        *tag_out;       /* GCM加密输出tag */

    const uint8_t  *in;
    uint8_t        *out;
    uint32_t        in_len;
} sm4_ctx_t;

/* ============================================================
 *  公共 API
 * ============================================================ */
RSP_StatusTypeDef sm4_hw_process(sm4_ctx_t *ctx);


/* DMA 版本 (性能测试用, 覆盖 ECB/CBC/CTR/GCM) */
RSP_StatusTypeDef sm4_hw_process_dma(sm4_ctx_t *ctx);


/**
 * @brief SM4 ECB 加解密
 * @param key      密钥, 长度必须为 SM4_KEY_BYTE_LEN(16)
 * @param key_len  密钥长度(字节), 非16返回 key_len_err
 * @param in       输入数据
 * @param out      输出数据, 容量须 >= ceil(len/16)*16
 * @param len      数据长度(字节), 任意非0长度; 非16整数倍时末块软件补0,
 *                 输出长度 = ceil(len/16)*16
 * @param is_encrypt 1:加密 0:解密
 * @return RSP_OK / RSP_ERR_NULL_PTR / RSP_ERR_INVALID_PARAM / RSP_ERR_FIFO
 */
RSP_StatusTypeDef sm4_ecb_hw(const uint8_t *key, uint32_t key_len,
                             const uint8_t *in, uint8_t *out,
                             uint32_t len, int is_encrypt);
/**
 * @brief SM4 CBC 加解密
 * @param key      密钥, 长度必须为 SM4_KEY_BYTE_LEN(16)
 * @param key_len  密钥长度(字节), 非16返回 key_len_err
 * @param iv       IV, 16字节, 不可为NULL(iv_null_err)
 * @param in/out   输入/输出数据(非空), out容量须 >= ceil(len/16)*16
 * @param len      数据长度(字节), 任意非0长度; 非16整数倍时末块软件补0,
 *                 输出长度 = ceil(len/16)*16
 * @param is_encrypt 1:加密 0:解密
 */
RSP_StatusTypeDef sm4_cbc_hw(const uint8_t *key, uint32_t key_len,
                             const uint8_t *iv, const uint8_t *in,
                             uint8_t *out, uint32_t len, int is_encrypt);
/**
 * @brief SM4 CTR 加解密
 * @param key      密钥, 长度必须为 SM4_KEY_BYTE_LEN(16)
 * @param key_len  密钥长度(字节), 非16返回 key_len_err
 * @param iv       IV, 16字节, 不可为NULL(iv_null_err)
 * @param in/out   输入/输出数据(非空)
 * @param len      数据长度(字节), 必须非0且为16的整数倍(msg_len_err)
 * @param is_encrypt 1:加密 0:解密
 */
RSP_StatusTypeDef sm4_ctr_hw(const uint8_t *key, uint32_t key_len,
                             const uint8_t *iv, const uint8_t *in,
                             uint8_t *out, uint32_t len, int is_encrypt);
/**
 * @brief SM4 GCM 加解密
 * @param key      密钥, 长度必须为 SM4_KEY_BYTE_LEN(16)
 * @param key_len  密钥长度(字节), 非16返回 key_len_err
 * @param iv       nonce, 12字节有效(取前12B补0到16), 不可为NULL(iv_null_err)
 * @param aad      AAD, aad_len非0时不可为NULL(aad_null_err)
 * @param aad_len  AAD长度(字节)
 * @param in/out   输入/输出数据(非空)
 * @param len      数据长度(字节), 必须非0且为16的整数倍(msg_len_err)
 * @param tag      TAG, 不可为NULL(tag_null_err)
 * @param is_encrypt 1:加密 0:解密
 */
RSP_StatusTypeDef sm4_gcm_hw(const uint8_t *key, uint32_t key_len,
                             const uint8_t *iv,
                             const uint8_t *aad, uint32_t aad_len,
                             const uint8_t *in, uint8_t *out,
                             uint32_t len, uint8_t *tag, int is_encrypt);

#endif /* __RSP_IP_SM4_H__ */
