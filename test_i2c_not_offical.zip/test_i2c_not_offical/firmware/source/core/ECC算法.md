# 

ECDSA 在 NIST P\-256（也叫 secp256r1 / prime256v1）上的核心公式如下。
注意：点坐标运算在模 p*p* 下进行，签名标量 r,s,k,d,e*r*,*s*,*k*,*d*,*e* 的运算在模 n*n* 下进行。

## P\-256  P\-384曲线参数

曲线：

E: y2≡x3\+ax\+b \(modp\)

P\-256 /P\-384：

a≡−3\(mod*p*\)

**P\-256 常用参数**

p  = FFFFFFFF 00000001 00000000 00000000 00000000 FFFFFFFF FFFFFFFF FFFFFFFF

a  = FFFFFFFF 00000001 00000000 00000000 00000000 FFFFFFFF FFFFFFFF FFFFFFFC

b  = 5AC635D8 AA3A93E7 B3EBBD55 769886BC 651D06B0 CC53B0F6 3BCE3C3E 27D2604

BGx = 6B17D1F2 E12C4247 F8BCE6E5 63A440F2 77037D81 2DEB33A0 F4A13945 D898C296

Gy = 4FE342E2 FE1A7F9B 8EE7EB4A 7C0F9E16 2BCE3357 6B315ECE CBB64068 37BF51F5

n  = FFFFFFFF 00000000 FFFFFFFF FFFFFFFF BCE6FAAD A7179E84 F3B9CAC2 FC632551

h  = 1

**P\-384常用参数**

p  = FFFFFFFF FFFFFFFF FFFFFFFF FFFFFFFF FFFFFFFF FFFFFFFF FFFFFFFF

FFFFFFFE FFFFFFFF 00000000 00000000 FFFFFFFF

a  = FFFFFFFF FFFFFFFF FFFFFFFF FFFFFFFF FFFFFFFF FFFFFFFF FFFFFFFF

FFFFFFFE FFFFFFFF 00000000 00000000 FFFFFFFC

b  = B3312FA7 E23EE7E4 988E056B E3F82D19 181D9C6E FE814112

0314088F 5013875A C656398D 8A2ED19D 2A85C8ED D3EC2AEF

Gx = AA87CA22 BE8B0537 8EB1C71E F320AD74 6E1D3B62 8BA79B98

59F741E0 82542A38 5502F25D BF55296C 3A545E38 72760AB7

Gy = 3617DE4A 96262C6F 5D9E98BF 9292DC29 F8F41DBD 289A147C

E9DA3113 B5F0B8C0 0A60B1CE 1D7E819D 7A431D7C 90EA0E5F

n  = FFFFFFFF FFFFFFFF FFFFFFFF FFFFFFFF FFFFFFFF FFFFFFFF

C7634D81 F4372DDF 581A0DB2 48B0A77A ECEC196A CCC52973



其中：

- p：有限域素数

- n：基点 G 的阶

- h：余因子，P\-256 中为 1

- G=\(Gx,Gy\)：基点

曲线方程可写成：

y2≡x3−3x\+b\(modp\)



---

## 密钥生成

私钥：

d∈\[1,n−1\]

公钥：

Q=dG

即私钥 d*d* 与基点 G*G* 做椭圆曲线标量乘法。

---

## 椭圆曲线点运算公式

点加与倍点的代数形式P384与 P\-256 完全相同,只是所有运算在模 P\-384 的 p*p* 下进行

### 点加：P=\(x1,y1\)，Q=\(x2,y2\)，且 P≠±Q

λ=y2−y1x2−x1\(modp\)*λ*=*x*2−*x*1*y*2−*y*1\(mod*p*\)x3=λ2−x1−x2\(modp\)*x*3=*λ*2−*x*1−*x*2\(mod*p*\)y3=λ\(x1−x3\)−y1\(modp\)*y*3=*λ*\(*x*1−*x*3\)−*y*1\(mod*p*\)

则：

P\+Q=\(x3,y3\)*P*\+*Q*=\(*x*3,*y*3\)

### 倍点：P=\(x1,y1\)*P*=\(*x*1,*y*1\)，且 y1≠0*y*1=0

λ=3x12\+a2y1\(modp\)*λ*=2*y*13*x*12\+*a*\(mod*p*\)

P\-256 中 a=−3*a*=−3，所以：

λ=3\(x12−1\)2y1\(modp\)*λ*=2*y*13\(*x*12−1\)\(mod*p*\)x3=λ2−2x1\(modp\)*x*3=*λ*2−2*x*1\(mod*p*\)y3=λ\(x1−x3\)−y1\(modp\)*y*3=*λ*\(*x*1−*x*3\)−*y*1\(mod*p*\)

则：

2P=\(x3,y3\)2*P*=\(*x*3,*y*3\)

所有除法都是模 p*p* 下的乘法逆元。

---

## ECDSA 签名公式

设消息为 m*m*，哈希函数为 H*H*。

### 第一步：计算消息摘要

P\-256 的 n*n* 是 256 位，因此：

e=leftmost\_256\_bits\(H\(m\)\)*e*=leftmost\_256\_bits\(*H*\(*m*\)\)

如果使用 SHA\-256，则 e=H\(m\)*e*=*H*\(*m*\) 直接作为大端整数。

### 第二步：选择随机数 k*k*

k∈\[1,n−1\]*k*∈\[1,*n*−1\]

计算点：

R=kG=\(x1,y1\)*R*=*kG*=\(*x*1,*y*1\)

取：

r=x1 mod n*r*=*x*1mod*n*

若 r=0*r*=0，重新选择 k*k*。

### 第三步：计算 s*s*

s=k−1\(e\+rd\) mod n*s*=*k*−1\(*e*\+*rd*\)mod*n*

若 s=0*s*=0，重新选择 k*k*。

最终签名为：

\(r,s\)\(*r*,*s*\)

---

## ECDSA 验证公式

给定公钥 Q=dG*Q*=*dG*，消息摘要 e*e*，签名 \(r,s\)\(*r*,*s*\)。

首先检查：

1≤r≤n−11≤*r*≤*n*−11≤s≤n−11≤*s*≤*n*−1

然后计算：

w=s−1 mod n*w*=*s*−1mod*n*u1=ew mod n*u*1=*ew*mod*n*u2=rw mod n*u*2=*rw*mod*n*

计算点：

X=u1G\+u2Q*X*=*u*1*G*\+*u*2*Q*

设：

X=\(xX,yX\)*X*=\(*xX*,*yX*\)

若 X=O*X*=*O*，即无穷远点，则验证失败。

计算：

v=xX mod n*v*=*xX*mod*n*

验证：

v=r*v*=*r*

若相等，则签名有效。

---

## 正确性核心推导

验证时：

X=u1G\+u2Q*X*=*u*1*G*\+*u*2*Q*

代入 Q=dG*Q*=*dG*：

X=u1G\+u2dG=\(u1\+u2d\)G*X*=*u*1*G*\+*u*2*dG*=\(*u*1\+*u*2*d*\)*G*

而：

u1=ew,u2=rw,w=s−1*u*1=*ew*,*u*2=*rw*,*w*=*s*−1

所以：

X=w\(e\+rd\)G=s−1\(e\+rd\)G*X*=*w*\(*e*\+*rd*\)*G*=*s*−1\(*e*\+*rd*\)*G*

签名中：

s=k−1\(e\+rd\) mod n*s*=*k*−1\(*e*\+*rd*\)mod*n*

因此：

s−1=k\(e\+rd\)−1 mod n*s*−1=*k*\(*e*\+*rd*\)−1mod*n*

所以：

X=kG*X*=*kG*

因此 X*X* 的横坐标模 n*n* 应等于签名中的 r*r*：

xX mod n=r*xX*mod*n*=*r*

这就是 ECDSA 验证成立的核心公式。

ECDSA 在 NIST P\-256（也叫 secp256r1 / prime256v1）上的核心公式如下。
注意：点坐标运算在模 p*p* 下进行，签名标量 r,s,k,d,e*r*,*s*,*k*,*d*,*e* 的运算在模 n*n* 下进行。

## 1\. P\-256 曲线参数

曲线：

E:y2≡x3\+ax\+b\(modp\)*E*:*y*2≡*x*3\+*ax*\+*b*\(mod*p*\)

P\-256 中：

a≡−3\(modp\)*a*≡−3\(mod*p*\)

常用参数：

text

p  = FFFFFFFF 00000001 00000000 00000000 00000000 FFFFFFFF FFFFFFFF FFFFFFFFa  = FFFFFFFF 00000001 00000000 00000000 00000000 FFFFFFFF FFFFFFFF FFFFFFFCb  = 5AC635D8 AA3A93E7 B3EBBD55 769886BC 651D06B0 CC53B0F6 3BCE3C3E 27D2604BGx = 6B17D1F2 E12C4247 F8BCE6E5 63A440F2 77037D81 2DEB33A0 F4A13945 D898C296Gy = 4FE342E2 FE1A7F9B 8EE7EB4A 7C0F9E16 2BCE3357 6B315ECE CBB64068 37BF51F5n  = FFFFFFFF 00000000 FFFFFFFF FFFFFFFF BCE6FAAD A7179E84 F3B9CAC2 FC632551h  = 1

其中：

- p*p*：有限域素数

- n*n*：基点 G*G* 的阶

- h*h*：余因子，P\-256 中为 1

- G=\(Gx,Gy\)*G*=\(*Gx*,*Gy*\)：基点

曲线方程可写成：

y2≡x3−3x\+b\(modp\)*y*2≡*x*3−3*x*\+*b*\(mod*p*\)

---

## 2\. 密钥生成

私钥：

d∈\[1,n−1\]*d*∈\[1,*n*−1\]

公钥：

Q=dG*Q*=*dG*

即私钥 d*d* 与基点 G*G* 做椭圆曲线标量乘法。

---

## 3\. 椭圆曲线点运算公式

### 点加：P=\(x1,y1\)*P*=\(*x*1,*y*1\)，Q=\(x2,y2\)*Q*=\(*x*2,*y*2\)，且 P≠±Q*P*=±*Q*

λ=y2−y1x2−x1\(modp\)*λ*=*x*2−*x*1*y*2−*y*1\(mod*p*\)x3=λ2−x1−x2\(modp\)*x*3=*λ*2−*x*1−*x*2\(mod*p*\)y3=λ\(x1−x3\)−y1\(modp\)*y*3=*λ*\(*x*1−*x*3\)−*y*1\(mod*p*\)

则：

P\+Q=\(x3,y3\)*P*\+*Q*=\(*x*3,*y*3\)

### 倍点：P=\(x1,y1\)*P*=\(*x*1,*y*1\)，且 y1≠0*y*1=0

λ=3x12\+a2y1\(modp\)*λ*=2*y*13*x*12\+*a*\(mod*p*\)

P\-256 中 a=−3*a*=−3，所以：

λ=3\(x12−1\)2y1\(modp\)*λ*=2*y*13\(*x*12−1\)\(mod*p*\)x3=λ2−2x1\(modp\)*x*3=*λ*2−2*x*1\(mod*p*\)y3=λ\(x1−x3\)−y1\(modp\)*y*3=*λ*\(*x*1−*x*3\)−*y*1\(mod*p*\)

则：

2P=\(x3,y3\)2*P*=\(*x*3,*y*3\)

所有除法都是模 p*p* 下的乘法逆元。

---

## 4\. ECDSA 签名公式

设消息为 m*m*，哈希函数为 H*H*。

### 第一步：计算消息摘要

P\-256 的 n*n* 是 256 位，因此：

e=leftmost\_256\_bits\(H\(m\)\)*e*=leftmost\_256\_bits\(*H*\(*m*\)\)

如果使用 SHA\-256，则 e=H\(m\)*e*=*H*\(*m*\) 直接作为大端整数。

### 第二步：选择随机数 k*k*

k∈\[1,n−1\]*k*∈\[1,*n*−1\]

计算点：

R=kG=\(x1,y1\)*R*=*kG*=\(*x*1,*y*1\)

取：

r=x1 mod n*r*=*x*1mod*n*

若 r=0*r*=0，重新选择 k*k*。

### 第三步：计算 s*s*

s=k−1\(e\+rd\) mod n*s*=*k*−1\(*e*\+*rd*\)mod*n*

若 s=0*s*=0，重新选择 k*k*。

最终签名为：

\(r,s\)\(*r*,*s*\)

---

## 5\. ECDSA 验证公式

给定公钥 Q=dG*Q*=*dG*，消息摘要 e*e*，签名 \(r,s\)\(*r*,*s*\)。

首先检查：

1≤r≤n−11≤*r*≤*n*−11≤s≤n−11≤*s*≤*n*−1

然后计算：

w=s−1 mod n*w*=*s*−1mod*n*u1=ew mod n*u*1=*ew*mod*n*u2=rw mod n*u*2=*rw*mod*n*

计算点：

X=u1G\+u2Q*X*=*u*1*G*\+*u*2*Q*

设：

X=\(xX,yX\)*X*=\(*xX*,*yX*\)

若 X=O*X*=*O*，即无穷远点，则验证失败。

计算：

v=xX mod n*v*=*xX*mod*n*

验证：

v=r*v*=*r*

若相等，则签名有效。

---

## 6\. 正确性核心推导

验证时：

X=u1G\+u2Q*X*=*u*1*G*\+*u*2*Q*

代入 Q=dG*Q*=*dG*：

X=u1G\+u2dG=\(u1\+u2d\)G*X*=*u*1*G*\+*u*2*dG*=\(*u*1\+*u*2*d*\)*G*

而：

u1=ew,u2=rw,w=s−1*u*1=*ew*,*u*2=*rw*,*w*=*s*−1

所以：

X=w\(e\+rd\)G=s−1\(e\+rd\)G*X*=*w*\(*e*\+*rd*\)*G*=*s*−1\(*e*\+*rd*\)*G*

签名中：

s=k−1\(e\+rd\) mod n*s*=*k*−1\(*e*\+*rd*\)mod*n*

因此：

s−1=k\(e\+rd\)−1 mod n*s*−1=*k*\(*e*\+*rd*\)−1mod*n*

所以：

X=kG*X*=*kG*

因此 X*X* 的横坐标模 n*n* 应等于签名中的 r*r*：

xX mod n=r*xX*mod*n*=*r*

这就是 ECDSA 验证成立的核心公式。



Mul:256 位模乘器,模逆，模加

