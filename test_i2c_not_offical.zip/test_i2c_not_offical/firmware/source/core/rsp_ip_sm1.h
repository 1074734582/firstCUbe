/**
 * @file rsp_ip_sm1.h
 * @brief SM1 hardware driver (基址 0x80000000)
 *
 *  依据 sm1_soc_test.txt 寄存器布局 (IFIFO@0x20, OFIFO@0xa0),
 *  与 SM4 (0x80030000) 同族: 寄存器偏移/位定义一致.
 *
 *  SM1 分组密码: 块 128bit(16B), 密钥 128bit(16B).
 *  IFIFO/OFIFO 128bit x 8 深, 每次写/读 16B.
 */
#ifndef __RSP_IP_SM1_H__
#define __RSP_IP_SM1_H__

#include "rsp_ip_common.h"
#include <stdint.h>

/* ========== 基地址 ========== */
#define SM1_IP_BASE  (0x80000000UL)
#define SM1_IP       ((SM1_TypeDef *)SM1_IP_BASE)
#define SM1_IP_IFIFO_BASE  (SM1_IP_BASE + 0x20U)
#define SM1_IP_OFIFO_BASE  (SM1_IP_BASE + 0xA0U)

/* ========== 寄存器结构体 ==========
 *
 *  偏移    寄存器
 *  0x00    STATE         RO
 *  0x04    INTR          RW
 *  0x08    CFG           RW   mode/key_len/tag_len/pkg_id/encdec
 *  0x0C    PKG_LEN_ALL   RW   总包长度(含 key+iv+aad)
 *  0x10    PKG_LEN_CUR   RW   当前包长度
 *  0x14    AAD_LEN       WO   GCM AAD 长度 (没用)
 *  0x18    PKG_POS       RW   包起始位置
 *  0x1C    ENABLE        W1SC 算核使能
 *  0x20~   IFIFO(128bit x 8)  WO
 *  0xA0~   OFIFO(128bit x 8)  RO
 */
typedef struct
{
    __I  uint32_t STATE;
    __IO uint32_t INTR;
    __IO uint32_t CFG;
    __IO uint32_t PKG_LEN_ALL;
    __IO uint32_t PKG_LEN_CUR;
    __O  uint32_t AAD_LEN;
    __IO uint32_t PKG_POS;
    __O  uint32_t ENABLE;
    __O  uint32_t IFIFO[32];
    __I  uint32_t OFIFO[32];
} SM1_TypeDef;

/* ========== STATE 位定义 (与 SM4 一致) ========== */
#define SM1_STATE_IFIFO_FULL          (1U << 0U)
#define SM1_STATE_IFIFO_EMPTY         (1U << 1U)
#define SM1_STATE_IFIFO_PROG_FULL     (1U << 2U)
#define SM1_STATE_IFIFO_PROG_EMPTY    (1U << 3U)
#define SM1_STATE_OFIFO_FULL          (1U << 4U)
#define SM1_STATE_OFIFO_EMPTY         (1U << 5U)
#define SM1_STATE_OFIFO_PROG_FULL     (1U << 6U)
#define SM1_STATE_OFIFO_PROG_EMPTY    (1U << 7U)
#define SM1_STATE_IFIFO_CNT_Pos       (8U)
#define SM1_STATE_IFIFO_CNT_Msk       (0xFFU << 8U)
#define SM1_STATE_OFIFO_CNT_Pos       (16U)
#define SM1_STATE_OFIFO_CNT_Msk       (0xFFU << 16U)

/* ========== INTR 位定义 ========== */
#define SM1_INTR_EN                   (1U << 0U)
#define SM1_INTR_MASK_Pos             (8U)
#define SM1_INTR_MASK_Msk             (0xFFU << 8U)
#define SM1_INTR_CLRER                (1U << 16U)
#define SM1_INTR_FIFO_STATE_CLEAR     (1U << 28U)  /* W1SC FIFO 状态清零 */

/* ========== CFG 位定义 ==========
 *
 *  sm1_init_pkg(enc_dec_sel, mode_sel, pkg_id, tag_len, key_byte, cur_send_byte, send_byte)
 *                   bit0     bit[7:4] bit[26:24] bit[19:16] bit[15:8]
 */
#define SM1_CFG_ENCDEC          (1U << 0U)   /* bit0  0:加密 1:解密 */

#define SM1_CFG_SER_TYPE_Pos    (4U)
#define SM1_SER_TYPE_ECB        (0U  << SM1_CFG_SER_TYPE_Pos)  /* mode_sel=0 */
#define SM1_SER_TYPE_CBC        (1U  << SM1_CFG_SER_TYPE_Pos)  /* mode_sel=1 */

#define SM1_CFG_KEY_LEN_Pos     (8U)
#define SM1_CFG_KEY_LEN_Msk     (0xFFU << 8U)  /* bit[15:8] key 字节数 */

#define SM1_CFG_TAG_LEN_Pos     (16U)
#define SM1_CFG_TAG_LEN_Msk     (0xFU << 16U)  /* bit[19:16] tag 字节数 */

#define SM1_CFG_HEADER_Pos      (24U)
#define SM1_CFG_HEADER_Msk      (0x7U << 24U)  /* bit[26:24] pkg_id */
#define SM1_PKG_FULL            (5U << SM1_CFG_HEADER_Pos)  /* 5 = 整包 */

/* ========== ENABLE ========== */
#define SM1_ENABLE              (1U << 0U)   /* 0x1C, bit0 W1SC */

/* ========== 常量 ========== */
#define SM1_BLOCK_BYTES         (16U)   /* SM1 分组大小 128bit = 16 字节 */
#define SM1_KEY_BYTES           (16U)   /* 密钥 128bit = 16 字节 */
#define SM1_IV_BYTES            (16U)   /* IV 与分组等长 128bit = 16 字节 */
#define SM1_ENTRY_BYTES         (16U)   /* IFIFO/OFIFO 条目 128bit = 16 字节 */
#define SM1_IFIFO_DEPTH         (8U)
#define SM1_POLL_TIMEOUT        (1000000U)

/* ========== 调试 ========== */
extern volatile uint32_t sm1_dbg[8];

/* ========== 公共 API ========== */

/* ECB: key(16B) + msg(nB) → cipher(nB) */
RSP_StatusTypeDef sm1_hw_ecb(const uint8_t *key, const uint8_t *in,
                             uint8_t *out, uint32_t len, int is_encrypt);

/* CBC: key(16B) + iv(16B) + msg(nB) → cipher(nB) */
RSP_StatusTypeDef sm1_hw_cbc(const uint8_t *key, const uint8_t *iv,
                             const uint8_t *in, uint8_t *out,
                             uint32_t len, int is_encrypt);

#endif /* __RSP_IP_SM1_H__ */
