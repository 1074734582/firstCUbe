/**
 * @file rsp_ip_sm2.h
 * @brief SM2 硬件 IP 驱动接口
 *        依据 sm2.xlsx (寄存器表) 与 sm2_输入输出数据格式.xlsx (数据包格式)
 *
 * 寄存器映射 (基址 0x80010000):
 *   0x00 STATE   RO   状态/中断标志
 *   0x04 INTR    RW   中断使能/屏蔽/阈值/FIFO状态清零
 *   0x08 PKG_LEN RW   数据包长度(变长数据字节数, 见各接口说明)
 *   0x0C CFG     RW   bit0 ENABLE(W1SC) / bit[11:8] MODE / bit12/13 SWAP
 *                     bit14 摘要/原始消息 / bit15 密钥交换角色
 *                     bit16 临时公钥输出 / bit17 密钥确认 / bit[27:16] ID_LEN
 *   0x10~0x8F IFIFO  WO  输入FIFO, 128bit×8深 (128B)
 *   0x90~0x10F OFIFO RO  输出FIFO, 128bit×8深 (128B)
 *
 * MODE 编码 (CFG.bit[11:8]):
 *   0 签名      1 验签        2 任意点点乘(KP)  3 基点点乘(KG)
 *   4 密钥交换  5 加密        6 解密
 *   8 模加      9 模减        10 模乘           11 P点模逆(mod p)
 *   12 N点模逆(mod n)         13 点倍           14 点加          15 SM3
 *
 * 数据约定:
 *   - 所有 256bit 数值为大端 32 字节; 每个 32B 拆成 2 个 128bit FIFO 条目
 *     (高 16B 先写, 低 16B 后写)
 *   - 椭圆曲线点 (x,y) 为 64B = x(32B) || y(32B)
 *   - Jacobian 点 (X,Y,Z) 为 96B
 *   - 变长字段 (消息/明文/密文C2/ID) 不足 16B 倍数时, 写入前补 0
 */
#ifndef __RSP_IP_SM2_H__
#define __RSP_IP_SM2_H__

#include "rsp_ip_common.h"
#include <stdint.h>

/* ========== 基地址 ========== */
#define SM2_IP_BASE  (0x80010000UL)
#define SM2_IP       ((SM2_TypeDef *)SM2_IP_BASE)

/* ========== 寄存器结构体 ========== */
typedef struct
{
    __I  uint32_t STATE;          /*!< 0x00 RO  状态/中断标志                      */
    __IO uint32_t INTR;           /*!< 0x04 RW  中断使能/屏蔽/阈值/FIFO清零        */
    __IO uint32_t PKG_LEN;        /*!< 0x08 RW  数据包长度(字节)                   */
    __IO uint32_t CFG;            /*!< 0x0C RW  配置                               */
    __O  uint32_t IFIFO[32];      /*!< 0x10~0x8F WO  输入FIFO 128bit×8深           */
    __I  uint32_t OFIFO[32];      /*!< 0x90~0x10F RO 输出FIFO 128bit×8深           */
} SM2_TypeDef;

#define SM2_IP_IFIFO_BASE  (SM2_IP_BASE + 0x10U)
#define SM2_IP_OFIFO_BASE  (SM2_IP_BASE + 0x90U)

/* ============================================================
 *  STATE 寄存器 (0x00) 位定义 (RO)
 * ============================================================ */
#define SM2_STATE_IFIFO_FULL             (1U << 0U)   /*!< bit0  IFIFO满             */
#define SM2_STATE_IFIFO_EMPTY            (1U << 1U)   /*!< bit1  IFIFO空             */
#define SM2_STATE_IFIFO_PROG_FULL        (1U << 2U)   /*!< bit2  IFIFO阈满           */
#define SM2_STATE_IFIFO_PROG_EMPTY       (1U << 3U)   /*!< bit3  IFIFO阈空           */
#define SM2_STATE_OFIFO_FULL             (1U << 4U)   /*!< bit4  OFIFO满             */
#define SM2_STATE_OFIFO_EMPTY            (1U << 5U)   /*!< bit5  OFIFO空             */
#define SM2_STATE_OFIFO_PROG_FULL        (1U << 6U)   /*!< bit6  OFIFO阈满           */
#define SM2_STATE_OFIFO_PROG_EMPTY       (1U << 7U)   /*!< bit7  OFIFO阈空           */
#define SM2_STATE_IFIFO_CNT_Pos          (8U)
#define SM2_STATE_IFIFO_CNT_Msk          (0xFFU << 8U)   /*!< bit[15:8]  IFIFO当前深度 */
#define SM2_STATE_OFIFO_CNT_Pos          (16U)
#define SM2_STATE_OFIFO_CNT_Msk          (0xFFU << 16U)  /*!< bit[23:16] OFIFO当前深度 */

/* 中断状态标志 (高有效, 对应 INTR_MASK 各位) */
#define SM2_STATE_IFIFO_FULL_INTR_FLAG          (1U << 24U)
#define SM2_STATE_IFIFO_EMPTY_INTR_FLAG         (1U << 25U)
#define SM2_STATE_IFIFO_PROG_FULL_INTR_FLAG     (1U << 26U)
#define SM2_STATE_IFIFO_PROG_EMPTY_INTR_FLAG    (1U << 27U)
#define SM2_STATE_OFIFO_FULL_INTR_FLAG          (1U << 28U)
#define SM2_STATE_OFIFO_EMPTY_INTR_FLAG         (1U << 29U)
#define SM2_STATE_OFIFO_PROG_FULL_INTR_FLAG     (1U << 30U)
#define SM2_STATE_OFIFO_PROG_EMPTY_INTR_FLAG    (1U << 31U)

/* ============================================================
 *  INTR 寄存器 (0x04) 位定义 (RW)
 * ============================================================ */
#define SM2_INTR_EN                         (1U << 0U)   /*!< bit0  全局中断使能         */
#define SM2_INTR_FIFO_STATE_CLEAR           (1U << 1U)   /*!< bit1  W1SC FIFO状态复位    */
#define SM2_INTR_MASK_Pos                   (8U)
#define SM2_INTR_MASK_Msk                   (0xFFU << 8U) /*!< bit[15:8] 中断屏蔽(低有效)*/
#define SM2_INTR_CLRER                      (1U << 16U)  /*!< bit16 W1SC 清全局中断      */
#define SM2_INTR_IFIFO_PROG_FULL_THRESH_Pos   (20U)
#define SM2_INTR_IFIFO_PROG_FULL_THRESH_Msk   (0x7U << 20U)
#define SM2_INTR_IFIFO_PROG_EMPTY_THRESH_Pos  (23U)
#define SM2_INTR_IFIFO_PROG_EMPTY_THRESH_Msk  (0x7U << 23U)
#define SM2_INTR_OFIFO_PROG_FULL_THRESH_Pos   (26U)
#define SM2_INTR_OFIFO_PROG_FULL_THRESH_Msk   (0x7U << 26U)
#define SM2_INTR_OFIFO_PROG_EMPTY_THRESH_Pos  (29U)
#define SM2_INTR_OFIFO_PROG_EMPTY_THRESH_Msk  (0x7U << 29U)

/* ============================================================
 *  CFG 寄存器 (0x0C) 位定义 (RW)
 * ============================================================ */
#define SM2_CFG_ENABLE              (1U << 0U)   /*!< bit0  W1SC 算核使能, 写1自清   */

#define SM2_CFG_MODE_Pos            (8U)
#define SM2_CFG_MODE_Msk            (0xFU << 8U)  /*!< bit[11:8] 模式选择             */
#define SM2_MODE_SIGN               (0x0U << SM2_CFG_MODE_Pos) /*!< 0  签名          */
#define SM2_MODE_VERIFY             (0x1U << SM2_CFG_MODE_Pos) /*!< 1  验签          */
#define SM2_MODE_KP                 (0x2U << SM2_CFG_MODE_Pos) /*!< 2  任意点点乘    */
#define SM2_MODE_KG                 (0x3U << SM2_CFG_MODE_Pos) /*!< 3  基点点乘      */
#define SM2_MODE_KEYEXCH            (0x4U << SM2_CFG_MODE_Pos) /*!< 4  密钥交换      */
#define SM2_MODE_ENC                (0x5U << SM2_CFG_MODE_Pos) /*!< 5  加密          */
#define SM2_MODE_DEC                (0x6U << SM2_CFG_MODE_Pos) /*!< 6  解密          */
#define SM2_MODE_MADD               (0x8U << SM2_CFG_MODE_Pos) /*!< 8  模加          */
#define SM2_MODE_MSUB               (0x9U << SM2_CFG_MODE_Pos) /*!< 9  模减          */
#define SM2_MODE_MMUL               (0xAU << SM2_CFG_MODE_Pos) /*!< 10 模乘          */
#define SM2_MODE_MINV_P             (0xBU << SM2_CFG_MODE_Pos) /*!< 11 P点模逆(mod p)*/
#define SM2_MODE_MINV_N             (0xCU << SM2_CFG_MODE_Pos) /*!< 12 N点模逆(mod n)*/
#define SM2_MODE_PDOUBLE            (0xDU << SM2_CFG_MODE_Pos) /*!< 13 点倍          */
#define SM2_MODE_PADD               (0xEU << SM2_CFG_MODE_Pos) /*!< 14 点加          */
#define SM2_MODE_SM3                (0xFU << SM2_CFG_MODE_Pos) /*!< 15 SM3           */

#define SM2_CFG_INPUT_SWAP          (1U << 12U)  /*!< bit12 输入数据大小端转换使能    */
#define SM2_CFG_OUTPUT_SWAP         (1U << 13U)  /*!< bit13 输出数据大小端转换使能    */
#define SM2_CFG_SING_VERIFY_MODE    (1U << 14U)  /*!< bit14 0:摘要 1:原始消息         */
#define SM2_CFG_KEY_EXCHA_MODE_I    (1U << 15U)  /*!< bit15 密钥交换 0:响应端B 1:发送端A */
#define SM2_CFG_TEMP_PUBLIC_OUT_EN  (1U << 16U)  /*!< bit16 密钥交换临时公钥输出使能  */
#define SM2_CFG_KEY_AGREE_EN        (1U << 17U)  /*!< bit17 密钥交换密钥协商使能      */

#define SM2_CFG_ID_LEN_Pos          (16U)
#define SM2_CFG_ID_LEN_Msk          (0xFFFU << 16U) /*!< bit[27:16] 用户ID长度(字节) */

/* ============================================================
 *  常量
 * ============================================================ */
#define SM2_ENTRY_BYTES            (16U)  /* 128bit FIFO 条目 = 16 字节 */
#define SM2_IFIFO_DEPTH            (8U)   /* FIFO 深度 8 条目            */
#define SM2_IFIFO_DATA_WIDTH_BYTE  SM2_ENTRY_BYTES
#define SM2_NUM_BYTES              (32U)  /* 256bit = 32 字节            */
#define SM2_POINT_BYTES            (64U)  /* (x,y) 各 32B                */
#define SM2_JACOBIAN_BYTES         (96U)  /* (X,Y,Z) 各 32B              */
#define SM2_SIG_BYTES              (64U)  /* r||s 各 32B                 */
#define SM2_ID_MAX_BYTES           (256U) /* 本驱动支持的 ID 最大长度    */
#define SM2_ID_DEFAULT             "1234567812345678"
#define SM2_ID_DEFAULT_LEN         (16U)
#define SM2_POLL_TIMEOUT           (1000000U)
/* 等输出: 签名含标量乘 kG, 耗时远大于 FIFO 轮询周期, 单独给更长预算 */
#define SM2_OUT_WAIT               (8000000U)

/* 调试记录: [0]阶段 1=写输入超时 2=读输出超时 3=启动后 4=输入写完;
 *           [1]STATE [2]PKG_LEN [3]CFG [4]IFIFO_CNT [5]OFIFO_CNT */
extern volatile uint32_t sm2_dbg[8];

/* ============================================================
 *  模运算 (256bit 大端 32B)
 * ============================================================ */

/* 模加: out = (a + b) mod p
 * IFIFO: A(32) + B(32) + P(32) = 96B -> OFIFO: 32B */
RSP_StatusTypeDef sm2_hw_madd(const uint8_t a[32], const uint8_t b[32],
                              const uint8_t p[32], uint8_t out[32]);

/* 模减: out = (a - b) mod p
 * IFIFO: A(32) + B(32) + P(32) = 96B -> OFIFO: 32B */
RSP_StatusTypeDef sm2_hw_msub(const uint8_t a[32], const uint8_t b[32],
                              const uint8_t p[32], uint8_t out[32]);

/* 模乘: out = (a * b) mod m (模数由硬件内部固定, 数据格式无 P 字段)
 * IFIFO: A(32) + B(32) = 64B -> OFIFO: 32B */
RSP_StatusTypeDef sm2_hw_mmul(const uint8_t a[32], const uint8_t b[32],
                              uint8_t out[32]);

/* 模逆: out = a^-1 mod p (SM2 曲线参数 p)
 * IFIFO: A(32) = 32B -> OFIFO: 32B */
RSP_StatusTypeDef sm2_hw_minv_p(const uint8_t a[32], uint8_t out[32]);

/* 模逆: out = a^-1 mod n (SM2 曲线阶 n)
 * IFIFO: A(32) = 32B -> OFIFO: 32B */
RSP_StatusTypeDef sm2_hw_minv_n(const uint8_t a[32], uint8_t out[32]);

/* ============================================================
 *  椭圆曲线点运算 (Jacobian 坐标, X||Y||Z 各 32B)
 * ============================================================ */

/* 点加: pc = pa + pb
 * IFIFO: PA(96) + PB(96) = 192B -> OFIFO: 96B */
RSP_StatusTypeDef sm2_hw_padd(const uint8_t pa[96], const uint8_t pb[96],
                              uint8_t pc[96]);

/* 点倍: pc = 2 * pa
 * IFIFO: PA(96) = 96B -> OFIFO: 96B */
RSP_StatusTypeDef sm2_hw_pdouble(const uint8_t pa[96], uint8_t pc[96]);

/* ============================================================
 *  点乘
 * ============================================================ */

/* 基点点乘 kG: 输入 k(32B) -> 输出公钥点 (x||y) 64B
 * IFIFO: k(32) = 32B -> OFIFO: 64B */
RSP_StatusTypeDef sm2_hw_kg(const uint8_t k[32], uint8_t pub_xy[64]);

/* 任意点点乘 kP: 输入 k(32B) + P(64B) -> 输出点 (x||y) 64B
 * IFIFO: k(32) + px(32) + py(32) = 96B -> OFIFO: 64B */
RSP_StatusTypeDef sm2_hw_kp(const uint8_t k[32], const uint8_t px[32],
                            const uint8_t py[32], uint8_t out_xy[64]);

/* ============================================================
 *  签名 / 验签
 * ============================================================ */

/* 签名(摘要版): 输入 e(32)+d(32)+k(32) = 96B -> 输出 r||s 64B
 * 注: 数据顺序为 e, d, k (新格式, 旧驱动为 e, k, d) */
RSP_StatusTypeDef sm2_hw_sign(const uint8_t e[32], const uint8_t d[32],
                              const uint8_t k[32], uint8_t rs[64]);

/* 签名(原始消息版): 硬件内部算 e = SM3(ZA || M)
 * IFIFO: [ENTL(2B)+ID, 补0到16B倍数] + Px(32) + Py(32)
 *        + [message, 补0到16B倍数] + d(32) + k(32)
 * OFIFO: r||s 64B
 * PKG_LEN = 消息原始字节数, CFG.ID_LEN = ID 字节数 */
RSP_StatusTypeDef sm2_hw_sign_msg(const uint8_t *id, uint32_t id_len,
                                  const uint8_t pub_xy[64],
                                  const uint8_t *msg, uint32_t msg_len,
                                  const uint8_t d[32], const uint8_t k[32],
                                  uint8_t rs[64]);

/* 验签(摘要版): 输入 e(32)+r(32)+s(32)+Px(32)+Py(32) = 160B
 * OFIFO: 64B 结果, 只有 1 位有效 (首字节非 0 即通过) */
RSP_StatusTypeDef sm2_hw_verify(const uint8_t e[32], const uint8_t r[32],
                                const uint8_t s[32], const uint8_t pub_xy[64],
                                int *is_valid);

/* 验签(原始消息版): 硬件内部算 e = SM3(ZA || M)
 * IFIFO: [ENTL+ID 补0] + px(32) + py(32) + [message 补0] + r(32) + s(32)
 *        + px(32) + py(32)
 * 注: 按数据格式, 公钥点在消息前后各出现一次, 本接口只传一次由驱动写两遍
 * PKG_LEN = 消息原始字节数, CFG.ID_LEN = ID 字节数 */
RSP_StatusTypeDef sm2_hw_verify_msg(const uint8_t *id, uint32_t id_len,
                                    const uint8_t *msg, uint32_t msg_len,
                                    const uint8_t r[32], const uint8_t s[32],
                                    const uint8_t pub_xy[64],
                                    int *is_valid);

/* ============================================================
 *  加解密
 * ============================================================ */

/* 加密: 输入 k(32) + Px(32) + Py(32) + plaintext(n) = 96+n
 * 输出 cipher = C1(64) || C2(n) || C3(32), *cipher_len = 96 + n
 * PKG_LEN = 明文长度 n
 * 注: 硬件 FIFO 中 C2 按 16B 补齐, 驱动读时自动裁掉补齐部分 */
RSP_StatusTypeDef sm2_hw_encrypt(const uint8_t k[32], const uint8_t pub_xy[64],
                                 const uint8_t *msg, uint32_t msg_len,
                                 uint8_t *cipher, uint32_t *cipher_len);

/* 解密: 输入 d(32) + cipher(C1||C2||C3), cipher_len = 96 + n
 * 硬件 IFIFO 实际写入顺序为 d + C1 + C3 + C2 (C3 在 C2 之前)
 * 输出明文 n 字节, *msg_len = n
 * PKG_LEN = C2 长度 n */
RSP_StatusTypeDef sm2_hw_decrypt(const uint8_t d[32], const uint8_t *cipher,
                                 uint32_t cipher_len, uint8_t *msg,
                                 uint32_t *msg_len);

/* ============================================================
 *  密钥交换 (模式 4)
 *
 *  输入顺序 (两侧对称):
 *    K(32) + 对端临时公钥(64) + [ENTL+对端ID 补0] + 对端静态公钥(64)
 *    + [ENTL+本端ID 补0] + 本端静态公钥(64) + 本端私钥(32) + KLEN(16)
 *    + [对端密钥确认标签(32), 仅 key_agree=1]
 *  输出顺序:
 *    [本端临时公钥(64), 仅 temp_pub_out=1] + 共享密钥(按16B倍数)
 *    + [本端密钥确认标签(32), 仅 key_agree=1] + CR(16)
 *
 *  说明: KLEN 为 16B 字段, 低 2 字节为大端 bit 长度, 其余补 0;
 *        kexch 模式不使用 CFG.ID_LEN (两侧 ID 由数据流中的 ENTL 给出),
 *        以避免与 bit16/bit17 标志位重叠。
 * ============================================================ */
typedef struct
{
    const uint8_t *self_id;      /*!< 本端用户 ID                */
    uint32_t self_id_len;        /*!< 本端 ID 字节数             */
    const uint8_t *peer_id;      /*!< 对端用户 ID                */
    uint32_t peer_id_len;        /*!< 对端 ID 字节数             */
    uint8_t self_pub[64];        /*!< 本端静态公钥 (Px||Py)      */
    uint8_t peer_pub[64];        /*!< 对端静态公钥 (Px||Py)      */
    uint8_t self_d[32];          /*!< 本端私钥                   */
    uint8_t k[32];               /*!< 本端临时随机数             */
    uint8_t peer_tmp[64];        /*!< 对端临时公钥 (Gx||Gy)      */
    uint16_t klen_bits;          /*!< 共享密钥长度 (bit)         */
    uint8_t peer_tag[32];        /*!< 对端密钥确认标签 (可选)    */
} sm2_kexch_in_t;

typedef struct
{
    uint8_t tmp_pub[64];         /*!< 本端临时公钥 (temp_pub_out=1 时有效) */
    uint8_t key[64];             /*!< 共享密钥, 按 16B 倍数给出            */
    uint32_t key_len;            /*!< 共享密钥字节数                       */
    uint8_t tag[32];             /*!< 本端密钥确认标签 (key_agree=1 时有效)*/
    uint8_t cr[16];              /*!< 协商结果 0:失败 1:成功               */
} sm2_kexch_out_t;

/**
 * @param in           输入参数
 * @param is_initiator 1: 发送端A, 0: 响应端B
 * @param temp_pub_out 1: 输出本端临时公钥
 * @param key_agree    1: 进行密钥确认 (需提供 in->peertag)
 * @param out          输出
 */
RSP_StatusTypeDef sm2_hw_kexch(const sm2_kexch_in_t *in, uint8_t is_initiator,
                               uint8_t temp_pub_out, uint8_t key_agree,
                               sm2_kexch_out_t *out);

#endif /* __RSP_IP_SM2_H__ */
