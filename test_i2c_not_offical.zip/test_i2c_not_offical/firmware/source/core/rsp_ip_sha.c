/**
 * @file rsp_ip_sha.c
 * @brief SHA2 硬件 IP 驱动（基于 sha2.xlsx 寄存器表）
 *        支持 SHA256 / SHA384 / SHA512，单算/HMAC，硬件/软件 padding，整包/分包
 */

#include "rsp_ip_sha.h"
#include <stdio.h>
#include <string.h>

#ifdef RSP_USE_DMA_PERF
#include "rsp_hal_dma.h"
#include "rsp_hal_misc.h"   /* rsp_hal_get_us() 性能计时 */
#endif

/* ============================================================
 *  内部常量
 * ============================================================ */

/* 各模式摘要长度 */
static const uint32_t sha2_digest_len[3] = {
    [SHA2_MODE_SHA256] = SHA256_DIGEST_SIZE,
    [SHA2_MODE_SHA384] = SHA384_DIGEST_SIZE,
    [SHA2_MODE_SHA512] = SHA512_DIGEST_SIZE,
};

/* 各模式分组大小 */
static const uint32_t sha2_block_len[3] = {
    [SHA2_MODE_SHA256] = SHA2_BLOCK_SIZE_256,
    [SHA2_MODE_SHA384] = SHA2_BLOCK_SIZE_512,
    [SHA2_MODE_SHA512] = SHA2_BLOCK_SIZE_512,
};

/* 各模式链式状态(IV)长度，单位字节
 * 依据 sha2_输入输出数据格式.xlsx 数据包格式2/4：
 *   sha256 iv=32B；sha384 iv=64B；sha512 iv=64B
 * 注意：SHA384 摘要输出为 48B，但其内部状态为 512bit(64B)，
 *       中间包/尾包回灌的 IV 必须写满 64B，否则硬件缺 16B 数据而挂死。
 */
static const uint32_t sha2_iv_len[3] = {
    [SHA2_MODE_SHA256] = 32U,
    [SHA2_MODE_SHA384] = 64U,
    [SHA2_MODE_SHA512] = 64U,
};

/* CFG SHA2_MODE 位 */
static const uint32_t sha2_cfg_mode[3] = {
    [SHA2_MODE_SHA256] = SHA2_CFG_SHA2_MODE_SHA256,
    [SHA2_MODE_SHA384] = SHA2_CFG_SHA2_MODE_SHA384,
    [SHA2_MODE_SHA512] = SHA2_CFG_SHA2_MODE_SHA512,
};

/* 各模式名称（参数错误日志用） */
static const char * const sha2_mode_name[3] = {
    [SHA2_MODE_SHA256] = "SHA256",
    [SHA2_MODE_SHA384] = "SHA384",
    [SHA2_MODE_SHA512] = "SHA512",
};

/* ============================================================
 *  核心内联辅助
 * ============================================================ */

/**
 * @brief 向 IFIFO 写一个 128bit(16字节)条目
 * @note  任意地址写 0x10~0x8F 均推入 IFIFO，固定写 base 地址
 */
static inline void SHA2_WriteIFIFO_128(const uint8_t *pData)
{
    const uint32_t *w = (const uint32_t *)pData;
    SHA2_IP->IFIFO[0] = w[0];
    SHA2_IP->IFIFO[1] = w[1];
    SHA2_IP->IFIFO[2] = w[2];
    SHA2_IP->IFIFO[3] = w[3];
}

/**
 * @brief 从 OFIFO 读一个 128bit(16字节)条目
 */
static inline void SHA2_ReadOFIFO_128(uint8_t *pData, uint32_t idx)
{
    uint32_t *w = (uint32_t *)pData;
    w[0] = SHA2_IP->OFIFO[idx + 0];
    w[1] = SHA2_IP->OFIFO[idx + 1];
    w[2] = SHA2_IP->OFIFO[idx + 2];
    w[3] = SHA2_IP->OFIFO[idx + 3];
}

/**
 * @brief 从 OFIFO 读一个 32bit 字
 */
static inline uint32_t SHA2_ReadOFIFO_Word(uint32_t idx)
{
    return SHA2_IP->OFIFO[idx];
}

/* ============================================================
 *  内部函数
 * ============================================================ */

/**
 * @brief SHA2 IP 软复位
 * @note  关 IP → 清 PKG_LEN/TOTAL_LEN → IFIFO 状态清零 → 排空 OFIFO 残留数据
 */
static void sha2_ip_reset(void)
{
    volatile uint32_t *base = (volatile uint32_t *)SHA2_IP_BASE;

    /* 1. 先关算核 */
    base[0x0C / 4] = 0U;

    /* 2. 清配置寄存器 */
    base[0x04 / 4] = 0U;   /* PKG_LEN */
    base[0x08 / 4] = 0U;   /* TOTAL_LEN */

    /* 3. FIFO 状态清零：写 1 持续清零，等待，写 0 恢复 */
    base[0x0C / 4] = SHA2_CFG_IFIFO_STATE_CLEAR;
    for (volatile int d = 0; d < 2000; d++);
    base[0x0C / 4] = 0U;

    /* 4. 排空 OFIFO 残留数据（与 SM3 一致），带超时防止死循环挂死固件 */
    {
        uint32_t timeout = SHA2_POLL_TIMEOUT;
        while ((SHA2_IP->STATE & SHA2_STATE_OFIFO_EMPTY_N) != 0U) {
            volatile uint32_t d = SHA2_IP->OFIFO[0];
            (void)d;
            if (--timeout == 0U) break;
        }
    }
}

/**
 * @brief 构建包含 INTR 阈值的 CFG 值
 */
static uint32_t sha2_build_cfg(sha2_mode_t mode, uint32_t header,
                                sha2_pad_t padding, uint8_t is_hmac)
{
    uint32_t cfg_val = sha2_cfg_mode[mode] | header;
    if (is_hmac) {
        cfg_val |= SHA2_CFG_HMAC_MODE_HMAC;
    }
    if (padding == SHA2_PAD_HARD) {
        cfg_val |= SHA2_CFG_PADDING_HARD;
    }
    /* INTR 阈值：PROG_FULL=7, PROG_EMPTY=1 */
    cfg_val |= (7U << SHA2_CFG_IFIFO_PROG_FULL_THRESH_Pos) |
               (1U << SHA2_CFG_IFIFO_PROG_EMPTY_THRESH_Pos);
    return cfg_val;
}

/**
 * @brief 软件 padding：计算 SHA2 padding 并追加到消息尾部
 * @param msg 原始消息
 * @param msg_len 原始长度
 * @param padded 输出 padded 缓冲区（调用者保证足够大）
 * @param padded_len 输出 padded 总长度
 * @param block_size 分组大小（64 或 128）
 * @param prefix_len 哈希流前置块字节数（HMAC 时=block_size，普通=0），仅影响 bit-length
 */
static void sha2_soft_pad(const uint8_t *msg, uint32_t msg_len,
                          uint8_t *padded, uint32_t *padded_len,
                          uint32_t block_size, uint32_t prefix_len)
{
    uint64_t bit_len = ((uint64_t)prefix_len + msg_len) * 8U;
    uint32_t mod = (prefix_len + msg_len) % block_size;
    /* SHA256 长度域 64bit(8B)，SHA384/512 长度域 128bit(16B) */
    uint32_t len_bytes = (block_size == 128U) ? 16U : 8U;
    uint32_t pad_len;

    /* 计算 padding 长度：需要 msg_len + 1 + pad_len + len_bytes ≡ 0 (mod block_size) */
    if (mod < (block_size - len_bytes)) {
        pad_len = block_size - len_bytes - mod - 1U;
    } else {
        pad_len = 2U * block_size - len_bytes - mod - 1U;
    }

    memcpy(padded, msg, msg_len);
    padded[msg_len] = 0x80U;
    memset(padded + msg_len + 1U, 0, pad_len);

    /* 追加大端位长度：高字节补 0，低 8 字节为 bit_len */
    for (uint32_t i = 0U; i < len_bytes; i++) {
        uint32_t shift = (len_bytes - i - 1U) * 8U;
        padded[msg_len + 1U + pad_len + i] =
            (shift < 64U) ? (uint8_t)(bit_len >> shift) : 0U;
    }

    *padded_len = msg_len + 1U + pad_len + len_bytes;
}

/**
 * @brief 计算软 padding 尾巴（不含原始消息），供流式分包使用
 * @param msg_len 原始消息长度
 * @param block_size 分组大小（64 或 128）
 * @param prefix_len 哈希流前置块字节数（HMAC 时=block_size，普通=0），仅影响 bit-length
 * @param tail 输出尾巴缓冲区（调用者保证 ≥ 2*block_size）
 * @param tail_len 输出尾巴长度
 * @param padded_total 输出 padded 总长度 = msg_len + tail_len
 * @note  流式分包时不在内存里拼接整条 padded 消息，只在最后一个包里
 *        "消息余数 + tail" 一次性写入，因此支持任意长度消息。
 */
static void sha2_soft_pad_tail(uint32_t msg_len, uint32_t block_size,
                               uint32_t prefix_len,
                               uint8_t *tail, uint32_t *tail_len,
                               uint32_t *padded_total)
{
    uint64_t bit_len = ((uint64_t)prefix_len + msg_len) * 8U;
    uint32_t mod = (prefix_len + msg_len) % block_size;
    uint32_t len_bytes = (block_size == 128U) ? 16U : 8U;
    uint32_t pad_len;

    if (mod < (block_size - len_bytes)) {
        pad_len = block_size - len_bytes - mod - 1U;
    } else {
        pad_len = 2U * block_size - len_bytes - mod - 1U;
    }

    memset(tail, 0, 1U + pad_len + len_bytes);
    tail[0] = 0x80U;
    for (uint32_t i = 0U; i < len_bytes; i++) {
        uint32_t shift = (len_bytes - i - 1U) * 8U;
        tail[1U + pad_len + i] = (shift < 64U) ? (uint8_t)(bit_len >> shift) : 0U;
    }

    *tail_len = 1U + pad_len + len_bytes;
    *padded_total = msg_len + *tail_len;
}

/**
 * @brief 构造 HMAC 的 K0：短 key 补零到硬件 key 槽位，超长 key 先哈希
 * @param mode SHA256/SHA384/SHA512
 * @param key 调用方传入的 key（长度可小于槽位）
 * @param key_len key 实际长度
 * @param k0 输出缓冲，长度 = 槽位长度（SHA256=64B，SHA384/512=128B）
 * @param k0_len 槽位长度
 * @note  硬件 IFIFO 的 key 槽位固定为 block_size，必须写满；
 *        若按调用方 key_len 直接 memcpy 槽位长度，会把 key 之后的
 *        消息内容当 key 写进硬件，导致 HMAC 结果错误。
 */
static RSP_StatusTypeDef sha2_build_k0(sha2_mode_t mode, const uint8_t *key,
                                       uint32_t key_len, uint8_t *k0, uint32_t k0_len)
{
    memset(k0, 0, k0_len);
    if (key_len > k0_len) {
        /* RFC 2104: key 超过分组长度时 K0 = H(key) 再补零 */
        return sha2_hw(mode, key, key_len, k0, sha2_digest_len[mode]);
    }
    memcpy(k0, key, key_len);
    return RSP_OK;
}

/**
 * @brief 向 IFIFO 流式写入数据（CPU 方式，16字节对齐）
 * @param data 数据
 * @param len 长度（必须 16 字节对齐）
 * @param use_prog_full 是否用 PROG_FULL 反压（ENABLE 后）
 * @return RSP_OK / RSP_ERR_FIFO
 */
static RSP_StatusTypeDef __attribute__((unused)) sha2_write_ififo(const uint8_t *data, uint32_t len,
                                          uint8_t use_prog_full)
{
    uint32_t i;
    uint32_t timeout;

    for (i = 0U; i < len; i += 16U) {
        timeout = SHA2_POLL_TIMEOUT;
        if (use_prog_full) {
            while ((SHA2_IP->STATE & SHA2_STATE_IFIFO_FULL) != 0U) {
                if (--timeout == 0U) return RSP_ERR_FIFO;
            }
        } else {
            while ((SHA2_IP->STATE & SHA2_STATE_IFIFO_FULL) != 0U) {
                if (--timeout == 0U) return RSP_ERR_FIFO;
            }
        }
        SHA2_WriteIFIFO_128(data + i);
    }
    return RSP_OK;
}

/**
 * @brief 读取 OFIFO 摘要
 * @param digest 输出缓冲区
 * @param digest_len 摘要长度（32/48/64）
 * @return RSP_OK / RSP_ERR_FIFO
 * @note  参照 SM3：每个 128bit 块读取前必须等待 OFIFO_EMPTY_N，
 *        否则连续读可能导致总线挂死（FIFO 暂空时无超时保护）
 */
static RSP_StatusTypeDef sha2_read_ofifo(uint8_t *digest, uint32_t digest_len)
{
    uint32_t timeout;
    uint32_t words = digest_len / 4U;
    uint32_t i;

    /* 按 128bit 条目读取，每块前等待 OFIFO 非空（与 SM3 一致） */
    for (i = 0U; i < words; i += 4U) {
        timeout = SHA2_POLL_TIMEOUT;
        while ((SHA2_IP->STATE & SHA2_STATE_OFIFO_EMPTY_N) == 0U) {
            if (--timeout == 0U) return RSP_ERR_FIFO;
        }
        if (i + 4U <= words) {
            SHA2_ReadOFIFO_128(digest + i * 4U, i);
        } else {
            /* 尾部长度不足 16B，逐字读取 */
            uint32_t j;
            for (j = i; j < words; j++) {
                ((uint32_t *)digest)[j] = SHA2_ReadOFIFO_Word(j);
            }
        }
    }
    return RSP_OK;
}

/**
 * @brief 等待算核完成
 */
static RSP_StatusTypeDef sha2_wait_done(void)
{
    uint32_t timeout = SHA2_POLL_TIMEOUT;
    while ((SHA2_IP->STATE & SHA2_STATE_DOEN) == 0U) {
        if (--timeout == 0U) {
            return RSP_ERR_TIMEOUT;
        }
    }
    return RSP_OK;
}

#ifdef RSP_USE_DMA_PERF
/* ============================================================
 *  SHA2 DMA 性能测试路径
 *
 *  参照 SM3 DMA 写法（IFIFO_WR_CNT 反压 + 64B 分块）和 SM4 三段式结构：
 *    ┌──────────┬──────────────────────────────────────────┐
 *    │ 预加载   │ 栈上拼连续 buffer → 单次 DMA 推进 IFIFO  │
 *    │ ENABLE后 │ 64B 大块 DMA 写 + IFIFO_WR_CNT 反压      │
 *    │ 读摘要   │ OFIFO_EMPTY_N 等待后 DMA 读              │
 *    └──────────┴──────────────────────────────────────────┘
 *
 *  注意：此 FPGA DMA IP 仅 TT_M2M_DFC 方向可用，M2P/P2M 会卡死
 *        SHA2 用 IFIFO_WR_CNT（非 PROG_FULL）做反压，与 SM3 一致
 *        SHA384/SHA512 硬 padding 有 bug，DMA 版统一用软 padding
 * ============================================================ */

/**
 * @brief DMA 写 IFIFO（64B 分块 + IFIFO_WR_CNT 反压）
 * @param len 必须 16 字节对齐
 */
static int sha2_dma_write_ififo(rsp_dma_transmit_t *dma,
                                const uint8_t *buf, uint32_t len)
{
    const uint32_t CHUNK_BYTES = 64U;  /* 4 个 128bit 条目，保守避免丢数 */
    uint32_t off = 0U;

    if ((len & 0x0FU) != 0U)
        return -1;

    while (off < len)
    {
        uint32_t n = len - off;
        if (n > CHUNK_BYTES) n = CHUNK_BYTES;
        uint32_t need_entries = n >> 4;

        uint32_t to = SHA2_POLL_TIMEOUT;
        while (((SHA2_IP->STATE & SHA2_STATE_IFIFO_WR_CNT_Msk)
                >> SHA2_STATE_IFIFO_WR_CNT_Pos) >
               (SHA2_IFIFO_DEPTH - need_entries))
        {
            if (--to == 0U) return -2;
        }

        int dret = dma_transfer(dma, (uint32_t)(buf + off), SHA2_IP_IFIFO_BASE, n);
        if (dret != 0) return dret;
        off += n;
    }
    return 0;
}

/**
 * @brief SHA2 DMA 性能测试版本（SHA256/SHA384/SHA512 单算）
 * @note  SHA256 用硬 padding；SHA384/SHA512 用软 padding（硬 padding 有 bug）
 */
RSP_StatusTypeDef sha2_hw_dma(sha2_mode_t mode, const uint8_t *in, uint32_t in_len,
                              uint8_t *out, uint32_t out_len)
{
    RSP_StatusTypeDef ret = RSP_OK;
    rsp_dma_transmit_t dma;
    uint32_t cfg_val, block_size, digest_len;
    uint32_t t_start, t_end, us, mbps, mbps_frac, mbs, frac;
    uint8_t pad_tail[256] __attribute__((aligned(4)));
    uint8_t tail_buf[256] __attribute__((aligned(4)));
    uint32_t pad_tail_len, padded_total, pkg_len_reg;
    uint32_t msg_rem, tail_len;
    int dr;

    if ((in == NULL) || (out == NULL) || (in_len == 0U))
        return RSP_ERR_NULL_PTR;

    block_size = (mode == SHA2_MODE_SHA256) ? SHA2_BLOCK_SIZE_256 : SHA2_BLOCK_SIZE_512;
    digest_len = sha2_digest_len[mode];
    if (out_len < digest_len)
        return RSP_ERR_INVALID_PARAM;

    /* 注意：此 FPGA DMA IP 仅 TT_M2M_DFC 方向可用 */
    if (rsp_hal_dma_init(&dma, 0, TT_M2M_DFC, DWIDTH_32, DWIDTH_32,
                         MSIZE_4, ADDR_INC, ADDR_INC,
                         HANDSHANKE_SOFT, HANDSHANKE_SOFT,
                         DMAC_REQ_DEFAULT, DMAC_REQ_DEFAULT) != 0)
        return RSP_ERR_FIFO;

    sha2_ip_reset();

    /* SHA384/SHA512 硬 padding 有 bug，统一软 padding；SHA256 用硬 padding */
    sha2_pad_t pad = (mode == SHA2_MODE_SHA256) ? SHA2_PAD_HARD : SHA2_PAD_SOFT;

    cfg_val = sha2_build_cfg(mode, SHA2_CFG_HEADER_ONE_PKG, pad, 0U);

    if (pad == SHA2_PAD_SOFT) {
        sha2_soft_pad_tail(in_len, block_size, 0U,
                           pad_tail, &pad_tail_len, &padded_total);
        pkg_len_reg = padded_total;
    } else {
        pkg_len_reg = in_len;
    }

    SHA2_IP->CFG = cfg_val;
    SHA2_IP->PKG_LEN = pkg_len_reg;
    SHA2_IP->TOTAL_LEN = pkg_len_reg;

    t_start = rsp_hal_get_us();

    /* ---- 阶段1：预加载（ENABLE 前 FIFO 空，无需反压）---- */
    /* 预加载最多 128B（IFIFO 深度），16B 对齐 */
    {
        uint32_t pre = (in_len >= 128U) ? 128U : in_len;
        uint8_t pre_buf[128] __attribute__((aligned(4)));
        uint32_t pre_aligned = (pre + 15U) & ~15U;
        memset(pre_buf, 0, sizeof(pre_buf));
        memcpy(pre_buf, in, pre);
        dr = dma_transfer(&dma, (uint32_t)pre_buf, SHA2_IP_IFIFO_BASE, pre_aligned);
        if (dr != 0) { ret = RSP_ERR_FIFO; goto err; }
    }

    /* ENABLE 算核 */
    SHA2_IP->CFG = cfg_val | SHA2_CFG_ENABLE;

    /* ---- 阶段2：流式写剩余 message ---- */
    /* 预加载已写了前 128B（2 个 64B 块） */
    {
        uint32_t written = (in_len >= 128U) ? 128U : ((in_len + 15U) & ~15U);
        uint32_t off;
        /* 从第 3 个 64B 块开始写（跳过预加载部分） */
        for (off = (written > in_len) ? in_len : written; off + 64U <= in_len; off += 64U) {
            dr = sha2_dma_write_ififo(&dma, in + off, 64U);
            if (dr != 0) { ret = RSP_ERR_FIFO; goto err; }
        }
        msg_rem = in_len - off;
    }

    /* 软 padding：尾部 message 余数 + padding 尾巴（保证 64B 对齐） */
    if (pad == SHA2_PAD_SOFT) {
        tail_len = msg_rem + pad_tail_len;
        /* tail_len 必为 64B 倍数（padded_total 是 block_size 倍数） */
        memset(tail_buf, 0, sizeof(tail_buf));
        memcpy(tail_buf, in + in_len - msg_rem, msg_rem);
        memcpy(tail_buf + msg_rem, pad_tail, pad_tail_len);
        dr = sha2_dma_write_ififo(&dma, tail_buf, tail_len);
        if (dr != 0) { ret = RSP_ERR_FIFO; goto err; }
    } else {
        /* 硬 padding：尾部余数 CPU 补零写（保证 16B 对齐） */
        if (msg_rem > 0U) {
            uint8_t tail[16] = {0};
            uint32_t to = SHA2_POLL_TIMEOUT;
            memcpy(tail, in + in_len - msg_rem, msg_rem);
            while ((SHA2_IP->STATE & SHA2_STATE_IFIFO_FULL) != 0U) {
                if (--to == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SHA2_WriteIFIFO_128(tail);
        }
    }

    /* 等待算核完成 */
    ret = sha2_wait_done();
    if (ret != RSP_OK) goto err;

    /* ---- 阶段3：DMA 读摘要 ---- */
    {
        uint32_t timeout = SHA2_POLL_TIMEOUT;
        while ((SHA2_IP->STATE & SHA2_STATE_OFIFO_EMPTY_N) == 0U) {
            if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
        }
    }
    {
        uint32_t digest_buf[16] __attribute__((aligned(4)));  /* 最大 64B */
        dr = dma_transfer(&dma, SHA2_IP_OFIFO_BASE, (uint32_t)digest_buf, digest_len);
        if (dr != 0) { ret = RSP_ERR_FIFO; goto err; }
        memcpy(out, digest_buf, digest_len);
    }

    t_end = rsp_hal_get_us();
    us = (t_end > t_start) ? (t_end - t_start) : 1U;
    if (us < 10U) us = 10U;
    mbps      = (uint32_t)(((uint64_t)in_len * 8ULL) / us);
    mbps_frac = (uint32_t)(((uint64_t)in_len * 8ULL * 1000ULL / us) % 1000ULL);
    mbs       = (uint32_t)((uint64_t)in_len / us);
    frac      = (uint32_t)(((uint64_t)in_len * 1000ULL / us) % 1000ULL);
    /* 性能打印已屏蔽 */
    (void)us; (void)mbps; (void)mbps_frac; (void)mbs; (void)frac;

    SHA2_IP->CFG = 0U;
    return RSP_OK;

err:
    SHA2_IP->CFG = 0U;
    return ret;
}

/**
 * @brief HMAC-SHA2 DMA 性能测试版本（SHA256/SHA384/SHA512）
 * @note  key 预处理：key>block_size 先哈希再补零，否则直接补零到 block_size
 *        SHA384/SHA512 用软 padding（HMAC 内层哈希流 bit-length 含 ipad 块）
 */
RSP_StatusTypeDef hmac_sha2_hw_dma(sha2_mode_t mode, const uint8_t *key, uint32_t key_len,
                                   const uint8_t *in, uint32_t in_len,
                                   uint8_t *out, uint32_t out_len)
{
    RSP_StatusTypeDef ret = RSP_OK;
    rsp_dma_transmit_t dma;
    uint32_t cfg_val, block_size, digest_len, key_slot;
    uint32_t t_start, t_end, us, mbps, mbps_frac, mbs, frac;
    uint8_t key_buf[128] __attribute__((aligned(4)));  /* 最大 128B（SHA384/512） */
    uint8_t pad_tail[256] __attribute__((aligned(4)));
    uint8_t tail_buf[256] __attribute__((aligned(4)));
    uint32_t pad_tail_len, padded_total, pkg_len_reg;
    uint32_t msg_rem, tail_len;
    int dr;

    if ((key == NULL) || (in == NULL) || (out == NULL) || (in_len == 0U))
        return RSP_ERR_NULL_PTR;
    if (key_len == 0U)
        return RSP_ERR_INVALID_PARAM;

    block_size = (mode == SHA2_MODE_SHA256) ? SHA2_BLOCK_SIZE_256 : SHA2_BLOCK_SIZE_512;
    digest_len = sha2_digest_len[mode];
    key_slot   = block_size;  /* HMAC key 槽位 = block_size */
    if (out_len < digest_len)
        return RSP_ERR_INVALID_PARAM;

    /* key 预处理：key>block_size 先哈希，否则补零 */
    memset(key_buf, 0, block_size);
    if (key_len > block_size) {
        ret = sha2_hw(mode, key, key_len, key_buf, block_size);
        if (ret != RSP_OK) return ret;
    } else {
        memcpy(key_buf, key, key_len);
    }

    if (rsp_hal_dma_init(&dma, 0, TT_M2M_DFC, DWIDTH_32, DWIDTH_32,
                         MSIZE_4, ADDR_INC, ADDR_INC,
                         HANDSHANKE_SOFT, HANDSHANKE_SOFT,
                         DMAC_REQ_DEFAULT, DMAC_REQ_DEFAULT) != 0)
        return RSP_ERR_FIFO;

    sha2_ip_reset();

    /* SHA384/SHA512 硬 padding 有 bug，HMAC 也用软 padding */
    sha2_pad_t pad = (mode == SHA2_MODE_SHA256) ? SHA2_PAD_HARD : SHA2_PAD_SOFT;

    cfg_val = sha2_build_cfg(mode, SHA2_CFG_HEADER_ONE_PKG, pad, 1U);

    if (pad == SHA2_PAD_SOFT) {
        /* HMAC 内层哈希流 = K0^ipad(block_size) || message，bit-length 含 ipad 块 */
        sha2_soft_pad_tail(in_len, block_size, block_size,
                           pad_tail, &pad_tail_len, &padded_total);
        pkg_len_reg = padded_total;
    } else {
        pkg_len_reg = in_len;
    }

    SHA2_IP->CFG = cfg_val;
    SHA2_IP->PKG_LEN = pkg_len_reg;
    SHA2_IP->TOTAL_LEN = pkg_len_reg;

    t_start = rsp_hal_get_us();

    /* ---- 阶段1：预加载 key（HMAC 首包无条件写 key）---- */
    /* key 占 key_slot 字节（64/128），必须在 message 之前写入 IFIFO */
    {
        uint32_t pre_msg = (128U - key_slot);  /* 预加载还能放多少 message */
        uint8_t pre_buf[128] __attribute__((aligned(4)));
        uint32_t pre_len;
        memset(pre_buf, 0, sizeof(pre_buf));
        memcpy(pre_buf, key_buf, key_slot);
        if (in_len <= pre_msg) {
            memcpy(pre_buf + key_slot, in, in_len);
            pre_len = key_slot + in_len;
        } else {
            memcpy(pre_buf + key_slot, in, pre_msg);
            pre_len = 128U;
        }
        pre_len = (pre_len + 15U) & ~15U;
        dr = dma_transfer(&dma, (uint32_t)pre_buf, SHA2_IP_IFIFO_BASE, pre_len);
        if (dr != 0) { ret = RSP_ERR_FIFO; goto err; }
    }

    /* ENABLE 算核 */
    SHA2_IP->CFG = cfg_val | SHA2_CFG_ENABLE;

    /* ---- 阶段2：流式写剩余 message ---- */
    {
        uint32_t pre_msg = (128U - key_slot);
        uint32_t off = (in_len <= pre_msg) ? in_len : pre_msg;
        /* 写完整 64B 块 */
        for (; off + 64U <= in_len; off += 64U) {
            dr = sha2_dma_write_ififo(&dma, in + off, 64U);
            if (dr != 0) { ret = RSP_ERR_FIFO; goto err; }
        }
        msg_rem = in_len - off;
    }

    /* padding 处理 */
    if (pad == SHA2_PAD_SOFT) {
        tail_len = msg_rem + pad_tail_len;
        memset(tail_buf, 0, sizeof(tail_buf));
        memcpy(tail_buf, in + in_len - msg_rem, msg_rem);
        memcpy(tail_buf + msg_rem, pad_tail, pad_tail_len);
        dr = sha2_dma_write_ififo(&dma, tail_buf, tail_len);
        if (dr != 0) { ret = RSP_ERR_FIFO; goto err; }
    } else {
        if (msg_rem > 0U) {
            uint8_t tail[16] = {0};
            uint32_t to = SHA2_POLL_TIMEOUT;
            memcpy(tail, in + in_len - msg_rem, msg_rem);
            while ((SHA2_IP->STATE & SHA2_STATE_IFIFO_FULL) != 0U) {
                if (--to == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SHA2_WriteIFIFO_128(tail);
        }
    }

    ret = sha2_wait_done();
    if (ret != RSP_OK) goto err;

    /* ---- 阶段3：DMA 读摘要 ---- */
    {
        uint32_t timeout = SHA2_POLL_TIMEOUT;
        while ((SHA2_IP->STATE & SHA2_STATE_OFIFO_EMPTY_N) == 0U) {
            if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
        }
    }
    {
        uint32_t digest_buf[16] __attribute__((aligned(4)));
        dr = dma_transfer(&dma, SHA2_IP_OFIFO_BASE, (uint32_t)digest_buf, digest_len);
        if (dr != 0) { ret = RSP_ERR_FIFO; goto err; }
        memcpy(out, digest_buf, digest_len);
    }

    t_end = rsp_hal_get_us();
    us = (t_end > t_start) ? (t_end - t_start) : 1U;
    if (us < 10U) us = 10U;
    mbps      = (uint32_t)(((uint64_t)in_len * 8ULL) / us);
    mbps_frac = (uint32_t)(((uint64_t)in_len * 8ULL * 1000ULL / us) % 1000ULL);
    mbs       = (uint32_t)((uint64_t)in_len / us);
    frac      = (uint32_t)(((uint64_t)in_len * 1000ULL / us) % 1000ULL);
    /* 性能打印已屏蔽 */
    (void)us; (void)mbps; (void)mbps_frac; (void)mbs; (void)frac;

    SHA2_IP->CFG = 0U;
    return RSP_OK;

err:
    SHA2_IP->CFG = 0U;
    return ret;
}
#endif /* RSP_USE_DMA_PERF */

/* ============================================================
 *  公开 API
 * ============================================================ */

/**
 * @brief SHA2 单包计算（整包模式）
 * @note  适用条件：key(64/128) + message ≤ 128B（IFIFO 深度）
 *        硬件 padding 时 PKG_LEN = msg_len，软件 padding 时 PKG_LEN = padded_len
 */
RSP_StatusTypeDef sha2_hw_one_pkg(sha2_ctx_t *ctx)
{
    RSP_StatusTypeDef ret = RSP_OK;
    uint32_t cfg_val;
    uint32_t pkg_len;
    uint32_t total_len;
    uint32_t key_slot;
    uint8_t key_buf[128];     /* HMAC K0：补零到硬件 key 槽位 */
    uint8_t padded_buf[256];  /* 软件 padding 缓冲区 */
    const uint8_t *msg_data;
    uint32_t msg_len;

    if ((ctx == NULL) || (ctx->in == NULL) || (ctx->out == NULL) || (ctx->in_len == 0U)) {
        return RSP_ERR_NULL_PTR;
    }

    /* 检查输出长度 */
    if (ctx->out_len < sha2_digest_len[ctx->mode]) {
        return RSP_ERR_INVALID_PARAM;
    }

    /* HMAC 模式检查 key */
    if (ctx->is_hmac) {
        if ((ctx->key == NULL) || (ctx->key_len == 0U)) {
            return RSP_ERR_NULL_PTR;
        }
    }

    /* key 在 IFIFO 中占固定槽位：SHA256=64B，SHA384/512=128B */
    key_slot = ctx->is_hmac ? ((ctx->mode == SHA2_MODE_SHA256) ? 64U : 128U) : 0U;

    /* HMAC：把调用方 key 补零成 K0（槽位长度），短 key 不能只按 key_len 写槽位 */
    if (ctx->is_hmac) {
        ret = sha2_build_k0(ctx->mode, ctx->key, ctx->key_len, key_buf, key_slot);
        if (ret != RSP_OK) return ret;
    }

    sha2_ip_reset();

    /* 构建 CFG（含 INTR 阈值）*/
    cfg_val = sha2_build_cfg(ctx->mode, SHA2_CFG_HEADER_ONE_PKG, ctx->padding, ctx->is_hmac);

    /* padding 方式 */
    if (ctx->padding == SHA2_PAD_HARD) {
        msg_data = ctx->in;
        msg_len = ctx->in_len;
        pkg_len = msg_len;
        total_len = msg_len;
    } else {
        /* 软件 padding */
        sha2_soft_pad(ctx->in, ctx->in_len, padded_buf, &msg_len, sha2_block_len[ctx->mode],
                      ctx->is_hmac ? sha2_block_len[ctx->mode] : 0U);
        msg_data = padded_buf;
        pkg_len = msg_len;
        total_len = msg_len;
    }

    /* IFIFO 容量检查：key槽 + 有效载荷 ≤ 128B（IFIFO 深度）。
     * 软 padding 后载荷可能膨胀超过 128B（如 SHA384 in_len∈[112,128] pad 到 256B），
     * 超出时回退流式分包，避免栈缓冲区和 IFIFO 双重溢出 */
    if (key_slot + msg_len > 128U) {
        return sha2_hw_stream(ctx);
    }

    SHA2_IP->CFG = cfg_val;
    SHA2_IP->PKG_LEN = pkg_len;
    SHA2_IP->TOTAL_LEN = total_len;

    /* ENABLE 前预加载 key + message 到 IFIFO（单包上限 128B = IFIFO 深度） */
    {
        uint8_t ififo_buf[128];
        uint32_t ififo_len = 0U;
        uint32_t timeout;

        /* 零初始化，消除尾条目非对齐部分的垃圾数据 */
        memset(ififo_buf, 0, sizeof(ififo_buf));

        /* 写 key（HMAC 模式，SHA256 key=64B, SHA384/512 key=128B） */
        if (ctx->is_hmac) {
            memcpy(ififo_buf, key_buf, key_slot);
            ififo_len += key_slot;
        }

        /* 写 message（按 16B 上对齐零填充，PKG_LEN 仍是原始 msg_len） */
        memcpy(ififo_buf + ififo_len, msg_data, msg_len);
        ififo_len += msg_len;
        if ((ififo_len & 0xFU) != 0U) {
            ififo_len = (ififo_len + 15U) & ~0xFU;
        }

        /* ENABLE 前写完所有 IFIFO 数据（单包 ≤ 128B 限制） */
        for (uint32_t i = 0U; i < ififo_len; i += 16U) {
            timeout = SHA2_POLL_TIMEOUT;
            while ((SHA2_IP->STATE & SHA2_STATE_IFIFO_FULL) != 0U) {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SHA2_WriteIFIFO_128(ififo_buf + i);
        }
    }

    /* ENABLE 算核 */
    SHA2_IP->CFG = cfg_val | SHA2_CFG_ENABLE;

    /* 等待完成 */
    ret = sha2_wait_done();
    if (ret != RSP_OK) goto err;

    /* 读取摘要：单包为最终摘要，按摘要长度读取
     * （SHA384 取 48B；若硬件实际输出完整 64B 状态，前 48B 即摘要）*/
    ret = sha2_read_ofifo(ctx->out, sha2_digest_len[ctx->mode]);
    if (ret != RSP_OK) goto err;

    /* 禁用算核 */
    SHA2_IP->CFG = 0U;
    return RSP_OK;

err:
    SHA2_IP->CFG = 0U;
    return ret;
}

/**
 * @brief SHA2 流式计算（分包模式）
 * @note  支持任意长度消息。首包/中间包/尾包自动切换。
 *        首包：HEADER=001，PKG_LEN=首包消息长度
 *        中间包：HEADER=010，PKG_LEN=中间包消息长度，需先读上段 IV
 *        尾包：HEADER=100，PKG_LEN=尾包消息长度
 *        硬件 padding 时 TOTAL_LEN = 总消息长度
 *        软件 padding 时 TOTAL_LEN = padded 总长度
 *        软件 padding 不在内存里拼接整条消息，只在最后一个包内
 *        写入"消息余数 + padding 尾巴"，因此消息长度不受缓冲区限制。
 */
RSP_StatusTypeDef sha2_hw_stream(sha2_ctx_t *ctx)
{
    RSP_StatusTypeDef ret = RSP_OK;
    uint32_t cfg_val;
    uint32_t block_size;
    uint32_t chunk_size;
    uint32_t msg_remaining;
    uint32_t msg_off = 0U;
    uint32_t pad_tail_len = 0U;
    uint32_t key_slot = 0U;
    uint8_t iv_buf[64];                          /* 中间包 IV */
    uint8_t key_buf[128];                        /* HMAC K0（补零到 key 槽位） */
    uint8_t pad_tail[2U * SHA2_BLOCK_SIZE_512];  /* 软 padding 尾巴，最大 144B */
    uint8_t last_buf[16U + 2U * SHA2_BLOCK_SIZE_512]; /* 最后一段消息余数 + tail */
    uint8_t use_soft_pad = 0U;
    uint32_t total_msg_len;
    uint32_t pkg_num = 0U;

    if ((ctx == NULL) || (ctx->in == NULL) || (ctx->out == NULL) || (ctx->in_len == 0U)) {
        return RSP_ERR_NULL_PTR;
    }

    if (ctx->out_len < sha2_digest_len[ctx->mode]) {
        return RSP_ERR_INVALID_PARAM;
    }

    if (ctx->is_hmac) {
        if ((ctx->key == NULL) || (ctx->key_len == 0U)) {
            return RSP_ERR_NULL_PTR;
        }
        /* key 槽位固定 block_size，必须写满（短 key 补零，超长 key 先哈希） */
        key_slot = (ctx->mode == SHA2_MODE_SHA256) ? 64U : 128U;
        ret = sha2_build_k0(ctx->mode, ctx->key, ctx->key_len, key_buf, key_slot);
        if (ret != RSP_OK) return ret;
    }

    block_size = sha2_block_len[ctx->mode];

    /* chunk_size：用户自定义或默认按块大小，向下对齐到块边界 */
    chunk_size = (ctx->chunk_size != 0U) ? ctx->chunk_size : block_size;
    if (chunk_size > block_size) {
        chunk_size = (chunk_size / block_size) * block_size;
    }
    if (chunk_size < block_size) {
        chunk_size = block_size;
    }

    /* SHA384/SHA512（128bit 分组家族）硬件 padding 会挂死，统一改软件 padding */
    if ((ctx->mode != SHA2_MODE_SHA256) && (ctx->padding == SHA2_PAD_HARD)) {
        ctx->padding = SHA2_PAD_SOFT;
    }

    /* 软件 padding：只算尾巴，不复制整条消息（消息可以任意长） */
    if (ctx->padding == SHA2_PAD_SOFT) {
        /* HMAC 时哈希流前置 ipad 块(block_size)，bit-length 需包含它 */
        sha2_soft_pad_tail(ctx->in_len, block_size, ctx->is_hmac ? block_size : 0U,
                           pad_tail, &pad_tail_len, &total_msg_len);
        use_soft_pad = 1U;
    } else {
        total_msg_len = ctx->in_len;
    }

    /* 分包循环：消息按 chunk_size 切分，软 padding 尾巴并入最后一个包 */
    msg_remaining = ctx->in_len;
    while ((msg_remaining > 0U) || (use_soft_pad && (pad_tail_len > 0U))) {
        uint32_t msg_part;
        uint32_t tail_part = 0U;
        uint32_t cur_pkg_len;
        uint32_t header;
        uint32_t pkg_len_reg;
        uint32_t total_len_reg;
        uint8_t is_first = (pkg_num == 0U) ? 1U : 0U;
        uint8_t is_last;

        /* 本包消息长度；最后一段消息后面并入 padding 尾巴 */
        msg_part = (msg_remaining > chunk_size) ? chunk_size : msg_remaining;
        if (use_soft_pad && (msg_part == msg_remaining)) {
            tail_part = pad_tail_len;
            pad_tail_len = 0U;   /* 尾巴只写一次 */
        }
        cur_pkg_len = msg_part + tail_part;
        is_last = (msg_part == msg_remaining) ? 1U : 0U;

        /* 确定 HEADER */
        if (is_first && is_last) {
            header = SHA2_CFG_HEADER_ONE_PKG;
        } else if (is_first) {
            header = SHA2_CFG_HEADER_HEAD_PKG;
        } else if (is_last) {
            header = SHA2_CFG_HEADER_TAIL_PKG;
        } else {
            header = SHA2_CFG_HEADER_MID_PKG;
        }

        sha2_ip_reset();

        /* 构建 CFG（含 INTR 阈值）*/
        cfg_val = sha2_build_cfg(ctx->mode, header, ctx->padding, ctx->is_hmac);

        /* PKG_LEN 和 TOTAL_LEN 设置 */
        if (ctx->padding == SHA2_PAD_HARD) {
            /* 硬件 padding：PKG_LEN = 当前包原始消息长度，TOTAL_LEN = 总原始消息长度 */
            pkg_len_reg = cur_pkg_len;
            total_len_reg = total_msg_len;
        } else {
            /* 软件 padding：PKG_LEN = 当前包 padded 长度，TOTAL_LEN = padded 总长度 */
            pkg_len_reg = cur_pkg_len;
            total_len_reg = total_msg_len;
        }

        SHA2_IP->CFG = cfg_val;
        SHA2_IP->PKG_LEN = pkg_len_reg;
        SHA2_IP->TOTAL_LEN = total_len_reg;

        /* ENABLE 后流式写（仿 SM3 StreamingHash：ENABLE → IFIFO_FULL 反压写）*/
        SHA2_IP->CFG = cfg_val | SHA2_CFG_ENABLE;
        {
            uint32_t timeout;

            /* 首包HMAC：写 K0（槽位 64/128B，已按槽位补零） */
            if (is_first && ctx->is_hmac) {
                for (uint32_t i = 0U; i < key_slot; i += 16U) {
                    timeout = SHA2_POLL_TIMEOUT;
                    while ((SHA2_IP->STATE & SHA2_STATE_IFIFO_FULL) != 0U) {
                        if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
                    }
                    SHA2_WriteIFIFO_128(key_buf + i);
                }
            }

            /* 中间/尾包：写 IV（上段运算结果；512 家族 IV=64B，非摘要长度 48B） */
            if (!is_first) {
                uint32_t iv_len = sha2_iv_len[ctx->mode];
                for (uint32_t i = 0U; i < iv_len; i += 16U) {
                    timeout = SHA2_POLL_TIMEOUT;
                    while ((SHA2_IP->STATE & SHA2_STATE_IFIFO_FULL) != 0U) {
                        if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
                    }
                    SHA2_WriteIFIFO_128(iv_buf + i);
                }
            }

            /* 写当前包数据（16B 条目流式写）：消息段 + 可选的 padding 尾巴 */
            {
                const uint8_t *p = ctx->in + msg_off;
                uint32_t full = msg_part / 16U;
                uint32_t rem = msg_part % 16U;

                for (uint32_t i = 0U; i < full; i++) {
                    timeout = SHA2_POLL_TIMEOUT;
                    while ((SHA2_IP->STATE & SHA2_STATE_IFIFO_FULL) != 0U) {
                        if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
                    }
                    SHA2_WriteIFIFO_128(p + i * 16U);
                }

                if (tail_part == 0U) {
                    /* 尾部不足 16B，零填充到一个条目 */
                    if (rem > 0U) {
                        uint8_t pad[16] = {0};
                        memcpy(pad, p + full * 16U, rem);
                        timeout = SHA2_POLL_TIMEOUT;
                        while ((SHA2_IP->STATE & SHA2_STATE_IFIFO_FULL) != 0U) {
                            if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
                        }
                        SHA2_WriteIFIFO_128(pad);
                    }
                } else {
                    /* 最后一段消息余数 + padding 尾巴，拼成 16B 条目写出 */
                    memset(last_buf, 0, sizeof(last_buf));
                    memcpy(last_buf, p + full * 16U, rem);
                    memcpy(last_buf + rem, pad_tail, tail_part);
                    for (uint32_t i = 0U; i < (rem + tail_part); i += 16U) {
                        timeout = SHA2_POLL_TIMEOUT;
                        while ((SHA2_IP->STATE & SHA2_STATE_IFIFO_FULL) != 0U) {
                            if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
                        }
                        SHA2_WriteIFIFO_128(last_buf + i);
                    }
                }
            }
        }

        /* 等待完成 */
        ret = sha2_wait_done();
        if (ret != RSP_OK) goto err;

        /* 读取结果：尾包读摘要长度（SHA384=48B，硬件尾包输出即最终摘要）；
         * 中间包读完整链接状态（512 家族 IV=64B）作为下一段 IV */
        if (is_last) {
            ret = sha2_read_ofifo(ctx->out, sha2_digest_len[ctx->mode]);
        } else {
            ret = sha2_read_ofifo(iv_buf, sha2_iv_len[ctx->mode]);
        }
        if (ret != RSP_OK) goto err;

        msg_off += msg_part;
        msg_remaining -= msg_part;
        pkg_num++;
    }

    SHA2_IP->CFG = 0U;
    return RSP_OK;

err:
    SHA2_IP->CFG = 0U;
    return ret;
}

/* ============================================================
 *  参数错误上报（参照 SM4 驱动：逐参数检查 + 诊断日志）
 * ============================================================ */
static RSP_StatusTypeDef sha2_param_null_err(const char *algo, const char *param)
{
    printf("[SHA2 %s] %s_null_err\n", algo, param);
    return RSP_ERR_NULL_PTR;
}

static RSP_StatusTypeDef sha2_param_len_err(const char *algo, const char *param,
                                            uint32_t got, const char *expect)
{
    printf("[SHA2 %s] %s_len_err: got=%lu expect=%s\n", algo, param,
           (unsigned long)got, expect);
    return RSP_ERR_INVALID_PARAM;
}

/**
 * @brief SHA2 计算（自动选择单包/流式）
 */
RSP_StatusTypeDef sha2_hw(sha2_mode_t mode, const uint8_t *in, uint32_t in_len,
                          uint8_t *out, uint32_t out_len)
{
    sha2_ctx_t ctx;
    uint32_t max_one_pkg = 128U;  /* IFIFO 深度 128B */
    uint32_t digest_len = sha2_digest_len[mode];

    if (in == NULL)   return sha2_param_null_err(sha2_mode_name[mode], "in");
    if (out == NULL)  return sha2_param_null_err(sha2_mode_name[mode], "out");
    if (in_len == 0U) return sha2_param_len_err(sha2_mode_name[mode], "msg", in_len, ">0");
    if (out_len < digest_len)
        return sha2_param_len_err(sha2_mode_name[mode], "out", out_len, ">=digest_len");

#if RSP_USE_DMA_PERF
    return sha2_hw_dma(mode, in, in_len, out, out_len);
#else

    if (in_len <= max_one_pkg) {
        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = mode;
        /* SHA384/SHA512（128bit 分组家族）硬件 padding 有 bug（BUSY 卡死），统一改软 padding */
        ctx.padding = (mode == SHA2_MODE_SHA256) ? SHA2_PAD_HARD : SHA2_PAD_SOFT;
        ctx.is_hmac = 0U;
        ctx.in = in;
        ctx.in_len = in_len;
        ctx.out = out;
        ctx.out_len = out_len;
        return sha2_hw_one_pkg(&ctx);
    }

    /* 流式分包 */
    memset(&ctx, 0, sizeof(ctx));
    ctx.mode = mode;
    ctx.padding = (mode == SHA2_MODE_SHA256) ? SHA2_PAD_HARD : SHA2_PAD_SOFT;
    ctx.is_hmac = 0U;
    ctx.in = in;
    ctx.in_len = in_len;
    ctx.out = out;
    ctx.out_len = out_len;
    return sha2_hw_stream(&ctx);
#endif
}

/**
 * @brief HMAC-SHA2 计算
 */
RSP_StatusTypeDef hmac_sha2_hw(sha2_mode_t mode, const uint8_t *key, uint32_t key_len,
                               const uint8_t *in, uint32_t in_len,
                               uint8_t *out, uint32_t out_len)
{
    sha2_ctx_t ctx;
    uint32_t key_ififo_len = (mode == SHA2_MODE_SHA256) ? 64U : 128U;
    uint32_t max_one_pkg = 128U - key_ififo_len;
    uint32_t digest_len = sha2_digest_len[mode];

    if (key == NULL)   return sha2_param_null_err(sha2_mode_name[mode], "key");
    if (in == NULL)    return sha2_param_null_err(sha2_mode_name[mode], "in");
    if (out == NULL)   return sha2_param_null_err(sha2_mode_name[mode], "out");
    if (key_len == 0U) return sha2_param_len_err(sha2_mode_name[mode], "key", key_len, ">0");
    if (in_len == 0U)  return sha2_param_len_err(sha2_mode_name[mode], "msg", in_len, ">0");
    if (out_len < digest_len)
        return sha2_param_len_err(sha2_mode_name[mode], "out", out_len, ">=digest_len");

#if RSP_USE_DMA_PERF
    return hmac_sha2_hw_dma(mode, key, key_len, in, in_len, out, out_len);
#else

    if (in_len <= max_one_pkg) {
        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = mode;
        ctx.padding = (mode == SHA2_MODE_SHA256) ? SHA2_PAD_HARD : SHA2_PAD_SOFT;
        ctx.is_hmac = 1U;
        ctx.key = key;
        ctx.key_len = key_len;
        ctx.in = in;
        ctx.in_len = in_len;
        ctx.out = out;
        ctx.out_len = out_len;
        return sha2_hw_one_pkg(&ctx);
    }

    /* 流式分包 */
    memset(&ctx, 0, sizeof(ctx));
    ctx.mode = mode;
    ctx.padding = SHA2_PAD_HARD;
    ctx.is_hmac = 1U;
    ctx.key = key;
    ctx.key_len = key_len;
    ctx.in = in;
    ctx.in_len = in_len;
    ctx.out = out;
    ctx.out_len = out_len;
    return sha2_hw_stream(&ctx);
#endif
}
