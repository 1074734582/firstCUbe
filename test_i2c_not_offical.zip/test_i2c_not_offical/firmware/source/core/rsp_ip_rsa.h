/**
 * @file rsp_ip_rsa.h
 * @brief RSA2048 硬件 IP 驱动 (基址 0x80070000)
 *        依据 rsa.xlsx 与 rsa_输入输出数据包格式.xlsx
 *
 *  支持模式:
 *    Sign2048           - 标准签名 (message 已做 DigestInfo + PKCS#1 v1.5 填充, 256B)
 *    Sign2048_CRT       - CRT 加速签名 (message 同上)
 *    verify2048         - 标准验签 (message 同上, 输出恢复的 m)
 *    Sign2048_pkcs      - IP 内部 PKCS#1 v1.5 填充签名 (message 原始, 任意长度)
 *    Sign2048_CRT_pkcs  - CRT + PKCS#1 内部填充
 *    Sign2048_pass      - IP 内部 RSA_PASS 填充签名 (message 原始, 任意长度)
 *    Sign2048_CRT_pass  - CRT + RSA_PASS 内部填充
 *    verify2048_pkcs    - IP 内部 PKCS#1 验签 (输出 128B 验签结果)
 *    verify2048_pass    - IP 内部 RSA_PASS 验签 (输出 128B 验签结果)
 */
#ifndef __RSP_IP_RSA_H__
#define __RSP_IP_RSA_H__

#include "rsp_ip_common.h"
#include <stdint.h>

/* ========== 基地址 ========== */
#define RSA_IP_BASE  (0x80070000UL)
#define RSA_IP       ((RSA_TypeDef *)RSA_IP_BASE)

/* ========== 常量 ========== */
#define RSA2048_N_BYTES     (256U)  /* 2048bit = 256B 模数 N / 指数 d/e */
#define RSA2048_P_BYTES     (128U)  /* 1024bit = 128B 素数 p/q/dp/dq/qinv */
#define RSA2048_BLOCK_BYTES (16U)   /* IFIFO/OFIFO 每个条目 128bit = 16B */
#define RSA_IFIFO_DEPTH     (8U)    /* IFIFO 深度 8 条目 */
#define RSA_OFIFO_DEPTH     (2U)    /* OFIFO 深度 2 条目 */
#define RSA_POLL_TIMEOUT    (1000000U)
/* 2048bit 模幂耗时远大于 FIFO 轮询周期, 等待首个输出字用更长的预算 */
#define RSA_OUT_WAIT        (8000000U)
/* 尾部不足一个 128bit 条目的字, 空标志会一直误报, 先短等再补踢 ENABLE */
#define RSA_TAIL_WAIT       (200000U)
/* 输入被算核取完后, 等待结果推进 OFIFO 的 settle 轮数 */
#define RSA_SETTLE          (1000000U)

/* ========== 寄存器结构体 ==========
 *  rsa_输入输出数据包格式.xlsx
 *
 *  偏移    寄存器          宽度    说明
 *  0x00    STATE           32bit   RO  状态/中断标志
 *  0x04    INTR            32bit   RW  中断使能/屏蔽/阈值 + FIFO 复位
 *  0x08    PKG_LEN         32bit   RW  数据包总长度 (IFIFO 全部字节数)
 *  0x0C    CFG             32bit   RW  配置寄存器
 *  0x10~   IFIFO           128bit  WO  输入 FIFO, 8 × 128bit = 128B
 *  0x8F    (共 0x80B = 128 字节)
 *  0x90~   OFIFO           128bit  RO  输出 FIFO, 2 × 128bit = 32B
 *  0xAF
 */
typedef struct
{
    __I  uint32_t STATE;          /* 0x00 RO  */
    __IO uint32_t INTR;           /* 0x04 RW  */
    __IO uint32_t PKG_LEN;        /* 0x08 RW  */
    __IO uint32_t CFG;            /* 0x0C RW  */
    __O  uint32_t IFIFO[32];      /* 0x10~0x8F WO  128B */
    __I  uint32_t OFIFO[8];       /* 0x90~0xAF RO   32B */
} RSA_TypeDef;

/* ========== STATE (0x00) ========== */
#define RSA_STATE_IFIFO_FULL          (1U << 0U)   /* bit0 IFIFO 真满 */
#define RSA_STATE_IFIFO_EMPTY         (1U << 1U)   /* bit1 IFIFO 真空 */
#define RSA_STATE_IFIFO_PROG_FULL     (1U << 2U)   /* bit2 IFIFO 阈满 */
#define RSA_STATE_IFIFO_PROG_EMPTY    (1U << 3U)   /* bit3 IFIFO 阈空 */
#define RSA_STATE_OFIFO_FULL          (1U << 4U)   /* bit4 OFIFO 真满 */
#define RSA_STATE_OFIFO_EMPTY         (1U << 5U)   /* bit5 OFIFO 真空 */
#define RSA_STATE_OFIFO_PROG_FULL     (1U << 6U)   /* bit6 OFIFO 阈满 */
#define RSA_STATE_OFIFO_PROG_EMPTY    (1U << 7U)   /* bit7 OFIFO 阈空 */
#define RSA_STATE_IFIFO_CNT_Pos       (8U)
#define RSA_STATE_IFIFO_CNT_Msk       (0xFFU << 8U)   /* bit[15:8] IFIFO 深度 */
#define RSA_STATE_OFIFO_CNT_Pos       (16U)
#define RSA_STATE_OFIFO_CNT_Msk       (0xFFU << 16U)  /* bit[23:16] OFIFO 深度 */
/* 中断标志 (RO) bit[31:24] */
#define RSA_STATE_IFIFO_FULL_INTR_FLAG         (1U << 24U)
#define RSA_STATE_IFIFO_EMPTY_INTR_FLAG        (1U << 25U)
#define RSA_STATE_IFIFO_PROG_FULL_INTR_FLAG    (1U << 26U)
#define RSA_STATE_IFIFO_PROG_EMPTY_INTR_FLAG   (1U << 27U)
#define RSA_STATE_OFIFO_FULL_INTR_FLAG         (1U << 28U)
#define RSA_STATE_OFIFO_EMPTY_INTR_FLAG        (1U << 29U)
#define RSA_STATE_OFIFO_PROG_FULL_INTR_FLAG    (1U << 30U)
#define RSA_STATE_OFIFO_PROG_EMPTY_INTR_FLAG   (1U << 31U)

/* ========== INTR (0x04) ========== */
#define RSA_INTR_EN                   (1U << 0U)   /* bit0 全局中断使能 */
#define RSA_INTR_FIFO_STATE_CLEAR     (1U << 1U)   /* bit1 W1SC FIFO 状态复位 */
#define RSA_INTR_MASK_Pos             (8U)
#define RSA_INTR_MASK_Msk             (0xFFU << 8U)
#define RSA_INTR_CLRER                (1U << 16U)  /* bit16 W1SC 清全局中断 */
#define RSA_INTR_IFIFO_PROG_FULL_THRESH_Pos   (20U)
#define RSA_INTR_IFIFO_PROG_FULL_THRESH_Msk   (0x7U << 20U)
#define RSA_INTR_IFIFO_PROG_EMPTY_THRESH_Pos  (23U)
#define RSA_INTR_IFIFO_PROG_EMPTY_THRESH_Msk  (0x7U << 23U)
#define RSA_INTR_OFIFO_PROG_FULL_THRESH_Pos   (26U)
#define RSA_INTR_OFIFO_PROG_FULL_THRESH_Msk   (0x7U << 26U)
#define RSA_INTR_OFIFO_PROG_EMPTY_THRESH_Pos  (29U)
#define RSA_INTR_OFIFO_PROG_EMPTY_THRESH_Msk  (0x7U << 29U)

/* ========== CFG (0x0C) ========== */
#define RSA_CFG_ENABLE                (1U << 0U)   /* bit0 W1SC 写1自清 */
#define RSA_CFG_PADDING_EN            (1U << 8U)   /* bit8 0=输入已填充 1=输入原始消息 */
#define RSA_CFG_PADDING_MODE          (1U << 9U)   /* bit9 0=PKCS#1 1=RSA_PASS */
#define RSA_CFG_SIGN_EN               (1U << 10U)  /* bit10 0=验签 1=签名 */
#define RSA_CFG_CRT_EN                (1U << 11U)  /* bit11 CRT 模式 */
#define RSA_CFG_INPUT_SWAP            (1U << 12U)  /* bit12 输入大小端转换 */
#define RSA_CFG_OUTPUT_SWAP           (1U << 13U)  /* bit13 输出大小端转换 */
/* 新版 rsa.xlsx 在 bit[15:14] 新增 MODE: 2'b00=2048, 2'b01=1024 */
#define RSA_CFG_MODE_Pos              (14U)
#define RSA_CFG_MODE_Msk              (0x3U << 14U)
#define RSA_CFG_MODE_2048             (0x0U << 14U)
#define RSA_CFG_MODE_1024             (0x1U << 14U)

/* ========== OFIFO 输出语义 ==========
 *
 *  模式                              输出字节数    含义
 *  Sign2048 / sign_CRT / sign_pkcs / sign_pass   256B   签名值 s
 *  verify2048                                      256B   恢复的 m = s^e mod n
 *  verify2048_pkcs / verify2048_pass               128B   验签结果
 *    result[31:0]        = bit 127..32 中 1 的个数
 *    result[39:32]       = 0x01 包头 00 01 正确, 0x00 错误
 *    result[47:40]       = 0x01 分隔符 0x00 正确, 0x00 错误
 */

/* ========== 公共 API ==========
 *
 *  以下所有函数内部完成: 参数校验 -> IP 复位 -> 配置 CFG/INTR/PKG_LEN
 *  -> 预加载 IFIFO -> ENABLE -> 流式写 (PROG_FULL 反压) -> 读 OFIFO -> IP 禁用
 *
 *  调用者负责: 传入正确格式的公/私钥参数, 正确长度的 message
 *
 *  参数说明:
 *    n_256  - 模数 N, 大端 256B
 *    d_256  - 私钥指数 d, 大端 256B
 *    e_256  - 公钥指数 e, 大端 256B (通常低 3B=0x010001, 高字节补 0)
 *    p_128  - 素数 p, 大端 128B
 *    q_128  - 素数 q, 大端 128B
 *    dp_128 - d mod (p-1), 大端 128B
 *    dq_128 - d mod (q-1), 大端 128B
 *    qinv_128 - q^-1 mod p, 大端 128B
 *    s_256  - RSA_PASS 盐值 S, 大端 256B (硬件内部填充用)
 *    msg    - 输入消息
 *    msg_len - 消息字节数
 *    out_256 - 输出缓冲区 (sign/verify 恢复模式需 256B)
 *    out_128 - 输出缓冲区 (pkcs/pass 验签结果 128B)
 */

/* ---------- Sign2048 (标准 modexp 签名, message 已填充 256B) ----------
 * IFIFO: N(256) + d(256) + message(256) = 768B = 48 条目
 * OFIFO: s(256B)
 */
RSP_StatusTypeDef rsa2048_sign_hw(const uint8_t *n_256, const uint8_t *d_256,
                                  const uint8_t *msg_256, uint8_t *sig_out);

/* ---------- Sign2048_CRT (CRT 加速签名, message 已填充 256B) ----------
 * IFIFO: dp(128) + dq(128) + p(128) + q(128) + qinv(128) + msg(256) = 896B = 56 条目
 * OFIFO: s(256B)
 */
RSP_StatusTypeDef rsa2048_sign_crt_hw(const uint8_t *dp_128, const uint8_t *dq_128,
                                      const uint8_t *p_128, const uint8_t *q_128,
                                      const uint8_t *qinv_128, const uint8_t *msg_256,
                                      uint8_t *sig_out);

/* ---------- verify2048 (标准 modexp 验签, message 已填充 256B, 输出恢复的 m) ----------
 * IFIFO: N(256) + e(256) + message(256) = 768B = 48 条目
 *        (算核第 1 个操作数固定是模数, 与 Sign2048 同数据通路;
 *         xlsx 列举的 e,N 顺序不能直接当作 FIFO 槽位顺序)
 * OFIFO: m(256B), 调用者自行和期望 DigestInfo 比较
 */
RSP_StatusTypeDef rsa2048_verify_hw(const uint8_t *e_256, const uint8_t *n_256,
                                    const uint8_t *msg_256, uint8_t *m_out);

/* ---------- Sign2048_pkcs (PKCS#1 v1.5 内部填充签名, message 原始) ----------
 * IFIFO: N(256) + d(256) + message(任意长度) = 512 + msg_len B
 * OFIFO: s(256B)
 */
RSP_StatusTypeDef rsa2048_sign_pkcs_hw(const uint8_t *n_256, const uint8_t *d_256,
                                       const uint8_t *msg, uint32_t msg_len,
                                       uint8_t *sig_out);

/* ---------- Sign2048_CRT_pkcs (CRT + PKCS#1 内部填充) ---------- */
RSP_StatusTypeDef rsa2048_sign_crt_pkcs_hw(const uint8_t *dp_128, const uint8_t *dq_128,
                                            const uint8_t *p_128, const uint8_t *q_128,
                                            const uint8_t *qinv_128,
                                            const uint8_t *msg, uint32_t msg_len,
                                            uint8_t *sig_out);

/* ---------- Sign2048_pass (RSA_PASS 内部填充签名, 需要盐值 S) ----------
 * IFIFO: N(256) + d(256) + S(256) + message(任意长度) = 768 + msg_len B
 */
RSP_StatusTypeDef rsa2048_sign_pass_hw(const uint8_t *n_256, const uint8_t *d_256,
                                        const uint8_t *s_256,
                                        const uint8_t *msg, uint32_t msg_len,
                                        uint8_t *sig_out);

/* ---------- Sign2048_CRT_pass (CRT + RSA_PASS 内部填充, 需要盐值 S) ----------
 * IFIFO: dp(128)+dq(128)+p(128)+q(128)+qinv(128)+S(256)+message = 896 + msg_len B
 */
RSP_StatusTypeDef rsa2048_sign_crt_pass_hw(const uint8_t *dp_128, const uint8_t *dq_128,
                                            const uint8_t *p_128, const uint8_t *q_128,
                                            const uint8_t *qinv_128,
                                            const uint8_t *s_256,
                                            const uint8_t *msg, uint32_t msg_len,
                                            uint8_t *sig_out);

/* ---------- verify2048_pkcs (IP 内部 PKCS#1 验签, 输出 128B 结果) ----------
 * IFIFO: N(256) + e(256) + message(任意长度) = 512 + msg_len B
 * OFIFO: result(128B), 见 OFIFO 输出语义
 */
RSP_StatusTypeDef rsa2048_verify_pkcs_hw(const uint8_t *e_256, const uint8_t *n_256,
                                         const uint8_t *msg, uint32_t msg_len,
                                         uint8_t *result_128);

/* ---------- verify2048_pass (IP 内部 RSA_PASS 验签, 输出 128B 结果) ----------
 * IFIFO: N(256) + e(256) + S(256) + message(任意长度) = 768 + msg_len B
 */
RSP_StatusTypeDef rsa2048_verify_pass_hw(const uint8_t *e_256, const uint8_t *n_256,
                                          const uint8_t *s_256,
                                          const uint8_t *msg, uint32_t msg_len,
                                          uint8_t *result_128);

#endif /* __RSP_IP_RSA_H__ */
