/**
 * @file rsp_ip_sm2.c
 * @brief SM2 硬件 IP 驱动
 *        依据 sm2.xlsx (寄存器表) 与 sm2_输入输出数据格式.xlsx (数据包格式)
 *
 * 数据约定:
 *   - 256bit 数值为大端 32 字节, 每个 32B 拆成 2 个 128bit FIFO 条目
 *     (高 16B 先写, 低 16B 后写)
 *   - 椭圆曲线点 (x,y) = 64B; Jacobian 点 (X,Y,Z) = 96B
 *   - 变长字段 (message / plaintext / C2 / ID) 不足 16B 倍数时末尾补 0
 *   - 完成信号: 硬件无 DONE/BUSY 位, 以 OFIFO 非空 + 期望条目数作为完成判据
 *
 * 执行时序 (所有模式统一):
 *   复位 -> 写 PKG_LEN -> 写 CFG(含 ENABLE 启动) -> 流式写 IFIFO -> 流式读 OFIFO
 *   因为 IFIFO 仅 8 条目深, 大数据包必须在启动后边写边被算核消费,
 *   故一律"先启动再写数据", 写时用 IFIFO_FULL 反压, 读时用 OFIFO_EMPTY 等待。
 */

#include "rsp_ip_sm2.h"
#include <string.h>
#include <stdio.h>

/* 调试记录, 供自测程序打印 (定位阶段用, 稳定后可删除) */
volatile uint32_t sm2_dbg[8];

/* 最近一次启动的 CFG(不含 ENABLE) 与 ENABLE 补踢标志 */
static uint32_t sm2_cfg_last;
static uint8_t  sm2_kicked;
static uint8_t  sm2_got;        /* 本次操作是否已读到过输出 */

static void sm2_dbg_snap(uint32_t stage)
{
    uint32_t st = SM2_IP->STATE;
    sm2_dbg[0] = stage;
    sm2_dbg[1] = st;
    sm2_dbg[2] = SM2_IP->PKG_LEN;
    sm2_dbg[3] = SM2_IP->CFG;
    sm2_dbg[4] = (st >> SM2_STATE_IFIFO_CNT_Pos) & 0xFFU;
    sm2_dbg[5] = (st >> SM2_STATE_OFIFO_CNT_Pos) & 0xFFU;
}

/* 出错即关闭算核并返回 */
#define SM2_CHK(x)                                                            \
    do {                                                                      \
        RSP_StatusTypeDef _r = (x);                                           \
        if (_r != RSP_OK) {                                                   \
            SM2_IP->CFG = 0U;                                                 \
            return _r;                                                        \
        }                                                                     \
    } while (0)

/* ============================================================
 *  FIFO / 寄存器基础操作
 * ============================================================ */

/**
 * @brief 软复位: 关算核 -> 清寄存器 -> FIFO 状态清零 -> 排空 OFIFO 残留
 */
static void sm2_ip_reset(void)
{
    uint32_t timeout = SM2_POLL_TIMEOUT;

    /* 1. 关算核, 清中断/长度寄存器 */
    SM2_IP->CFG     = 0U;
    SM2_IP->INTR    = 0U;
    SM2_IP->PKG_LEN = 0U;

    /* 2. FIFO 状态清零: INTR.bit1 写 1 (W1SC) 保持一拍后写 0 */
    SM2_IP->INTR = SM2_INTR_FIFO_STATE_CLEAR;
    for (volatile int d = 0; d < 2000; d++);
    SM2_IP->INTR = 0U;

    /* 3. 排空 OFIFO 残留数据, 带超时防止挂死固件 */
    while ((SM2_IP->STATE & SM2_STATE_OFIFO_EMPTY) == 0U)
    {
        volatile uint32_t d = SM2_IP->OFIFO[0];
        (void)d;
        if (--timeout == 0U) break;
    }
}

/**
 * @brief 向 IFIFO 压入一个 128bit(16B) 条目
 * @note  IFIFO 窗口内任意地址写均写入 FIFO, 固定写 0x10 起始的 4 个字
 */
static RSP_StatusTypeDef sm2_push_entry(const uint8_t ent[SM2_ENTRY_BYTES])
{
    uint32_t w[4];
    uint32_t timeout = SM2_POLL_TIMEOUT;

    while ((SM2_IP->STATE & SM2_STATE_IFIFO_FULL) != 0U)
    {
        if (--timeout == 0U) { sm2_dbg_snap(1U); return RSP_ERR_FIFO; }
    }

    memcpy(w, ent, SM2_ENTRY_BYTES);
    SM2_IP->IFIFO[0] = w[0];
    SM2_IP->IFIFO[1] = w[1];
    SM2_IP->IFIFO[2] = w[2];
    SM2_IP->IFIFO[3] = w[3];

    return RSP_OK;
}

/**
 * @brief 从 OFIFO 弹出一个 128bit(16B) 条目
 */
static RSP_StatusTypeDef sm2_pull_entry(uint8_t ent[SM2_ENTRY_BYTES])
{
    uint32_t w[4];
    uint32_t timeout = SM2_OUT_WAIT;

    while ((SM2_IP->STATE & SM2_STATE_OFIFO_EMPTY) != 0U)
    {
        if (--timeout == 0U)
        {
            /* 等满一个窗口仍无输出, 且 IFIFO 仍有残留条目:
             * 说明 ENABLE 脉冲在跨时钟域丢失, 算核根本没启动;
             * 补踢一次 ENABLE (不改变模式位), 再给一段完整等待预算. */
            uint32_t cnt = (SM2_IP->STATE & SM2_STATE_IFIFO_CNT_Msk)
                         >> SM2_STATE_IFIFO_CNT_Pos;
            if ((sm2_kicked == 0U) && (sm2_got == 0U) && (cnt != 0U))
            {
                sm2_kicked = 1U;
                SM2_IP->CFG = sm2_cfg_last | SM2_CFG_ENABLE;
                sm2_dbg_snap(5U);
                timeout = SM2_OUT_WAIT;
                continue;
            }
            sm2_dbg_snap(2U);
            return RSP_ERR_FIFO;
        }
    }

    w[0] = SM2_IP->OFIFO[0];
    w[1] = SM2_IP->OFIFO[1];
    w[2] = SM2_IP->OFIFO[2];
    w[3] = SM2_IP->OFIFO[3];
    memcpy(ent, w, SM2_ENTRY_BYTES);
    sm2_got = 1U;

    return RSP_OK;
}

/**
 * @brief 写入任意长度数据, 末尾不足 16B 的部分用 0 补齐后作为一个条目写入
 * @note  各字段按数据格式要求独立补齐, 因此每次调用对应一个完整字段
 */
static RSP_StatusTypeDef sm2_put(const uint8_t *data, uint32_t len)
{
    uint32_t i;

    if (len == 0U) return RSP_OK;

    for (i = 0U; (i + SM2_ENTRY_BYTES) <= len; i += SM2_ENTRY_BYTES)
    {
        SM2_CHK(sm2_push_entry(data + i));
    }

    if (i < len)
    {
        uint8_t tail[SM2_ENTRY_BYTES];
        memset(tail, 0, sizeof(tail));
        memcpy(tail, data + i, len - i);
        SM2_CHK(sm2_push_entry(tail));
    }

    return RSP_OK;
}

/**
 * @brief 读取任意长度数据 (长度为 16B 倍数)
 */
static RSP_StatusTypeDef sm2_get(uint8_t *dst, uint32_t len)
{
    uint32_t i;

    for (i = 0U; i < len; i += SM2_ENTRY_BYTES)
    {
        SM2_CHK(sm2_pull_entry(dst + i));
    }

    return RSP_OK;
}

/**
 * @brief 写入用户 ID 块: ENTL(2B, 大端 bit 长度) + ID, 整体补 0 到 16B 倍数
 */
static RSP_StatusTypeDef sm2_put_id(const uint8_t *id, uint32_t id_len)
{
    uint8_t buf[SM2_ID_MAX_BYTES + 2U];
    uint32_t entl;

    if ((id == NULL) || (id_len == 0U) || (id_len > SM2_ID_MAX_BYTES))
        return RSP_ERR_INVALID_PARAM;

    entl = id_len * 8U;
    buf[0] = (uint8_t)(entl >> 8);
    buf[1] = (uint8_t)(entl);
    memcpy(&buf[2], id, id_len);

    return sm2_put(buf, id_len + 2U);
}

/**
 * @brief 复位 + 配置 + 启动算核
 * @param cfg     模式及配置位 (不含 ENABLE)
 * @param pkg_len PKG_LEN 寄存器值
 */
static void sm2_start(uint32_t cfg, uint32_t pkg_len)
{
    sm2_ip_reset();
    SM2_IP->PKG_LEN = pkg_len;
    SM2_IP->CFG     = cfg | SM2_CFG_ENABLE;   /* bit0 W1SC, 写 1 启动 */
    sm2_cfg_last    = cfg;
    sm2_kicked      = 0U;
    sm2_got         = 0U;
}

/**
 * @brief 读取 64B 验签结果并取有效位
 * @note  数据格式为 64B, 只有 1 位有效; 取首字节非 0 作为通过判据
 */
static RSP_StatusTypeDef sm2_get_result(int *is_valid)
{
    uint8_t tmp[SM2_SIG_BYTES];

    SM2_CHK(sm2_get(tmp, SM2_SIG_BYTES));
    *is_valid = (tmp[0] != 0U) ? 1 : 0;

    return RSP_OK;
}

/* ============================================================
 *  模运算
 * ============================================================ */

/* 参数错误上报: 打印具体出错的参数名, 便于调用者定位误用 */
static RSP_StatusTypeDef sm2_param_null_err(const char *algo, const char *param)
{
    printf("[SM2 %s] %s_null_err\n", algo, param);
    return RSP_ERR_NULL_PTR;
}

static RSP_StatusTypeDef sm2_param_len_err(const char *algo, const char *param,
                                           uint32_t got, const char *expect)
{
    printf("[SM2 %s] %s_len_err: got=%lu expect=%s\n", algo, param,
           (unsigned long)got, expect);
    return RSP_ERR_INVALID_PARAM;
}

RSP_StatusTypeDef sm2_hw_madd(const uint8_t a[32], const uint8_t b[32],
                              const uint8_t p[32], uint8_t out[32])
{
    if (a == NULL)   return sm2_param_null_err("MADD", "a");
    if (b == NULL)   return sm2_param_null_err("MADD", "b");
    if (p == NULL)   return sm2_param_null_err("MADD", "p");
    if (out == NULL) return sm2_param_null_err("MADD", "out");

    sm2_start(SM2_MODE_MADD, 3U * SM2_NUM_BYTES);
    SM2_CHK(sm2_put(a, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(b, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(p, SM2_NUM_BYTES));
    SM2_CHK(sm2_get(out, SM2_NUM_BYTES));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

RSP_StatusTypeDef sm2_hw_msub(const uint8_t a[32], const uint8_t b[32],
                              const uint8_t p[32], uint8_t out[32])
{
    if (a == NULL)   return sm2_param_null_err("MSUB", "a");
    if (b == NULL)   return sm2_param_null_err("MSUB", "b");
    if (p == NULL)   return sm2_param_null_err("MSUB", "p");
    if (out == NULL) return sm2_param_null_err("MSUB", "out");

    sm2_start(SM2_MODE_MSUB, 3U * SM2_NUM_BYTES);
    SM2_CHK(sm2_put(a, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(b, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(p, SM2_NUM_BYTES));
    SM2_CHK(sm2_get(out, SM2_NUM_BYTES));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

RSP_StatusTypeDef sm2_hw_mmul(const uint8_t a[32], const uint8_t b[32],
                              uint8_t out[32])
{
    if (a == NULL)   return sm2_param_null_err("MMUL", "a");
    if (b == NULL)   return sm2_param_null_err("MMUL", "b");
    if (out == NULL) return sm2_param_null_err("MMUL", "out");

    sm2_start(SM2_MODE_MMUL, 2U * SM2_NUM_BYTES);
    SM2_CHK(sm2_put(a, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(b, SM2_NUM_BYTES));
    SM2_CHK(sm2_get(out, SM2_NUM_BYTES));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

RSP_StatusTypeDef sm2_hw_minv_p(const uint8_t a[32], uint8_t out[32])
{
    if (a == NULL)   return sm2_param_null_err("MINV_P", "a");
    if (out == NULL) return sm2_param_null_err("MINV_P", "out");

    sm2_start(SM2_MODE_MINV_P, SM2_NUM_BYTES);
    SM2_CHK(sm2_put(a, SM2_NUM_BYTES));
    SM2_CHK(sm2_get(out, SM2_NUM_BYTES));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

RSP_StatusTypeDef sm2_hw_minv_n(const uint8_t a[32], uint8_t out[32])
{
    if (a == NULL)   return sm2_param_null_err("MINV_N", "a");
    if (out == NULL) return sm2_param_null_err("MINV_N", "out");

    sm2_start(SM2_MODE_MINV_N, SM2_NUM_BYTES);
    SM2_CHK(sm2_put(a, SM2_NUM_BYTES));
    SM2_CHK(sm2_get(out, SM2_NUM_BYTES));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

/* ============================================================
 *  椭圆曲线点运算 (Jacobian)
 * ============================================================ */

RSP_StatusTypeDef sm2_hw_padd(const uint8_t pa[96], const uint8_t pb[96],
                              uint8_t pc[96])
{
    if (pa == NULL) return sm2_param_null_err("PADD", "pa");
    if (pb == NULL) return sm2_param_null_err("PADD", "pb");
    if (pc == NULL) return sm2_param_null_err("PADD", "pc");

    sm2_start(SM2_MODE_PADD, 2U * SM2_JACOBIAN_BYTES);
    SM2_CHK(sm2_put(pa, SM2_JACOBIAN_BYTES));
    SM2_CHK(sm2_put(pb, SM2_JACOBIAN_BYTES));
    SM2_CHK(sm2_get(pc, SM2_JACOBIAN_BYTES));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

RSP_StatusTypeDef sm2_hw_pdouble(const uint8_t pa[96], uint8_t pc[96])
{
    if (pa == NULL) return sm2_param_null_err("PDOUBLE", "pa");
    if (pc == NULL) return sm2_param_null_err("PDOUBLE", "pc");

    sm2_start(SM2_MODE_PDOUBLE, SM2_JACOBIAN_BYTES);
    SM2_CHK(sm2_put(pa, SM2_JACOBIAN_BYTES));
    SM2_CHK(sm2_get(pc, SM2_JACOBIAN_BYTES));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

/* ============================================================
 *  点乘
 * ============================================================ */

RSP_StatusTypeDef sm2_hw_kg(const uint8_t k[32], uint8_t pub_xy[64])
{
    if (k == NULL)      return sm2_param_null_err("KG", "k");
    if (pub_xy == NULL) return sm2_param_null_err("KG", "pub_xy");

    sm2_start(SM2_MODE_KG, SM2_NUM_BYTES);
    SM2_CHK(sm2_put(k, SM2_NUM_BYTES));
    SM2_CHK(sm2_get(pub_xy, SM2_POINT_BYTES));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

RSP_StatusTypeDef sm2_hw_kp(const uint8_t k[32], const uint8_t px[32],
                            const uint8_t py[32], uint8_t out_xy[64])
{
    if (k == NULL)      return sm2_param_null_err("KP", "k");
    if (px == NULL)     return sm2_param_null_err("KP", "px");
    if (py == NULL)     return sm2_param_null_err("KP", "py");
    if (out_xy == NULL) return sm2_param_null_err("KP", "out_xy");

    sm2_start(SM2_MODE_KP, 3U * SM2_NUM_BYTES);
    SM2_CHK(sm2_put(k, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(px, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(py, SM2_NUM_BYTES));
    SM2_CHK(sm2_get(out_xy, SM2_POINT_BYTES));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

/* ============================================================
 *  签名 / 验签
 * ============================================================ */

RSP_StatusTypeDef sm2_hw_sign(const uint8_t e[32], const uint8_t d[32],
                              const uint8_t k[32], uint8_t rs[64])
{
    if (e == NULL)  return sm2_param_null_err("SIGN", "e");
    if (d == NULL)  return sm2_param_null_err("SIGN", "d");
    if (k == NULL)  return sm2_param_null_err("SIGN", "k");
    if (rs == NULL) return sm2_param_null_err("SIGN", "rs");

    /* 摘要版: CFG.SING_VERIFY_MODE = 0; 输入 e + d + k */
    sm2_start(SM2_MODE_SIGN, 3U * SM2_NUM_BYTES);
    sm2_dbg_snap(3U);
    SM2_CHK(sm2_put(e, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(d, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(k, SM2_NUM_BYTES));
    sm2_dbg_snap(4U);
    SM2_CHK(sm2_get(rs, SM2_SIG_BYTES));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

RSP_StatusTypeDef sm2_hw_sign_msg(const uint8_t *id, uint32_t id_len,
                                  const uint8_t pub_xy[64],
                                  const uint8_t *msg, uint32_t msg_len,
                                  const uint8_t d[32], const uint8_t k[32],
                                  uint8_t rs[64])
{
    uint32_t cfg;

    if (id == NULL)     return sm2_param_null_err("SIGN_MSG", "id");
    if (pub_xy == NULL) return sm2_param_null_err("SIGN_MSG", "pub_xy");
    if (d == NULL)      return sm2_param_null_err("SIGN_MSG", "d");
    if (k == NULL)      return sm2_param_null_err("SIGN_MSG", "k");
    if (rs == NULL)     return sm2_param_null_err("SIGN_MSG", "rs");
    if ((msg == NULL) && (msg_len != 0U))
        return sm2_param_null_err("SIGN_MSG", "msg");
    if ((id_len == 0U) || (id_len > SM2_ID_MAX_BYTES))
        return sm2_param_len_err("SIGN_MSG", "id_len", id_len, "1..SM2_ID_MAX");

    /* 原始消息版: CFG.SING_VERIFY_MODE = 1, PKG_LEN = 消息字节数 */
    cfg = SM2_MODE_SIGN | SM2_CFG_SING_VERIFY_MODE |
          ((id_len << SM2_CFG_ID_LEN_Pos) & SM2_CFG_ID_LEN_Msk);

    sm2_start(cfg, msg_len);
    SM2_CHK(sm2_put_id(id, id_len));
    SM2_CHK(sm2_put(pub_xy, SM2_POINT_BYTES));
    SM2_CHK(sm2_put(msg, msg_len));
    SM2_CHK(sm2_put(d, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(k, SM2_NUM_BYTES));
    SM2_CHK(sm2_get(rs, SM2_SIG_BYTES));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

RSP_StatusTypeDef sm2_hw_verify(const uint8_t e[32], const uint8_t r[32],
                                const uint8_t s[32], const uint8_t pub_xy[64],
                                int *is_valid)
{
    if (e == NULL)        return sm2_param_null_err("VERIFY", "e");
    if (r == NULL)        return sm2_param_null_err("VERIFY", "r");
    if (s == NULL)        return sm2_param_null_err("VERIFY", "s");
    if (pub_xy == NULL)   return sm2_param_null_err("VERIFY", "pub_xy");
    if (is_valid == NULL) return sm2_param_null_err("VERIFY", "is_valid");

    /* 摘要版: 输入 e + r + s + Px + Py = 160B */
    sm2_start(SM2_MODE_VERIFY, 5U * SM2_NUM_BYTES);
    SM2_CHK(sm2_put(e, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(r, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(s, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(pub_xy, SM2_POINT_BYTES));
    SM2_CHK(sm2_get_result(is_valid));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

RSP_StatusTypeDef sm2_hw_verify_msg(const uint8_t *id, uint32_t id_len,
                                    const uint8_t *msg, uint32_t msg_len,
                                    const uint8_t r[32], const uint8_t s[32],
                                    const uint8_t pub_xy[64],
                                    int *is_valid)
{
    uint32_t cfg;

    if (id == NULL)        return sm2_param_null_err("VERIFY_MSG", "id");
    if (r == NULL)         return sm2_param_null_err("VERIFY_MSG", "r");
    if (s == NULL)         return sm2_param_null_err("VERIFY_MSG", "s");
    if (pub_xy == NULL)    return sm2_param_null_err("VERIFY_MSG", "pub_xy");
    if (is_valid == NULL)  return sm2_param_null_err("VERIFY_MSG", "is_valid");
    if ((msg == NULL) && (msg_len != 0U))
        return sm2_param_null_err("VERIFY_MSG", "msg");
    if ((id_len == 0U) || (id_len > SM2_ID_MAX_BYTES))
        return sm2_param_len_err("VERIFY_MSG", "id_len", id_len, "1..SM2_ID_MAX");

    /* 原始消息版: 公钥点在消息前后各出现一次, 此处写两遍 */
    cfg = SM2_MODE_VERIFY | SM2_CFG_SING_VERIFY_MODE |
          ((id_len << SM2_CFG_ID_LEN_Pos) & SM2_CFG_ID_LEN_Msk);

    sm2_start(cfg, msg_len);
    SM2_CHK(sm2_put_id(id, id_len));
    SM2_CHK(sm2_put(pub_xy, SM2_POINT_BYTES));
    SM2_CHK(sm2_put(msg, msg_len));
    SM2_CHK(sm2_put(r, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(s, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(pub_xy, SM2_POINT_BYTES));
    SM2_CHK(sm2_get_result(is_valid));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

/* ============================================================
 *  加解密
 * ============================================================ */

RSP_StatusTypeDef sm2_hw_encrypt(const uint8_t k[32], const uint8_t pub_xy[64],
                                 const uint8_t *msg, uint32_t msg_len,
                                 uint8_t *cipher, uint32_t *cipher_len)
{
    uint32_t c2_ent = (msg_len + SM2_ENTRY_BYTES - 1U) / SM2_ENTRY_BYTES;
    uint32_t rem = msg_len;
    uint32_t i;

    if (k == NULL)          return sm2_param_null_err("ENC", "k");
    if (pub_xy == NULL)     return sm2_param_null_err("ENC", "pub_xy");
    if (cipher == NULL)     return sm2_param_null_err("ENC", "cipher");
    if (cipher_len == NULL) return sm2_param_null_err("ENC", "cipher_len");
    if ((msg == NULL) && (msg_len != 0U))
        return sm2_param_null_err("ENC", "msg");

    /* PKG_LEN = 明文长度 */
    sm2_start(SM2_MODE_ENC, msg_len);
    SM2_CHK(sm2_put(k, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(pub_xy, SM2_POINT_BYTES));
    SM2_CHK(sm2_put(msg, msg_len));

    /* C1: 64B (4 条目) */
    SM2_CHK(sm2_get(cipher, SM2_POINT_BYTES));

    /* C2: 硬件按 16B 条目输出, 只保留前 msg_len 字节 */
    for (i = 0U; i < c2_ent; i++)
    {
        uint8_t blk[SM2_ENTRY_BYTES];
        uint32_t cpy = (rem >= SM2_ENTRY_BYTES) ? SM2_ENTRY_BYTES : rem;

        SM2_CHK(sm2_pull_entry(blk));
        memcpy(cipher + SM2_POINT_BYTES + (i * SM2_ENTRY_BYTES), blk, cpy);
        rem -= cpy;
    }

    /* C3: 32B (2 条目) */
    SM2_CHK(sm2_get(cipher + SM2_POINT_BYTES + msg_len, SM2_NUM_BYTES));

    *cipher_len = SM2_POINT_BYTES + msg_len + SM2_NUM_BYTES;

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

RSP_StatusTypeDef sm2_hw_decrypt(const uint8_t d[32], const uint8_t *cipher,
                                 uint32_t cipher_len, uint8_t *msg,
                                 uint32_t *msg_len)
{
    uint32_t c2_len;
    uint32_t c2_ent;
    uint32_t rem;
    uint32_t i;

    if (d == NULL)       return sm2_param_null_err("DEC", "d");
    if (cipher == NULL)  return sm2_param_null_err("DEC", "cipher");
    if (msg == NULL)     return sm2_param_null_err("DEC", "msg");
    if (msg_len == NULL) return sm2_param_null_err("DEC", "msg_len");
    if (cipher_len < (SM2_POINT_BYTES + SM2_NUM_BYTES))
        return sm2_param_len_err("DEC", "cipher_len", cipher_len,
                                 ">=SM2_POINT_BYTES+SM2_NUM_BYTES");

    /* cipher = C1(64) || C2(n) || C3(32) */
    c2_len = cipher_len - SM2_POINT_BYTES - SM2_NUM_BYTES;
    c2_ent = (c2_len + SM2_ENTRY_BYTES - 1U) / SM2_ENTRY_BYTES;

    /* PKG_LEN = C2 长度; IFIFO 顺序为 d + C1 + C3 + C2 */
    sm2_start(SM2_MODE_DEC, c2_len);
    SM2_CHK(sm2_put(d, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(cipher, SM2_POINT_BYTES));
    SM2_CHK(sm2_put(cipher + SM2_POINT_BYTES + c2_len, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(cipher + SM2_POINT_BYTES, c2_len));

    /* 明文: 硬件按 16B 条目输出, 只保留前 c2_len 字节 */
    rem = c2_len;
    for (i = 0U; i < c2_ent; i++)
    {
        uint8_t blk[SM2_ENTRY_BYTES];
        uint32_t cpy = (rem >= SM2_ENTRY_BYTES) ? SM2_ENTRY_BYTES : rem;

        SM2_CHK(sm2_pull_entry(blk));
        memcpy(msg + (i * SM2_ENTRY_BYTES), blk, cpy);
        rem -= cpy;
    }

    *msg_len = c2_len;

    SM2_IP->CFG = 0U;
    return RSP_OK;
}

/* ============================================================
 *  密钥交换
 * ============================================================ */

RSP_StatusTypeDef sm2_hw_kexch(const sm2_kexch_in_t *in, uint8_t is_initiator,
                               uint8_t temp_pub_out, uint8_t key_agree,
                               sm2_kexch_out_t *out)
{
    uint8_t  klen16[SM2_ENTRY_BYTES];
    uint32_t key_bytes;
    uint32_t cfg;
    uint32_t pkg_len;

    if (in == NULL)  return sm2_param_null_err("KEXCH", "in");
    if (out == NULL) return sm2_param_null_err("KEXCH", "out");
    if (in->self_id == NULL) return sm2_param_null_err("KEXCH", "in->self_id");
    if (in->peer_id == NULL) return sm2_param_null_err("KEXCH", "in->peer_id");
    if ((in->self_id_len == 0U) || (in->self_id_len > SM2_ID_MAX_BYTES))
        return sm2_param_len_err("KEXCH", "in->self_id_len", in->self_id_len,
                                 "1..SM2_ID_MAX");
    if ((in->peer_id_len == 0U) || (in->peer_id_len > SM2_ID_MAX_BYTES))
        return sm2_param_len_err("KEXCH", "in->peer_id_len", in->peer_id_len,
                                 "1..SM2_ID_MAX");
    if ((in->klen_bits == 0U) || (in->klen_bits > 512U))
        return sm2_param_len_err("KEXCH", "in->klen_bits", in->klen_bits,
                                 "1..512");

    /* 共享密钥按 16B 倍数输出 */
    key_bytes = (((uint32_t)in->klen_bits + 15U) / 16U) * 16U;

    /* KLEN 字段为 16B, 低 2 字节为大端 bit 长度 */
    memset(klen16, 0, sizeof(klen16));
    klen16[0] = (uint8_t)(in->klen_bits >> 8);
    klen16[1] = (uint8_t)(in->klen_bits);

    /* PKG_LEN 取逻辑输入字节数 (不含补齐) */
    pkg_len = SM2_NUM_BYTES + SM2_POINT_BYTES
            + (2U + in->peer_id_len) + SM2_POINT_BYTES
            + (2U + in->self_id_len) + SM2_POINT_BYTES
            + SM2_NUM_BYTES + SM2_ENTRY_BYTES
            + (key_agree ? SM2_NUM_BYTES : 0U);

    cfg = SM2_MODE_KEYEXCH;
    if (is_initiator) cfg |= SM2_CFG_KEY_EXCHA_MODE_I;
    if (temp_pub_out) cfg |= SM2_CFG_TEMP_PUBLIC_OUT_EN;
    if (key_agree)    cfg |= SM2_CFG_KEY_AGREE_EN;

    sm2_start(cfg, pkg_len);
    SM2_CHK(sm2_put(in->k, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(in->peer_tmp, SM2_POINT_BYTES));
    SM2_CHK(sm2_put_id(in->peer_id, in->peer_id_len));
    SM2_CHK(sm2_put(in->peer_pub, SM2_POINT_BYTES));
    SM2_CHK(sm2_put_id(in->self_id, in->self_id_len));
    SM2_CHK(sm2_put(in->self_pub, SM2_POINT_BYTES));
    SM2_CHK(sm2_put(in->self_d, SM2_NUM_BYTES));
    SM2_CHK(sm2_put(klen16, SM2_ENTRY_BYTES));
    if (key_agree) SM2_CHK(sm2_put(in->peer_tag, SM2_NUM_BYTES));

    memset(out, 0, sizeof(*out));

    if (temp_pub_out) SM2_CHK(sm2_get(out->tmp_pub, SM2_POINT_BYTES));
    SM2_CHK(sm2_get(out->key, key_bytes));
    out->key_len = key_bytes;
    if (key_agree) SM2_CHK(sm2_get(out->tag, SM2_NUM_BYTES));
    SM2_CHK(sm2_get(out->cr, SM2_ENTRY_BYTES));

    SM2_IP->CFG = 0U;
    return RSP_OK;
}
