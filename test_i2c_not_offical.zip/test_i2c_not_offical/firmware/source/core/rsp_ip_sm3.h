#ifndef __RSP_IP_SM3_H__
#define __RSP_IP_SM3_H__

#include "rsp_ip_common.h"
#include "stdint.h"

/* ========== 基地址 ========== */
#define SM3_IP_BASE (0x80020000UL)
#define SM3_IP ((SM3_TypeDef *)SM3_IP_BASE)
#define SM3_TEST_MSG_LEN (1024)
/* ========== 寄存器结构体（依据 sm3.xlsx 寄存器表）==========
 *
 *  偏移    寄存器       宽度      说明
 *  0x00    STATE        32bit     状态/中断寄存器
 *  0x04    PKG_LEN      32bit     当前包数据长度
 *  0x08    TOTAL_LEN    32bit     数据总长度
 *  0x0C    CFG          32bit     配置寄存器
 *  0x10~   IFIFO        128bit    输入FIFO, 深度8, 8×128bit=128字节
 *  0x8F                          对 0x10~0x8F 任意地址写均写入 IFIFO
 *  0x90~   OFIFO        32bit     输出FIFO, 存放 256bit SM3 运算结果
 *  0xAF
 */
typedef struct
{
    __IO uint32_t STATE;      /*!< 0x00 RW: 状态/中断寄存器                */
    __IO uint32_t PKG_LEN;    /*!< 0x04 RW: 当前包数据长度（字节）          */
    __IO uint32_t TOTAL_LEN;  /*!< 0x08 RW: 数据总长度（字节）              */
    __IO uint32_t CFG;        /*!< 0x0c RW: 配置寄存器                      */
    __IO uint32_t IFIFO[32];  /*!< 0x10~0x8F WO: 输入FIFO, 128bit宽, 8深, 128B */
    __IO uint32_t OFIFO[8];   /*!< 0x90~0xAF RO: 输出FIFO, 256bit=8word     */
} SM3_TypeDef;

/* IFIFO/OFIFO 窗口绝对基址（DMA等不能用结构体解引用的场景使用）*/
#define SM3_IP_IFIFO_BASE (SM3_IP_BASE + 0x10U) /*!< IFIFO 窗口 0x10~0x8F */
#define SM3_IP_OFIFO_BASE (SM3_IP_BASE + 0x90U) /*!< OFIFO 窗口 0x90~0xAF */

/* ============================================================
 *  STATE 寄存器 (0x00) 位定义
 * ============================================================ */

/* ---- 状态位（RO）---- */
#define SM3_STATE_DOEN_Pos (0U)
#define SM3_STATE_DOEN (1U << 0) /*!< bit0  算核完成，高有效              */
#define SM3_STATE_IFIFO_FULL_Pos (1U)
#define SM3_STATE_IFIFO_FULL (1U << 1) /*!< bit1  IFIFO满状态                   */
#define SM3_STATE_OFIFO_EMPTY_N_Pos (2U)
#define SM3_STATE_OFIFO_EMPTY_N (1U << 2) /*!< bit2  OFIFO非空状态，高有效（有数据可读） */
#define SM3_STATE_BUSY_Pos (3U)
#define SM3_STATE_BUSY (1U << 3) /*!< bit3  算核忙状态，高有效             */
#define SM3_STATE_IFIFO_WR_CNT_Pos (8U)
#define SM3_STATE_IFIFO_WR_CNT_Msk (0xFFU << 8) /*!< bit[15:8] IFIFO当前有效数据深度     */

/* ---- 中断标志位（RO）---- */
#define SM3_STATE_DOEN_INT_FLAG_Pos (16U)
#define SM3_STATE_DOEN_INT_FLAG (1U << 16) /*!< bit16 算核完成中断标志         */
#define SM3_STATE_IFIFO_FULL_INT_FLAG_Pos (17U)
#define SM3_STATE_IFIFO_FULL_INT_FLAG (1U << 17) /*!< bit17 IFIFO满中断标志          */
#define SM3_STATE_IFIFO_EMPTY_THRESH_INT_FLAG_Pos (18U)
#define SM3_STATE_IFIFO_EMPTY_THRESH_INT_FLAG (1U << 18) /*!< bit18 IFIFO阈空中断标志  */
#define SM3_STATE_IFIFO_FULL_THRESH_INT_FLAG_Pos (19U)
#define SM3_STATE_IFIFO_FULL_THRESH_INT_FLAG (1U << 19) /*!< bit19 IFIFO阈满中断标志  */
#define SM3_STATE_OFIFO_EMPTY_N_INT_FLAG_Pos (20U)
#define SM3_STATE_OFIFO_EMPTY_N_INT_FLAG (1U << 20) /*!< bit20 OFIFO非空中断标志   */
#define SM3_STATE_BUSY_INT_FLAG_Pos (21U)
#define SM3_STATE_BUSY_INT_FLAG (1U << 21) /*!< bit21 BUSY中断标志        */

/* ---- 中断控制位（RW/W1CS）---- */
#define SM3_STATE_INT_ENABLE_Pos (24U)
#define SM3_STATE_INT_ENABLE (1U << 24) /*!< bit24 RW   全局中断使能               */
#define SM3_STATE_INT_CLEAR_Pos (25U)
#define SM3_STATE_INT_CLEAR (1U << 25) /*!< bit25 W1CS 清除中断标志（写1清零）    */
#define SM3_STATE_INTMASK_Pos (26U)
#define SM3_STATE_INTMASK_Msk (0x3FU << 26) /*!< bit[31:26] RW 中断屏蔽，低有效               \
                                             *   [0]算核完成  [1]IFIFO满  [2]IFIFO阈空 \
                                             *   [3]IFIFO阈满 [4]OFIFO非空 [5]BUSY      */

/* ============================================================
 *  CFG 寄存器 (0x04) 位定义
 * ============================================================ */
#define SM3_CFG_ENABLE_Pos (0U)
#define SM3_CFG_ENABLE (1U << 0) /*!< bit0  W1SC 算核使能，写1自清           */

#define SM3_CFG_MODE_Pos (1U)
#define SM3_CFG_MODE_SM3 (0U << 1)  /*!< bit1  0: SM3 模式                     */
#define SM3_CFG_MODE_HMAC (1U << 1) /*!<       1: HMAC模式                     */

#define SM3_CFG_HEADER_Pos (2U)
#define SM3_CFG_HEADER_Msk (0x7U << 2)        /*!< bit[4:2] 包标识                        */
#define SM3_CFG_HEADER_ONE_PKG (0b101U << 2)  /*!<  3'b101 整包                          */
#define SM3_CFG_HEADER_HEAD_PKG (0b001U << 2) /*!<  3'b001 首包                          */
#define SM3_CFG_HEADER_MID_PKG (0b010U << 2)  /*!<  3'b010 中间包                        */
#define SM3_CFG_HEADER_TAIL_PKG (0b100U << 2) /*!<  3'b100 尾包                          */

#define SM3_CFG_PADDING_Pos (5U)
#define SM3_CFG_PADDING_SOFT (0U << 5) /*!< bit5  0: 软件padding                   */
#define SM3_CFG_PADDING_HARD (1U << 5) /*!<       1: 硬件padding                   */

#define SM3_CFG_IFIFO_STATE_CLEAR_Pos (6U)
#define SM3_CFG_IFIFO_STATE_CLEAR (1U << 6) /*!< bit6 FIFO状态清零：清FIFO的CNT值和数据 \
                                            *       （bit7保留）                      */

#define SM3_CFG_IFIFO_PROG_FULL_THRESH_Pos (8U)
#define SM3_CFG_IFIFO_PROG_FULL_THRESH_Msk (0x7U << 8) /*!< bit[10:8]  IFIFO阈满值(3bit, 0~7) */
#define SM3_CFG_IFIFO_PROG_EMPTY_THRESH_Pos (16U)
#define SM3_CFG_IFIFO_PROG_EMPTY_THRESH_Msk (0x7U << 16) /*!< bit[18:16] IFIFO阈空值(3bit, 0~7) */
#define SM3_CFG_THRESH_MAX (0x7U) /*!< 阈满/阈空字段宽度3bit，合法范围0~7 */

/* ============================================================
 *  PKG_LEN / TOTAL_LEN 寄存器 (0x04 / 0x08)
 * ============================================================ */
#define SM3_PKG_LEN_Msk (0xFFFFFFFFU)   /*!< bit[31:0] 当前包长度（字节） */
#define SM3_TOTAL_LEN_Msk (0xFFFFFFFFU) /*!< bit[31:0] 总长度（字节）     */

/* ============================================================
 *  常量定义
 * ============================================================ */
#define SM3_IFIFO_DATA_WIDTH_BYTE (16U) /* IFIFO数据位宽128bit = 16字节 */
#define SM3_IFIFO_DEPTH (8U)            /* IFIFO深度8（8×128bit）       */
#define SM3_IFIFO_SIZE_BYTE (128U)      /* IFIFO存储空间128字节         */

#define SM3_OFIFO_DATA_WIDTH_BYTE (4U) /* OFIFO数据位宽32bit = 4字节  */
#define SM3_OFIFO_DEPTH (8U)           /* OFIFO深度8（256bit/32bit）  */
#define SM3_OFIFO_SIZE_BYTE (32U)      /* OFIFO存储空间32字节         */

#define SM3_BLOCK_BYTE_LEN (64U)  /* SM3分组大小 512bit = 64字节  */
#define SM3_LENTAG_BYTE_LEN (8U)  /* 末尾8字节比特长度            */
#define SM3_DIGEST_BYTE_LEN (32U) /* 摘要256bit = 32字节          */
#define SM3_DIGEST_WORD_CNT (8U)  /* 32bit word数量: 32/4 = 8     */

/* ============================================================
 *  便捷操作宏
 * ============================================================ */

/* 使能/关闭算核（CFG.bit0, W1SC）*/
#define SM3_IP_ENABLE() (SM3_IP->CFG |= SM3_CFG_ENABLE)
#define SM3_IP_DISABLE() (SM3_IP->CFG &= ~SM3_CFG_ENABLE)

/* 清除全部中断标志（STATE.bit25, W1CS）*/
#define SM3_IP_INT_CLEAR_ALL() (SM3_IP->STATE = SM3_STATE_INT_CLEAR)

/* FIFO状态/数据清零（CFG.bit6 IFIFO_STATE_CLEAR，置1清CNT与数据）*/
#define SM3_IP_FIFO_RESET() (SM3_IP->CFG |= SM3_CFG_IFIFO_STATE_CLEAR)

/* ============================================================
 *  公共 API
 * ============================================================ */
void SM3_SoftPadding(const uint8_t *pRawData, uint32_t rawByteLen,
                     uint8_t *pPadBuf, uint32_t *pPadTotalLen);

RSP_StatusTypeDef SM3_IP_TestOnePackage(const uint8_t *pInData,
                                        uint32_t inByteLen,
                                        uint8_t *pOutDigest);
RSP_StatusTypeDef SM3_IP_SoftPaddingOnePackage(const uint8_t *pInData,
                                               uint32_t inByteLen,
                                               uint8_t *pOutDigest);
RSP_StatusTypeDef SM3_IP_HMAC_SM3(const uint8_t *pKey, uint32_t keyByteLen,
                                  const uint8_t *pMsg, uint32_t msgByteLen,
                                  uint8_t *pOutHmac);

/* ========== HMAC 多包模式（大数据，head/mid/tail + IV链接）========== */
/* head写key(64)+msg_chunk，mid写IV+msg_chunk，tail写IV+msg+软件padding。
 * tail的bitlen = (64 + totalMsgByteLen) * 8（key是内层哈希输入）。
 * msg<=448回退到SM3_IP_HMAC_SM3单包。 */
RSP_StatusTypeDef SM3_IP_HMAC_HeadPackage(const uint8_t *pKey64,
                                           const uint8_t *pMsg, uint32_t msgByteLen,
                                           uint8_t *pOutIV);
RSP_StatusTypeDef SM3_IP_HMAC_MidPackage(const uint8_t *pIV,
                                          const uint8_t *pMsg, uint32_t msgByteLen,
                                          uint8_t *pOutIV);
RSP_StatusTypeDef SM3_IP_HMAC_TailPackage(const uint8_t *pIV,
                                           const uint8_t *pMsg, uint32_t msgByteLen,
                                           uint32_t totalMsgByteLen,
                                           uint8_t *pOutHmac);
RSP_StatusTypeDef SM3_IP_HMAC_MultiPackage(const uint8_t *pKey, uint32_t keyByteLen,
                                            const uint8_t *pMsg, uint32_t msgByteLen,
                                            uint8_t *pOutHmac);

/* ========== 方式1：多包模式（大数据，head/mid/tail + IV链接）========== */
/* head/mid：本包数据必须是64字节分组整数倍，不做padding，
 * PKG_LEN/TOTAL_LEN=本包数据长度(IV写IFIFO但不计长度)。
 * tail：软件padding；totalByteLen=整条消息总字节数(不含IV)，
 * 用于padding末尾全局bitlen */
RSP_StatusTypeDef SM3_IP_HeadPackage(const uint8_t *pInData, uint32_t inByteLen,
                                     uint8_t *pOutIV);
RSP_StatusTypeDef SM3_IP_MidPackage(const uint8_t *pIV, const uint8_t *pInData,
                                    uint32_t inByteLen, uint8_t *pOutIV);
RSP_StatusTypeDef SM3_IP_TailPackage(const uint8_t *pIV, const uint8_t *pInData,
                                     uint32_t inByteLen, uint32_t totalByteLen,
                                     uint8_t *pOutDigest);
RSP_StatusTypeDef SM3_IP_MultiPackage(const uint8_t *pInData, uint32_t inByteLen,
                                      uint8_t *pOutDigest);

/* ========== 方式2：阈值流式模式（大数据，不拆包，阈值控流）========== */
RSP_StatusTypeDef SM3_IP_StreamingHash(const uint8_t *pInData, uint32_t inByteLen,
                                       uint8_t *pOutDigest);
/* 硬件padding版本（对比测试接口；硬件padding对>64字节且非64整数倍数据有bug）*/
RSP_StatusTypeDef SM3_IP_StreamingHashHardPad(const uint8_t *pInData, uint32_t inByteLen,
                                              uint8_t *pOutDigest);

/* 性能测试函数（全内联，零子函数调用，软件padding路径，输入>64字节）*/
RSP_StatusTypeDef SM3_IP_PerfHash(const uint8_t *pInData, uint32_t inByteLen,
                                  uint8_t *pOutDigest);

/* HMAC性能测试函数（硬件padding, 任意message长度, 长度只算message不含key）*/
RSP_StatusTypeDef SM3_IP_PerfHMAC(const uint8_t *pKey, uint32_t keyByteLen,
                                  const uint8_t *pMsg, uint32_t msgByteLen,
                                  uint8_t *pOutHmac);

#endif /* __RSP_IP_SM3_H__ */
