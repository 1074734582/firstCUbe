/**
 * @file rsp_ip_sm1.c
 * @brief SM1 硬件 IP 驱动 (基址 0x80000000)
 *
 * 依据 sm1_soc_test.txt 时序:
 *    sm1_init_pkg(enc_dec, mode_sel, pkg_id, tag_len, key_byte, cur_send_byte, send_byte)
 *    → 写 CFG / PKG_LEN_ALL / PKG_LEN_CUR / ENABLE
 *    → IFIFO 顺序: ECB: key(16B) → msg(nB)
 *                   CBC: key(16B) → iv(16B) → msg(nB)
 *    → OFIFO 输出 nB
 *
 * 注: 经实测, msg 长度必须 16B 对齐, 否则硬件输出错乱 (RTL 行为)
 */

#include "rsp_ip_sm1.h"
#include <string.h>
#include <stdio.h>

volatile uint32_t sm1_dbg[8];

/* ========== 内部辅助 ========== */

/* 软复位: 关 CFG, 清 FIFO 状态, 排空 OFIFO 残留 */
static void sm1_ip_reset(void)
{
    SM1_IP->CFG = 0U;
    SM1_IP->PKG_LEN_ALL = 0U;
    SM1_IP->PKG_LEN_CUR = 0U;

    SM1_IP->INTR = SM1_INTR_FIFO_STATE_CLEAR;
    for (volatile int d = 0; d < 2000; d++);
    SM1_IP->INTR = 0U;

    uint32_t timeout = SM1_POLL_TIMEOUT;
    while ((SM1_IP->STATE & SM1_STATE_OFIFO_EMPTY) == 0U)
    {
        volatile uint32_t dw = SM1_IP->OFIFO[0];
        (void)dw;
        if (--timeout == 0U) break;
    }
}

/* 压入一个 16B 条目, 带反压等待 */
static RSP_StatusTypeDef sm1_push_entry(const uint8_t ent[SM1_ENTRY_BYTES])
{
    uint32_t w[4];
    uint32_t timeout = SM1_POLL_TIMEOUT;

    while ((SM1_IP->STATE & SM1_STATE_IFIFO_FULL) != 0U)
    {
        if (--timeout == 0U) return RSP_ERR_FIFO;
    }

    memcpy(w, ent, SM1_ENTRY_BYTES);
    SM1_IP->IFIFO[0] = w[0];
    SM1_IP->IFIFO[1] = w[1];
    SM1_IP->IFIFO[2] = w[2];
    SM1_IP->IFIFO[3] = w[3];

    return RSP_OK;
}

/* 弹出一个 16B 条目, 等待 OFIFO 有数据 */
static RSP_StatusTypeDef sm1_pull_entry(uint8_t ent[SM1_ENTRY_BYTES])
{
    uint32_t w[4];
    uint32_t timeout = SM1_POLL_TIMEOUT;

    while (((SM1_IP->STATE & SM1_STATE_OFIFO_CNT_Msk) >> SM1_STATE_OFIFO_CNT_Pos) == 0U)
    {
        if (--timeout == 0U) return RSP_ERR_FIFO;
    }

    w[0] = SM1_IP->OFIFO[0];
    w[1] = SM1_IP->OFIFO[1];
    w[2] = SM1_IP->OFIFO[2];
    w[3] = SM1_IP->OFIFO[3];
    memcpy(ent, w, SM1_ENTRY_BYTES);

    return RSP_OK;
}

/* 写任意长度, 末尾不足 16B 自动补零 */
static RSP_StatusTypeDef sm1_put(const uint8_t *data, uint32_t len)
{
    uint32_t i;
    if (len == 0U) return RSP_OK;

    for (i = 0U; (i + SM1_ENTRY_BYTES) <= len; i += SM1_ENTRY_BYTES)
    {
        RSP_StatusTypeDef r = sm1_push_entry(data + i);
        if (r != RSP_OK) return r;
    }
    if (i < len)
    {
        uint8_t tail[SM1_ENTRY_BYTES];
        memset(tail, 0, sizeof(tail));
        memcpy(tail, data + i, len - i);
        return sm1_push_entry(tail);
    }
    return RSP_OK;
}

/* 读 len 字节 (向上取整到 16B 读取) */
static RSP_StatusTypeDef sm1_get(uint8_t *dst, uint32_t len)
{
    uint32_t i;
    for (i = 0U; i < len; i += SM1_ENTRY_BYTES)
    {
        RSP_StatusTypeDef r = sm1_pull_entry(dst + i);
        if (r != RSP_OK) return r;
    }
    return RSP_OK;
}

/* ========== 参数错误上报 ========== */
static RSP_StatusTypeDef sm1_param_null_err(const char *algo, const char *param)
{
    printf("[SM1 %s] %s_null_err\n", algo, param);
    return RSP_ERR_NULL_PTR;
}

static RSP_StatusTypeDef sm1_param_len_err(const char *algo, const char *param,
                                           uint32_t got, const char *expect)
{
    printf("[SM1 %s] %s_len_err: got=%lu expect=%s\n", algo, param,
           (unsigned long)got, expect);
    return RSP_ERR_INVALID_PARAM;
}

/* ========== 公共 API ========== */

RSP_StatusTypeDef sm1_hw_ecb(const uint8_t *key, const uint8_t *in,
                             uint8_t *out, uint32_t len, int is_encrypt)
{
    RSP_StatusTypeDef ret;
    uint32_t cfg, cur_send;

    /* ---- 参数校验 ---- */
    if (key == NULL)  return sm1_param_null_err("ECB", "key");
    if (in == NULL)   return sm1_param_null_err("ECB", "in");
    if (out == NULL)  return sm1_param_null_err("ECB", "out");
    if ((len % SM1_ENTRY_BYTES) != 0U)   /* 必须 16B 对齐 */
        return sm1_param_len_err("ECB", "msg", len, "N*16");

    cur_send = SM1_KEY_BYTES + len;      /* FIFO 实际写入的总字节 */

    sm1_ip_reset();

    cfg = ((uint32_t)is_encrypt & 0x1U)
        | SM1_SER_TYPE_ECB
        | (((uint32_t)SM1_KEY_BYTES & 0xFFU) << SM1_CFG_KEY_LEN_Pos)
        | (SM1_PKG_FULL);

    SM1_IP->CFG         = cfg;
    SM1_IP->PKG_LEN_ALL = cur_send;
    SM1_IP->PKG_LEN_CUR = cur_send;
    SM1_IP->ENABLE      = SM1_ENABLE;

    ret = sm1_put(key, SM1_KEY_BYTES);
    if (ret == RSP_OK) ret = sm1_put(in, len);
    if (ret == RSP_OK) ret = sm1_get(out, len);

    SM1_IP->CFG = 0U;
    return ret;
}

RSP_StatusTypeDef sm1_hw_cbc(const uint8_t *key, const uint8_t *iv,
                             const uint8_t *in, uint8_t *out,
                             uint32_t len, int is_encrypt)
{
    RSP_StatusTypeDef ret;
    uint32_t cfg, cur_send;
    uint8_t iv_buf[SM1_ENTRY_BYTES];

    /* ---- 参数校验 ---- */
    if (key == NULL)  return sm1_param_null_err("CBC", "key");
    if (in == NULL)   return sm1_param_null_err("CBC", "in");
    if (out == NULL)  return sm1_param_null_err("CBC", "out");
    if ((iv == NULL) && is_encrypt) return sm1_param_null_err("CBC", "iv");
    if ((len % SM1_ENTRY_BYTES) != 0U)   /* 必须 16B 对齐 */
        return sm1_param_len_err("CBC", "msg", len, "N*16");

    memset(iv_buf, 0, sizeof(iv_buf));
    if (iv != NULL) memcpy(iv_buf, iv, SM1_IV_BYTES);

    cur_send = SM1_KEY_BYTES + SM1_IV_BYTES + len;

    sm1_ip_reset();

    cfg = ((uint32_t)is_encrypt & 0x1U)
        | SM1_SER_TYPE_CBC
        | (((uint32_t)SM1_KEY_BYTES & 0xFFU) << SM1_CFG_KEY_LEN_Pos)
        | (SM1_PKG_FULL);

    SM1_IP->CFG         = cfg;
    SM1_IP->PKG_LEN_ALL = cur_send;
    SM1_IP->PKG_LEN_CUR = cur_send;
    SM1_IP->ENABLE      = SM1_ENABLE;

    ret = sm1_put(key, SM1_KEY_BYTES);
    if (ret == RSP_OK) ret = sm1_put(iv_buf, SM1_ENTRY_BYTES);
    if (ret == RSP_OK) ret = sm1_put(in, len);
    if (ret == RSP_OK) ret = sm1_get(out, len);

    SM1_IP->CFG = 0U;
    return ret;
}
