/**
 * @file rsp_ip_sm4.c
 * @brief SM4 hardware driver (based on sm4.xlsx register map)
 *        Support ECB / CBC / CTR / GCM
 */

#include "rsp_ip_sm4.h"
#ifdef RSP_USE_DMA_PERF
#include "rsp_hal_dma.h"
#include "rsp_hal_misc.h"   /* rsp_hal_get_us() 性能计时 */
#endif
#include <stdio.h>
#include <string.h>

/* ============================================================
 *  核心内联辅助（零调用开销，编译器-O2完全展开）
 * ============================================================ */

/**
 * @brief 向IFIFO写一个128bit(16字节)条目
 * @note  SM4 IFIFO/OFIFO仅支持base地址访问(IFIFO[0..3]/OFIFO[0..3])，
 *        不支持索引式访问。固定写base地址，FIFO自动推入一个条目。
 */
static inline void SM4_WriteIFIFO_128(const uint8_t *pData, uint32_t blk)
{
    (void)blk;
    const uint32_t *w = (const uint32_t *)pData;
    SM4_IP->IFIFO[0] = w[0];
    SM4_IP->IFIFO[1] = w[1];
    SM4_IP->IFIFO[2] = w[2];
    SM4_IP->IFIFO[3] = w[3];
}

/**
 * @brief 从OFIFO读一个128bit(16字节)条目
 * @note  固定读base地址OFIFO[0..3]，FIFO自动弹出最旧条目。
 */
static inline void SM4_ReadOFIFO_128(uint8_t *pData, uint32_t blk)
{
    (void)blk;
    uint32_t *w = (uint32_t *)pData;
    w[0] = SM4_IP->OFIFO[0];
    w[1] = SM4_IP->OFIFO[1];
    w[2] = SM4_IP->OFIFO[2];
    w[3] = SM4_IP->OFIFO[3];
}

/**
 * @brief SM4 IP软复位：禁用算核、清配置、清FIFO
 * @note  0x10(PKG_LEN_CUR)/0x18(PKG_POS)均为RW寄存器(经sm4.xlsx和ECB实测确认)。
 *        FIFO清零用 CFG@0x08 bit28 (W1SC)。
 */
static void sm4_ip_reset(void)
{
    volatile uint32_t *base = (volatile uint32_t *)SM4_IP_BASE;

    /* 1. 先关算核 */
    base[0x1C / 4] = 0U;

    /* 2. 清配置寄存器 */
    base[0x04 / 4] = 0U;   /* INTR        */
    base[0x08 / 4] = 0U;   /* CFG         */
    base[0x0C / 4] = 0U;   /* PKG_LEN_ALL */
    base[0x10 / 4] = 0U;   /* PKG_LEN_CUR */
    base[0x14 / 4] = 0U;   /* AAD_LEN     */
    base[0x18 / 4] = 0U;   /* PKG_POS     */

    /* 3. FIFO状态清零: 写bit28，等待，写0恢复 */
    base[0x08 / 4] = SM4_CFG_FIFO_STATE_CLEAR;
    for (volatile int d = 0; d < 2000; d++);
    base[0x08 / 4] = 0U;
}

/* 分段模式专用轻量 reset: 跳过重的 FIFO_STATE_CLEAR (16ms!)
 * 上一段结束后 ENABLE=0, OFIFO 已读完, FIFO 自然清空, 无需硬清
 */
static void __attribute__((unused)) sm4_ip_reset_lite(void)
{
    volatile uint32_t *base = (volatile uint32_t *)SM4_IP_BASE;

    base[0x1C / 4] = 0U;   /* ENABLE = 0 */
    base[0x04 / 4] = 0U;   /* INTR        */
    base[0x08 / 4] = 0U;   /* CFG         */
    base[0x0C / 4] = 0U;   /* PKG_LEN_ALL */
    base[0x10 / 4] = 0U;   /* PKG_LEN_CUR */
    base[0x14 / 4] = 0U;   /* AAD_LEN     */
    base[0x18 / 4] = 0U;   /* PKG_POS     */
}

/* ============================================================
 *  SM4硬件统一处理入口
 * ============================================================ */
RSP_StatusTypeDef sm4_hw_process(sm4_ctx_t *ctx)
{
    RSP_StatusTypeDef ret;
    uint32_t cfg_val;
    uint32_t blk_cnt;
    uint32_t i;
    uint32_t timeout;

    if ((ctx == NULL) || (ctx->key == NULL) ||
        (ctx->in == NULL) || (ctx->out == NULL) || (ctx->in_len == 0U))
    {
        return RSP_ERR_NULL_PTR;
    }

    sm4_ip_reset();

    cfg_val = 0U;

    switch (ctx->mode)
    {
    /* -------------------- ECB -------------------- */
    case SM4_MODE_ECB:
    {
        /* ECB: IFIFO = key(16) + message(N×16)
         * 必须在ENABLE前预加载key+message到FIFO，否则硬件用key当message */
        uint32_t pre;
        uint32_t rd_cnt = 0U;
        uint32_t pad_len;
        uint8_t  pad_buf[SM4_BLOCK_BYTE_LEN];

        /* MSG长度任意: 非16整数倍时末块软件补0到整块 */
        blk_cnt = (ctx->in_len + SM4_BLOCK_BYTE_LEN - 1U) / SM4_BLOCK_BYTE_LEN;
        pad_len = blk_cnt * SM4_BLOCK_BYTE_LEN - ctx->in_len;   /* 0..15 */
        if (pad_len != 0U)
        {
            memset(pad_buf, 0, sizeof(pad_buf));
            memcpy(pad_buf, ctx->in + (blk_cnt - 1U) * SM4_BLOCK_BYTE_LEN,
                   SM4_BLOCK_BYTE_LEN - pad_len);
        }

        cfg_val = SM4_SER_TYPE_ECB |
                  (SM4_KEY_BYTE_LEN << SM4_CFG_KEY_LEN_Pos) |
                  SM4_PKG_FULL;
        if (!ctx->is_encrypt)
            cfg_val |= SM4_CFG_ENCDEC;

        /* 配置IFIFO阈满/阈空阈值: PROG_FULL=7(7条目时停写留缓冲),
         * PROG_EMPTY=1(降到1条目时恢复写), 防FULL标志竞态丢数据 */
        SM4_IP->INTR = (7U << SM4_INTR_IFIFO_PROG_FULL_THRESH_Pos) |
                       (1U << SM4_INTR_IFIFO_PROG_EMPTY_THRESH_Pos);

        SM4_IP->CFG = cfg_val;
        SM4_IP->PKG_LEN_ALL = SM4_KEY_BYTE_LEN + blk_cnt * SM4_BLOCK_BYTE_LEN;
        SM4_IP->PKG_LEN_CUR = SM4_KEY_BYTE_LEN + blk_cnt * SM4_BLOCK_BYTE_LEN;

        /* 写 key + 前 min(blk_cnt, DEPTH-1) 个 message block (ENABLE前)
         * 预加载用IFIFO_FULL(真满), 最多写满8条目不溢出 */
        SM4_WriteIFIFO_128(ctx->key, 0U);
        pre = (blk_cnt > (SM4_IFIFO_DEPTH - 1U)) ? (SM4_IFIFO_DEPTH - 1U) : blk_cnt;
        for (i = 0U; i < pre; i++)
        {
            const uint8_t *blk = ((pad_len != 0U) && (i + 1U == blk_cnt))
                               ? pad_buf : (ctx->in + i * SM4_BLOCK_BYTE_LEN);
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_IFIFO_FULL) != 0U)
            {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_WriteIFIFO_128(blk, i + 1U);
        }

        /* 启动算核 */
        SM4_IP->ENABLE = SM4_ENABLE;

        /* 流式写剩余message: 用PROG_FULL(阈满7)控制写入节奏 +
         * 交替读result(防OFIFO满反压死锁) */
        for (i = pre; i < blk_cnt; i++)
        {
            const uint8_t *blk = ((pad_len != 0U) && (i + 1U == blk_cnt))
                               ? pad_buf : (ctx->in + i * SM4_BLOCK_BYTE_LEN);
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_IFIFO_PROG_FULL) != 0U)
            {
                if ((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) != 0U)
                {
                    SM4_ReadOFIFO_128(ctx->out + rd_cnt * SM4_BLOCK_BYTE_LEN, rd_cnt);
                    rd_cnt++;
                    timeout = SM4_POLL_TIMEOUT;
                }
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_WriteIFIFO_128(blk, i + 1U);
        }

        /* 读剩余result */
        for (; rd_cnt < blk_cnt; rd_cnt++)
        {
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) == 0U)
            {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_ReadOFIFO_128(ctx->out + rd_cnt * SM4_BLOCK_BYTE_LEN, rd_cnt);
        }
        break;
    }

    /* -------------------- CBC -------------------- */
    case SM4_MODE_CBC:
    {
        /* CBC: IFIFO = key(16) + IV(16) + message(N×16)
         * 必须在ENABLE前预加载key+IV+message到FIFO */
        uint32_t pre;
        uint32_t rd_cnt = 0U;
        uint32_t pad_len;
        uint8_t  pad_buf[SM4_BLOCK_BYTE_LEN];

        if (ctx->iv == NULL)
            return RSP_ERR_NULL_PTR;

        /* MSG长度任意: 非16整数倍时末块软件补0到整块 */
        blk_cnt = (ctx->in_len + SM4_BLOCK_BYTE_LEN - 1U) / SM4_BLOCK_BYTE_LEN;
        pad_len = blk_cnt * SM4_BLOCK_BYTE_LEN - ctx->in_len;   /* 0..15 */
        if (pad_len != 0U)
        {
            memset(pad_buf, 0, sizeof(pad_buf));
            memcpy(pad_buf, ctx->in + (blk_cnt - 1U) * SM4_BLOCK_BYTE_LEN,
                   SM4_BLOCK_BYTE_LEN - pad_len);
        }

        cfg_val = SM4_SER_TYPE_CBC |
                  (SM4_KEY_BYTE_LEN << SM4_CFG_KEY_LEN_Pos) |
                  SM4_PKG_FULL;
        if (!ctx->is_encrypt)
            cfg_val |= SM4_CFG_ENCDEC;

        /* 配置IFIFO阈满/阈空阈值(同ECB) */
        SM4_IP->INTR = (7U << SM4_INTR_IFIFO_PROG_FULL_THRESH_Pos) |
                       (1U << SM4_INTR_IFIFO_PROG_EMPTY_THRESH_Pos);

        SM4_IP->CFG = cfg_val;
        SM4_IP->PKG_LEN_ALL = SM4_KEY_BYTE_LEN + SM4_IV_BYTE_LEN +
                              blk_cnt * SM4_BLOCK_BYTE_LEN;
        SM4_IP->PKG_LEN_CUR = SM4_KEY_BYTE_LEN + SM4_IV_BYTE_LEN +
                              blk_cnt * SM4_BLOCK_BYTE_LEN;

        /* 写 key + IV + 前 min(blk_cnt, DEPTH-2) 个 message block (ENABLE前)
         * 预加载用IFIFO_FULL(真满), 最多写满8条目不溢出 */
        SM4_WriteIFIFO_128(ctx->key, 0U);
        SM4_WriteIFIFO_128(ctx->iv, 1U);
        pre = (blk_cnt > (SM4_IFIFO_DEPTH - 2U)) ? (SM4_IFIFO_DEPTH - 2U) : blk_cnt;
        for (i = 0U; i < pre; i++)
        {
            const uint8_t *blk = ((pad_len != 0U) && (i + 1U == blk_cnt))
                               ? pad_buf : (ctx->in + i * SM4_BLOCK_BYTE_LEN);
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_IFIFO_FULL) != 0U)
            {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_WriteIFIFO_128(blk, i + 2U);
        }

        /* 启动算核 */
        SM4_IP->ENABLE = SM4_ENABLE;

        /* 流式写剩余message: 用PROG_FULL(阈满7)控制写入 +
         * 交替读result(防OFIFO满反压死锁) */
        for (i = pre; i < blk_cnt; i++)
        {
            const uint8_t *blk = ((pad_len != 0U) && (i + 1U == blk_cnt))
                               ? pad_buf : (ctx->in + i * SM4_BLOCK_BYTE_LEN);
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_IFIFO_PROG_FULL) != 0U)
            {
                if ((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) != 0U)
                {
                    SM4_ReadOFIFO_128(ctx->out + rd_cnt * SM4_BLOCK_BYTE_LEN, rd_cnt);
                    rd_cnt++;
                    timeout = SM4_POLL_TIMEOUT;
                }
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_WriteIFIFO_128(blk, i + 2U);
        }

        /* 读剩余result */
        for (; rd_cnt < blk_cnt; rd_cnt++)
        {
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) == 0U)
            {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_ReadOFIFO_128(ctx->out + rd_cnt * SM4_BLOCK_BYTE_LEN, rd_cnt);
        }
        break;
    }

    /* -------------------- CTR -------------------- */
    case SM4_MODE_CTR:
    {
        /* CTR: IFIFO = key(16) + IV(16) + message(N×16)
         * 必须在ENABLE前预加载key+IV+message到FIFO */
        uint32_t pre;
        uint32_t rd_cnt = 0U;

        if (ctx->iv == NULL)
            return RSP_ERR_NULL_PTR;
        if ((ctx->in_len % SM4_BLOCK_BYTE_LEN) != 0U)
            return RSP_ERR_INVALID_PARAM;

        cfg_val = SM4_SER_TYPE_CTR |
                  (SM4_KEY_BYTE_LEN << SM4_CFG_KEY_LEN_Pos) |
                  SM4_PKG_FULL;

        /* 配置IFIFO阈满/阈空阈值(同ECB/CBC): PROG_FULL=7, PROG_EMPTY=1
         * 必须放在CFG之前, 防FULL标志竞态丢数据 */
        SM4_IP->INTR = (7U << SM4_INTR_IFIFO_PROG_FULL_THRESH_Pos) |
                       (1U << SM4_INTR_IFIFO_PROG_EMPTY_THRESH_Pos);

        SM4_IP->CFG = cfg_val;
        SM4_IP->PKG_LEN_ALL = SM4_KEY_BYTE_LEN + SM4_IV_BYTE_LEN + ctx->in_len;
        SM4_IP->PKG_LEN_CUR = SM4_KEY_BYTE_LEN + SM4_IV_BYTE_LEN + ctx->in_len;

        blk_cnt = ctx->in_len / SM4_BLOCK_BYTE_LEN;

        /* 写 key + IV + 前 min(blk_cnt, DEPTH-2) 个 message block (ENABLE前)
         * 预加载用IFIFO_FULL(真满), 最多写满8条目不溢出 */
        SM4_WriteIFIFO_128(ctx->key, 0U);
        SM4_WriteIFIFO_128(ctx->iv, 1U);
        pre = (blk_cnt > (SM4_IFIFO_DEPTH - 2U)) ? (SM4_IFIFO_DEPTH - 2U) : blk_cnt;
        for (i = 0U; i < pre; i++)
        {
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_IFIFO_FULL) != 0U)
            {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_WriteIFIFO_128(ctx->in + i * SM4_BLOCK_BYTE_LEN, i + 2U);
        }

        /* 启动算核 */
        SM4_IP->ENABLE = SM4_ENABLE;

        /* 流式写剩余message: 用PROG_FULL(阈满7)控制写入 +
         * 交替读result(防OFIFO满反压死锁) */
        for (i = pre; i < blk_cnt; i++)
        {
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_IFIFO_PROG_FULL) != 0U)
            {
                if ((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) != 0U)
                {
                    SM4_ReadOFIFO_128(ctx->out + rd_cnt * SM4_BLOCK_BYTE_LEN, rd_cnt);
                    rd_cnt++;
                    timeout = SM4_POLL_TIMEOUT;
                }
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_WriteIFIFO_128(ctx->in + i * SM4_BLOCK_BYTE_LEN, i + 2U);
        }

        /* 读剩余result */
        for (; rd_cnt < blk_cnt; rd_cnt++)
        {
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) == 0U)
            {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_ReadOFIFO_128(ctx->out + rd_cnt * SM4_BLOCK_BYTE_LEN, rd_cnt);
        }
        break;
    }

    /* -------------------- GCM -------------------- */
    case SM4_MODE_GCM:
    {
        /* GCM IFIFO格式: key(16) + IV(16) + MID_TAG(16) + TAG2(16)
         *                + AAD(M×16, 补0对齐) + message(N×16, 补0对齐)
         * PKG_LEN_ALL = message长度(仅数据)
         * AAD_LEN@0x14 = 附加认证数据长度
         * OFIFO输出: result(N×16) + TAG(16)
         *   加密: TAG为生成的认证标签
         *   解密: TAG为Pass/Fail(全FF=Pass, 全0=Fail)
         */
        uint8_t iv_buf[16] = {0};
        uint8_t zero_tag[16] = {0};
        uint8_t tag_read[16];
        uint32_t msg_blk, aad_blk;
        uint32_t rd_cnt = 0U;
        int tag_cached = 0;

        if (ctx->iv == NULL)
            return RSP_ERR_NULL_PTR;

        /* IV: 喂完整 GCM J0 = nonce || 0x00000001
         *   软件 GCM: J0=nonce||00000001, CTR counter 从 J0+1 开始
         *   硬件如果把 IV 当 J0, counter 也从 IV+1 = J0+1 开始
         *   → 两边 keystream 应该一致 */
        memset(iv_buf, 0, 16U);
        memcpy(iv_buf, ctx->iv, 12U);
        iv_buf[15] = 1U;

        /* APP 已补零到 16B 边界, len 直接整除 (不需要 ceil) */
        msg_blk = ctx->in_len / SM4_BLOCK_BYTE_LEN;
        aad_blk = ctx->aad_len / SM4_BLOCK_BYTE_LEN;

        cfg_val = SM4_SER_TYPE_GCM |
                  (SM4_KEY_BYTE_LEN << SM4_CFG_KEY_LEN_Pos) |
                  /* TAG_LEN@19:16 与 AES 同款: 字面字节长度(sm4.xlsx "单位BYTE"),
                   * 4bit 最大写 15。写 15 → 硬件只输出 15B TAG(第16字节补0,
                   * KAT 差最后1字节); 写 16 位域溢出 → TAG 全 0。
                   * 写 0 = 16B (mod-16 编码, 4bit 域表达 16 的唯一方式) */
                  (0U << SM4_CFG_TAG_LEN_Pos) |
                  SM4_PKG_FULL;
        if (!ctx->is_encrypt)
            cfg_val |= SM4_CFG_ENCDEC;

        /* 配置IFIFO阈满/阈空阈值(同ECB/CBC/CTR/CCM): PROG_FULL=7, PROG_EMPTY=1
         * 必须放在CFG之前, 防FULL标志竞态丢数据; N>=8时缺此配置会OFIFO超深死锁 */
        SM4_IP->INTR = (7U << SM4_INTR_IFIFO_PROG_FULL_THRESH_Pos) |
                       (1U << SM4_INTR_IFIFO_PROG_EMPTY_THRESH_Pos);

        SM4_IP->CFG = cfg_val;
        /* APP 保证补零, 直接用 ctx 里的值
         * PKG_LEN_ALL = GCM 长度块里的消息长度(只算 message), 与标准 GCM 一致;
         *               写总包长会让硬件 GHASH 的 len(C) 取错值, TAG 与标准不符
         * PKG_LEN_CUR = 本包 IFIFO 实际消费的字节数(含 header/AAD/msg) */
        SM4_IP->PKG_LEN_ALL = ctx->in_len;
        SM4_IP->PKG_LEN_CUR = 64U + ctx->aad_len + ctx->in_len;
        SM4_IP->AAD_LEN = ctx->aad_len;

        /* 预加载阶段(ENABLE前): header(4块) + 最多 4 块 AAD (刚好到 IFIFO 深度 8)
         * IFIFO 深度有限, 超过 4 block (64B) 的 AAD 放到 ENABLE 后 PROG_FULL 流式灌,
         * 硬件 GHASH 靠 AAD_LEN 寄存器区分 AAD 和 message 边界 */
        uint32_t aad_pre  = (aad_blk > 4U) ? 4U : aad_blk; /* ENABLE 前灌 min(aad, 4) */
        uint32_t aad_rem  = aad_blk - aad_pre;            /* 剩下的 ENABLE 后流式灌 */
        uint32_t pre = 0U;                                /* message ENABLE 前不预载 */
        uint32_t blk = 0U;

        /* 1. key */
        SM4_WriteIFIFO_128(ctx->key, blk++);
        /* 2. IV (12B nonce补0到16B) */
        SM4_WriteIFIFO_128(iv_buf, blk++);
        /* 3. MID_TAG: 整包任意值, 写全0 */
        SM4_WriteIFIFO_128(zero_tag, blk++);
        /* 4. TAG2: 加密=任意值(全0); 解密=待验证tag */
        if (!ctx->is_encrypt && (ctx->tag_in == NULL))
            return RSP_ERR_NULL_PTR;
        SM4_WriteIFIFO_128(ctx->is_encrypt ? zero_tag : ctx->tag_in, blk++);

        /* 5. AAD (ENABLE 前): 最多 4 块, 防 IFIFO_FULL 卡死 */
        for (i = 0U; i < aad_pre; i++)
        {
            uint8_t pad[16];
            memcpy(pad, ctx->aad + i * 16U, 16U);
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_IFIFO_FULL) != 0U) {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_WriteIFIFO_128(pad, blk++);
        }

        /* 启动算核 —— GHASH 从 IFIFO 开始消费 header + 前 N 块 AAD */
        SM4_IP->ENABLE = SM4_ENABLE;

        /* 6. ENABLE 后流式灌剩余 AAD (如果 aad_blk > 4), 同样用 PROG_FULL 反压
         * GHASH 引擎会先消费所有 AAD 字节(AAD_LEN 寄存器界定), 自动切到 CTR 模式 */
        for (i = 0U; i < aad_rem; i++)
        {
            uint8_t pad[16];
            memcpy(pad, ctx->aad + (aad_pre + i) * 16U, 16U);
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_IFIFO_PROG_FULL) != 0U) {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_WriteIFIFO_128(pad, blk++);
        }

        /* 7. 流式写 message: PROG_FULL反压 + 交替读OFIFO(防OFIFO满死锁)
         *    rd_cnt>=msg_blk时TAG提前缓存, 跳过重复读 */
        for (i = pre; i < msg_blk; i++)
        {
            uint8_t pad[16];
            memcpy(pad, ctx->in + i * 16U, 16U);

            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_IFIFO_PROG_FULL) != 0U)
            {
                if ((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) != 0U)
                {
                    if (rd_cnt < msg_blk)
                    {
                        SM4_ReadOFIFO_128(ctx->out + rd_cnt * SM4_BLOCK_BYTE_LEN, rd_cnt);
                        rd_cnt++;
                    }
                    else if (!tag_cached)
                    {
                        SM4_ReadOFIFO_128(tag_read, 0);
                        tag_cached = 1;
                    }
                    timeout = SM4_POLL_TIMEOUT;
                }
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_WriteIFIFO_128(pad, blk++);
        }

        /* 读剩余result */
        for (; rd_cnt < msg_blk; rd_cnt++)
        {
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) == 0U)
            {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_ReadOFIFO_128(ctx->out + rd_cnt * SM4_BLOCK_BYTE_LEN, rd_cnt);
        }
        /* 读TAG (如果交替读阶段已缓存, 直接用) */
        if (!tag_cached)
        {
            timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) == 0U)
            {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            SM4_ReadOFIFO_128(tag_read, 0);
        }

        if (ctx->is_encrypt)
        {
            /* 加密: tag_read是生成的TAG */
            if (ctx->tag_out != NULL)
                memcpy(ctx->tag_out, tag_read, SM4_TAG_BYTE_LEN);
        }
        else
        {
            /* 解密: tag_read是Pass/Fail(全FF=Pass) */
            uint8_t pass_tag[16];
            memset(pass_tag, 0xFF, sizeof(pass_tag));
            if (memcmp(tag_read, pass_tag, 16U) != 0U)
            {
                return RSP_ERR_DATA_CHECK;   /* TAG校验失败 */
            }
        }
        break;
    }

    default:
        return RSP_ERR_INVALID_PARAM;
    }

    /* 成功路径也必须 reset: 硬件 GCM 内部有 GHASH 累积器 / CTR counter 等
     * 不可见 shadow register, 入口 reset 清 FIFO 时这些状态可能还在,
     * 出口补一次完整 reset 保证下次调用完全 clean */
    sm4_ip_reset();
    return RSP_OK;

err:
    /* 出错时不能只关 CFG: 残留的 IFIFO/OFIFO 条目会让下一次 I2C 传输
     * 读到脏数据甚至把从机拖死(主机侧表现为 read ack failed -110)。
     * 这里做完整软复位, 清 FIFO 状态, 保证下一次请求可正常执行。 */
    sm4_ip_reset();
    return ret;
}


/* ============================================================
 *  SM4 DMA 版本（性能测试用, 所有 IFIFO/OFIFO 操作全 DMA）
 *
 *  DMA 配置: TT_M2M_DFC + MSIZE_4(128bit 突发) + DWIDTH_32
 *  ┌──────────┬─────────────────────────────────────────────────┐
 *  │ 预加载   │ 栈上拼连续 buffer → 单次 DMA 推进 IFIFO        │
 *  │ ENABLE后 │ 128B 大块 DMA 写 + PROG_FULL 反压              │
 *  │ 交替读   │ PROG_FULL 等待中检查 OFIFO → DMA 读释放空间    │
 *  │ 收尾读   │ OFIFO_CNT 轮询后 DMA 读                        │
 *  └──────────┴─────────────────────────────────────────────────┘
 *  当前覆盖 ECB / CBC / CTR / CFB / OFB
 * ============================================================ */
RSP_StatusTypeDef sm4_hw_process_dma(sm4_ctx_t *ctx)
{
    RSP_StatusTypeDef ret = RSP_OK;
    uint32_t cfg_val, blk_cnt, pre, msg_rem, chunk, i, dr;
    uint32_t t_start, t_end, us, mbps, mbs, frac;
    rsp_dma_transmit_t dma;
    /* 预加载: 栈上拼 key/IV/message 连续 buffer, 最大 DEPTH×16 = 128B */
    uint8_t pre_buf[SM4_IFIFO_DEPTH * SM4_BLOCK_BYTE_LEN] __attribute__((aligned(4)));
    /* OFIFO 批量读缓存: 一次读最多 BUCKET×16B 然后从缓存搬运到 out */
#define SM4_OFBUF_ENTRIES  8U
    uint32_t of_buf[SM4_OFBUF_ENTRIES * 4U] __attribute__((aligned(4)));

    if ((ctx == NULL) || (ctx->key == NULL) ||
        (ctx->in == NULL) || (ctx->in_len == 0U))
        return RSP_ERR_NULL_PTR;

    /* ECB MSG 非16整数倍: 末块需软件补0, DMA路径只处理整块, 交CPU路径 */
    if ((ctx->mode == SM4_MODE_ECB) &&
        ((ctx->in_len % SM4_BLOCK_BYTE_LEN) != 0U))
        return sm4_hw_process(ctx);

    /* 注意: 此 FPGA DMA IP 仅 TT_M2M_DFC 方向可用, M2P/P2M 会卡死 */
    if (rsp_hal_dma_init(&dma, 0, TT_M2M_DFC, DWIDTH_32, DWIDTH_32,
                         MSIZE_4, ADDR_INC, ADDR_INC,
                         HANDSHANKE_SOFT, HANDSHANKE_SOFT,
                         DMAC_REQ_DEFAULT, DMAC_REQ_DEFAULT) != 0)
        return RSP_ERR_FIFO;

    sm4_ip_reset();
    cfg_val = 0U;
    /* t_start 移到各 case 内部 memcpy 准备完、首个 dma_transfer 前 */

    switch (ctx->mode)
    {
    /* -------------------- ECB -------------------- */
    case SM4_MODE_ECB:
    {
        uint32_t rd_cnt = 0U, pre_len, of_bat, of_tail;
        const uint8_t *w;

        if (ctx->out == NULL) return RSP_ERR_NULL_PTR;

        cfg_val = SM4_SER_TYPE_ECB |
                  (SM4_KEY_BYTE_LEN << SM4_CFG_KEY_LEN_Pos) | SM4_PKG_FULL;
        if (!ctx->is_encrypt) cfg_val |= SM4_CFG_ENCDEC;

        SM4_IP->INTR = (7U << SM4_INTR_IFIFO_PROG_FULL_THRESH_Pos) |
                       (1U << SM4_INTR_IFIFO_PROG_EMPTY_THRESH_Pos);
        SM4_IP->CFG = cfg_val;
        SM4_IP->PKG_LEN_ALL = SM4_KEY_BYTE_LEN + ctx->in_len;
        SM4_IP->PKG_LEN_CUR = SM4_KEY_BYTE_LEN + ctx->in_len;
        blk_cnt = ctx->in_len / SM4_BLOCK_BYTE_LEN;

        /* ---- DMA 预加载: key + 前 min(blk_cnt, DEPTH-1) 个 message ----
         * 栈上拼连续 buffer, 一次 DMA 推进 IFIFO (ENABLE 前 FIFO 空, 无需反压) */
        pre = (blk_cnt > (SM4_IFIFO_DEPTH - 1U)) ? (SM4_IFIFO_DEPTH - 1U) : blk_cnt;
        memcpy(pre_buf, ctx->key, 16U);
        for (i = 0U; i < pre; i++)
            memcpy(pre_buf + 16U + i * 16U, ctx->in + i * 16U, 16U);
        pre_len = 16U + pre * 16U;
        t_start = rsp_hal_get_us();
        dr = dma_transfer(&dma, (uint32_t)pre_buf, SM4_IP_IFIFO_BASE, pre_len);
        if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }

        SM4_IP->ENABLE = SM4_ENABLE;

        /* ---- DMA 流式写剩余 message + 交替批量读 OFIFO ----
         * 每次写 chunk=128B (IFIFO 深度上限)
         * 反压等待里: 先让算核慢慢消费 (PROG_FULL 清了才能继续写),
         * 同时如果 OFIFO 有数据, 攒到 SM4_OFBUF_ENTRIES 条目再 DMA 批量读 */
        msg_rem = (blk_cnt - pre) * SM4_BLOCK_BYTE_LEN;
        w = ctx->in + pre * SM4_BLOCK_BYTE_LEN;
        while (msg_rem > 0U)
        {
            chunk = (msg_rem >= 128U) ? 128U : msg_rem;

            uint32_t timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_IFIFO_PROG_FULL) != 0U)
            {
                /* 交替读 OFIFO: 攒到 BUCKET 条或直到 PROG_FULL 清为止 */
                of_bat = (SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) >> SM4_STATE_OFIFO_CNT_Pos;
                of_bat = (of_bat > SM4_OFBUF_ENTRIES) ? SM4_OFBUF_ENTRIES : of_bat;
                if (of_bat > 0U)
                {
                    /* DMA 批量读 OFIFO → 缓存 → memcpy 到 out */
                    dr = dma_transfer(&dma, SM4_IP_OFIFO_BASE,
                                      (uint32_t)of_buf, of_bat * 16U);
                    if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
                    memcpy(ctx->out + rd_cnt * 16U, of_buf, of_bat * 16U);
                    rd_cnt += of_bat;
                }
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
            }

            dr = dma_transfer(&dma, (uint32_t)w, SM4_IP_IFIFO_BASE, chunk);
            if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
            w += chunk;
            msg_rem -= chunk;
        }

        /* ---- 收尾: 批量读剩余 OFIFO ---- */
        while (rd_cnt < blk_cnt)
        {
            uint32_t timeout = SM4_POLL_TIMEOUT;
            while (((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk)
                    >> SM4_STATE_OFIFO_CNT_Pos) == 0U)
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err_dma; }

            of_bat = (SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) >> SM4_STATE_OFIFO_CNT_Pos;
            of_bat = (of_bat > (blk_cnt - rd_cnt)) ? (blk_cnt - rd_cnt) : of_bat;
            of_bat = (of_bat > SM4_OFBUF_ENTRIES) ? SM4_OFBUF_ENTRIES : of_bat;

            dr = dma_transfer(&dma, SM4_IP_OFIFO_BASE,
                              (uint32_t)of_buf, of_bat * 16U);
            if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
            of_tail = (blk_cnt - rd_cnt >= of_bat) ? of_bat : (blk_cnt - rd_cnt);
            memcpy(ctx->out + rd_cnt * 16U, of_buf, of_tail * 16U);
            rd_cnt += of_tail;
        }
        goto perf_print;
    }

    /* -------------------- CBC / CTR (头部 key+IV+pre, 尾部同 ECB) -------------------- */
    case SM4_MODE_CBC:
    case SM4_MODE_CTR:
    {
        uint32_t rd_cnt = 0U, pre_len, of_bat, of_tail;
        const uint8_t *w;

        if (ctx->iv == NULL) return RSP_ERR_NULL_PTR;
        if (ctx->out == NULL) return RSP_ERR_NULL_PTR;
        if ((ctx->in_len % SM4_BLOCK_BYTE_LEN) != 0U)
        {
            /* CBC 末块不足16B: 交CPU路径软件补0; CTR 仍要求整块 */
            if (ctx->mode == SM4_MODE_CBC)
                return sm4_hw_process(ctx);
            return RSP_ERR_INVALID_PARAM;
        }

        switch (ctx->mode)
        {
        case SM4_MODE_CBC:
            cfg_val = SM4_SER_TYPE_CBC;
            if (!ctx->is_encrypt) cfg_val |= SM4_CFG_ENCDEC;
            break;
        case SM4_MODE_CTR: cfg_val = SM4_SER_TYPE_CTR; break;
        default:           cfg_val = SM4_SER_TYPE_CTR; break;
        }
        cfg_val |= (SM4_KEY_BYTE_LEN << SM4_CFG_KEY_LEN_Pos) | SM4_PKG_FULL;

        SM4_IP->INTR = (7U << SM4_INTR_IFIFO_PROG_FULL_THRESH_Pos) |
                       (1U << SM4_INTR_IFIFO_PROG_EMPTY_THRESH_Pos);
        SM4_IP->CFG = cfg_val;
        SM4_IP->PKG_LEN_ALL = SM4_KEY_BYTE_LEN + SM4_IV_BYTE_LEN + ctx->in_len;
        SM4_IP->PKG_LEN_CUR = SM4_KEY_BYTE_LEN + SM4_IV_BYTE_LEN + ctx->in_len;
        blk_cnt = ctx->in_len / SM4_BLOCK_BYTE_LEN;

        /* ---- DMA 预加载: key(16) + IV(16) + 前 min(blk_cnt, DEPTH-2) 个 message ---- */
        pre = (blk_cnt > (SM4_IFIFO_DEPTH - 2U)) ? (SM4_IFIFO_DEPTH - 2U) : blk_cnt;
        memcpy(pre_buf, ctx->key, 16U);
        memcpy(pre_buf + 16U, ctx->iv, 16U);
        for (i = 0U; i < pre; i++)
            memcpy(pre_buf + 32U + i * 16U, ctx->in + i * 16U, 16U);
        pre_len = 32U + pre * 16U;
        t_start = rsp_hal_get_us();
        dr = dma_transfer(&dma, (uint32_t)pre_buf, SM4_IP_IFIFO_BASE, pre_len);
        if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }

        SM4_IP->ENABLE = SM4_ENABLE;

        /* ---- DMA 流式写剩余 message + 交替批量读 OFIFO ---- */
        msg_rem = (blk_cnt - pre) * SM4_BLOCK_BYTE_LEN;
        w = ctx->in + pre * SM4_BLOCK_BYTE_LEN;
        while (msg_rem > 0U)
        {
            chunk = (msg_rem >= 128U) ? 128U : msg_rem;

            uint32_t timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_IFIFO_PROG_FULL) != 0U)
            {
                of_bat = (SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) >> SM4_STATE_OFIFO_CNT_Pos;
                of_bat = (of_bat > SM4_OFBUF_ENTRIES) ? SM4_OFBUF_ENTRIES : of_bat;
                if (of_bat > 0U)
                {
                    dr = dma_transfer(&dma, SM4_IP_OFIFO_BASE,
                                      (uint32_t)of_buf, of_bat * 16U);
                    if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
                    memcpy(ctx->out + rd_cnt * 16U, of_buf, of_bat * 16U);
                    rd_cnt += of_bat;
                }
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
            }

            dr = dma_transfer(&dma, (uint32_t)w, SM4_IP_IFIFO_BASE, chunk);
            if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
            w += chunk;
            msg_rem -= chunk;
        }

        /* ---- 收尾: 批量读剩余 OFIFO ---- */
        while (rd_cnt < blk_cnt)
        {
            uint32_t timeout = SM4_POLL_TIMEOUT;
            while (((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk)
                    >> SM4_STATE_OFIFO_CNT_Pos) == 0U)
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err_dma; }

            of_bat = (SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) >> SM4_STATE_OFIFO_CNT_Pos;
            of_bat = (of_bat > (blk_cnt - rd_cnt)) ? (blk_cnt - rd_cnt) : of_bat;
            of_bat = (of_bat > SM4_OFBUF_ENTRIES) ? SM4_OFBUF_ENTRIES : of_bat;

            dr = dma_transfer(&dma, SM4_IP_OFIFO_BASE,
                              (uint32_t)of_buf, of_bat * 16U);
            if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
            of_tail = (blk_cnt - rd_cnt >= of_bat) ? of_bat : (blk_cnt - rd_cnt);
            memcpy(ctx->out + rd_cnt * 16U, of_buf, of_tail * 16U);
            rd_cnt += of_tail;
        }
        goto perf_print;
    }

    /* -------------------- GCM 整包 --------------------
     * IFIFO: key(16) + IV(16) + MID_TAG(16,0) + TAG2(16) + AAD(M×16) + message(N×16)
     * PKG_LEN_ALL = 消息长度; PKG_LEN_CUR = 64 + aad_padded + msg_padded
     * AAD_LEN = aad_len
     * OFIFO: result(N×16) + TAG(16)
     *   加密: TAG 输出到 ctx->tag_out
     *   解密: TAG2=ctx->tag_in, OFIFO 末条目=pass/fail(全FF通过)
     * GCM: IV 取前 12B nonce 补 0 到 16B
     */
    case SM4_MODE_GCM:
    {
        uint32_t rd_cnt = 0U, pre_len, of_bat, of_tail, aad_blk, header_n, msg_pre;
        const uint8_t *w;
        uint8_t iv_buf[16] = {0};
        uint8_t zero16[16] = {0};
        uint8_t tag_buf[16] __attribute__((aligned(4)));
        int tag_cached = 0;

        if (ctx->iv == NULL || ctx->out == NULL)
            return RSP_ERR_NULL_PTR;
        if ((ctx->in_len % SM4_BLOCK_BYTE_LEN) != 0U)
            return RSP_ERR_INVALID_PARAM;
        if (!ctx->is_encrypt && ctx->tag_in == NULL)
            return RSP_ERR_NULL_PTR;

        /* IV 处理: GCM 取 12B nonce 补 0, CCM 直接用 */
        memcpy(iv_buf, ctx->iv, 12U);

        aad_blk = (ctx->aad_len + 15U) / 16U;
        blk_cnt = ctx->in_len / SM4_BLOCK_BYTE_LEN;
        header_n = 4U + aad_blk;

        uint32_t ser = SM4_SER_TYPE_GCM;
        /* TAG_LEN 同 CPU 路径: 写 0 = 16B (mod-16), 写 16 位域溢出 TAG 全 0 */
        cfg_val = ser | (SM4_KEY_BYTE_LEN << SM4_CFG_KEY_LEN_Pos) |
                  (0U << SM4_CFG_TAG_LEN_Pos) | SM4_PKG_FULL;
        if (!ctx->is_encrypt) cfg_val |= SM4_CFG_ENCDEC;

        SM4_IP->INTR = (7U << SM4_INTR_IFIFO_PROG_FULL_THRESH_Pos) |
                       (1U << SM4_INTR_IFIFO_PROG_EMPTY_THRESH_Pos);
        SM4_IP->CFG = cfg_val;
        /* PKG_LEN_ALL = GCM 长度块里的消息长度(只算 message), 与标准 GCM 一致
         * PKG_LEN_CUR = 本包 IFIFO 实际消费的字节数 */
        SM4_IP->PKG_LEN_ALL = blk_cnt * 16U;
        SM4_IP->PKG_LEN_CUR = 64U + aad_blk * 16U + blk_cnt * 16U;
        SM4_IP->AAD_LEN = aad_blk * 16U;

        /* DMA 预加载: key + IV + MID_TAG(0) + TAG2 + AAD + 部分 message
         * 受 IFIFO 深度 8 限制, header_n 可能占满, message 预加载量 = min(blk_cnt, DEPTH-header_n) */
        msg_pre = (header_n >= SM4_IFIFO_DEPTH) ? 0U :
                  ((blk_cnt > (SM4_IFIFO_DEPTH - header_n)) ? (SM4_IFIFO_DEPTH - header_n) : blk_cnt);

        memcpy(pre_buf, ctx->key, 16U);
        memcpy(pre_buf + 16U, iv_buf, 16U);
        memcpy(pre_buf + 32U, zero16, 16U);                                    /* MID_TAG */
        memcpy(pre_buf + 48U, ctx->is_encrypt ? zero16 : ctx->tag_in, 16U);  /* TAG2 */
        /* AAD (补0对齐) */
        for (i = 0U; i < aad_blk; i++)
        {
            uint8_t pad[16] = {0};
            uint32_t cp = ((ctx->aad_len - i * 16U) > 16U) ? 16U : (ctx->aad_len - i * 16U);
            if (ctx->aad != NULL) memcpy(pad, ctx->aad + i * 16U, cp);
            memcpy(pre_buf + 64U + i * 16U, pad, 16U);
        }
        /* 预加载部分 message */
        for (i = 0U; i < msg_pre; i++)
            memcpy(pre_buf + 64U + aad_blk * 16U + i * 16U, ctx->in + i * 16U, 16U);

        pre_len = 64U + aad_blk * 16U + msg_pre * 16U;
        t_start = rsp_hal_get_us();
        dr = dma_transfer(&dma, (uint32_t)pre_buf, SM4_IP_IFIFO_BASE, pre_len);
        if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }

        SM4_IP->ENABLE = SM4_ENABLE;

        /* DMA 流式写剩余 message + 交替批量读 OFIFO */
        msg_rem = (blk_cnt - msg_pre) * SM4_BLOCK_BYTE_LEN;
        w = ctx->in + msg_pre * SM4_BLOCK_BYTE_LEN;
        while (msg_rem > 0U)
        {
            chunk = (msg_rem >= 128U) ? 128U : msg_rem;
            uint32_t timeout = SM4_POLL_TIMEOUT;
            while ((SM4_IP->STATE & SM4_STATE_IFIFO_PROG_FULL) != 0U)
            {
                /* 交替读: rd_cnt<blk_cnt 读 result, 否则读 TAG 缓存 */
                of_bat = (SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) >> SM4_STATE_OFIFO_CNT_Pos;
                if (of_bat > 0U)
                {
                    if (rd_cnt < blk_cnt)
                    {
                        of_bat = (of_bat > (blk_cnt - rd_cnt)) ? (blk_cnt - rd_cnt) : of_bat;
                        of_bat = (of_bat > SM4_OFBUF_ENTRIES) ? SM4_OFBUF_ENTRIES : of_bat;
                        dr = dma_transfer(&dma, SM4_IP_OFIFO_BASE,
                                          (uint32_t)of_buf, of_bat * 16U);
                        if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
                        memcpy(ctx->out + rd_cnt * 16U, of_buf, of_bat * 16U);
                        rd_cnt += of_bat;
                    }
                    else if (!tag_cached)
                    {
                        dr = dma_transfer(&dma, SM4_IP_OFIFO_BASE,
                                          (uint32_t)tag_buf, 16U);
                        if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
                        tag_cached = 1;
                    }
                }
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
            }
            dr = dma_transfer(&dma, (uint32_t)w, SM4_IP_IFIFO_BASE, chunk);
            if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
            w += chunk;
            msg_rem -= chunk;
        }

        /* 收尾: 读剩余 result */
        while (rd_cnt < blk_cnt)
        {
            uint32_t timeout = SM4_POLL_TIMEOUT;
            while (((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) >> SM4_STATE_OFIFO_CNT_Pos) == 0U)
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
            of_bat = (SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) >> SM4_STATE_OFIFO_CNT_Pos;
            of_bat = (of_bat > (blk_cnt - rd_cnt)) ? (blk_cnt - rd_cnt) : of_bat;
            of_bat = (of_bat > SM4_OFBUF_ENTRIES) ? SM4_OFBUF_ENTRIES : of_bat;
            dr = dma_transfer(&dma, SM4_IP_OFIFO_BASE, (uint32_t)of_buf, of_bat * 16U);
            if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
            of_tail = (blk_cnt - rd_cnt >= of_bat) ? of_bat : (blk_cnt - rd_cnt);
            memcpy(ctx->out + rd_cnt * 16U, of_buf, of_tail * 16U);
            rd_cnt += of_tail;
        }
        /* 读 TAG (如果交替读阶段已缓存) */
        if (!tag_cached)
        {
            uint32_t timeout = SM4_POLL_TIMEOUT;
            while (((SM4_IP->STATE & SM4_STATE_OFIFO_CNT_Msk) >> SM4_STATE_OFIFO_CNT_Pos) == 0U)
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
            dr = dma_transfer(&dma, SM4_IP_OFIFO_BASE, (uint32_t)tag_buf, 16U);
            if (dr != 0U) { ret = RSP_ERR_FIFO; goto err_dma; }
        }

        if (ctx->is_encrypt)
        {
            if (ctx->tag_out != NULL) memcpy(ctx->tag_out, tag_buf, 16U);
        }
        else
        {
            /* 解密验证: pass/fail 全 FF */
            for (i = 0U; i < 16U; i++)
                if (tag_buf[i] != 0xFFU) { ret = RSP_ERR_DATA_CHECK; goto err_dma; }
        }
        goto perf_print;
    }

    default:
        /* XTS 头部特殊(双key+tweak), 回退 CPU */
        return sm4_hw_process(ctx);
    }

perf_print:
    t_end = rsp_hal_get_us();
    us = (t_end > t_start) ? (t_end - t_start) : 1U;
    if (us < 10U) us = 10U;   /* 防 us=0 或过小导致 mbps 飙飞 */
    /* Mbps 整数+千分位小数 */
    mbps     = (uint32_t)(((uint64_t)ctx->in_len * 8ULL) / us);
    uint32_t mbps_frac = (uint32_t)(((uint64_t)ctx->in_len * 8ULL * 1000ULL / us) % 1000ULL);
    /* MB/s 整数+千分位小数 */
    mbs      = (uint32_t)((uint64_t)ctx->in_len / us);
    frac     = (uint32_t)(((uint64_t)ctx->in_len * 1000ULL / us) % 1000ULL);
    /* 性能打印已屏蔽 */
    (void)us; (void)mbps; (void)mbps_frac; (void)mbs; (void)frac;
    return RSP_OK;

err_dma:
    SM4_IP->CFG = 0U;
    return ret;
}


/* ============================================================
 *  便捷接口
 * ============================================================ */

/* 参数错误上报: 打印具体出错的参数名, 便于调用者定位误用 */
static RSP_StatusTypeDef sm4_param_null_err(const char *algo, const char *param)
{
    printf("[SM4 %s] %s_null_err\n", algo, param);
    return RSP_ERR_NULL_PTR;
}

static RSP_StatusTypeDef sm4_param_len_err(const char *algo, const char *param,
                                           uint32_t got, const char *expect)
{
    printf("[SM4 %s] %s_len_err: got=%lu expect=%s\n", algo, param,
           (unsigned long)got, expect);
    return RSP_ERR_INVALID_PARAM;
}

RSP_StatusTypeDef sm4_ecb_hw(const uint8_t *key, uint32_t key_len,
                             const uint8_t *in, uint8_t *out,
                             uint32_t len, int is_encrypt)
{
    sm4_ctx_t ctx;

    /* ---- 参数校验 ---- */
    if (key == NULL)  return sm4_param_null_err("ECB", "key");
    if (key_len != SM4_KEY_BYTE_LEN)
        return sm4_param_len_err("ECB", "key", key_len, "16");
    if (in == NULL)   return sm4_param_null_err("ECB", "in");
    if (out == NULL)  return sm4_param_null_err("ECB", "out");
    if (len == 0U )   return sm4_param_len_err("ECB", "msg", len, ">0");
    if ((len % SM4_BLOCK_BYTE_LEN) != 0U) return sm4_param_len_err("ECB", "msg", len, "N*16");

    memset(&ctx, 0, sizeof(ctx));
    ctx.mode = SM4_MODE_ECB;
    ctx.is_encrypt = (uint8_t)is_encrypt;
    ctx.key = key;
    ctx.in = in;
    ctx.out = out;
    ctx.in_len = len;
#if RSP_USE_DMA_PERF
    return sm4_hw_process_dma(&ctx);
#else
    return sm4_hw_process(&ctx);
#endif
}

RSP_StatusTypeDef sm4_cbc_hw(const uint8_t *key, uint32_t key_len,
                             const uint8_t *iv, const uint8_t *in,
                             uint8_t *out, uint32_t len, int is_encrypt)
{
    sm4_ctx_t ctx;

    /* ---- 参数校验 ---- */
    if (key == NULL)  return sm4_param_null_err("CBC", "key");
    if (key_len != SM4_KEY_BYTE_LEN)
        return sm4_param_len_err("CBC", "key", key_len, "16");
    if (iv == NULL)   return sm4_param_null_err("CBC", "iv");
    if (in == NULL)   return sm4_param_null_err("CBC", "in");
    if (out == NULL)  return sm4_param_null_err("CBC", "out");
    if (len == 0U)
        return sm4_param_len_err("CBC", "msg", len, ">0");

    memset(&ctx, 0, sizeof(ctx));
    ctx.mode = SM4_MODE_CBC;
    ctx.is_encrypt = (uint8_t)is_encrypt;
    ctx.key = key;
    ctx.iv = iv;
    ctx.in = in;
    ctx.out = out;
    ctx.in_len = len;
#if RSP_USE_DMA_PERF
    return sm4_hw_process_dma(&ctx);
#else
    return sm4_hw_process(&ctx);
#endif
}

RSP_StatusTypeDef sm4_ctr_hw(const uint8_t *key, uint32_t key_len,
                             const uint8_t *iv, const uint8_t *in,
                             uint8_t *out, uint32_t len, int is_encrypt)
{
    sm4_ctx_t ctx;

    /* ---- 参数校验 ---- */
    if (key == NULL)  return sm4_param_null_err("CTR", "key");
    if (key_len != SM4_KEY_BYTE_LEN)
        return sm4_param_len_err("CTR", "key", key_len, "16");
    if (iv == NULL)   return sm4_param_null_err("CTR", "iv");
    if (in == NULL)   return sm4_param_null_err("CTR", "in");
    if (out == NULL)  return sm4_param_null_err("CTR", "out");
    if ((len == 0U) || ((len % SM4_BLOCK_BYTE_LEN) != 0U))
        return sm4_param_len_err("CTR", "msg", len, "N*16");

    memset(&ctx, 0, sizeof(ctx));
    ctx.mode = SM4_MODE_CTR;
    ctx.is_encrypt = (uint8_t)is_encrypt;
    ctx.key = key;
    ctx.iv = iv;
    ctx.in = in;
    ctx.out = out;
    ctx.in_len = len;
#if RSP_USE_DMA_PERF
    return sm4_hw_process_dma(&ctx);
#else
    return sm4_hw_process(&ctx);
#endif
}

RSP_StatusTypeDef sm4_gcm_hw(const uint8_t *key, uint32_t key_len,
                             const uint8_t *iv,
                             const uint8_t *aad, uint32_t aad_len,
                             const uint8_t *in, uint8_t *out,
                             uint32_t len, uint8_t *tag, int is_encrypt)
{
    uint32_t msg_blk, aad_blk;

    /* ---- 参数校验 ---- */
    if (key == NULL)  return sm4_param_null_err("GCM", "key");
    if (key_len != SM4_KEY_BYTE_LEN)
        return sm4_param_len_err("GCM", "key", key_len, "16");
    if (iv == NULL)   return sm4_param_null_err("GCM", "iv");
    if (in == NULL)   return sm4_param_null_err("GCM", "in");
    if (out == NULL)  return sm4_param_null_err("GCM", "out");
    if (tag == NULL)  return sm4_param_null_err("GCM", "tag");
    if ((aad_len != 0U) && (aad == NULL))
        return sm4_param_null_err("GCM", "aad");
    if ((len == 0U) || ((len % SM4_BLOCK_BYTE_LEN) != 0U))
        return sm4_param_len_err("GCM", "msg", len, "N*16");

    msg_blk = (len + SM4_BLOCK_BYTE_LEN - 1U) / SM4_BLOCK_BYTE_LEN;
    aad_blk = (aad_len + SM4_BLOCK_BYTE_LEN - 1U) / SM4_BLOCK_BYTE_LEN;

    /* AAD 长度不再限制: 内部 GCM 已用 PROG_FULL 流式灌 IFIFO,
     * 只要 header(4) + AAD 能装 IFIFO 就行 — 流式写不受深度硬限制
     * 之前旧假设 "4+aad_blk ≤ 8" 仅适用于老版本整包预载模式 */
    (void)msg_blk;
    (void)aad_blk;

    {
        sm4_ctx_t ctx;
        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SM4_MODE_GCM;
        ctx.is_encrypt = (uint8_t)is_encrypt;
        ctx.key = key;
        ctx.iv = iv;
        ctx.aad = aad;
        ctx.aad_len = aad_len;
        ctx.in = in;
        ctx.out = out;
        ctx.in_len = len;
        if (is_encrypt) { ctx.tag_out = tag; ctx.tag_in = NULL; }
        else            { ctx.tag_in = tag;  ctx.tag_out = NULL; }
#if RSP_USE_DMA_PERF
        return sm4_hw_process_dma(&ctx);
#else
        return sm4_hw_process(&ctx);
#endif
    }

}

