#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "rsp_ip_sm3.h"
#include "rsp_hal_dma.h"
#include "rsp_hal_misc.h"   /* rsp_hal_get_us() 性能计时 */

/* 轮询超时值（SM3每分组约数十周期，2分组+padding留足余量）*/
#define SM3_POLL_TIMEOUT_VAL  1000000U

/* 多包模式：每包最大写入字节数=448=7×64=28×16（64分组整数倍）。
 * head/mid不做padding，IV在分组边界链接，每包必须64字节整数倍。*/
#define SM3_MULTI_PKG_CHUNK   (448U)

/* 阈值流式模式默认值：阈满4（剩4条目可写），阈空2。
 * 字段宽度3bit(0~7)，阈满必须<深度8。*/
#define SM3_DEFAULT_PROG_FULL_THRESH   (4U)
#define SM3_DEFAULT_PROG_EMPTY_THRESH  (2U)

/* ============================================================
 *  参数错误上报: 打印具体出错的参数名, 便于调用者定位误用
 * ============================================================ */
static RSP_StatusTypeDef sm3_param_null_err(const char *algo, const char *param)
{
    printf("[SM3 %s] %s_null_err\n", algo, param);
    return RSP_ERR_NULL_PTR;
}

static RSP_StatusTypeDef sm3_param_len_err(const char *algo, const char *param,
                                           uint32_t got, const char *expect)
{
    printf("[SM3 %s] %s_len_err: got=%lu expect=%s\n", algo, param,
           (unsigned long)got, expect);
    return RSP_ERR_INVALID_PARAM;
}

/* ============================================================
 *  核心内联辅助（零调用开销，编译器-O2完全展开）
 * ============================================================ */

/**
 * @brief 向IFIFO写一个128bit(16字节)条目
 * @note  IFIFO是128bit端口，4个32bit连续写组成一个条目。
 *        pData需保证4字节对齐（调用者负责，测试数据/内部缓冲均对齐）。
 */
static inline void SM3_WriteIFIFO_128(const uint8_t *pData, uint32_t blk)
{
    uint32_t idx = (blk % SM3_IFIFO_DEPTH) * 4U;
    const uint32_t *w = (const uint32_t *)pData;
    SM3_IP->IFIFO[idx + 0] = w[0];
    SM3_IP->IFIFO[idx + 1] = w[1];
    SM3_IP->IFIFO[idx + 2] = w[2];
    SM3_IP->IFIFO[idx + 3] = w[3];
}

/**
 * @brief 从OFIFO读一个128bit(16字节)条目
 */
static inline void SM3_ReadOFIFO_128(uint8_t *pData, uint32_t blk)
{
    uint32_t idx = blk * 4U;
    uint32_t *w = (uint32_t *)pData;
    w[0] = SM3_IP->OFIFO[idx + 0];
    w[1] = SM3_IP->OFIFO[idx + 1];
    w[2] = SM3_IP->OFIFO[idx + 2];
    w[3] = SM3_IP->OFIFO[idx + 3];
}

/**
 * @brief 等待算核完成（STATE.DOEN, 高有效）
 */
static inline RSP_StatusTypeDef SM3_WaitDone(void)
{
    uint32_t timeout = SM3_POLL_TIMEOUT_VAL;
    while ((SM3_IP->STATE & SM3_STATE_DOEN) == 0U)
    {
        if (--timeout == 0U)
            return RSP_ERR_TIMEOUT;
    }
    return RSP_OK;
}

/**
 * @brief 等待BUSY释放
 */
static inline RSP_StatusTypeDef SM3_WaitIdle(void)
{
    uint32_t timeout = SM3_POLL_TIMEOUT_VAL;
    while ((SM3_IP->STATE & SM3_STATE_BUSY) != 0U)
    {
        if (--timeout == 0U)
            return RSP_ERR_TIMEOUT;
    }
    return RSP_OK;
}

/* ============================================================
 *  软件padding算法（纯软件，用于DMA路径）
 * ============================================================ */
void SM3_SoftPadding(const uint8_t *pRawData, uint32_t rawByteLen,
                     uint8_t *pPadBuf, uint32_t *pPadTotalLen)
{
    uint64_t bit_len = (uint64_t)rawByteLen * 8ULL;
    uint32_t left = rawByteLen % SM3_BLOCK_BYTE_LEN;
    uint32_t pad_bytes = (left < 56U) ? (56U - left) : ((SM3_BLOCK_BYTE_LEN + 56U) - left);

    memcpy(pPadBuf, pRawData, rawByteLen);
    pPadBuf[rawByteLen] = 0x80U;
    memset(pPadBuf + rawByteLen + 1U, 0, pad_bytes - 1U);

    uint32_t pos = rawByteLen + pad_bytes;
    pPadBuf[pos + 0] = (uint8_t)((bit_len >> 56U) & 0xFFU);
    pPadBuf[pos + 1] = (uint8_t)((bit_len >> 48U) & 0xFFU);
    pPadBuf[pos + 2] = (uint8_t)((bit_len >> 40U) & 0xFFU);
    pPadBuf[pos + 3] = (uint8_t)((bit_len >> 32U) & 0xFFU);
    pPadBuf[pos + 4] = (uint8_t)((bit_len >> 24U) & 0xFFU);
    pPadBuf[pos + 5] = (uint8_t)((bit_len >> 16U) & 0xFFU);
    pPadBuf[pos + 6] = (uint8_t)((bit_len >> 8U)  & 0xFFU);
    pPadBuf[pos + 7] = (uint8_t)(bit_len & 0xFFU);

    *pPadTotalLen = pos + SM3_LENTAG_BYTE_LEN;
}

/* ============================================================
 *  DMA分块写IFIFO（按IFIFO_CNT软件反压，chunk=64B=1分组）
 * ============================================================ */
static int __attribute__((unused)) SM3_DMA_WriteIFIFO(rsp_dma_transmit_t *ctx,
                              const uint8_t *buf, uint32_t len)
{
    const uint32_t CHUNK_BYTES = 64U;  /* 4个128bit条目=一个SM3分组，避免死锁 */
    uint32_t off = 0U;

    if ((len & 0x0FU) != 0U)
        return -1;

    while (off < len)
    {
        uint32_t n = len - off;
        if (n > CHUNK_BYTES) n = CHUNK_BYTES;
        uint32_t need_entries = n >> 4;

        uint32_t to = SM3_POLL_TIMEOUT_VAL;
        while ((((SM3_IP->STATE & SM3_STATE_IFIFO_WR_CNT_Msk)
                 >> SM3_STATE_IFIFO_WR_CNT_Pos) >
                (SM3_IFIFO_DEPTH - need_entries)))
        {
            if (--to == 0U) return -2;
        }

        int dret = dma_transfer(ctx, (uint32_t)(buf + off), SM3_IP_IFIFO_BASE, n);
        if (dret != 0) return dret;
        off += n;
    }
    return 0;
}

/* ============================================================
 *  HMAC-SM3 单包模式（硬件padding，key=64字节）
 * ============================================================ */
RSP_StatusTypeDef SM3_IP_HMAC_SM3(const uint8_t *pKey, uint32_t keyByteLen,
                                  const uint8_t *pMsg, uint32_t msgByteLen,
                                  uint8_t *pOutHmac)
{
    if ((pKey == NULL) || (pMsg == NULL) || (pOutHmac == NULL))
        return RSP_ERR_NULL_PTR;
    if (keyByteLen == 0U)
        return RSP_ERR_INVALID_PARAM;

    /* 密钥预处理：key>64先K=SM3(key)再补0，key<=64直接补0 */
    uint8_t key_buf[SM3_BLOCK_BYTE_LEN] = {0};
    if (keyByteLen > SM3_BLOCK_BYTE_LEN)
    {
        RSP_StatusTypeDef ret = SM3_IP_StreamingHash(pKey, keyByteLen, key_buf);
        if (ret != RSP_OK) return ret;
    }
    else
    {
        memcpy(key_buf, pKey, keyByteLen);
    }

    /* 复位（密钥摘要计算会留FIFO状态）*/
    SM3_IP->CFG = 0U;
    SM3_IP->CFG = SM3_CFG_IFIFO_STATE_CLEAR;
    for (volatile int i = 0; i < 100; i++);
    SM3_IP->CFG = 0U;
    while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) != 0U)
    {
        volatile uint32_t d = SM3_IP->OFIFO[0];
        (void)d;
    }

    /* 配置：HMAC整包+硬件padding，长度只算message不含key */
    SM3_IP->CFG = SM3_CFG_MODE_HMAC | SM3_CFG_HEADER_ONE_PKG | SM3_CFG_PADDING_HARD;
    SM3_IP->PKG_LEN   = msgByteLen;
    SM3_IP->TOTAL_LEN = msgByteLen;
    SM3_IP->CFG |= SM3_CFG_ENABLE;

    /* 写key(64B=4条目) */
    uint32_t blk = 0U;
    for (uint32_t i = 0U; i < 4U; i++)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(&key_buf[i * SM3_IFIFO_DATA_WIDTH_BYTE], blk++);
    }

    /* 写message */
    uint32_t full = msgByteLen / SM3_IFIFO_DATA_WIDTH_BYTE;
    uint32_t rem  = msgByteLen % SM3_IFIFO_DATA_WIDTH_BYTE;
    for (uint32_t i = 0U; i < full; i++)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(&pMsg[i * SM3_IFIFO_DATA_WIDTH_BYTE], blk++);
    }
    if (rem != 0U)
    {
        uint8_t tail[SM3_IFIFO_DATA_WIDTH_BYTE] = {0};
        memcpy(tail, &pMsg[full * SM3_IFIFO_DATA_WIDTH_BYTE], rem);
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(tail, blk);
    }

    RSP_StatusTypeDef ret = SM3_WaitDone();
    if (ret != RSP_OK) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    for (uint32_t b = 0U; b < 2U; b++)
    {
        while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) == 0U);
        SM3_ReadOFIFO_128(&pOutHmac[b * SM3_IFIFO_DATA_WIDTH_BYTE], b);
    }

    SM3_IP->CFG &= ~SM3_CFG_ENABLE;
    return RSP_OK;
}

/* ============================================================
 *  SM3 多包模式 head/mid/tail
 * ============================================================ */

RSP_StatusTypeDef SM3_IP_HeadPackage(const uint8_t *pInData, uint32_t inByteLen,
                                     uint8_t *pOutIV)
{
    if (pInData == NULL || pOutIV == NULL)
        return RSP_ERR_NULL_PTR;

    SM3_IP->CFG = SM3_CFG_MODE_SM3 | SM3_CFG_HEADER_HEAD_PKG;
    SM3_IP->PKG_LEN   = inByteLen;
    SM3_IP->TOTAL_LEN = inByteLen;
    SM3_IP->CFG |= SM3_CFG_ENABLE;

    uint32_t full = inByteLen / SM3_IFIFO_DATA_WIDTH_BYTE;
    uint32_t rem  = inByteLen % SM3_IFIFO_DATA_WIDTH_BYTE;
    for (uint32_t i = 0U; i < full; i++)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(&pInData[i * SM3_IFIFO_DATA_WIDTH_BYTE], i);
    }
    if (rem != 0U)
    {
        uint8_t tail[SM3_IFIFO_DATA_WIDTH_BYTE] = {0};
        memcpy(tail, &pInData[full * SM3_IFIFO_DATA_WIDTH_BYTE], rem);
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(tail, full);
    }

    RSP_StatusTypeDef ret = SM3_WaitDone();
    if (ret != RSP_OK) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    for (uint32_t b = 0U; b < 2U; b++)
    {
        while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) == 0U);
        SM3_ReadOFIFO_128(&pOutIV[b * SM3_IFIFO_DATA_WIDTH_BYTE], b);
    }

    SM3_IP->CFG &= ~SM3_CFG_ENABLE;
    return RSP_OK;
}

RSP_StatusTypeDef SM3_IP_MidPackage(const uint8_t *pIV, const uint8_t *pInData,
                                    uint32_t inByteLen, uint8_t *pOutIV)
{
    if (pIV == NULL || pInData == NULL || pOutIV == NULL)
        return RSP_ERR_NULL_PTR;

    SM3_IP->CFG = SM3_CFG_MODE_SM3 | SM3_CFG_HEADER_MID_PKG;
    SM3_IP->PKG_LEN   = inByteLen;
    SM3_IP->TOTAL_LEN = inByteLen;
    SM3_IP->CFG |= SM3_CFG_ENABLE;

    /* 先写IV(32B=2条目) */
    uint32_t blk = 0U;
    while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
    SM3_WriteIFIFO_128(&pIV[0], blk++);
    while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
    SM3_WriteIFIFO_128(&pIV[16], blk++);

    /* 再写数据 */
    uint32_t full = inByteLen / SM3_IFIFO_DATA_WIDTH_BYTE;
    uint32_t rem  = inByteLen % SM3_IFIFO_DATA_WIDTH_BYTE;
    for (uint32_t i = 0U; i < full; i++)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(&pInData[i * SM3_IFIFO_DATA_WIDTH_BYTE], blk++);
    }
    if (rem != 0U)
    {
        uint8_t tail[SM3_IFIFO_DATA_WIDTH_BYTE] = {0};
        memcpy(tail, &pInData[full * SM3_IFIFO_DATA_WIDTH_BYTE], rem);
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(tail, blk);
    }

    RSP_StatusTypeDef ret = SM3_WaitDone();
    if (ret != RSP_OK) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    for (uint32_t b = 0U; b < 2U; b++)
    {
        while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) == 0U);
        SM3_ReadOFIFO_128(&pOutIV[b * SM3_IFIFO_DATA_WIDTH_BYTE], b);
    }

    SM3_IP->CFG &= ~SM3_CFG_ENABLE;
    return RSP_OK;
}

RSP_StatusTypeDef SM3_IP_TailPackage(const uint8_t *pIV, const uint8_t *pInData,
                                     uint32_t inByteLen, uint32_t totalByteLen,
                                     uint8_t *pOutDigest)
{
    if (pIV == NULL || pInData == NULL || pOutDigest == NULL)
        return RSP_ERR_NULL_PTR;
    if (inByteLen > SM3_MULTI_PKG_CHUNK)
        return RSP_ERR_INVALID_PARAM;

    /* CPU侧构造尾段padding：0x80+zeros+全局bitlen(大端)，补到64整数倍 */
    uint8_t pad_buf[SM3_MULTI_PKG_CHUNK + SM3_BLOCK_BYTE_LEN];
    uint64_t bit_len = (uint64_t)totalByteLen * 8ULL;
    uint32_t last_block = inByteLen % SM3_BLOCK_BYTE_LEN;
    uint32_t pad_total = (last_block < 56U) ? (SM3_BLOCK_BYTE_LEN - last_block)
                                            : (SM3_BLOCK_BYTE_LEN * 2U - last_block);
    uint32_t padded_len = inByteLen + pad_total;

    memcpy(pad_buf, pInData, inByteLen);
    memset(pad_buf + inByteLen, 0, pad_total);
    pad_buf[inByteLen] = 0x80U;
    pad_buf[padded_len - 8U + 0] = (uint8_t)(bit_len >> 56);
    pad_buf[padded_len - 8U + 1] = (uint8_t)(bit_len >> 48);
    pad_buf[padded_len - 8U + 2] = (uint8_t)(bit_len >> 40);
    pad_buf[padded_len - 8U + 3] = (uint8_t)(bit_len >> 32);
    pad_buf[padded_len - 8U + 4] = (uint8_t)(bit_len >> 24);
    pad_buf[padded_len - 8U + 5] = (uint8_t)(bit_len >> 16);
    pad_buf[padded_len - 8U + 6] = (uint8_t)(bit_len >> 8);
    pad_buf[padded_len - 8U + 7] = (uint8_t)(bit_len);

    SM3_IP->CFG = SM3_CFG_MODE_SM3 | SM3_CFG_HEADER_TAIL_PKG;
    SM3_IP->PKG_LEN   = padded_len;
    SM3_IP->TOTAL_LEN = padded_len;
    SM3_IP->CFG |= SM3_CFG_ENABLE;

    /* 先写IV(32B=2条目) */
    uint32_t blk = 0U;
    while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
    SM3_WriteIFIFO_128(&pIV[0], blk++);
    while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
    SM3_WriteIFIFO_128(&pIV[16], blk++);

    /* 再写补齐后的尾段 */
    uint32_t entries = padded_len / SM3_IFIFO_DATA_WIDTH_BYTE;
    for (uint32_t i = 0U; i < entries; i++)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(&pad_buf[i * SM3_IFIFO_DATA_WIDTH_BYTE], blk++);
    }

    RSP_StatusTypeDef ret = SM3_WaitDone();
    if (ret != RSP_OK) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    for (uint32_t b = 0U; b < 2U; b++)
    {
        while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) == 0U);
        SM3_ReadOFIFO_128(&pOutDigest[b * SM3_IFIFO_DATA_WIDTH_BYTE], b);
    }

    SM3_IP->CFG &= ~SM3_CFG_ENABLE;
    return RSP_OK;
}

/**
 * @brief SM3 IP 多包模式自动拆包
 * @note  ≤448字节回退StreamingHash(软件padding，任意长度正确)；
 *        >448按head/mid/tail拆包，tail用软件padding(全局bitlen)。
 */
RSP_StatusTypeDef SM3_IP_MultiPackage(const uint8_t *pInData, uint32_t inByteLen,
                                      uint8_t *pOutDigest)
{
    if (pInData == NULL)   return sm3_param_null_err("MULTI-PKG", "in");
    if (pOutDigest == NULL) return sm3_param_null_err("MULTI-PKG", "out");

    if (inByteLen <= SM3_MULTI_PKG_CHUNK)
        return SM3_IP_StreamingHash(pInData, inByteLen, pOutDigest);

    /* 入口统一清FIFO（子包原语内部不清）*/
    SM3_IP->CFG = 0U;
    SM3_IP->CFG = SM3_CFG_IFIFO_STATE_CLEAR;
    for (volatile int i = 0; i < 100; i++);
    SM3_IP->CFG = 0U;
    while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) != 0U)
    {
        volatile uint32_t d = SM3_IP->OFIFO[0];
        (void)d;
    }

    uint8_t iv[SM3_DIGEST_BYTE_LEN];
    uint32_t offset = 0U;
    uint32_t remaining = inByteLen;
    RSP_StatusTypeDef ret;

    ret = SM3_IP_HeadPackage(&pInData[offset], SM3_MULTI_PKG_CHUNK, iv);
    if (ret != RSP_OK) return ret;
    offset    += SM3_MULTI_PKG_CHUNK;
    remaining -= SM3_MULTI_PKG_CHUNK;

    while (remaining > SM3_MULTI_PKG_CHUNK)
    {
        ret = SM3_IP_MidPackage(iv, &pInData[offset], SM3_MULTI_PKG_CHUNK, iv);
        if (ret != RSP_OK) return ret;
        offset    += SM3_MULTI_PKG_CHUNK;
        remaining -= SM3_MULTI_PKG_CHUNK;
    }

    ret = SM3_IP_TailPackage(iv, &pInData[offset], remaining, inByteLen, pOutDigest);
    if (ret != RSP_OK) return ret;

    return RSP_OK;
}

/* ============================================================
 *  方式2：阈值流式模式（软件padding，任意长度，大数据）
 * ============================================================ */
RSP_StatusTypeDef SM3_IP_StreamingHash(const uint8_t *pInData, uint32_t inByteLen,
                                       uint8_t *pOutDigest)
{
    if (pInData == NULL)   return sm3_param_null_err("STREAM", "in");
    if (pOutDigest == NULL) return sm3_param_null_err("STREAM", "out");

    /* 软件padding长度计算 */
    uint32_t last_block = inByteLen % 64U;
    uint32_t pad_total = (last_block < 56U) ? (64U - last_block) : (128U - last_block);
    uint32_t padded_len = inByteLen + pad_total;

    /* 复位 */
    SM3_IP->CFG = 0U;
    SM3_IP->CFG = SM3_CFG_IFIFO_STATE_CLEAR;
    for (volatile int i = 0; i < 100; i++);
    SM3_IP->CFG = 0U;
    while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) != 0U)
    {
        volatile uint32_t d = SM3_IP->OFIFO[0];
        (void)d;
    }

    /* 配置：SM3单整包+软件padding+阈值 */
    uint32_t cfg = SM3_CFG_MODE_SM3 | SM3_CFG_HEADER_ONE_PKG
                 | (SM3_DEFAULT_PROG_FULL_THRESH  << SM3_CFG_IFIFO_PROG_FULL_THRESH_Pos)
                 | (SM3_DEFAULT_PROG_EMPTY_THRESH << SM3_CFG_IFIFO_PROG_EMPTY_THRESH_Pos);
    SM3_IP->CFG = cfg;
    SM3_IP->PKG_LEN   = padded_len;
    SM3_IP->TOTAL_LEN = padded_len;
    SM3_IP->CFG |= SM3_CFG_ENABLE;


    /* CPU路径：流式写 消息+软件padding（数据尾部与0x80拼同一条目）*/
    uint32_t t_start = rsp_hal_get_us();

    uint32_t full = inByteLen / SM3_IFIFO_DATA_WIDTH_BYTE;
    uint32_t rem  = inByteLen % SM3_IFIFO_DATA_WIDTH_BYTE;
    uint32_t total_entries = padded_len / SM3_IFIFO_DATA_WIDTH_BYTE;
    uint32_t blk = 0U;
    uint64_t bit_len = (uint64_t)inByteLen * 8ULL;

    /* 完整16字节数据条目 */
    for (uint32_t i = 0U; i < full; i++)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(&pInData[i * SM3_IFIFO_DATA_WIDTH_BYTE], blk++);
    }

    /* padding条目：首条目含数据尾部+0x80，其余0...0+大端bitlen */
    uint32_t pad_k = 0U;
    for (uint32_t e = full; e < total_entries; e++)
    {
        uint8_t entry[SM3_IFIFO_DATA_WIDTH_BYTE] = {0};
        uint32_t start = 0U;
        if ((e == full) && (rem != 0U))
        {
            memcpy(entry, &pInData[full * SM3_IFIFO_DATA_WIDTH_BYTE], rem);
            start = rem;
        }
        for (uint32_t j = start; (j < SM3_IFIFO_DATA_WIDTH_BYTE) && (pad_k < pad_total); j++, pad_k++)
        {
            if (pad_k == 0U)
                entry[j] = 0x80U;
            else if (pad_k >= pad_total - 8U)
                entry[j] = (uint8_t)(bit_len >> (8U * (pad_total - 1U - pad_k)));
        }
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(entry, blk++);
    }

    RSP_StatusTypeDef ret = SM3_WaitDone();
    if (ret != RSP_OK) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    (void)t_start; /* PERF LOG disabled */

    for (uint32_t b = 0U; b < 2U; b++)
    {
        while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) == 0U);
        SM3_ReadOFIFO_128(&pOutDigest[b * SM3_IFIFO_DATA_WIDTH_BYTE], b);
    }

 


    SM3_IP->CFG &= ~SM3_CFG_ENABLE;
    return RSP_OK;
}

/* ============================================================
 *  HMAC 多包模式 head/mid/tail（与SM3多包对称，MODE=HMAC）
 * ============================================================ */

RSP_StatusTypeDef SM3_IP_HMAC_HeadPackage(const uint8_t *pKey64,
                                           const uint8_t *pMsg, uint32_t msgByteLen,
                                           uint8_t *pOutIV)
{
    if (pKey64 == NULL || pMsg == NULL || pOutIV == NULL)
        return RSP_ERR_NULL_PTR;

    SM3_IP->CFG = SM3_CFG_MODE_HMAC | SM3_CFG_HEADER_HEAD_PKG;
    SM3_IP->PKG_LEN   = msgByteLen;
    SM3_IP->TOTAL_LEN = msgByteLen;
    SM3_IP->CFG |= SM3_CFG_ENABLE;

    /* 写key(64B=4条目) */
    uint32_t blk = 0U;
    for (uint32_t i = 0U; i < 4U; i++)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(&pKey64[i * SM3_IFIFO_DATA_WIDTH_BYTE], blk++);
    }

    /* 写message */
    uint32_t full = msgByteLen / SM3_IFIFO_DATA_WIDTH_BYTE;
    uint32_t rem  = msgByteLen % SM3_IFIFO_DATA_WIDTH_BYTE;
    for (uint32_t i = 0U; i < full; i++)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(&pMsg[i * SM3_IFIFO_DATA_WIDTH_BYTE], blk++);
    }
    if (rem != 0U)
    {
        uint8_t tail[SM3_IFIFO_DATA_WIDTH_BYTE] = {0};
        memcpy(tail, &pMsg[full * SM3_IFIFO_DATA_WIDTH_BYTE], rem);
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(tail, blk);
    }

    RSP_StatusTypeDef ret = SM3_WaitDone();
    if (ret != RSP_OK) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    for (uint32_t b = 0U; b < 2U; b++)
    {
        while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) == 0U);
        SM3_ReadOFIFO_128(&pOutIV[b * SM3_IFIFO_DATA_WIDTH_BYTE], b);
    }

    SM3_IP->CFG &= ~SM3_CFG_ENABLE;
    return RSP_OK;
}

RSP_StatusTypeDef SM3_IP_HMAC_MidPackage(const uint8_t *pIV,
                                          const uint8_t *pMsg, uint32_t msgByteLen,
                                          uint8_t *pOutIV)
{
    if (pIV == NULL || pMsg == NULL || pOutIV == NULL)
        return RSP_ERR_NULL_PTR;

    SM3_IP->CFG = SM3_CFG_MODE_HMAC | SM3_CFG_HEADER_MID_PKG;
    SM3_IP->PKG_LEN   = msgByteLen;
    SM3_IP->TOTAL_LEN = msgByteLen;
    SM3_IP->CFG |= SM3_CFG_ENABLE;

    /* 写IV(32B=2条目) */
    uint32_t blk = 0U;
    while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
    SM3_WriteIFIFO_128(&pIV[0], blk++);
    while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
    SM3_WriteIFIFO_128(&pIV[16], blk++);

    /* 写message */
    uint32_t full = msgByteLen / SM3_IFIFO_DATA_WIDTH_BYTE;
    uint32_t rem  = msgByteLen % SM3_IFIFO_DATA_WIDTH_BYTE;
    for (uint32_t i = 0U; i < full; i++)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(&pMsg[i * SM3_IFIFO_DATA_WIDTH_BYTE], blk++);
    }
    if (rem != 0U)
    {
        uint8_t tail[SM3_IFIFO_DATA_WIDTH_BYTE] = {0};
        memcpy(tail, &pMsg[full * SM3_IFIFO_DATA_WIDTH_BYTE], rem);
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(tail, blk);
    }

    RSP_StatusTypeDef ret = SM3_WaitDone();
    if (ret != RSP_OK) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    for (uint32_t b = 0U; b < 2U; b++)
    {
        while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) == 0U);
        SM3_ReadOFIFO_128(&pOutIV[b * SM3_IFIFO_DATA_WIDTH_BYTE], b);
    }

    SM3_IP->CFG &= ~SM3_CFG_ENABLE;
    return RSP_OK;
}

RSP_StatusTypeDef SM3_IP_HMAC_TailPackage(const uint8_t *pIV,
                                           const uint8_t *pMsg, uint32_t msgByteLen,
                                           uint32_t totalMsgByteLen,
                                           uint8_t *pOutHmac)
{
    if (pIV == NULL || pMsg == NULL || pOutHmac == NULL)
        return RSP_ERR_NULL_PTR;
    if (msgByteLen > SM3_MULTI_PKG_CHUNK)
        return RSP_ERR_INVALID_PARAM;

    /* 软件padding：bitlen=(64+totalMsgByteLen)*8（key是内层哈希输入）*/
    uint8_t pad_buf[SM3_MULTI_PKG_CHUNK + SM3_BLOCK_BYTE_LEN];
    uint64_t bit_len = (uint64_t)(SM3_BLOCK_BYTE_LEN + totalMsgByteLen) * 8ULL;
    uint32_t last_block = totalMsgByteLen % SM3_BLOCK_BYTE_LEN;
    uint32_t pad_total = (last_block < 56U) ? (SM3_BLOCK_BYTE_LEN - last_block)
                                            : (SM3_BLOCK_BYTE_LEN * 2U - last_block);
    uint32_t padded_len = msgByteLen + pad_total;

    memcpy(pad_buf, pMsg, msgByteLen);
    memset(pad_buf + msgByteLen, 0, pad_total);
    pad_buf[msgByteLen] = 0x80U;
    pad_buf[padded_len - 8U + 0] = (uint8_t)(bit_len >> 56);
    pad_buf[padded_len - 8U + 1] = (uint8_t)(bit_len >> 48);
    pad_buf[padded_len - 8U + 2] = (uint8_t)(bit_len >> 40);
    pad_buf[padded_len - 8U + 3] = (uint8_t)(bit_len >> 32);
    pad_buf[padded_len - 8U + 4] = (uint8_t)(bit_len >> 24);
    pad_buf[padded_len - 8U + 5] = (uint8_t)(bit_len >> 16);
    pad_buf[padded_len - 8U + 6] = (uint8_t)(bit_len >> 8);
    pad_buf[padded_len - 8U + 7] = (uint8_t)(bit_len);

    SM3_IP->CFG = SM3_CFG_MODE_HMAC | SM3_CFG_HEADER_TAIL_PKG;
    SM3_IP->PKG_LEN   = padded_len;
    SM3_IP->TOTAL_LEN = padded_len;
    SM3_IP->CFG |= SM3_CFG_ENABLE;

    /* 写IV(32B=2条目) */
    uint32_t blk = 0U;
    while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
    SM3_WriteIFIFO_128(&pIV[0], blk++);
    while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
    SM3_WriteIFIFO_128(&pIV[16], blk++);

    /* 写补齐后的尾段 */
    uint32_t entries = padded_len / SM3_IFIFO_DATA_WIDTH_BYTE;
    for (uint32_t i = 0U; i < entries; i++)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(&pad_buf[i * SM3_IFIFO_DATA_WIDTH_BYTE], blk++);
    }

    RSP_StatusTypeDef ret = SM3_WaitDone();
    if (ret != RSP_OK) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    for (uint32_t b = 0U; b < 2U; b++)
    {
        while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) == 0U);
        SM3_ReadOFIFO_128(&pOutHmac[b * SM3_IFIFO_DATA_WIDTH_BYTE], b);
    }

    SM3_IP->CFG &= ~SM3_CFG_ENABLE;
    return RSP_OK;
}

/**
 * @brief HMAC-SM3 多包入口（大数据，head/mid/tail + IV链接）
 * @note  ≤448字节回退SM3_IP_HMAC_SM3单包；>448拆包，mid用SM3_IP_MidPackage
 *        （HMAC模式MID_PKG会DOEN超时），tail用SM3_IP_TailPackage完成
 *        内层哈希，CPU软件计算外层H(K_opad||inner_result)。
 */
RSP_StatusTypeDef SM3_IP_HMAC_MultiPackage(const uint8_t *pKey, uint32_t keyByteLen,
                                            const uint8_t *pMsg, uint32_t msgByteLen,
                                            uint8_t *pOutHmac)
{
    if (pKey == NULL)     return sm3_param_null_err("HMAC-MULTI-PKG", "key");
    if (pMsg == NULL)     return sm3_param_null_err("HMAC-MULTI-PKG", "msg");
    if (pOutHmac == NULL) return sm3_param_null_err("HMAC-MULTI-PKG", "out");
    if (keyByteLen == 0U)
        return sm3_param_len_err("HMAC-MULTI-PKG", "key", keyByteLen, ">0");

    if (msgByteLen <= SM3_MULTI_PKG_CHUNK)
        return SM3_IP_HMAC_SM3(pKey, keyByteLen, pMsg, msgByteLen, pOutHmac);

    /* 密钥预处理 */
    uint8_t key_buf[SM3_BLOCK_BYTE_LEN] = {0};
    RSP_StatusTypeDef ret;
    if (keyByteLen > SM3_BLOCK_BYTE_LEN)
    {
        ret = SM3_IP_StreamingHash(pKey, keyByteLen, key_buf);
        if (ret != RSP_OK) return ret;
    }
    else
    {
        memcpy(key_buf, pKey, keyByteLen);
    }

    /* 入口清FIFO */
    SM3_IP->CFG = 0U;
    SM3_IP->CFG = SM3_CFG_IFIFO_STATE_CLEAR;
    for (volatile int i = 0; i < 100; i++);
    SM3_IP->CFG = 0U;
    while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) != 0U)
    {
        volatile uint32_t d = SM3_IP->OFIFO[0];
        (void)d;
    }

    uint8_t iv[SM3_DIGEST_BYTE_LEN];
    uint32_t offset = 0U;
    uint32_t remaining = msgByteLen;

    ret = SM3_IP_HMAC_HeadPackage(key_buf, &pMsg[offset], SM3_MULTI_PKG_CHUNK, iv);
    if (ret != RSP_OK) return ret;
    offset    += SM3_MULTI_PKG_CHUNK;
    remaining -= SM3_MULTI_PKG_CHUNK;

    while (remaining > SM3_MULTI_PKG_CHUNK)
    {
        ret = SM3_IP_MidPackage(iv, &pMsg[offset], SM3_MULTI_PKG_CHUNK, iv);
        if (ret != RSP_OK) return ret;
        offset    += SM3_MULTI_PKG_CHUNK;
        remaining -= SM3_MULTI_PKG_CHUNK;
    }

    /* tail用SM3_IP_TailPackage(MODE=SM3)只完成内层哈希 */
    uint8_t inner_result[SM3_DIGEST_BYTE_LEN];
    ret = SM3_IP_TailPackage(iv, &pMsg[offset], remaining,
                             SM3_BLOCK_BYTE_LEN + msgByteLen, inner_result);
    if (ret != RSP_OK) return ret;

    /* 软件计算外层哈希：HMAC = H(K_opad || inner_result) */
    uint8_t outer_input[SM3_BLOCK_BYTE_LEN + SM3_DIGEST_BYTE_LEN];
    for (uint32_t i = 0U; i < SM3_BLOCK_BYTE_LEN; i++)
        outer_input[i] = key_buf[i] ^ 0x5cU;
    memcpy(outer_input + SM3_BLOCK_BYTE_LEN, inner_result, SM3_DIGEST_BYTE_LEN);

    ret = SM3_IP_StreamingHash(outer_input,
                               SM3_BLOCK_BYTE_LEN + SM3_DIGEST_BYTE_LEN,
                               pOutHmac);
    return ret;
}

/* ============================================================
 *  性能测试函数（全内联，硬件padding，64整数倍输入）
 * ============================================================ */
RSP_StatusTypeDef SM3_IP_PerfHash(const uint8_t *pInData, uint32_t inByteLen,
                                  uint8_t *pOutDigest)
{
    if (pInData == NULL)   return sm3_param_null_err("HASH", "in");
    if (pOutDigest == NULL) return sm3_param_null_err("HASH", "out");

    /* 复位 */
    SM3_IP->CFG = 0U;
    SM3_IP->CFG = SM3_CFG_IFIFO_STATE_CLEAR;
    for (volatile int i = 0; i < 100; i++);
    SM3_IP->CFG = 0U;
    while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) != 0U)
    {
        volatile uint32_t d = SM3_IP->OFIFO[0];
        (void)d;
    }

    /* 配置：硬件padding */
    SM3_IP->CFG = SM3_CFG_MODE_SM3 | SM3_CFG_HEADER_ONE_PKG | SM3_CFG_PADDING_HARD
                 | (SM3_DEFAULT_PROG_FULL_THRESH  << SM3_CFG_IFIFO_PROG_FULL_THRESH_Pos)
                 | (SM3_DEFAULT_PROG_EMPTY_THRESH << SM3_CFG_IFIFO_PROG_EMPTY_THRESH_Pos);
    SM3_IP->PKG_LEN   = inByteLen;
    SM3_IP->TOTAL_LEN = inByteLen;
    SM3_IP->CFG |= SM3_CFG_ENABLE;

    /* 写IFIFO：原始数据，尾部补0 */
    uint32_t full = inByteLen / SM3_IFIFO_DATA_WIDTH_BYTE;
    uint32_t rem  = inByteLen % SM3_IFIFO_DATA_WIDTH_BYTE;
    uint32_t blk = 0U;
    const uint32_t *kkk = (const uint32_t *)pInData;
    volatile uint32_t *ififo_base = &SM3_IP->IFIFO[0];

   
#if 1
 uint32_t t_start = rsp_hal_get_us();
    for (uint32_t i = 0U; i < full * 4U; i += 4U)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        uint32_t idx = (blk % SM3_IFIFO_DEPTH) * 4U;
        ififo_base[idx + 0] = kkk[i];
        ififo_base[idx + 1] = kkk[i + 1];
        ififo_base[idx + 2] = kkk[i + 2];
        ififo_base[idx + 3] = kkk[i + 3];

        blk++;
    }
    if (rem != 0U)
    {
        uint8_t tail[SM3_IFIFO_DATA_WIDTH_BYTE] = {0};
        memcpy(tail, &pInData[full * SM3_IFIFO_DATA_WIDTH_BYTE], rem);
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        uint32_t *tw = (uint32_t *)tail;
        uint32_t idx = (blk % SM3_IFIFO_DEPTH) * 4U;
        ififo_base[idx + 0] = tw[0];
        ififo_base[idx + 1] = tw[1];
        ififo_base[idx + 2] = tw[2];
        ififo_base[idx + 3] = tw[3];
    }

    while ((SM3_IP->STATE & SM3_STATE_DOEN) == 0U);

    volatile uint32_t *ofifo_base = &SM3_IP->OFIFO[0];
    uint32_t *outw = (uint32_t *)pOutDigest;
    for (uint32_t b = 0U; b < 2U; b++)
    {
        while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) == 0U);
        uint32_t idx = b * 4U;
        outw[b * 4 + 0] = ofifo_base[idx + 0];
        outw[b * 4 + 1] = ofifo_base[idx + 1];
        outw[b * 4 + 2] = ofifo_base[idx + 2];
        outw[b * 4 + 3] = ofifo_base[idx + 3];
    }

    SM3_IP->CFG &= ~SM3_CFG_ENABLE;
    (void)t_start; /* PERF LOG disabled */
#else 
     /* DMA路径：软件padding后分块DMA写IFIFO */
    rsp_dma_transmit_t ctx;
    RSP_StatusTypeDef ret = rsp_hal_dma_init(&ctx, 0, TT_M2M_DFC, DWIDTH_32, DWIDTH_32,
                            MSIZE_4, ADDR_INC, ADDR_INC, HANDSHANKE_SOFT, HANDSHANKE_SOFT,
                            DMAC_REQ_DEFAULT, DMAC_REQ_DEFAULT);
    if (ret != 0) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    uint32_t data_buf[SM3_TEST_MSG_LEN] = {0};
    uint32_t dma_len = 0U;
  //  SM3_SoftPadding(pInData, inByteLen, (uint8_t *)data_buf, &dma_len);

    uint32_t t_start = rsp_hal_get_us();
    /* 每次DMA传128B(8条目), 发送前轮询IFIFO_WR_CNT确保有足够空闲条目,
     * 避免DMA不感知FIFO满导致丢数 (memory教训) */
    const uint8_t *p = pInData;
    uint32_t remaining = SM3_TEST_MSG_LEN;
    while (remaining > 0U)
    {
        uint32_t chunk = (remaining >= 128U) ? 128U : remaining;
        uint32_t need  = (chunk + 15U) / 16U;
        while (((SM3_IP->STATE & SM3_STATE_IFIFO_WR_CNT_Msk) >> SM3_STATE_IFIFO_WR_CNT_Pos)
               > (SM3_IFIFO_DEPTH - need));
        dma_transfer_t transfers[] = {
            {(uint32_t)p, SM3_IP_IFIFO_BASE, chunk},
        };
        ret = dma_transfer_batch(&ctx, transfers, sizeof(transfers) / sizeof(transfers[0]));
        if (ret != 0)
        {
            printf("DMA transfer failed\n");
            return ret;
        }
        p += chunk;
        remaining -= chunk;
    }
    // if (dret != 0) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return RSP_ERR_TIMEOUT; }

    ret = SM3_WaitDone();
    if (ret != RSP_OK) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) == 0U);
    uint32_t ss_buf[8];
    ret = rsp_hal_dma_read(&ctx, SM3_IP_OFIFO_BASE, (uint32_t)ss_buf, SM3_DIGEST_BYTE_LEN);
    if (ret != 0) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    uint32_t t_end = rsp_hal_get_us();
    uint32_t us = (t_end >= t_start) ? (t_end - t_start) : 1U;
    uint32_t mbps = (uint32_t)(((uint64_t)inByteLen * 8ULL) / us);
    uint32_t mbs  = (uint32_t)((uint64_t)inByteLen / us);
    /* 性能打印已屏蔽 */
    (void)us; (void)mbps; (void)mbs;

    memcpy(pOutDigest, ss_buf, SM3_DIGEST_BYTE_LEN);


#endif
    return RSP_OK;
}

/* ============================================================
 *  HMAC性能测试函数（硬件padding, 任意message长度）
 *  与SM3_IP_HMAC_SM3功能等价但加性能统计; 长度只算message不含key.
 *  HMAC硬件padding对任意message长度都正确(message从64B边界开始,
 *  与SM3单算模式不同, 无需软件padding).
 * ============================================================ */
RSP_StatusTypeDef SM3_IP_PerfHMAC(const uint8_t *pKey, uint32_t keyByteLen,
                                  const uint8_t *pMsg, uint32_t msgByteLen,
                                  uint8_t *pOutHmac)
{
    if (pKey == NULL)     return sm3_param_null_err("HMAC", "key");
    if (pMsg == NULL)     return sm3_param_null_err("HMAC", "msg");
    if (pOutHmac == NULL) return sm3_param_null_err("HMAC", "out");
    if (keyByteLen == 0U)
        return sm3_param_len_err("HMAC", "key", keyByteLen, ">0");

    /* 密钥预处理: key>64先K=SM3(key)再补0, key<=64直接补0 */
    uint8_t key_buf[SM3_BLOCK_BYTE_LEN] = {0};
    if (keyByteLen > SM3_BLOCK_BYTE_LEN)
    {
        RSP_StatusTypeDef ret = SM3_IP_StreamingHash(pKey, keyByteLen, key_buf);
        if (ret != RSP_OK) return ret;
    }
    else
    {
        memcpy(key_buf, pKey, keyByteLen);
    }

    /* 复位 */
    SM3_IP->CFG = 0U;
    SM3_IP->CFG = SM3_CFG_IFIFO_STATE_CLEAR;
    for (volatile int i = 0; i < 100; i++);
    SM3_IP->CFG = 0U;
    while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) != 0U)
    {
        volatile uint32_t d = SM3_IP->OFIFO[0];
        (void)d;
    }

    /* 配置: HMAC整包+硬件padding+阈值; PKG_LEN/TOTAL_LEN只填message长度 */
    SM3_IP->CFG = SM3_CFG_MODE_HMAC | SM3_CFG_HEADER_ONE_PKG | SM3_CFG_PADDING_HARD
                 | (SM3_DEFAULT_PROG_FULL_THRESH  << SM3_CFG_IFIFO_PROG_FULL_THRESH_Pos)
                 | (SM3_DEFAULT_PROG_EMPTY_THRESH << SM3_CFG_IFIFO_PROG_EMPTY_THRESH_Pos);
    SM3_IP->PKG_LEN   = msgByteLen;
    SM3_IP->TOTAL_LEN = msgByteLen;
    SM3_IP->CFG |= SM3_CFG_ENABLE;
#if 1
    uint32_t t_start = rsp_hal_get_us();

    /* 写IFIFO: key(4×16B) + message(N×16B + 尾部补0) */
    uint32_t blk = 0U;
    for (uint32_t i = 0U; i < 4U; i++)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(&key_buf[i * SM3_IFIFO_DATA_WIDTH_BYTE], blk++);
    }
    uint32_t full = msgByteLen / SM3_IFIFO_DATA_WIDTH_BYTE;
    for (uint32_t i = 0U; i < full; i++)
    {
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(&pMsg[i * SM3_IFIFO_DATA_WIDTH_BYTE], blk++);
    }
    uint32_t rem = msgByteLen % SM3_IFIFO_DATA_WIDTH_BYTE;
    if (rem != 0U)
    {
        uint8_t tail[SM3_IFIFO_DATA_WIDTH_BYTE] = {0};
        memcpy(tail, &pMsg[full * SM3_IFIFO_DATA_WIDTH_BYTE], rem);
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(tail, blk);
    }

    while ((SM3_IP->STATE & SM3_STATE_DOEN) == 0U);

    /* 读OFIFO: 2×16B=32B摘要 */
    for (uint32_t b = 0U; b < 2U; b++)
    {
        while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) == 0U);
        SM3_ReadOFIFO_128(&pOutHmac[b * SM3_IFIFO_DATA_WIDTH_BYTE], b);
    }

    SM3_IP->CFG &= ~SM3_CFG_ENABLE;
    (void)t_start; /* PERF LOG disabled */
#else
    /* DMA路径：key(64B) + message(完整16B块) 分块DMA写IFIFO,
     * 尾部不足16B用CPU补零写, 摘要用DMA读OFIFO */
    rsp_dma_transmit_t ctx;
    RSP_StatusTypeDef ret = rsp_hal_dma_init(&ctx, 0, TT_M2M_DFC, DWIDTH_32, DWIDTH_32,
                            MSIZE_4, ADDR_INC, ADDR_INC, HANDSHANKE_SOFT, HANDSHANKE_SOFT,
                            DMAC_REQ_DEFAULT, DMAC_REQ_DEFAULT);
    if (ret != 0) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    uint32_t t_start = rsp_hal_get_us();

    /* 1. key 64B = 4条目, 拷到uint32_t缓冲区保证DMA源地址4字节对齐 */
    uint32_t key_dma[SM3_BLOCK_BYTE_LEN / 4U] = {0};
    memcpy(key_dma, key_buf, SM3_BLOCK_BYTE_LEN);
    int dret = SM3_DMA_WriteIFIFO(&ctx, (const uint8_t *)key_dma, SM3_BLOCK_BYTE_LEN);
    if (dret != 0) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return RSP_ERR_TIMEOUT; }

    /* 2. message完整16B块DMA写入 (内部64B分块+IFIFO_WR_CNT反压) */
    uint32_t full_len = msgByteLen & ~(uint32_t)(SM3_IFIFO_DATA_WIDTH_BYTE - 1U);
    if (full_len > 0U)
    {
        dret = SM3_DMA_WriteIFIFO(&ctx, pMsg, full_len);
        if (dret != 0) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return RSP_ERR_TIMEOUT; }
    }

    /* 3. 尾部不足16B: CPU补零写最后一个条目 (DMA要求16B对齐长度) */
    if (msgByteLen != full_len)
    {
        uint8_t tail[SM3_IFIFO_DATA_WIDTH_BYTE] = {0};
        uint32_t blk = 4U + (full_len / SM3_IFIFO_DATA_WIDTH_BYTE);
        memcpy(tail, &pMsg[full_len], msgByteLen - full_len);
        while ((SM3_IP->STATE & SM3_STATE_IFIFO_FULL) != 0U);
        SM3_WriteIFIFO_128(tail, blk);
    }

    /* 4. 等待算核完成 */
    ret = SM3_WaitDone();
    if (ret != RSP_OK) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }

    /* 5. DMA读OFIFO 32B摘要 */
    while ((SM3_IP->STATE & SM3_STATE_OFIFO_EMPTY_N) == 0U);
    uint32_t ss_buf[SM3_DIGEST_BYTE_LEN / 4U];
    ret = rsp_hal_dma_read(&ctx, SM3_IP_OFIFO_BASE, (uint32_t)ss_buf, SM3_DIGEST_BYTE_LEN);
    if (ret != 0) { SM3_IP->CFG &= ~SM3_CFG_ENABLE; return ret; }
    memcpy(pOutHmac, ss_buf, SM3_DIGEST_BYTE_LEN);

    SM3_IP->CFG &= ~SM3_CFG_ENABLE;
    uint32_t t_end = rsp_hal_get_us();
    uint32_t us = (t_end >= t_start) ? (t_end - t_start) : 1U;
    uint32_t mbps = (uint32_t)(((uint64_t)msgByteLen * 8ULL) / us);
    uint32_t mbs  = (uint32_t)((uint64_t)msgByteLen / us);
    /* 性能打印已屏蔽 */
    (void)us; (void)mbps; (void)mbs;
#endif
    return RSP_OK;
}

