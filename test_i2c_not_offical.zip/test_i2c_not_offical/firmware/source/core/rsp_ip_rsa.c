/**
 * @file rsp_ip_rsa.c
 * @brief RSA2048 硬件 IP 驱动实现 (基址 0x80070000)
 *
 *  所有 9 种模式共用统一内部入口 rsa_ip_run().
 *  高层 API 负责: 参数校验 -> 连续 IFIFO buffer 组装 (memcpy)
 *  -> CFG/PKG_LEN 计算 -> 调 rsa_ip_run.
 *
 *  IFIFO 深度 8 × 128bit = 128B, OFIFO 深度 2 × 128bit = 32B.
 *  所有有效配置 IFIFO 总字节数 > 128B, 必须用 PROG_FULL=7 / PROG_EMPTY=1
 *  反压流式写, 不能 ENABLE 后直接灌满.
 *
 *  各模式最大头部 (含 msg_len=256B):
 *    sign2048_CRT_pass = 896 + 256 = 1152B. 栈上分配 ififo_buf[1600] 足够.
 */

#include "rsp_ip_rsa.h"
#include <stdio.h>
#include <string.h>

/* ---- 参数校验错误打印 (与 rsp_ip_sm4.c 风格一致) ---- */
static RSP_StatusTypeDef rsa_param_null_err(const char *algo, const char *param)
{
    printf("[RSA %s] %s_null_err\n", algo, param);
    return RSP_ERR_NULL_PTR;
}

/* ============================================================
 *  核心内联辅助
 * ============================================================ */

static inline void RSA_WriteIFIFO_128(const uint8_t *p)
{
    const uint32_t *w = (const uint32_t *)p;
    RSA_IP->IFIFO[0] = w[0];
    RSA_IP->IFIFO[1] = w[1];
    RSA_IP->IFIFO[2] = w[2];
    RSA_IP->IFIFO[3] = w[3];
}

/* 读一个 32bit OFIFO 字 (实测: 每次 32bit 读取走 1 个字) */
static inline uint32_t rsa_pop_word(void)
{
    return RSA_IP->OFIFO[0];
}

/* 按小端字节序把一个 32bit 字写入 out (未做最终字节序调整) */
static inline void rsa_store_word(uint8_t *p, uint32_t w)
{
    p[0] = (uint8_t)(w);
    p[1] = (uint8_t)(w >> 8U);
    p[2] = (uint8_t)(w >> 16U);
    p[3] = (uint8_t)(w >> 24U);
}

/* 写一个 16B 输入块; 最后一块不足 16B 时补 0 */
static void rsa_push_blk(uint32_t idx, uint32_t total_len,
                         const uint8_t *src, uint8_t *pad)
{
    uint32_t rem;

    if (idx * RSA2048_BLOCK_BYTES + RSA2048_BLOCK_BYTES > total_len)
    {
        rem = total_len - idx * RSA2048_BLOCK_BYTES;
        memcpy(pad, src + idx * RSA2048_BLOCK_BYTES, rem);
        memset(pad + rem, 0, RSA2048_BLOCK_BYTES - rem);
        RSA_WriteIFIFO_128(pad);
    }
    else
    {
        RSA_WriteIFIFO_128(src + idx * RSA2048_BLOCK_BYTES);
    }
}

/* ============================================================
 *  IP 复位
 * ============================================================ */

static void rsa_ip_reset(void)
{
    volatile uint32_t *base = (volatile uint32_t *)RSA_IP_BASE;

    base[0x04 / 4] = 0U;   /* INTR     */
    base[0x08 / 4] = 0U;   /* PKG_LEN  */
    base[0x0C / 4] = 0U;   /* CFG      */

    /* FIFO 状态复位: INTR@0x04 bit1 (W1SC) */
    base[0x04 / 4] = RSA_INTR_FIFO_STATE_CLEAR;
    for (volatile int d = 0; d < 2000; d++);
    base[0x04 / 4] = 0U;

    /* 软清空 OFIFO 残留: OFIFO 深度 2, 读两次 base 地址即可 */
    volatile uint32_t *of = (volatile uint32_t *)(RSA_IP_BASE + 0x90);
    (void)of[0]; (void)of[1]; (void)of[2]; (void)of[3];
    (void)of[0]; (void)of[1]; (void)of[2]; (void)of[3];
}

/* ============================================================
 *  统一 IP 运行入口
 *
 *  参数:
 *    cfg_val    - CFG 值 (不含 ENABLE bit, 调用者不设 bit0)
 *    ififo_data - 连续字节序列 (头部 + msg, 按 rsa.xlsx 顺序)
 *    total_len  - IFIFO 总字节数 (= PKG_LEN)
 *    out_len    - 期望输出字节数 (256B / 128B)
 *    out        - 输出缓冲区, 至少 out_len 字节
 *  返回:
 *    RSP_OK / RSP_ERR_FIFO / RSP_ERR_TIMEOUT
 * ============================================================ */

/* 按小端顺序拷贝一个操作数: dst[0] = src[len-1] (len 必须是 16 的整数倍) */
static void put_rev(uint8_t *dst, const uint8_t *src, uint32_t len);

/* 原地字节反转 */
static void rev_bytes(uint8_t *p, uint32_t len);

static RSP_StatusTypeDef rsa_ip_run(uint32_t cfg_val,
                                     const uint8_t *ififo_data,
                                     uint32_t total_len,
                                     uint32_t out_len,
                                     uint8_t *out)
{
    uint32_t timeout;
    uint32_t total_blks = (total_len + RSA2048_BLOCK_BYTES - 1U) / RSA2048_BLOCK_BYTES;
    uint32_t word_cnt = out_len / 4U;
    uint32_t i, rd = 0U, kicks = 0U, okicks = 0U, nz = 0U;
    uint8_t  last_pad[RSA2048_BLOCK_BYTES];

    rsa_ip_reset();

    RSA_IP->CFG = cfg_val | RSA_CFG_MODE_2048;
    RSA_IP->PKG_LEN = total_len;

    /* 启动算核 (写 1 自清). 实测该位流: 先把 IFIFO 灌满 8 条再 ENABLE,
     * 算核完全不消费 (STATE=0x8A5: IFIFO_FULL=1, IFIFO_CNT=8 恒定);
     * 必须先 ENABLE, 再灌数据.
     * 若 ENABLE 脉冲在跨时钟域丢失, 灌满后仍不消费时再补踢一次. */
    RSA_IP->CFG = cfg_val | RSA_CFG_MODE_2048 | RSA_CFG_ENABLE;

    /* 逐块灌入: FIFO 满则等算核取走.
     * 算核要等全部操作数收齐才开始计算, 灌数据期间不会产出, 所以这里不读 OFIFO. */
    for (i = 0U; i < total_blks; i++)
    {
        timeout = RSA_POLL_TIMEOUT;
        while ((RSA_IP->STATE & RSA_STATE_IFIFO_FULL) != 0U)
        {
            if (--timeout == 0U)
            {
                if (kicks < 2U)
                {
                    kicks++;
                    RSA_IP->CFG = cfg_val | RSA_CFG_MODE_2048 | RSA_CFG_ENABLE;
                    timeout = RSA_POLL_TIMEOUT;
                    continue;
                }
                return RSP_ERR_FIFO;
            }
        }
        rsa_push_blk(i, total_len, ififo_data, last_pad);
    }

    /* 收全部输出.
     * 实测三条硬约束:
     *  1) OFIFO 每读一个 32bit 字就弹出一个字 (不是按 128bit 条目弹),
     *     所以按字读、按字存.
     *  2) 算核未产出时 OFIFO_EMPTY 会虚假地报"非空", 读到的都是 0.
     *     因此不能"标志为 0 就读", 也不能靠"第一个非零字"找起点
     *     (结果首字本身可能为 0).
     *  3) IFIFO_EMPTY 是可靠的: 它置 1 表示输入已被算核全部取走, 之后
     *     再 settle 一小段即可确保结果已推进 OFIFO, 然后按 word_cnt 逐字直读.
     *     若整段读回全 0, 说明算核没有产出, 按超时处理. */
    {
        uint32_t budget = RSA_OUT_WAIT;
        uint32_t settle;

        while ((RSA_IP->STATE & RSA_STATE_IFIFO_EMPTY) == 0U)
        {
            if (--budget == 0U) return RSP_ERR_TIMEOUT;
        }
        for (settle = 0U; settle < RSA_SETTLE; settle++)
        {
            (void)RSA_IP->STATE;
        }
    }

    for (; rd < word_cnt; rd++)
    {
        if (okicks == 0U)
        {
            /* 最后一个 128bit 条目不完整时, OFIFO_EMPTY 会一直保持"空",
             * 但数据其实已在 FIFO 内; 实测补发一次 ENABLE 并等待一小段后,
             * 剩余字即可直接读出, 且内容仍是原结果 (不是重新计算). */
            uint32_t last_entry = (rd + RSA_OFIFO_DEPTH * 4U >= word_cnt) ? 1U : 0U;

            timeout = last_entry ? RSA_TAIL_WAIT : RSA_OUT_WAIT;
            while ((RSA_IP->STATE & RSA_STATE_OFIFO_EMPTY) != 0U)
            {
                if (--timeout == 0U)
                {
                    if (last_entry != 0U)
                    {
                        uint32_t settle;

                        okicks = 1U;
                        RSA_IP->CFG = cfg_val | RSA_CFG_MODE_2048 | RSA_CFG_ENABLE;
                        for (settle = 0U; settle < RSA_TAIL_WAIT; settle++)
                        {
                            (void)RSA_IP->STATE;
                        }
                        break;          /* 补踢后不再看空标志, 直接读剩余字 */
                    }
                    return RSP_ERR_TIMEOUT;
                }
            }
        }
        rsa_store_word(out + rd * 4U, rsa_pop_word());
    }

    /* 全 0 不可能是真实结果, 说明算核没有产出 (读的是空 FIFO 全 0) */
    for (i = 0U; i < out_len; i++) nz |= out[i];
    if (nz == 0U) return RSP_ERR_TIMEOUT;

    /* 实测: 硬件按小端(LSB 先)逐字输出, 即 out 是结果整体反转后的字节流,
     * 这里整体反转回大端 */
    rev_bytes(out, out_len);

    return RSP_OK;
}

/* 按小端顺序拷贝一个操作数: dst[0] = src[len-1] (len 必须是 16 的整数倍) */
static void put_rev(uint8_t *dst, const uint8_t *src, uint32_t len)
{
    uint32_t i;
    for (i = 0U; i < len; i++) dst[i] = src[len - 1U - i];
}

/* 原地字节反转 */
static void rev_bytes(uint8_t *p, uint32_t len)
{
    uint32_t i;
    uint8_t  t;
    for (i = 0U; i < len / 2U; i++)
    {
        t = p[i];
        p[i] = p[len - 1U - i];
        p[len - 1U - i] = t;
    }
}

/* ============================================================
 *  公共 API 实现
 *
 *  每个 API: 参数校验 -> 栈上 ififo_buf 连续拼接头部 + msg
 *  -> rsa_ip_run
 *
 *  ififo_buf[1600] 覆盖最大模式: sign2048_CRT_pass + msg_len=256
 *  = 896 + 256 = 1152B. 预留到 1600B 方便以后加大 msg_len.
 * ============================================================ */

RSP_StatusTypeDef rsa2048_sign_hw(const uint8_t *n_256, const uint8_t *d_256,
                                  const uint8_t *msg_256, uint8_t *sig_out)
{
    uint8_t ififo_buf[1600];
    uint32_t off = 0U;

    /* ---- 参数校验 ---- */
    if (n_256 == NULL)   return rsa_param_null_err("SIGN", "n_256");
    if (d_256 == NULL)   return rsa_param_null_err("SIGN", "d_256");
    if (msg_256 == NULL) return rsa_param_null_err("SIGN", "msg_256");
    if (sig_out == NULL) return rsa_param_null_err("SIGN", "sig_out");

    put_rev(ififo_buf + off, n_256, 256U); off += 256;
    put_rev(ififo_buf + off, d_256, 256U); off += 256;
    put_rev(ififo_buf + off, msg_256, 256U); off += 256;

    return rsa_ip_run(RSA_CFG_SIGN_EN, ififo_buf, off, 256U, sig_out);
}

RSP_StatusTypeDef rsa2048_sign_crt_hw(const uint8_t *dp_128, const uint8_t *dq_128,
                                      const uint8_t *p_128, const uint8_t *q_128,
                                      const uint8_t *qinv_128, const uint8_t *msg_256,
                                      uint8_t *sig_out)
{
    uint8_t ififo_buf[1600];
    uint32_t off = 0U;

    /* ---- 参数校验 ---- */
    if (dp_128 == NULL)   return rsa_param_null_err("SIGN_CRT", "dp_128");
    if (dq_128 == NULL)   return rsa_param_null_err("SIGN_CRT", "dq_128");
    if (p_128 == NULL)    return rsa_param_null_err("SIGN_CRT", "p_128");
    if (q_128 == NULL)    return rsa_param_null_err("SIGN_CRT", "q_128");
    if (qinv_128 == NULL) return rsa_param_null_err("SIGN_CRT", "qinv_128");
    if (msg_256 == NULL)  return rsa_param_null_err("SIGN_CRT", "msg_256");
    if (sig_out == NULL)  return rsa_param_null_err("SIGN_CRT", "sig_out");

    put_rev(ififo_buf + off, dp_128, 128U); off += 128;
    put_rev(ififo_buf + off, dq_128, 128U); off += 128;
    put_rev(ififo_buf + off, p_128, 128U); off += 128;
    put_rev(ififo_buf + off, q_128, 128U); off += 128;
    put_rev(ififo_buf + off, qinv_128, 128U); off += 128;
    put_rev(ififo_buf + off, msg_256, 256U); off += 256;

    return rsa_ip_run(RSA_CFG_SIGN_EN | RSA_CFG_CRT_EN, ififo_buf, off, 256U, sig_out);
}

RSP_StatusTypeDef rsa2048_verify_hw(const uint8_t *e_256, const uint8_t *n_256,
                                    const uint8_t *msg_256, uint8_t *m_out)
{
    uint8_t ififo_buf[1600];
    uint32_t off = 0U;

    /* ---- 参数校验 ---- */
    if (e_256 == NULL)   return rsa_param_null_err("VERIFY", "e_256");
    if (n_256 == NULL)   return rsa_param_null_err("VERIFY", "n_256");
    if (msg_256 == NULL) return rsa_param_null_err("VERIFY", "msg_256");
    if (m_out == NULL)   return rsa_param_null_err("VERIFY", "m_out");

    /* 实测: 算核第 1 个操作数固定是模数 (与 Sign2048 的 N,d,msg 同一数据通路),
     * 所以验签必须 N 在前、e 在后; 若按 xlsx 列举顺序传 e,N,
     * 算核会以 e=65537 为模数, 输出只剩 1 个 32bit 字 (0x6334, 无效运算). */
    put_rev(ififo_buf + off, n_256, 256U); off += 256;
    put_rev(ififo_buf + off, e_256, 256U); off += 256;
    put_rev(ififo_buf + off, msg_256, 256U); off += 256;

    return rsa_ip_run(0U, ififo_buf, off, 256U, m_out);
}

/* ---------- Sign2048_pkcs ---------- */
RSP_StatusTypeDef rsa2048_sign_pkcs_hw(const uint8_t *n_256, const uint8_t *d_256,
                                       const uint8_t *msg, uint32_t msg_len,
                                       uint8_t *sig_out)
{
    uint8_t ififo_buf[1600];
    uint32_t off = 0U;

    if (!n_256 || !d_256 || !msg || !sig_out) return RSP_ERR_NULL_PTR;

    put_rev(ififo_buf + off, n_256, 256U); off += 256;
    put_rev(ififo_buf + off, d_256, 256U); off += 256;
    memcpy(ififo_buf + off, msg,     msg_len); off += msg_len;

    return rsa_ip_run(RSA_CFG_SIGN_EN | RSA_CFG_PADDING_EN, ififo_buf, off, 256U, sig_out);
}

/* ---------- sign2048_CRT_pkcs ---------- */
RSP_StatusTypeDef rsa2048_sign_crt_pkcs_hw(const uint8_t *dp_128, const uint8_t *dq_128,
                                            const uint8_t *p_128, const uint8_t *q_128,
                                            const uint8_t *qinv_128,
                                            const uint8_t *msg, uint32_t msg_len,
                                            uint8_t *sig_out)
{
    uint8_t ififo_buf[1600];
    uint32_t off = 0U;

    if (!dp_128 || !dq_128 || !p_128 || !q_128 || !qinv_128 || !msg || !sig_out)
        return RSP_ERR_NULL_PTR;

    put_rev(ififo_buf + off, dp_128, 128U); off += 128;
    put_rev(ififo_buf + off, dq_128, 128U); off += 128;
    put_rev(ififo_buf + off, p_128, 128U); off += 128;
    put_rev(ififo_buf + off, q_128, 128U); off += 128;
    put_rev(ififo_buf + off, qinv_128, 128U); off += 128;
    memcpy(ififo_buf + off, msg,       msg_len); off += msg_len;

    return rsa_ip_run(RSA_CFG_SIGN_EN | RSA_CFG_CRT_EN | RSA_CFG_PADDING_EN,
                      ififo_buf, off, 256U, sig_out);
}

/* ---------- Sign2048_pass ---------- */
RSP_StatusTypeDef rsa2048_sign_pass_hw(const uint8_t *n_256, const uint8_t *d_256,
                                        const uint8_t *s_256,
                                        const uint8_t *msg, uint32_t msg_len,
                                        uint8_t *sig_out)
{
    uint8_t ififo_buf[1600];
    uint32_t off = 0U;

    if (!n_256 || !d_256 || !s_256 || !msg || !sig_out) return RSP_ERR_NULL_PTR;

    put_rev(ififo_buf + off, n_256, 256U); off += 256;
    put_rev(ififo_buf + off, d_256, 256U); off += 256;
    put_rev(ififo_buf + off, s_256, 256U); off += 256;
    memcpy(ififo_buf + off, msg,     msg_len); off += msg_len;

    return rsa_ip_run(RSA_CFG_SIGN_EN | RSA_CFG_PADDING_EN | RSA_CFG_PADDING_MODE,
                      ififo_buf, off, 256U, sig_out);
}

/* ---------- Sign2048_CRT_pass ---------- */
RSP_StatusTypeDef rsa2048_sign_crt_pass_hw(const uint8_t *dp_128, const uint8_t *dq_128,
                                            const uint8_t *p_128, const uint8_t *q_128,
                                            const uint8_t *qinv_128,
                                            const uint8_t *s_256,
                                            const uint8_t *msg, uint32_t msg_len,
                                            uint8_t *sig_out)
{
    uint8_t ififo_buf[1600];
    uint32_t off = 0U;

    if (!dp_128 || !dq_128 || !p_128 || !q_128 || !qinv_128 || !s_256 || !msg || !sig_out)
        return RSP_ERR_NULL_PTR;

    put_rev(ififo_buf + off, dp_128, 128U); off += 128;
    put_rev(ififo_buf + off, dq_128, 128U); off += 128;
    put_rev(ififo_buf + off, p_128, 128U); off += 128;
    put_rev(ififo_buf + off, q_128, 128U); off += 128;
    put_rev(ififo_buf + off, qinv_128, 128U); off += 128;
    put_rev(ififo_buf + off, s_256, 256U); off += 256;
    memcpy(ififo_buf + off, msg,      msg_len); off += msg_len;

    return rsa_ip_run(RSA_CFG_SIGN_EN | RSA_CFG_CRT_EN |
                      RSA_CFG_PADDING_EN | RSA_CFG_PADDING_MODE,
                      ififo_buf, off, 256U, sig_out);
}

/* ---------- verify2048_pkcs ---------- */
RSP_StatusTypeDef rsa2048_verify_pkcs_hw(const uint8_t *e_256, const uint8_t *n_256,
                                         const uint8_t *msg, uint32_t msg_len,
                                         uint8_t *result_128)
{
    uint8_t ififo_buf[1600];
    uint32_t off = 0U;

    if (!e_256 || !n_256 || !msg || !result_128) return RSP_ERR_NULL_PTR;

    /* 同 verify2048: 模数 N 在第一个槽位 */
    put_rev(ififo_buf + off, n_256, 256U); off += 256;
    put_rev(ififo_buf + off, e_256, 256U); off += 256;
    memcpy(ififo_buf + off, msg,     msg_len); off += msg_len;

    return rsa_ip_run(RSA_CFG_PADDING_EN, ififo_buf, off, 128U, result_128);
}

/* ---------- verify2048_pass ---------- */
RSP_StatusTypeDef rsa2048_verify_pass_hw(const uint8_t *e_256, const uint8_t *n_256,
                                          const uint8_t *s_256,
                                          const uint8_t *msg, uint32_t msg_len,
                                          uint8_t *result_128)
{
    uint8_t ififo_buf[1600];
    uint32_t off = 0U;

    if (!e_256 || !n_256 || !s_256 || !msg || !result_128) return RSP_ERR_NULL_PTR;

    /* 同 verify2048: 模数 N 在第一个槽位 */
    put_rev(ififo_buf + off, n_256, 256U); off += 256;
    put_rev(ififo_buf + off, e_256, 256U); off += 256;
    put_rev(ififo_buf + off, s_256, 256U); off += 256;
    memcpy(ififo_buf + off, msg,     msg_len); off += msg_len;

    return rsa_ip_run(RSA_CFG_PADDING_EN | RSA_CFG_PADDING_MODE,
                      ififo_buf, off, 128U, result_128);
}
