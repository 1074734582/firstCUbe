#ifndef __RSP_IP_SHA_H__
#define __RSP_IP_SHA_H__

#include "rsp_ip_common.h"
#include "stdint.h"

/* ========== 基地址 ========== */
#define SHA2_IP_BASE (0x80060000UL)
#define SHA2_IP ((SHA2_TypeDef *)SHA2_IP_BASE)

/* ========== 寄存器结构体（依据 sha2.xlsx 寄存器表）==========
 *
 *  偏移    寄存器       宽度      说明
 *  0x00    STATE        32bit     状态/中断寄存器
 *  0x04    PKG_LEN      32bit     当前包数据长度（不含key/iv）
 *  0x08    TOTAL_LEN    32bit     数据总长度（不含key/iv）
 *  0x0C    CFG          32bit     配置寄存器
 *  0x10~   IFIFO        128bit    输入FIFO, 深度8, 8×128bit=128字节
 *  0x8F                          对 0x10~0x8F 任意地址写均写入 IFIFO
 *  0x90~   OFIFO        32bit     输出FIFO, 存放 SHA2 运算结果
 *  0xCF                          SHA256=32B, SHA384=48B, SHA512=64B
 */
typedef struct
{
    __IO uint32_t STATE;      /*!< 0x00 RW: 状态/中断寄存器                */
    __IO uint32_t PKG_LEN;    /*!< 0x04 RW: 当前包数据长度（不含key/iv）     */
    __IO uint32_t TOTAL_LEN;  /*!< 0x08 RW: 数据总长度（不含key/iv）         */
    __IO uint32_t CFG;        /*!< 0x0c RW: 配置寄存器                      */
    __IO uint32_t IFIFO[32];  /*!< 0x10~0x8F WO: 输入FIFO, 128bit宽, 8深, 128B */
    __IO uint32_t OFIFO[16];  /*!< 0x90~0xCF RO: 输出FIFO, 最大64B=16word   */
} SHA2_TypeDef;

/* IFIFO/OFIFO 窗口绝对基址 */
#define SHA2_IP_IFIFO_BASE (SHA2_IP_BASE + 0x10U)
#define SHA2_IP_OFIFO_BASE (SHA2_IP_BASE + 0x90U)

/* ============================================================
 *  STATE 寄存器 (0x00) 位定义
 * ============================================================ */

/* ---- 状态位（RO）---- */
#define SHA2_STATE_DOEN_Pos (0U)
#define SHA2_STATE_DOEN (1U << 0)              /*!< bit0  算核完成，高有效 */
#define SHA2_STATE_IFIFO_FULL_Pos (1U)
#define SHA2_STATE_IFIFO_FULL (1U << 1)        /*!< bit1  IFIFO满状态 */
#define SHA2_STATE_OFIFO_EMPTY_N_Pos (2U)
#define SHA2_STATE_OFIFO_EMPTY_N (1U << 2)     /*!< bit2  OFIFO非空状态 */
#define SHA2_STATE_BUSY_Pos (3U)
#define SHA2_STATE_BUSY (1U << 3)              /*!< bit3  算核忙状态 */
#define SHA2_STATE_IFIFO_WR_CNT_Pos (8U)
#define SHA2_STATE_IFIFO_WR_CNT_Msk (0xFFU << 8) /*!< bit[15:8] IFIFO当前有效数据深度 */

/* ---- 中断标志位（RO）---- */
#define SHA2_STATE_DOEN_INT_FLAG_Pos (16U)
#define SHA2_STATE_DOEN_INT_FLAG (1U << 16)
#define SHA2_STATE_IFIFO_FULL_INT_FLAG_Pos (17U)
#define SHA2_STATE_IFIFO_FULL_INT_FLAG (1U << 17)
#define SHA2_STATE_IFIFO_EMPTY_THRESH_INT_FLAG_Pos (18U)
#define SHA2_STATE_IFIFO_EMPTY_THRESH_INT_FLAG (1U << 18)
#define SHA2_STATE_IFIFO_FULL_THRESH_INT_FLAG_Pos (19U)
#define SHA2_STATE_IFIFO_FULL_THRESH_INT_FLAG (1U << 19)
#define SHA2_STATE_OFIFO_EMPTY_N_INT_FLAG_Pos (20U)
#define SHA2_STATE_OFIFO_EMPTY_N_INT_FLAG (1U << 20)
#define SHA2_STATE_BUSY_INT_FLAG_Pos (21U)
#define SHA2_STATE_BUSY_INT_FLAG (1U << 21)

/* ---- 中断控制位（RW/W1CS）---- */
#define SHA2_STATE_INT_ENABLE_Pos (24U)
#define SHA2_STATE_INT_ENABLE (1U << 24)
#define SHA2_STATE_INT_CLEAR_Pos (25U)
#define SHA2_STATE_INT_CLEAR (1U << 25)
#define SHA2_STATE_INTMASK_Pos (26U)
#define SHA2_STATE_INTMASK_Msk (0x3FU << 26)

/* ============================================================
 *  CFG 寄存器 (0x0C) 位定义
 * ============================================================ */
#define SHA2_CFG_ENABLE_Pos (0U)
#define SHA2_CFG_ENABLE (1U << 0)              /*!< bit0  W1SC 算核使能 */

#define SHA2_CFG_HMAC_MODE_Pos (1U)
#define SHA2_CFG_HMAC_MODE_SHA2 (0U << 1)      /*!< bit1  0: SHA2 模式 */
#define SHA2_CFG_HMAC_MODE_HMAC (1U << 1)      /*!<       1: HMAC 模式 */

#define SHA2_CFG_HEADER_Pos (2U)
#define SHA2_CFG_HEADER_Msk (0x7U << 2)
#define SHA2_CFG_HEADER_ONE_PKG (0b101U << 2)  /*!< 整包 */
#define SHA2_CFG_HEADER_HEAD_PKG (0b001U << 2) /*!< 首包 */
#define SHA2_CFG_HEADER_MID_PKG (0b010U << 2)  /*!< 中间包 */
#define SHA2_CFG_HEADER_TAIL_PKG (0b100U << 2) /*!< 尾包 */

#define SHA2_CFG_PADDING_Pos (5U)
#define SHA2_CFG_PADDING_SOFT (0U << 5)        /*!< bit5  0: 软件padding */
#define SHA2_CFG_PADDING_HARD (1U << 5)        /*!<       1: 硬件padding */

#define SHA2_CFG_IFIFO_STATE_CLEAR_Pos (6U)
#define SHA2_CFG_IFIFO_STATE_CLEAR (1U << 6)   /*!< bit6  FIFO状态清零 */

#define SHA2_CFG_IFIFO_PROG_FULL_THRESH_Pos (8U)
#define SHA2_CFG_IFIFO_PROG_FULL_THRESH_Msk (0x7U << 8)

#define SHA2_CFG_IFIFO_PROG_EMPTY_THRESH_Pos (16U)
#define SHA2_CFG_IFIFO_PROG_EMPTY_THRESH_Msk (0x7U << 16)

#define SHA2_CFG_SHA2_MODE_Pos (24U)
#define SHA2_CFG_SHA2_MODE_Msk (0x7U << 24)
#define SHA2_CFG_SHA2_MODE_SHA256 (0b001U << 24) /*!< SHA256 */
#define SHA2_CFG_SHA2_MODE_SHA384 (0b010U << 24) /*!< SHA384 */
#define SHA2_CFG_SHA2_MODE_SHA512 (0b100U << 24) /*!< SHA512 */

/* ============================================================
 *  常量定义
 * ============================================================ */
#define SHA2_IFIFO_DEPTH (8U)          /*!< IFIFO 深度：8×128bit=128B */
#define SHA2_BLOCK_SIZE_256 (64U)      /*!< SHA256 分组大小 64B */
#define SHA2_BLOCK_SIZE_512 (128U)     /*!< SHA384/SHA512 分组大小 128B */

#define SHA256_DIGEST_SIZE (32U)
#define SHA384_DIGEST_SIZE (48U)
#define SHA512_DIGEST_SIZE (64U)

/* 轮询超时 */
#define SHA2_POLL_TIMEOUT (1000000U)

/* ============================================================
 *  类型定义
 * ============================================================ */
typedef enum
{
    SHA2_MODE_SHA256 = 0,
    SHA2_MODE_SHA384,
    SHA2_MODE_SHA512
} sha2_mode_t;

typedef enum
{
    SHA2_PAD_SOFT = 0,   /*!< 软件 padding */
    SHA2_PAD_HARD        /*!< 硬件 padding */
} sha2_pad_t;

typedef struct
{
    sha2_mode_t mode;       /*!< SHA256/SHA384/SHA512 */
    sha2_pad_t padding;     /*!< 软件/硬件 padding */
    uint8_t is_hmac;        /*!< 0=单算, 1=HMAC */
    uint32_t chunk_size;    /*!< 分包大小，0=自动(按块大小) */
    const uint8_t *key;     /*!< HMAC key（仅 HMAC 模式） */
    uint32_t key_len;       /*!< key 长度（仅 HMAC 模式） */
    const uint8_t *in;      /*!< 输入消息 */
    uint32_t in_len;        /*!< 消息长度 */
    uint8_t *out;           /*!< 输出摘要 */
    uint32_t out_len;       /*!< 输出缓冲区长度 */
} sha2_ctx_t;

/* ============================================================
 *  API 函数
 * ============================================================ */

/**
 * @brief SHA2 单包计算（整包模式）
 * @param ctx 上下文
 * @return RSP_OK / RSP_ERR_xxx
 */
RSP_StatusTypeDef sha2_hw_one_pkg(sha2_ctx_t *ctx);

/**
 * @brief SHA2 流式计算（分包模式：首/中/尾）
 * @param ctx 上下文
 * @return RSP_OK / RSP_ERR_xxx
 */
RSP_StatusTypeDef sha2_hw_stream(sha2_ctx_t *ctx);

/**
 * @brief SHA2 计算（自动选择单包/流式）
 * @param mode SHA256/SHA384/SHA512
 * @param in 输入消息
 * @param in_len 消息长度
 * @param out 输出摘要
 * @param out_len 输出缓冲区长度
 * @return RSP_OK / RSP_ERR_xxx
 */
RSP_StatusTypeDef sha2_hw(sha2_mode_t mode, const uint8_t *in, uint32_t in_len,
                          uint8_t *out, uint32_t out_len);

/**
 * @brief HMAC-SHA2 计算
 * @param mode SHA256/SHA384/SHA512
 * @param key HMAC key
 * @param key_len key 长度
 * @param in 输入消息
 * @param in_len 消息长度
 * @param out 输出摘要
 * @param out_len 输出缓冲区长度
 * @return RSP_OK / RSP_ERR_xxx
 */
RSP_StatusTypeDef hmac_sha2_hw(sha2_mode_t mode, const uint8_t *key, uint32_t key_len,
                               const uint8_t *in, uint32_t in_len,
                               uint8_t *out, uint32_t out_len);

#endif /* __RSP_IP_SHA_H__ */
