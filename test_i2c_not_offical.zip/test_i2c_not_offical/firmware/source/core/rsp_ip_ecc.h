/**
 * @file rsp_ip_ecc.h
 * @brief ECC(ECDSA) 硬件 IP 驱动接口
 *        依据 ecc.xlsx(寄存器表) + SOC_ECC_TEST_*.txt 实测反解
 *
 * 寄存器映射 (基址 0x80090000):
 *   0x00 STATE    RO  状态/中断标志
 *   0x04 INTR     RW  中断使能/屏蔽/阈值/FIFO 状态清零
 *   0x08 PKG_LEN  RW  数据包长度(字节)
 *   0x0C CFG      RW  bit0 ENABLE / bit[10:8] MODE / bit11 P384
 *                     bit12/13 输入/输出大小端 / bit14 摘要-原始数据
 *   0x10~0x8F  IFIFO  WO  输入 FIFO, 128bit x 8 深
 *   0x90~0x10F OFIFO  RO  输出 FIFO, 128bit x 8 深
 *
 * MODE (CFG[10:8]):
 *   000 SIGN  (ECDSA sign):       d -> k -> msg     OFIFO: r || s
 *   001 VERIFY (ECDSA verify):    pub(x||y) -> sig(r||s) -> msg   OFIFO: 1B pass/fail
 *   010 KP    (d * P 点乘):       k -> pub(x||y)    OFIFO: Q.y || Q.x (前后 swap)
 *   011 KG    (d * G 公钥生成):   k (仅标量)        OFIFO: Q.y || Q.x (前后 swap)
 *
 * KG/KP 输出顺序注意: 硬件先出 Q.y 再出 Q.x, 使用时需要把前后 blen 交换!
 * SOC 参考: SOC_ECC_TEST_KG.txt L69-76, SOC_ECC_TEST_KP.txt L74-80
 *
 * CFG 典型值 (P-256, bit11=0; P-384 时加 bit11=0x0800):
 *   SIGN   : 0x3001 = ENABLE | ISW | OSW
 *   VERIFY : 0x3101 = MODE=1 | ISW | OSW
 *   KP     : 0x3201 = MODE=2 | ISW | OSW
 *   KG     : 0x3301 = MODE=3 | ISW | OSW
 *
 * CFG.bit14 (SING_VERIFY_MODE):
 *   0 = 原始消息模式 (硬件内部 hash message)
 *   1 = 摘要模式 (输入已经是 SHA-256/384 摘要, 硬件不再 hash)
 */
#ifndef __RSP_IP_ECC_H__
#define __RSP_IP_ECC_H__

#include "rsp_ip_common.h"
#include <stdint.h>

/* ========== 基地址 ==========
 * 按 IP 编号顺序推定: 0x8001 SM2 / 0x8002 SM3 / 0x8003 SM4 / 0x8004 AES
 *                  0x8005 DES / 0x8006 SHA2 / 0x8007 RSA / 0x8008 ChaCha20
 * 如与 FPGA 实际地址不同, 只改这里即可.
 */
#define ECC_IP_BASE  (0x80090000UL)
#define ECC_IP       ((ECC_TypeDef *)ECC_IP_BASE)

#define ECC_IP_IFIFO_BASE  (ECC_IP_BASE + 0x10U)
#define ECC_IP_OFIFO_BASE  (ECC_IP_BASE + 0x90U)

/* ========== 寄存器结构体 (ecc.xlsx) ========== */
typedef struct
{
    __I  uint32_t STATE;          /*!< 0x00 RO 状态/中断标志                 */
    __IO uint32_t INTR;           /*!< 0x04 RW 中断/阈值/FIFO 状态复位       */
    __IO uint32_t PKG_LEN;        /*!< 0x08 RW 数据包长度(字节)              */
    __IO uint32_t CFG;            /*!< 0x0C RW 配置(ENABLE/MODE/曲线/交换)   */
    __O  uint32_t IFIFO[32];      /*!< 0x10~0x8F WO 输入 FIFO 128bit x 8 深  */
    __I  uint32_t OFIFO[32];      /*!< 0x90~0x10F RO 输出 FIFO 128bit x 8 深 */
} ECC_TypeDef;

/* ========== STATE (0x00) 位定义 (RO) ========== */
#define ECC_STATE_IFIFO_FULL             (1U << 0U)   /*!< bit0  IFIFO 满            */
#define ECC_STATE_IFIFO_EMPTY            (1U << 1U)   /*!< bit1  IFIFO 空            */
#define ECC_STATE_IFIFO_PROG_FULL        (1U << 2U)   /*!< bit2  IFIFO 阈满          */
#define ECC_STATE_IFIFO_PROG_EMPTY       (1U << 3U)   /*!< bit3  IFIFO 阈空          */
#define ECC_STATE_OFIFO_FULL             (1U << 4U)   /*!< bit4  OFIFO 满            */
#define ECC_STATE_OFIFO_EMPTY            (1U << 5U)   /*!< bit5  OFIFO 空            */
#define ECC_STATE_OFIFO_PROG_FULL        (1U << 6U)   /*!< bit6  OFIFO 阈满          */
#define ECC_STATE_OFIFO_PROG_EMPTY       (1U << 7U)   /*!< bit7  OFIFO 阈空          */
#define ECC_STATE_IFIFO_CNT_Pos          (8U)
#define ECC_STATE_IFIFO_CNT_Msk          (0xFFU << 8U)    /*!< bit[15:8]  输入深度  */
#define ECC_STATE_OFIFO_CNT_Pos          (16U)
#define ECC_STATE_OFIFO_CNT_Msk          (0xFFU << 16U)   /*!< bit[23:16] 输出深度  */

/* ========== INTR (0x04) 位定义 ========== */
#define ECC_INTR_EN                      (1U << 0U)   /*!< bit0 全局中断使能          */
#define ECC_INTR_FIFO_STATE_CLEAR        (1U << 1U)   /*!< bit1 W1SC FIFO 状态复位    */
#define ECC_INTR_MASK_Pos                (8U)
#define ECC_INTR_MASK_Msk                (0xFFU << 8U)
#define ECC_INTR_CLRER                   (1U << 16U)  /*!< bit16 W1SC 清全局中断      */
#define ECC_INTR_IFIFO_PROG_FULL_THRESH_Pos   (20U)
#define ECC_INTR_IFIFO_PROG_FULL_THRESH_Msk   (0x7U << 20U)
#define ECC_INTR_IFIFO_PROG_EMPTY_THRESH_Pos  (23U)
#define ECC_INTR_IFIFO_PROG_EMPTY_THRESH_Msk  (0x7U << 23U)
#define ECC_INTR_OFIFO_PROG_FULL_THRESH_Pos   (26U)
#define ECC_INTR_OFIFO_PROG_FULL_THRESH_Msk   (0x7U << 26U)
#define ECC_INTR_OFIFO_PROG_EMPTY_THRESH_Pos  (29U)
#define ECC_INTR_OFIFO_PROG_EMPTY_THRESH_Msk  (0x7U << 29U)

/* ========== CFG (0x0C) 位定义 ========== */
#define ECC_CFG_ENABLE                   (1U << 0U)   /*!< bit0 W1SC 算核启动, 写 1 自清 */
#define ECC_CFG_MODE_Pos                 (8U)
#define ECC_CFG_MODE_Msk                 (0x7U << 8U) /*!< bit[10:8] 模式             */
#define ECC_CFG_MODE_SIGN                (0U << 8U)   /*!< 000 签名                   */
#define ECC_CFG_MODE_VERIFY              (1U << 8U)   /*!< 001 验签                   */
#define ECC_CFG_MODE_KP                  (2U << 8U)   /*!< 010 点乘 (d*P, 共享密钥)   */
#define ECC_CFG_MODE_KG                  (3U << 8U)   /*!< 011 公钥生成 (d*G)         */
#define ECC_CFG_CURVE_P384               (1U << 11U)  /*!< bit11 0=P256 1=P384        */
#define ECC_CFG_INPUT_SWAP               (1U << 12U)  /*!< bit12 输入大小端转换       */
#define ECC_CFG_OUTPUT_SWAP              (1U << 13U)  /*!< bit13 输出大小端转换       */
#define ECC_CFG_SING_VERIFY_MODE         (1U << 14U)  /*!< bit14 0=原始消息(硬件内部hash) 1=输入已是摘要 */
#define ECC_CFG_ID_LEN_Pos               (16U)
#define ECC_CFG_ID_LEN_Msk               (0xFFFU << 16U)

/* ========== 曲线 ========== */
#define ECC_CURVE_P256                   (0U)
#define ECC_CURVE_P384                   (1U)

/* ========== 常量 ========== */
#define ECC_ENTRY_BYTES                  (16U)       /*!< 一个 FIFO 条目 128bit      */
#define ECC_IFIFO_DEPTH                  (8U)        /*!< IFIFO 深度 8 条目          */
#define ECC_OFIFO_DEPTH                  (8U)        /*!< OFIFO 深度 8 条目          */
#define ECC_P256_BYTES                   (32U)
#define ECC_P384_BYTES                   (48U)
#define ECC_POLL_TIMEOUT                 (1000000U)
/* 标量乘耗时长, 等首拍输出用更长预算 */
#define ECC_OUT_WAIT                     (8000000U)

/* ========== 公共 API ========== */

/**
 * @brief ECDSA 签名 (原始消息模式, CFG.SING_VERIFY_MODE=0, SOC_ECC_SIGN.txt 2026-11)
 * @param curve    ECC_CURVE_P256 (当前 SOC 仅验证了 P256)
 * @param d        私钥, 固定 32 字节, 大端
 * @param k        随机数 k, 大端, 字节数 = msg_len (1 <= k < n)
 * @param message  原始消息 (不是摘要!), 大端
 * @param msg_len  消息字节数 (同时作为 PKG_LEN 和 random_k 长度)
 * @param r_out    输出 r, 大端 32/48 字节
 * @param s_out    输出 s, 大端 32/48 字节
 * @return RSP_OK / RSP_ERR_xxx
 *
 * IFIFO 顺序 (上板实测反解):
 *   1) d[0..31]
 *   2) random_k[0..31]
 *   3) message[0..31]     (作为 e)
 *
 * PKG_LEN (0x08) = msg_len 字节数 (32), 不是 entry 数
 */
RSP_StatusTypeDef ecc_hw_sign(uint32_t curve, const uint8_t *d, const uint8_t *k,
                              const uint8_t *message, uint32_t msg_len,
                              uint8_t *r_out, uint8_t *s_out);

/* 临时探测: sign FAIL 时定位操作数排列/标量映射, curve 必须与被测曲线一致! */
void ecc_probe_sign_order(uint32_t curve, const uint8_t *d, const uint8_t *k, const uint8_t *msg);
void ecc_probe_scalar_map(uint32_t curve, const uint8_t *d, const uint8_t *msg);

/**
 * @brief ECDSA 验签 (CFG.SING_VERIFY_MODE=0, 对应 SOC_ECC_TEST_verify.txt)
 * @param curve    ECC_CURVE_P256
 * @param pubkey   公钥 64 字节, 大端 x||y
 * @param message  原始消息 (作为 e, 32 字节)
 * @param msg_len  消息字节数, 固定 32
 * @param sig      签名 64 字节, 大端 r||s
 * @return RSP_OK=验签通过 / RSP_ERR_DATA_CHECK=验签失败 / 其他错误
 *
 * IFIFO 顺序: 1) pubkey[0..63]  2) sig[0..63]  3) message[0..31]
 */
RSP_StatusTypeDef ecc_hw_verify(uint32_t curve, const uint8_t *pubkey,
                                const uint8_t *message, uint32_t msg_len,
                                const uint8_t *sig);

/**
 * @brief ECC 公钥生成 (d * G, CFG.MODE=3)
 * @param curve      ECC_CURVE_P256 / ECC_CURVE_P384
 * @param k          输入私钥/标量, 32 (P-256) 或 48 (P-384) 字节, 大端
 * @param pubkey_out 输出公钥 64/96 字节, 大端 x||y (硬件输出 Q.y||Q.x 已 swap)
 * @return RSP_OK / RSP_ERR_xxx
 *
 * 协议 (SOC_ECC_TEST_KG.txt 实测):
 *   CFG     = 0x3301 (KG, P-256) / 0x3B01 (KG, P-384)
 *   PKG_LEN = blen (32 或 48)
 *   IFIFO   = k (仅一个操作数!)
 *   OFIFO   = Q.y(blen) -> Q.x(blen), 共 64/96B = 4/6 拍
 *             ⚠️ 硬件先出 y 后出 x, 本函数内部已做前后 swap 输出标准 x||y
 */
RSP_StatusTypeDef ecc_hw_keygen(uint32_t curve, const uint8_t *k, uint8_t *pubkey_out);

/**
 * @brief ECC 点乘 (d * P, CFG.MODE=2) — 用于 ECDH 共享密钥
 * @param curve      ECC_CURVE_P256 / ECC_CURVE_P384
 * @param k          输入标量 (本方私钥), 32/48 字节, 大端
 * @param peer_pub   对端公钥 x||y, 64/96 字节, 大端
 * @param result     输出点 x||y, 64/96 字节, 大端 (硬件输出已 swap)
 * @return RSP_OK / RSP_ERR_xxx
 *
 * 协议 (SOC_ECC_TEST_KP.txt 实测):
 *   CFG     = 0x3201 (KP, P-256) / 0x3A01 (KP, P-384)
 *   PKG_LEN = blen (32 或 48)
 *   IFIFO   = k(blen) -> peer_pub(x||y, 2*blen)
 *   OFIFO   = Q.y(blen) -> Q.x(blen), 共 64/96B = 4/6 拍
 */
RSP_StatusTypeDef ecc_hw_kp(uint32_t curve, const uint8_t *k,
                            const uint8_t *peer_pub, uint8_t *result);

/* 硬件自测入口 (test_ecc.c) */
int ecc_test(void);

#endif /* __RSP_IP_ECC_H__ */
