/**
 * @file rsp_ip_ecc.c
 * @brief ECC(ECDSA) 硬件 IP 驱动实现 (基址 0x80090000)
 *
 * === MODE 位域 (CFG[10:8], CFG=0x3001 + MODE<<8 + P384) ===
 *   000 SIGN  CFG=0x3001  IFIFO d->k->msg           OFIFO r||s
 *   001 VERIFY CFG=0x3101 IFIFO pub(x||y)->sig->msg   OFIFO 1B (1=pass)
 *   010 KP    CFG=0x3201  IFIFO k->pub(x||y)        OFIFO Q.y||Q.x ← swap!
 *   011 KG    CFG=0x3301  IFIFO k (仅标量!)          OFIFO Q.y||Q.x ← swap!
 *   P-384 时加 bit11=0x0800
 *
 * === SOC 协议证据 ===
 *   SOC_ECC_TEST_KG.txt: mode_sel=3, IFIFO 仅 push k, PKG_LEN=k_len,
 *                        输出 Q.y(先) || Q.x(后), swap 前后 blen 得标准格式
 *   SOC_ECC_TEST_KP.txt: mode_sel=2, IFIFO push k -> push pub(x||y), 其余同上
 *   crypo_lib_api.txt L268: pkg_data = 1|mode_sel<<8|ecc_p_sel<<11|isw<<12|osw<<13|sv<<14
 *
 * === RTL 已知限制 ===
 *   - k=2,3 极小值算错 (P-256/P-384 都有)
 *   - 当前 P-384 bitstream: sign/verify 已验证, KG/KP 未测试
 *   - KG/KP 输出 Q.y 在 Q.x 前面, 驱动内部已 swap 成标准 x||y
 *
 * reset 策略 (Phase 1 dummy sign 解决算核内部锁存残留):
 *   Phase 1  首次 reset 强制算核跑一轮 dummy sign, 消费 FPGA 从上一次
 *            运行残留的内部锁存操作数 (INTR.CLEAR 只清 FIFO 状态,
 *            清不掉算核内部流水线的残留数据)
 *   Phase 2  多轮 INTR.bit1 FIFO_STATE_CLEAR
 *   Phase 3  深度排空 OFIFO 残留
 */

#include "rsp_ip_ecc.h"
#include <string.h>
#include <stdio.h>

/* === 前向声明 ===
 * ecc_simple_reset() Phase 1 需要调用 ecc_push_bytes / ecc_pull_n,
 * 但这两个 static 函数定义在 reset 之后, 编译器会默认成 extern 导致
 * "static declaration follows non-static declaration" 冲突,
 * 所以这里提前声明. */
static void ecc_push_bytes(const uint8_t *b, uint32_t len);
static int  ecc_pull_n(uint8_t *b, uint32_t beats);

/**
 * @brief 软复位 (见文件头注释 reset 策略)
 * @param curve ECC_CURVE_P256 / ECC_CURVE_P384, Phase 1 dummy sign 按
 *              此曲线配置 (必须与 bitstream 支持的曲线一致才能完成)
 */
static void ecc_simple_reset(uint32_t curve)
{
    /* Phase 1: 按 curve 分开的 dummy sign (不共享 phase1_done!)
     * 原因: phase1_done 如果是单一全局 flag, 一个曲线跑通后另一个曲线
     * Phase 1 被跳过, Phase 2 清 CFG 可能清不掉算核内部锁存的曲线模式.
     * 必须每条曲线自己跑一次 Phase 1 dummy, 确保算核处于正确曲线状态. */
    static int phase1_p256_done = 0;
    static int phase1_p384_done = 0;
    int *phase1_done = (curve == ECC_CURVE_P384) ? &phase1_p384_done : &phase1_p256_done;

    if (!*phase1_done) {
        static const uint8_t dummy[48] = {0};
        uint8_t out_dummy[96];
        uint32_t blen  = (curve == ECC_CURVE_P384) ? 48U : 32U;
        uint32_t cfg   = 0x3001U;
        uint32_t beats = (2U * blen) / 16U;
        uint32_t i, t;
        int ok = 1;

        if (curve == ECC_CURVE_P384) cfg |= ECC_CFG_CURVE_P384;

        ECC_IP->PKG_LEN = blen;
        ECC_IP->CFG     = cfg;
        ecc_push_bytes(dummy, blen);
        ecc_push_bytes(dummy, blen);
        ecc_push_bytes(dummy, blen);

        /* 自带短超时: 曲线不匹配时最多等 ~15s, 不算 phase1_done */
        for (i = 0U; i < beats; i++)
        {
            t = (i == 0U) ? 10000000U : 200000U;
            while (((ECC_IP->STATE >> ECC_STATE_OFIFO_CNT_Pos) & 0xFFU) == 0U)
            {
                if (--t == 0U) { ok = 0; break; }
            }
            if (!ok) break;
            memcpy(out_dummy + i * 16U, (const void *)&ECC_IP->OFIFO[0], 16);
        }
        ECC_IP->CFG = 0U;
        if (ok) *phase1_done = 1;
    }

    /* Phase 2: 关算核 + 清 FIFO 状态标志 */
    ECC_IP->CFG = 0U;
    ECC_IP->INTR = 0U;
    ECC_IP->PKG_LEN = 0U;

    for (int pass = 0; pass < 3; pass++)
    {
        ECC_IP->INTR = ECC_INTR_FIFO_STATE_CLEAR;
        for (volatile int d = 0; d < 5000; d++);
        ECC_IP->INTR = 0U;
        for (volatile int d = 0; d < 500; d++);
    }

    /* Phase 3: 深度排空 OFIFO */
    for (int pass = 0; pass < 5; pass++)
    {
        uint32_t t = 1000000U;
        while ((ECC_IP->STATE & ECC_STATE_OFIFO_EMPTY) == 0U)
        {
            volatile uint32_t dw = ECC_IP->OFIFO[0]; (void)dw;
            volatile uint32_t dw1 = ECC_IP->OFIFO[1]; (void)dw1;
            volatile uint32_t dw2 = ECC_IP->OFIFO[2]; (void)dw2;
            volatile uint32_t dw3 = ECC_IP->OFIFO[3]; (void)dw3;
            if (--t == 0U) break;
        }
    }
}

/** push 32B = 2 条 16B IFIFO entry */
static void __attribute__((unused)) ecc_push32(const uint8_t *b)
{
    uint32_t w[4];

    while ((ECC_IP->STATE & ECC_STATE_IFIFO_FULL) != 0U);
    memcpy(w, b, 16U);
    ECC_IP->IFIFO[0] = w[0]; ECC_IP->IFIFO[1] = w[1];
    ECC_IP->IFIFO[2] = w[2]; ECC_IP->IFIFO[3] = w[3];

    while ((ECC_IP->STATE & ECC_STATE_IFIFO_FULL) != 0U);
    memcpy(w, b + 16, 16U);
    ECC_IP->IFIFO[0] = w[0]; ECC_IP->IFIFO[1] = w[1];
    ECC_IP->IFIFO[2] = w[2]; ECC_IP->IFIFO[3] = w[3];
}

/** push len 字节 (len 须为 16 的倍数): P256=32B/2拍, P384=48B/3拍 */
static void ecc_push_bytes(const uint8_t *b, uint32_t len)
{
    uint32_t w[4];

    for (uint32_t off = 0U; off < len; off += 16U)
    {
        while ((ECC_IP->STATE & ECC_STATE_IFIFO_FULL) != 0U);
        memcpy(w, b + off, 16U);
        ECC_IP->IFIFO[0] = w[0]; ECC_IP->IFIFO[1] = w[1];
        ECC_IP->IFIFO[2] = w[2]; ECC_IP->IFIFO[3] = w[3];
    }
}

/** pull 64B = 4 条 16B OFIFO entry, 返回 0 成功 -1 超时 */
static int __attribute__((unused)) ecc_pull64(uint8_t *b)
{
    uint32_t t = 60000000U;

    for (int e = 0; e < 4; e++)
    {
        while (((ECC_IP->STATE >> ECC_STATE_OFIFO_CNT_Pos) & 0xFFU) == 0U)
        {
            if (--t == 0U) return -1;
        }
        memcpy(b + e * 16, (const void *)&ECC_IP->OFIFO[0], 16);
    }
    return 0;
}

/** 从 OFIFO 连续读 beats 拍 16B, 返回 0 成功 -1 超时
 * 首拍给 60M 循环余量 (P-384 sign 实测 3-4s), 后续 200K */
static int ecc_pull_n(uint8_t *b, uint32_t beats)
{
    for (uint32_t i = 0U; i < beats; i++)
    {
        uint32_t t = (i == 0U) ? 60000000U : 200000U;

        while (((ECC_IP->STATE >> ECC_STATE_OFIFO_CNT_Pos) & 0xFFU) == 0U)
        {
            if (--t == 0U) return -1;
        }
        memcpy(b + i * 16U, (const void *)&ECC_IP->OFIFO[0], 16);
    }
    return 0;
}

/* ---- 临时探测函数 (sign FAIL 时由 test_ecc.c 调用) ----
 * ⚠️ 重要: curve 参数必须与被测曲线一致! 之前硬编码 ECC_CURVE_P384
 * 导致 CFG.bit11=1, 算核锁存 P-384 模式, reset Phase 2+3 清不掉,
 * 后续所有 Sign/Keygen 全错. 必须动态计算 blen/CFG. */

void ecc_probe_sign_order(uint32_t curve, const uint8_t *d, const uint8_t *k, const uint8_t *msg)
{
    const uint8_t *ops[3] = {d, k, msg};
    const char *nm[3] = {"d", "k", "e"};
    static const uint8_t perm[6][3] = {
        {0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}
    };
    uint32_t blen  = (curve == ECC_CURVE_P384) ? 48U : 32U;
    uint32_t cfg   = 0x3001U;
    uint32_t beats = (2U * blen) / 16U;
    uint8_t out[96];

    if (curve == ECC_CURVE_P384) cfg |= ECC_CFG_CURVE_P384;

    for (int p = 0; p < 6; p++)
    {
        ecc_simple_reset(curve);
        ECC_IP->PKG_LEN = blen;
        ECC_IP->CFG     = cfg;
        ecc_push_bytes(ops[perm[p][0]], blen);
        ecc_push_bytes(ops[perm[p][1]], blen);
        ecc_push_bytes(ops[perm[p][2]], blen);
        if (ecc_pull_n(out, beats) != 0) {
            printf("  [order %s%s%s] TIMEOUT\n",
                   nm[perm[p][0]], nm[perm[p][1]], nm[perm[p][2]]);
            continue;
        }
        ECC_IP->CFG = 0U;
        printf("  [order %s%s%s] r=", nm[perm[p][0]], nm[perm[p][1]], nm[perm[p][2]]);
        for (int j = 0; j < (int)blen; j++) printf("%02x", out[j]);
        printf(" s=");
        for (int j = blen; j < 2U * blen; j++) printf("%02x", out[j]);
        printf("\n");
    }
}

void ecc_probe_scalar_map(uint32_t curve, const uint8_t *d, const uint8_t *msg)
{
    uint32_t blen  = (curve == ECC_CURVE_P384) ? 48U : 32U;
    uint32_t cfg   = 0x3001U;
    uint32_t beats = (2U * blen) / 16U;
    uint8_t k[48];
    uint8_t out[96];

    if (curve == ECC_CURVE_P384) cfg |= ECC_CFG_CURVE_P384;

    /* 标量探针根据 blen 动态生成: 极小值 k=1,2,3 到高位 k=2^(blen-1) */
    static const char *tag[] = {"1", "2", "3", "256", "2^16", "2^32", "high"};
    static const uint8_t val[] = {1, 2, 3, 1, 1, 1, 0x80};
    uint8_t off[7];
    /* 动态计算偏移, 避免 runtime blen 初始化 static 数组 (GCC 报错) */
    off[0]=0; off[1]=0; off[2]=0;
    off[3]=(blen>2) ? blen-2 : 0;
    off[4]=(blen>4) ? blen-4 : 0;
    off[5]=(blen>8) ? blen-8 : 0;
    off[6]=0;

    for (unsigned i = 0; i < sizeof(tag)/sizeof(tag[0]); i++)
    {
        memset(k, 0, blen);
        k[off[i]] = val[i];

        ecc_simple_reset(curve);
        ECC_IP->PKG_LEN = blen;
        ECC_IP->CFG     = cfg;
        ecc_push_bytes(d, blen);
        ecc_push_bytes(k, blen);
        ecc_push_bytes(msg, blen);
        if (ecc_pull_n(out, beats) != 0) {
            printf("  [k=%-5s] TIMEOUT\n", tag[i]);
            continue;
        }
        ECC_IP->CFG = 0U;
        printf("  [k=%-5s] r=", tag[i]);
        for (int j = 0; j < 16 && j < (int)blen; j++) printf("%02x", out[j]);
        printf("...\n");
    }
}

/* ==================== 公共 API ==================== */

/* 参数错误上报: 打印具体出错的参数名, 便于调用者定位误用 */
static RSP_StatusTypeDef ecc_param_null_err(const char *algo, const char *param)
{
    printf("[ECC %s] %s_null_err\n", algo, param);
    return RSP_ERR_NULL_PTR;
}

static RSP_StatusTypeDef ecc_param_len_err(const char *algo, const char *param,
                                           uint32_t got, const char *expect)
{
    printf("[ECC %s] %s_len_err: got=%lu expect=%s\n", algo, param,
           (unsigned long)got, expect);
    return RSP_ERR_INVALID_PARAM;
}

RSP_StatusTypeDef ecc_hw_sign(uint32_t curve, const uint8_t *d, const uint8_t *k,
                              const uint8_t *message, uint32_t msg_len,
                              uint8_t *r_out, uint8_t *s_out)
{
    uint8_t out[96];
    if ((curve != ECC_CURVE_P256) && (curve != ECC_CURVE_P384))
        return ecc_param_len_err("SIGN", "curve", curve, "P256/P384");
    if (d == NULL)       return ecc_param_null_err("SIGN", "d");
    if (k == NULL)       return ecc_param_null_err("SIGN", "k");
    if (message == NULL) return ecc_param_null_err("SIGN", "message");
    if (r_out == NULL)   return ecc_param_null_err("SIGN", "r_out");
    if (s_out == NULL)   return ecc_param_null_err("SIGN", "s_out");

    uint32_t blen = (curve == ECC_CURVE_P384) ? 48U : 32U;
    if (msg_len != blen)
        return ecc_param_len_err("SIGN", "msg_len", msg_len,
                                 (curve == ECC_CURVE_P384) ? "48" : "32");

    ecc_simple_reset(curve);

    /* CFG = ENABLE | MODE=0 SIGN | INPUT_SWAP | OUTPUT_SWAP | P384 */
    uint32_t cfg = 0x3001U;
    if (curve == ECC_CURVE_P384) cfg |= ECC_CFG_CURVE_P384;

    ECC_IP->PKG_LEN = msg_len;
    ECC_IP->CFG     = cfg;

    /* 关键路径: CFG→push→pull 必须零延迟, 不能插任何 printf/UART */
    ecc_push_bytes(d, blen);
    ecc_push_bytes(k, blen);
    ecc_push_bytes(message, blen);

    if (ecc_pull_n(out, (2U * blen) / 16U) != 0)
    {
        ECC_IP->CFG = 0U;
        return RSP_ERR_FIFO;
    }

    ECC_IP->CFG = 0U;
    memcpy(r_out, out, blen);
    memcpy(s_out, out + blen, blen);
    return RSP_OK;
}

RSP_StatusTypeDef ecc_hw_verify(uint32_t curve, const uint8_t *pubkey,
                                const uint8_t *message, uint32_t msg_len,
                                const uint8_t *sig)
{
    uint8_t out[16];

    if ((curve != ECC_CURVE_P256) && (curve != ECC_CURVE_P384))
        return ecc_param_len_err("VERIFY", "curve", curve, "P256/P384");
    if (pubkey == NULL)  return ecc_param_null_err("VERIFY", "pubkey");
    if (message == NULL) return ecc_param_null_err("VERIFY", "message");
    if (sig == NULL)     return ecc_param_null_err("VERIFY", "sig");

    uint32_t blen = (curve == ECC_CURVE_P384) ? 48U : 32U;
    if (msg_len != blen)
        return ecc_param_len_err("VERIFY", "msg_len", msg_len,
                                 (curve == ECC_CURVE_P384) ? "48" : "32");

    ecc_simple_reset(curve);

    /* CFG = MODE=1 VERIFY | INPUT_SWAP | OUTPUT_SWAP | ENABLE | P384 */
    uint32_t cfg = 0x3101U;
    if (curve == ECC_CURVE_P384) cfg |= ECC_CFG_CURVE_P384;
    ECC_IP->PKG_LEN = msg_len;
    ECC_IP->CFG     = cfg;

    /* IFIFO: pubkey(x||y) -> sig(r||s) -> message */
    ecc_push_bytes(pubkey, blen);
    ecc_push_bytes(pubkey + blen, blen);
    ecc_push_bytes(sig, blen);
    ecc_push_bytes(sig + blen, blen);
    ecc_push_bytes(message, blen);

    if (ecc_pull_n(out, 1U) != 0)
    {
        ECC_IP->CFG = 0U;
        return RSP_ERR_FIFO;
    }

    ECC_IP->CFG = 0U;

    /* byte[0]: 1 = pass, 0 = fail */
    return (out[0] == 1U) ? RSP_OK : RSP_ERR_DATA_CHECK;
}

/**
 * @brief ECC 公钥生成 (d * G) — SOC_ECC_TEST_KG.txt MODE=3 协议
 *
 * 关键: IFIFO 只 push k 一个标量 (无 d 无 msg), PKG_LEN=blen
 *       OFIFO 先出 Q.y 再出 Q.x, 本函数内部 swap 成标准 x||y
 */
RSP_StatusTypeDef ecc_hw_keygen(uint32_t curve, const uint8_t *k, uint8_t *pubkey_out)
{
    uint8_t out[96];   /* max P-384 96B */

    if ((curve != ECC_CURVE_P256) && (curve != ECC_CURVE_P384))
        return ecc_param_len_err("KEYGEN", "curve", curve, "P256/P384");
    if (k == NULL)          return ecc_param_null_err("KEYGEN", "k");
    if (pubkey_out == NULL) return ecc_param_null_err("KEYGEN", "pubkey_out");

    uint32_t blen = (curve == ECC_CURVE_P384) ? 48U : 32U;

    ecc_simple_reset(curve);

    /* CFG = MODE=3 KG | ISW | OSW | ENABLE | P384 */
    uint32_t cfg = ECC_CFG_MODE_KG | 0x3001U;   /* 0x3301 (P-256) */
    if (curve == ECC_CURVE_P384) cfg |= ECC_CFG_CURVE_P384;

    ECC_IP->PKG_LEN = blen;   /* 标量长度, 不是 0 也不是 2*blen */
    ECC_IP->CFG     = cfg;

    /* IFIFO: 只 push k (一个操作数!) */
    ecc_push_bytes(k, blen);

    /* OFIFO: Q.y(blen) -> Q.x(blen), 共 2*blen B */
    if (ecc_pull_n(out, (2U * blen) / 16U) != 0)
    {
        ECC_IP->CFG = 0U;
        return RSP_ERR_FIFO;
    }

    ECC_IP->CFG = 0U;

    /* ⚠️ SOC 实测: 硬件先出 Q.y 后出 Q.x, swap 前后 blen 输出标准 x||y */
    /* out[0..blen-1] = Q.y, out[blen..2*blen-1] = Q.x */
    memcpy(pubkey_out,          out + blen, blen);   /* Q.x */
    memcpy(pubkey_out + blen,   out,        blen);   /* Q.y */

    return RSP_OK;
}

/**
 * @brief ECC 点乘 (d * P) — SOC_ECC_TEST_KP.txt MODE=2 协议
 *
 * 关键: IFIFO push k → push peer_pub(x||y), PKG_LEN=k_len
 *       OFIFO 先出 Q.y 再出 Q.x, 本函数内部 swap 成标准 x||y
 */
RSP_StatusTypeDef ecc_hw_kp(uint32_t curve, const uint8_t *k,
                            const uint8_t *peer_pub, uint8_t *result)
{
    uint8_t out[96];

    if ((curve != ECC_CURVE_P256) && (curve != ECC_CURVE_P384))
        return ecc_param_len_err("KP", "curve", curve, "P256/P384");
    if (k == NULL)         return ecc_param_null_err("KP", "k");
    if (peer_pub == NULL)  return ecc_param_null_err("KP", "peer_pub");
    if (result == NULL)    return ecc_param_null_err("KP", "result");

    uint32_t blen = (curve == ECC_CURVE_P384) ? 48U : 32U;

    ecc_simple_reset(curve);

    /* CFG = MODE=2 KP | ISW | OSW | ENABLE | P384 */
    uint32_t cfg = ECC_CFG_MODE_KP | 0x3001U;   /* 0x3201 (P-256) */
    if (curve == ECC_CURVE_P384) cfg |= ECC_CFG_CURVE_P384;

    ECC_IP->PKG_LEN = blen;   /* 标量长度 */
    ECC_IP->CFG     = cfg;

    /* IFIFO: k(blen) -> peer_pub(x||y, 2*blen) */
    ecc_push_bytes(k, blen);
    ecc_push_bytes(peer_pub, blen);        /* peer Q.x */
    ecc_push_bytes(peer_pub + blen, blen); /* peer Q.y */

    /* OFIFO: Q.y(blen) -> Q.x(blen), 共 2*blen B */
    if (ecc_pull_n(out, (2U * blen) / 16U) != 0)
    {
        ECC_IP->CFG = 0U;
        return RSP_ERR_FIFO;
    }

    ECC_IP->CFG = 0U;

    /* swap Q.y/Q.x → 标准 x||y */
    memcpy(result,        out + blen, blen);
    memcpy(result + blen, out,        blen);

    return RSP_OK;
}
