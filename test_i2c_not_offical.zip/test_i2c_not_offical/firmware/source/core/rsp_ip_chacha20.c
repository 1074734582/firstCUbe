/**
 * @file rsp_ip_chacha20.c
 * @brief ChaCha20-Poly1305 硬件 IP 驱动（依据上板实测协议，非文档时序）
 *
 *  协议要点（与 SOC 验证通过的参考代码 SOC_CHACHA20_ENC.txt 对齐）：
 *   1. IFIFO 写基址 0x18，OFIFO 读基址 0x98
 *      （即结构体里的 IFIFO[0] / OFIFO[0]，4 个 32bit 字顺序写/读 = 1 拍）
 *   2. key 的 2 拍按自然顺序：先写 key[0:16]，再写 key[16:32]
 *   3. 必须先把 IFIFO 预加载满（最多 8 拍）再写 START；START 后再补写的数据
 *      会因算核等待超时而报错误码 101
 *   4. ADD_LEN=0 时不能写 AAD 拍（会被当成数据）；内核会自行把一个 16B
 *      全零块计入 Poly1305，故 AAD=0 时 tag 与标准值不同（已确认的 RTL 缺陷，
 *      密文正确，仅 tag 非标准；驱动不做规避，测试中 AAD=0 只比密文）
 *
 *  IFIFO 数据顺序: keyL(1拍) -> keyH(1拍) -> nonce(1拍) -> AAD(ceil(ADD_LEN/16)拍)
 *                 -> message(ceil(DATA_LEN/16)拍) -> tag(1拍，加解密都写)
 *  OFIFO 数据顺序: result(ceil(DATA_LEN/16)拍) -> TAG(1拍) -> 状态字(1拍)
 */

#include "rsp_ip_chacha20.h"
#include <stdio.h>

/* FIFO 访问下标：IFIFO[0]=0x18，OFIFO[0]=0x98（与 SOC 验证代码一致） */
#define CHACHA20_FIFO_ALIGN_IDX (0U)

/* IFIFO 映像缓冲（uint32_t 声明保证 4 字节对齐，便于 128bit 突发访问） */
static uint32_t chacha20_img_buf[CHACHA20_IMG_MAX_BYTE / 4U];

/* ============================================================
 *  核心内联辅助
 * ============================================================ */

/* 写一个 128bit(16B) 条目到 IFIFO（必须 16B 对齐基址，4 字写完才推入 1 拍） */
static inline void CHACHA20_WriteIFIFO_128(const uint8_t *pData)
{
    volatile uint32_t *f = &CHACHA20_IP->IFIFO[CHACHA20_FIFO_ALIGN_IDX];
    const uint32_t *w = (const uint32_t *)pData;

    f[0] = w[0];
    f[1] = w[1];
    f[2] = w[2];
    f[3] = w[3];
}

/* 从 OFIFO 读一个 128bit(16B) 条目（必须 16B 对齐基址） */
static inline void CHACHA20_ReadOFIFO_128(uint8_t *pData)
{
    volatile uint32_t *f = &CHACHA20_IP->OFIFO[CHACHA20_FIFO_ALIGN_IDX];
    uint32_t *w = (uint32_t *)pData;

    w[0] = f[0];
    w[1] = f[1];
    w[2] = f[2];
    w[3] = f[3];
}

/* ============================================================
 *  内部函数
 * ============================================================ */

/* 软复位：清配置 -> FIFO 状态清零 -> 排空 OFIFO 残留 */
static void chacha20_ip_reset(void)
{
    volatile uint32_t *base = (volatile uint32_t *)CHACHA20_IP_BASE;

    /* 1. 清配置（含 START/MODE） */
    base[0x14 / 4] = 0U;   /* CFG       */
    base[0x08 / 4] = 0U;   /* ADD_LEN   */
    base[0x0C / 4] = 0U;   /* DATA_LEN  */
    base[0x10 / 4] = 0U;   /* START_CNT */
    base[0x04 / 4] = 0U;   /* INTR      */

    /* 2. FIFO 状态清零（INTR bit17 W1SC）：写1 -> 等待 -> 写0 */
    base[0x04 / 4] = CHACHA20_INTR_IFIFO_STATE_CLEAR;
    for (volatile int d = 0; d < 2000; d++);
    base[0x04 / 4] = 0U;

    /* 3. 排空 OFIFO 残留（必须按 16B 对齐读，4 字读完才弹出一拍）。
     *    限定次数：若上一包把 IP 卡在"永远 1 拍不弹出"的状态，这里不能死等。 */
    for (uint32_t n = 0U; n < 64U; n++) {
        uint32_t dw[4];
        if ((CHACHA20_IP->STATE & CHACHA20_STATE_OFIFO_CNT_Msk) == 0U) break;
        CHACHA20_ReadOFIFO_128((uint8_t *)dw);
    }

    /* 4. 再清一次 FIFO 状态，保证下一包从干净状态开始 */
    base[0x04 / 4] = CHACHA20_INTR_IFIFO_STATE_CLEAR;
    for (volatile int d = 0; d < 100; d++);
    base[0x04 / 4] = 0U;
}

/* 按 IFIFO 顺序拼接映像: keyL|keyH|nonce|AAD|message|tag，返回总拍数 */
static uint32_t chacha20_build_img(const chacha20_ctx_t *ctx, uint8_t *img,
                                   uint32_t *aad_blk, uint32_t *msg_blk)
{
    uint32_t off = 0U;
    uint32_t ab = (ctx->aad_len + 15U) / 16U;
    uint32_t mb = (ctx->in_len + 15U) / 16U;

    /* key: 32B 分 2 拍，按自然顺序先写 key[0:16] 再写 key[16:32] */
    memcpy(img + off, ctx->key, CHACHA20_ENTRY_BYTE_LEN);
    off += CHACHA20_ENTRY_BYTE_LEN;
    memcpy(img + off, ctx->key + 16, CHACHA20_ENTRY_BYTE_LEN);
    off += CHACHA20_ENTRY_BYTE_LEN;

    /* nonce: 12B（1 拍，低 12B，高 4B 补 0） */
    memset(img + off, 0, CHACHA20_ENTRY_BYTE_LEN);
    memcpy(img + off, ctx->nonce, CHACHA20_NONCE_BYTE_LEN);
    off += CHACHA20_ENTRY_BYTE_LEN;

    /* AAD: ab 拍，末拍不足补 0。AB=0 时绝对不能写（会被算核当成数据） */
    if (ab > 0U) {
        memset(img + off, 0, ab * CHACHA20_ENTRY_BYTE_LEN);
        memcpy(img + off, ctx->aad, ctx->aad_len);
        off += ab * CHACHA20_ENTRY_BYTE_LEN;
    }

    /* message: mb 拍，末拍不足补 0（DATA_LEN=0 时不写） */
    if (mb > 0U) {
        memset(img + off, 0, mb * CHACHA20_ENTRY_BYTE_LEN);
        memcpy(img + off, ctx->in, ctx->in_len);
        off += mb * CHACHA20_ENTRY_BYTE_LEN;
    }

    /* tag: 固定 1 拍，加解密都要写（SOC 验证代码加密写 SW tag、解密写全 0）。
     * 加密时 tag 是硬件输出，此处无值可填，写全 0 占位即可。 */
    memset(img + off, 0, CHACHA20_ENTRY_BYTE_LEN);
    if (!ctx->is_encrypt) {
        memcpy(img + off, ctx->tag, CHACHA20_TAG_BYTE_LEN);
    }
    off += CHACHA20_ENTRY_BYTE_LEN;

    *aad_blk = ab;
    *msg_blk = mb;
    return off / CHACHA20_ENTRY_BYTE_LEN;
}

/* 保存一拍 result 到 out（末拍只写有效字节，避免越界） */
static void chacha20_store_result(uint8_t *out, uint32_t idx, uint32_t in_len,
                                  const uint8_t *beat)
{
    uint32_t off = idx * CHACHA20_ENTRY_BYTE_LEN;
    uint32_t n;

    if ((out == NULL) || (off >= in_len)) {
        return;
    }
    n = in_len - off;
    if (n > CHACHA20_ENTRY_BYTE_LEN) {
        n = CHACHA20_ENTRY_BYTE_LEN;
    }
    memcpy(out + off, beat, n);
}

/* 等待 OFIFO 有数据（轮询 OFIFO 计数） */
static RSP_StatusTypeDef chacha20_ofifo_wait(void)
{
    uint32_t timeout = CHACHA20_POLL_TIMEOUT;
    while ((CHACHA20_IP->STATE & CHACHA20_STATE_OFIFO_CNT_Msk) == 0U) {
        if (--timeout == 0U) return RSP_ERR_FIFO;
    }
    return RSP_OK;
}

/* 读取 OFIFO：result(msg_blk 拍) + TAG(1 拍) + 状态字(1 拍)，缺任何一拍都算失败 */
static RSP_StatusTypeDef chacha20_read_output(uint8_t *out, uint32_t *rd_cnt,
                                              uint32_t msg_blk, uint32_t in_len,
                                              uint8_t *tag_buf, uint8_t *status_buf)
{
    uint32_t beat_w[4];
    uint8_t *beat = (uint8_t *)beat_w;
    uint32_t idx;

    for (idx = *rd_cnt; idx < msg_blk; idx++) {
        if (chacha20_ofifo_wait() != RSP_OK) {
            *rd_cnt = idx;
            return RSP_ERR_FIFO;
        }
        CHACHA20_ReadOFIFO_128(beat);
        chacha20_store_result(out, idx, in_len, beat);
    }
    *rd_cnt = msg_blk;

    if (chacha20_ofifo_wait() != RSP_OK) return RSP_ERR_FIFO;
    CHACHA20_ReadOFIFO_128(tag_buf);

    if (chacha20_ofifo_wait() != RSP_OK) return RSP_ERR_FIFO;
    CHACHA20_ReadOFIFO_128(status_buf);

    return RSP_OK;
}

/* ============================================================
 *  参数错误上报（参照 SM4/SHA 驱动：逐参数检查 + 诊断日志）
 * ============================================================ */
static RSP_StatusTypeDef chacha20_param_null_err(const char *param)
{
    printf("[CHACHA20] %s_null_err\n", param);
    return RSP_ERR_NULL_PTR;
}

static RSP_StatusTypeDef chacha20_param_len_err(const char *param,
                                                uint32_t got, const char *expect)
{
    printf("[CHACHA20] %s_len_err: got=%lu expect=%s\n", param,
           (unsigned long)got, expect);
    return RSP_ERR_INVALID_PARAM;
}

/* ============================================================
 *  公开 API
 * ============================================================ */

RSP_StatusTypeDef chacha20_hw(chacha20_ctx_t *ctx)
{
    RSP_StatusTypeDef ret = RSP_OK;
    uint8_t *img = (uint8_t *)chacha20_img_buf;
    uint32_t aad_blk = 0U;
    uint32_t msg_blk = 0U;
    uint32_t total_beats;
    uint32_t need;
    uint32_t i;
    uint32_t timeout;
    uint32_t cfg_val;
    uint32_t start_cnt;
    uint32_t rd_cnt = 0U;
    uint32_t beat_w[4];
    uint8_t *beat = (uint8_t *)beat_w;
    uint32_t hw_tag_w[4];
    uint32_t status_w[4];
    uint8_t *hw_tag = (uint8_t *)hw_tag_w;
    uint8_t *status = (uint8_t *)status_w;
    uint32_t auth_pass;
    uint32_t err_code;

    /* ---- 入参检查 ---- */
    if (ctx == NULL) return chacha20_param_null_err("ctx");
    if (ctx->key == NULL)    return chacha20_param_null_err("ctx->key");
    if (ctx->nonce == NULL)  return chacha20_param_null_err("ctx->nonce");
    if (ctx->tag == NULL)    return chacha20_param_null_err("ctx->tag");
    if ((ctx->in_len > 0U) && (ctx->in == NULL))  return chacha20_param_null_err("ctx->in");
    if ((ctx->in_len > 0U) && (ctx->out == NULL)) return chacha20_param_null_err("ctx->out");
    if ((ctx->aad_len > 0U) && (ctx->aad == NULL)) return chacha20_param_null_err("ctx->aad");

    /* ---- 映像容量检查 ---- */
    need = CHACHA20_ENTRY_BYTE_LEN * (5U + (ctx->aad_len + 15U) / 16U +
                                          (ctx->in_len + 15U) / 16U);
    if (need > CHACHA20_IMG_MAX_BYTE) {
        return chacha20_param_len_err("img", need, "<=IMG_MAX");
    }

    start_cnt = (ctx->start_cnt == 0U) ? CHACHA20_DEFAULT_START_CNT : ctx->start_cnt;

    chacha20_ip_reset();

    /* 复位后 OFIFO 必须为空；否则上一包把 IP 卡死了，继续跑只会读到残留垃圾 */
    if ((CHACHA20_IP->STATE & CHACHA20_STATE_OFIFO_CNT_Msk) != 0U) {
        return RSP_ERR_IP_BUSY;
    }

    total_beats = chacha20_build_img(ctx, img, &aad_blk, &msg_blk);
    (void)aad_blk;

    cfg_val = ctx->is_encrypt ? CHACHA20_CFG_MODE_ENC : CHACHA20_CFG_MODE_DEC;

    /* 阈值配置：IFIFO PROG_FULL=7 / PROG_EMPTY=1 */
    CHACHA20_IP->INTR = (7U << CHACHA20_INTR_IFIFO_PROG_FULL_THRESH_Pos) |
                        (1U << CHACHA20_INTR_IFIFO_PROG_EMPTY_THRESH_Pos);
    CHACHA20_IP->ADD_LEN = ctx->aad_len;
    CHACHA20_IP->DATA_LEN = ctx->in_len;
    CHACHA20_IP->START_CNT = start_cnt;

    /* ---- 先预加载 IFIFO（最多 8 拍），再写 START ---- */
    /* 实测：START 之后才补写的数据会因算核等待超时而报错误码 101，
     * 所以必须让算核启动时 FIFO 里已经有它马上要读的拍。 */
    for (i = 0U; i < total_beats; i++) {
        if ((CHACHA20_IP->STATE & CHACHA20_STATE_IFIFO_FULL) != 0U) {
            break;
        }
        CHACHA20_WriteIFIFO_128(img + i * CHACHA20_ENTRY_BYTE_LEN);
    }

    CHACHA20_IP->CFG = cfg_val | CHACHA20_CFG_START;

    /* ---- 剩余拍：每写一拍前先把 OFIFO 里已产生的 result 拍读空 ----
     *  输出 FIFO 只有 8 拍深，边写边算时若不及时排空会丢拍（大包失败的根因） */
    for (; i < total_beats; i++) {
        while ((rd_cnt < msg_blk) &&
               ((CHACHA20_IP->STATE & CHACHA20_STATE_OFIFO_CNT_Msk) != 0U)) {
            CHACHA20_ReadOFIFO_128(beat);
            chacha20_store_result(ctx->out, rd_cnt, ctx->in_len, beat);
            rd_cnt++;
        }

        timeout = CHACHA20_POLL_TIMEOUT;
        while ((CHACHA20_IP->STATE & CHACHA20_STATE_IFIFO_FULL) != 0U) {
            if ((rd_cnt < msg_blk) &&
                ((CHACHA20_IP->STATE & CHACHA20_STATE_OFIFO_CNT_Msk) != 0U)) {
                CHACHA20_ReadOFIFO_128(beat);
                chacha20_store_result(ctx->out, rd_cnt, ctx->in_len, beat);
                rd_cnt++;
                timeout = CHACHA20_POLL_TIMEOUT;
            }
            if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
        }
        CHACHA20_WriteIFIFO_128(img + i * CHACHA20_ENTRY_BYTE_LEN);
    }

    /* ---- 读取剩余 result + TAG + 状态字 ---- */
    ret = chacha20_read_output(ctx->out, &rd_cnt, msg_blk, ctx->in_len, hw_tag, status);
    if (ret != RSP_OK) goto err;

    auth_pass = status[0] & 0x01U;
    err_code = (status[0] >> CHACHA20_STATUS_ERR_Pos) & 0x07U;

    if (err_code != 0U) {
        ret = RSP_ERR_DATA_CHECK;
        goto err;
    }

    if (ctx->is_encrypt) {
        memcpy(ctx->tag, hw_tag, CHACHA20_TAG_BYTE_LEN);
    } else {
        /* 解密：认证通过才算成功 */
        if (auth_pass == 0U) {
            if ((ctx->out != NULL) && (ctx->in_len > 0U)) {
                memset(ctx->out, 0, ctx->in_len);
            }
            ret = RSP_ERR_DATA_CHECK;
            goto err;
        }
        memcpy(ctx->tag, hw_tag, CHACHA20_TAG_BYTE_LEN);
    }

    CHACHA20_IP->CFG = 0U;
    return RSP_OK;

err:
    CHACHA20_IP->CFG = 0U;
    return ret;
}

RSP_StatusTypeDef chacha20_poly1305_hw(const uint8_t *key, const uint8_t *nonce,
                                       const uint8_t *aad, uint32_t aad_len,
                                       const uint8_t *in, uint32_t in_len,
                                       uint8_t *out, uint8_t *tag, int is_encrypt)
{
    chacha20_ctx_t ctx;

    if (key == NULL)   return chacha20_param_null_err("key");
    if (nonce == NULL) return chacha20_param_null_err("nonce");
    if (tag == NULL)   return chacha20_param_null_err("tag");
    if ((in_len > 0U) && (in == NULL))  return chacha20_param_null_err("in");
    if ((in_len > 0U) && (out == NULL)) return chacha20_param_null_err("out");
    if ((aad_len > 0U) && (aad == NULL)) return chacha20_param_null_err("aad");

    memset(&ctx, 0, sizeof(ctx));
    ctx.key = key;
    ctx.nonce = nonce;
    ctx.aad = aad;
    ctx.aad_len = aad_len;
    ctx.in = in;
    ctx.in_len = in_len;
    ctx.out = out;
    ctx.tag = tag;
    ctx.start_cnt = CHACHA20_DEFAULT_START_CNT;
    ctx.is_encrypt = is_encrypt;

    return chacha20_hw(&ctx);
}
