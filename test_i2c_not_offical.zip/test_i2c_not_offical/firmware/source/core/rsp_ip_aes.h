/**
 * @file rsp_ip_aes.h
 * @brief AES hardware driver — ECB / CBC / CTR / GCM only
 */
#ifndef __RSP_IP_AES_H__
#define __RSP_IP_AES_H__

#include "rsp_ip_common.h"
#include <string.h>

/* ============================================================
 *  AES IP Register Map (matches aes.xlsx)
 * ============================================================ */
#define AES_IP_BASE         (0x80040000UL)

typedef struct
{
    __IO uint32_t STATE;        /* 0x00 RO */
    __IO uint32_t INTR;         /* 0x04 RW */
    __IO uint32_t CFG;          /* 0x08 RW */
    __IO uint32_t PKG_LEN_ALL;  /* 0x0C RW */
    __IO uint32_t PKG_LEN_CUR;  /* 0x10 RW */
    __IO uint32_t AAD_LEN;      /* 0x14 RW */
    __IO uint32_t PKG_POS;      /* 0x18 RW (GCM only) */
    __IO uint32_t ENABLE;       /* 0x1C W1SC */
    __O  uint32_t IFIFO[32];    /* 0x20~0x9F WO */
    __I  uint32_t OFIFO[32];    /* 0xA0~0x11F RO */
} AES_TypeDef;

#define AES_IP              ((AES_TypeDef *)AES_IP_BASE)

/* IFIFO/OFIFO 窗口基址（DMA 等场景使用）*/
#define AES_IP_IFIFO_BASE   (AES_IP_BASE + 0x20U)
#define AES_IP_OFIFO_BASE   (AES_IP_BASE + 0xA0U)

/* ============================================================
 *  CFG bit definitions
 * ============================================================ */
#define AES_CFG_ENCDEC              (1U << 0)   /* 0=encrypt, 1=decrypt (AES opposite to SM4!) */
#define AES_CFG_SER_TYPE_Msk        (0xFU << 4)
#define AES_CFG_SER_TYPE_Pos        (4U)
#define AES_SER_TYPE_ECB            (0U << 4)
#define AES_SER_TYPE_CBC            (1U << 4)
#define AES_SER_TYPE_CTR            (4U << 4)
#define AES_SER_TYPE_GCM            (9U << 4)

#define AES_CFG_KEY_LEN_Msk         (0xFFU << 8)
#define AES_CFG_KEY_LEN_Pos         (8U)

#define AES_CFG_TAG_LEN_Msk         (0xFU << 16)
#define AES_CFG_TAG_LEN_Pos         (16U)

#define AES_CFG_HEADER_Msk          (7U << 24)
#define AES_PKG_FULL                (5U << 24)   /* 101 */
#define AES_PKG_FIRST               (1U << 24)   /* 001 */
#define AES_PKG_MID                 (2U << 24)   /* 010 */
#define AES_PKG_LAST                (4U << 24)   /* 100 */

#define AES_CFG_GCM_TAG_HEARD       (1U << 27)
#define AES_CFG_FIFO_STATE_CLEAR    (1U << 28)   /* W1SC */

/* ============================================================
 *  STATE bit definitions
 * ============================================================ */
#define AES_STATE_IFIFO_FULL        (1U << 0)
#define AES_STATE_IFIFO_EMPTY       (1U << 1)
#define AES_STATE_IFIFO_PROG_FULL   (1U << 2)
#define AES_STATE_IFIFO_PROG_EMPTY  (1U << 3)
#define AES_STATE_OFIFO_FULL        (1U << 4)
#define AES_STATE_OFIFO_EMPTY       (1U << 5)
#define AES_STATE_OFIFO_PROG_FULL   (1U << 6)
#define AES_STATE_OFIFO_PROG_EMPTY  (1U << 7)
#define AES_STATE_IFIFO_CNT_Msk     (0xFFU << 8)
#define AES_STATE_IFIFO_CNT_Pos     (8U)
#define AES_STATE_OFIFO_CNT_Msk     (0xFFU << 16)
#define AES_STATE_OFIFO_CNT_Pos     (16U)

/* ============================================================
 *  INTR bit definitions
 * ============================================================ */
#define AES_INTR_IFIFO_PROG_FULL_THRESH_Msk     (7U << 20)
#define AES_INTR_IFIFO_PROG_FULL_THRESH_Pos     (20U)
#define AES_INTR_IFIFO_PROG_EMPTY_THRESH_Msk    (7U << 23)
#define AES_INTR_IFIFO_PROG_EMPTY_THRESH_Pos    (23U)
#define AES_INTR_OFIFO_PROG_FULL_THRESH_Msk     (7U << 26)
#define AES_INTR_OFIFO_PROG_FULL_THRESH_Pos     (26U)
#define AES_INTR_OFIFO_PROG_EMPTY_THRESH_Msk    (7U << 29)
#define AES_INTR_OFIFO_PROG_EMPTY_THRESH_Pos    (29U)

/* ============================================================
 *  Constants
 * ============================================================ */
#define AES_BLOCK_BYTE_LEN      (16U)
#define AES_IV_BYTE_LEN         (16U)
#define AES_IFIFO_DEPTH         (8U)
#define AES_POLL_TIMEOUT        (1000000U)

/* ============================================================
 *  Context structure (unified entry)
 * ============================================================ */
typedef enum
{
    AES_MODE_ECB = 0,
    AES_MODE_CBC,
    AES_MODE_CTR,
    AES_MODE_GCM,
} aes_mode_t;

typedef struct
{
    aes_mode_t  mode;
    const uint8_t *key;
    uint32_t    key_len;        /* 16/24/32 */
    const uint8_t *iv;          /* NULL for ECB */
    const uint8_t *aad;         /* for CCM/GCM */
    uint32_t    aad_len;
    const uint8_t *in;
    uint8_t     *out;
    uint32_t    in_len;
    uint8_t     *tag;           /* for MAC/AEAD */
    int         is_encrypt;     /* 1=encrypt/gen, 0=decrypt/verify */
} aes_ctx_t;

/* ============================================================
 *  Public APIs
 * ============================================================ */

/* DMA 性能测试入口（覆盖全部 10 种模式，开启 RSP_USE_DMA_PERF 时使用） */
#ifdef RSP_USE_DMA_PERF
RSP_StatusTypeDef aes_hw_process_dma(aes_ctx_t *ctx);
#endif

RSP_StatusTypeDef aes_ecb(const uint8_t *key, uint32_t key_len,
                          const uint8_t *in, uint8_t *out, uint32_t len, int is_encrypt);
RSP_StatusTypeDef aes_cbc(const uint8_t *key, uint32_t key_len,
                          const uint8_t *iv,
                          const uint8_t *in, uint8_t *out, uint32_t len, int is_encrypt);
RSP_StatusTypeDef aes_ctr(const uint8_t *key, uint32_t key_len,
                          const uint8_t *iv,
                          const uint8_t *in, uint8_t *out, uint32_t len, int is_encrypt);
RSP_StatusTypeDef aes_gcm(const uint8_t *key, uint32_t key_len,
                          const uint8_t *iv,
                          const uint8_t *aad, uint32_t aad_len,
                          const uint8_t *in, uint8_t *out, uint32_t len,
                          uint8_t *tag, int is_encrypt);

#endif /* __RSP_IP_AES_H__ */
