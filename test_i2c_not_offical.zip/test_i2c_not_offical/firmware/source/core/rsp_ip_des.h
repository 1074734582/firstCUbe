/**
 * @file rsp_ip_des.h
 * @brief DES 硬件 IP 驱动接口 (当前仅实现 ECB 模式)
 *        依据 DES_寄存器列表.xlsx 与 DES_FPGA算法设计文档.docx
 *
 * 寄存器映射 (基址 0x80050000, 32bit 字偏移):
 *   0x000 CTRL       RW   bit0 ENABLE(W1SC) / bit1 FIFO_CLEAR / bit[4:2] HEADER
 *   0x004 MODE       RW   bit[3:0] 算法(1=DES,2=3DES) / bit4 分组(0=ECB,1=CBC)
 *                        / bit8 加解密(0=加密,1=解密)
 *   0x008~0x024 KEY0~KEY7  RW  密钥寄存器 (KEY0=密钥高 32bit, KEY7=最低)
 *                        (3DES 时 KEY0~KEY3=K1, KEY4~KEY7=K2/K3)
 *   0x028~0x034 IV0~IV3    RW  初始向量 (CBC 用)
 *   0x038 PKG_LEN    RW   包长度 = 64bit 块数 << 4 (1 块写 16, 2 块写 32)
 *   0x03C STATUS     RO   bit0 BUSY / bit1 OFIFO_EMPTY / bit2 IFIFO_FULL
 *                        bit[7:3] 中断标志 / bit[15:8] IFIFO_CNT
 *                        / bit[23:16] OFIFO_CNT
 *   0x040 INT_ENABLE RW   bit0 中断总使能
 *   0x044 INT_MASK   RW   bit[5:0] 中断屏蔽
 *   0x048 INT_CLEAR  W1SC 写 1 清全部中断标志
 *   0x050~0x05C IFIFO WO 连续写 4 个 32bit 字合成 1 个 128bit 条目
 *                        (先写的字在块内高位)
 *   0x090~0x0AF OFIFO RO 连续读 4 个 32bit 字拆出 1 个 128bit 条目
 *                        (先读的字为块内高位)
 *
 * 数据约定:
 *   - 密钥/明文/密文均按大端字节序理解: key[0]、plain[0] 为最高字节,
 *     对应 DES 标准向量中的 k1 / 第一个比特
 *   - 32bit 寄存器/FIFO 字按小端解释(实测): 标准字节要按小端打包成字,
 *     读回时按小端拆包; 驱动内部已处理, 调用方无需关心
 *   - 一个 128bit FIFO 条目 = 2 个 64bit DES 分组, 低地址分组在前
 *   - PKG_LEN = (len / 8) << 4, 因此 len 为 16 字节整数倍时 PKG_LEN = 2 * len
 */
#ifndef __RSP_IP_DES_H__
#define __RSP_IP_DES_H__

#include "rsp_ip_common.h"
#include <stdint.h>

/* ========== 基地址 ========== */
#define DES_IP_BASE  (0x80050000UL)
#define DES_IP       ((DES_TypeDef *)DES_IP_BASE)

/* ========== 寄存器结构体 ========== */
typedef struct
{
    __IO uint32_t CTRL;           /*!< 0x000 RW  控制                        */
    __IO uint32_t MODE;           /*!< 0x004 RW  模式选择                    */
    __IO uint32_t KEY[8];         /*!< 0x008~0x024 RW  密钥                  */
    __IO uint32_t IV[4];          /*!< 0x028~0x034 RW  初始向量              */
    __IO uint32_t PKG_LEN;        /*!< 0x038 RW  包长度                      */
    __I  uint32_t STATUS;         /*!< 0x03C RO  状态                        */
    __IO uint32_t INT_ENABLE;     /*!< 0x040 RW  中断总使能                  */
    __IO uint32_t INT_MASK;       /*!< 0x044 RW  中断屏蔽                    */
    __O  uint32_t INT_CLEAR;      /*!< 0x048 W1SC 清中断标志                 */
    uint32_t      RESERVED0[1];   /*!< 0x04C                                 */
    __O  uint32_t IFIFO[4];       /*!< 0x050~0x05C WO  输入数据窗口          */
    uint32_t      RESERVED1[12];  /*!< 0x060~0x08C                           */
    __I  uint32_t OFIFO[8];       /*!< 0x090~0x0AF RO  输出数据窗口          */
} DES_TypeDef;

#define DES_IP_IFIFO_BASE  (DES_IP_BASE + 0x050U)
#define DES_IP_OFIFO_BASE  (DES_IP_BASE + 0x090U)

/* ============================================================
 *  CTRL 寄存器 (0x000) 位定义
 * ============================================================ */
#define DES_CTRL_ENABLE             (1U << 0U)   /*!< bit0 写 1 启动一次加解密 */
#define DES_CTRL_FIFO_CLEAR         (1U << 1U)   /*!< bit1 写 1 清空 FIFO 指针 */
#define DES_CTRL_HEADER_Pos         (2U)
#define DES_CTRL_HEADER_Msk         (0x7U << 2U) /*!< bit[4:2] 包标识          */
#define DES_CTRL_HEADER_DEFAULT     (0x4U << 2U) /*!< 复位默认 3'b100          */

/* ============================================================
 *  MODE 寄存器 (0x004) 位定义
 * ============================================================ */
#define DES_MODE_ALG_Pos            (0U)
#define DES_MODE_ALG_Msk            (0xFU << 0U) /*!< bit[3:0] 算法            */
#define DES_MODE_ALG_DES            (0x1U << 0U) /*!< 1 = DES                  */
#define DES_MODE_ALG_3DES           (0x2U << 0U) /*!< 2 = 3DES                 */
#define DES_MODE_GROUP_CBC          (1U << 4U)   /*!< bit4 0=ECB, 1=CBC        */
#define DES_MODE_DECRYPT            (1U << 8U)   /*!< bit8 0=加密, 1=解密      */

/* ============================================================
 *  STATUS 寄存器 (0x03C) 位定义
 * ============================================================ */
#define DES_STATUS_BUSY             (1U << 0U)   /*!< bit0 1=算法核忙          */
#define DES_STATUS_OFIFO_EMPTY      (1U << 1U)   /*!< bit1 1=输出 FIFO 空      */
#define DES_STATUS_IFIFO_FULL       (1U << 2U)   /*!< bit2 1=输入 FIFO 满      */
#define DES_STATUS_INTR_FLAG_Msk    (0x3FU << 3U)/*!< bit[7:3] 中断标志        */
#define DES_STATUS_IFIFO_CNT_Pos    (8U)
#define DES_STATUS_IFIFO_CNT_Msk    (0xFFU << 8U)
#define DES_STATUS_OFIFO_CNT_Pos    (16U)
#define DES_STATUS_OFIFO_CNT_Msk    (0xFFU << 16U)

/* ============================================================
 *  常量
 * ============================================================ */
#define DES_BLOCK_BYTE_LEN          (8U)    /* 单个 DES 分组 8 字节      */
#define DES_ENTRY_BYTE_LEN          (16U)   /* 128bit FIFO 条目 = 2 分组 */
#define DES_IFIFO_DEPTH             (8U)    /* FIFO 深度 8 条目          */
#define DES_KEY_BYTE_LEN            (8U)    /* DES 密钥 8 字节           */
#define DES_POLL_TIMEOUT            (1000000U)

/* ============================================================
 *  公有接口
 * ============================================================ */

/**
 * @brief DES-ECB 批量加解密 (硬件)
 * @param key        8 字节密钥, key[0] 为最高字节
 * @param in         输入数据, 长度须为 16 的整数倍
 * @param out        输出数据
 * @param len        输入字节数
 * @param is_encrypt 1=加密, 0=解密
 * @retval RSP_OK 成功, 其余为错误码
 */
RSP_StatusTypeDef des_ecb_hw(const uint8_t *key, const uint8_t *in,
                             uint8_t *out, uint32_t len, int is_encrypt);

/**
 * @brief DES-CBC 批量加解密 (硬件)
 * @param key        8 字节密钥, key[0] 为最高字节
 * @param iv         8 字节初始向量, iv[0] 为最高字节
 * @param in         输入数据, 长度须为 16 的整数倍
 * @param out        输出数据
 * @param len        输入字节数
 * @param is_encrypt 1=加密, 0=解密
 * @retval RSP_OK 成功, 其余为错误码
 *
 * 链式关系由软件维护: 每个 128bit 条目处理完后, 用上一段密文末分组
 * 覆盖 IV 寄存器, 因此每次调用都从调用方给的 iv 重新开始.
 */
RSP_StatusTypeDef des_cbc_hw(const uint8_t *key, const uint8_t *iv,
                             const uint8_t *in, uint8_t *out,
                             uint32_t len, int is_encrypt);

#endif /* __RSP_IP_DES_H__ */
