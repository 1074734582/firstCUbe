/**
 * @file rsp_ip_des.c
 * @brief DES 硬件 IP 驱动 (当前仅实现 ECB 模式)
 *        依据 DES_寄存器列表.xlsx 与 DES_FPGA算法设计文档.docx
 *
 * 执行时序:
 *   软复位(清 FIFO/中断) -> 写 KEY/IV/MODE/PKG_LEN
 *   -> 逐条目: 写 1 个 128bit 条目 -> CTRL[0]=1 启动 -> 等 BUSY 清零
 *      -> 读 1 个 128bit 条目
 *
 * 注: 实测本 IP 每次 ENABLE 只处理 1 个 128bit 条目(2 个 64bit 分组),
 *     与 PKG_LEN 无关, 也不支持"一次启动连续处理整包", 故采用逐条目方式。
 *     这样任意 16B 整数倍长度都能正确处理, 代价是吞吐不如文档宣称的流式。
 *
 * FIFO 说明:
 *   IFIFO/OFIFO 均为 128bit 条目, 一个条目承载 2 个 64bit DES 分组;
 *   写/读窗口固定用基址连续的 4 个 32bit 字, 先写/先读的字为块内高位。
 *   由于每次只灌 1 个条目, 不会触及 FIFO 深度限制; 读侧仍以
 *   OFIFO_EMPTY 作为数据就绪标志。STATUS 的 IFIFO_FULL 与
 *   IFIFO/OFIFO_CNT 在本 FPGA 版本实测不生效, 仅作兜底轮询。
 *
 * 字节序 (上板实测确定):
 *   本 IP 的 32bit 寄存器/FIFO 字一律按小端解释, 即写入字 W 后算核看到的
 *   4 个字节为 W 的低字节在前。因此标准(大端)字节数据要按小端打包成字,
 *   读回时同样按小端拆包, 才能得到标准字节序的结果。
 *   验证依据: 零密钥/零明文得到 8CA64DE9C1B123A7, 标准向量得到
 *   85E813540F0AB405, 与 NIST SP 800-17 一致。
 */

#include "rsp_ip_des.h"
#include <stdio.h>

/* ============================================================
 *  字节序 / FIFO 基础操作
 * ============================================================ */

/** 小端 32bit 打包: p[0] 对应字的最低字节 */
static inline uint32_t des_get_le32(const uint8_t *p)
{
    return  (uint32_t)p[0]         | ((uint32_t)p[1] << 8U) |
           ((uint32_t)p[2] << 16U) | ((uint32_t)p[3] << 24U);
}

/** 小端 32bit 拆包: 字的最低字节落到 p[0] */
static inline void des_put_le32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8U);
    p[2] = (uint8_t)(v >> 16U);
    p[3] = (uint8_t)(v >> 24U);
}

/** 写一个 128bit(16B) 条目到 IFIFO: 先写的字在块内高位 */
static inline void des_write_entry(const uint8_t *p)
{
    DES_IP->IFIFO[0] = des_get_le32(p + 0U);
    DES_IP->IFIFO[1] = des_get_le32(p + 4U);
    DES_IP->IFIFO[2] = des_get_le32(p + 8U);
    DES_IP->IFIFO[3] = des_get_le32(p + 12U);
}

/** 从 OFIFO 读一个 128bit(16B) 条目: 先读的字为块内高位
 *  注: 设计文档中"第 1 次读为加载周期无效"的描述与寄存器列表冲突,
 *      此处按寄存器列表(每次 4 字即一个条目)实现, 实测异常时再评估。 */
static inline void des_read_entry(uint8_t *p)
{
    des_put_le32(p + 0U,  DES_IP->OFIFO[0]);
    des_put_le32(p + 4U,  DES_IP->OFIFO[1]);
    des_put_le32(p + 8U,  DES_IP->OFIFO[2]);
    des_put_le32(p + 12U, DES_IP->OFIFO[3]);
}

/* ============================================================
 *  状态轮询
 * ============================================================ */

static RSP_StatusTypeDef des_wait_ififo_writable(void)
{
    uint32_t timeout = DES_POLL_TIMEOUT;

    while ((DES_IP->STATUS & DES_STATUS_IFIFO_FULL) != 0U)
    {
        if (--timeout == 0U) return RSP_ERR_FIFO;
    }
    return RSP_OK;
}

static RSP_StatusTypeDef des_wait_ofifo_readable(void)
{
    uint32_t timeout = DES_POLL_TIMEOUT;

    while ((DES_IP->STATUS & DES_STATUS_OFIFO_EMPTY) != 0U)
    {
        if (--timeout == 0U) return RSP_ERR_FIFO;
    }
    return RSP_OK;
}

/* ============================================================
 *  软复位
 * ============================================================ */
static void des_ip_reset(void)
{
    uint32_t timeout = DES_POLL_TIMEOUT;

    /* 1. 清 FIFO 指针: CTRL.bit1 写 1, 保持数拍后恢复 HEADER 默认值 */
    DES_IP->CTRL = DES_CTRL_FIFO_CLEAR;
    for (volatile int d = 0; d < 200; d++);
    DES_IP->CTRL = DES_CTRL_HEADER_DEFAULT;

    /* 2. 清模式/长度/中断 */
    DES_IP->MODE       = 0U;
    DES_IP->PKG_LEN    = 0U;
    DES_IP->INT_ENABLE = 0U;
    DES_IP->INT_MASK   = 0U;
    DES_IP->INT_CLEAR  = 1U;
    DES_IP->INT_CLEAR  = 0U;

    /* 3. 排空 OFIFO 残留: 一个条目需连续读 4 个 32bit 字才会弹出 */
    while ((DES_IP->STATUS & DES_STATUS_OFIFO_EMPTY) == 0U)
    {
        for (volatile int k = 0; k < 4; k++) (void)DES_IP->OFIFO[k];
        if (--timeout == 0U) break;
    }
}

/* ============================================================
 *  参数错误上报
 * ============================================================ */
static RSP_StatusTypeDef des_param_null_err(const char *algo, const char *param)
{
    printf("[DES %s] %s_null_err\n", algo, param);
    return RSP_ERR_NULL_PTR;
}

static RSP_StatusTypeDef des_param_len_err(const char *algo, const char *param,
                                           uint32_t got, const char *expect)
{
    printf("[DES %s] %s_len_err: got=%lu expect=%s\n", algo, param,
           (unsigned long)got, expect);
    return RSP_ERR_INVALID_PARAM;
}

/* ============================================================
 *  DES-ECB 批量加解密
 * ============================================================ */
RSP_StatusTypeDef des_ecb_hw(const uint8_t *key, const uint8_t *in,
                             uint8_t *out, uint32_t len, int is_encrypt)
{
    uint32_t nent, i, timeout;
    RSP_StatusTypeDef ret;

    /* ---- 参数校验 ---- */
    if (key == NULL)  return des_param_null_err("ECB", "key");
    if (in == NULL)   return des_param_null_err("ECB", "in");
    if (out == NULL)  return des_param_null_err("ECB", "out");
    if (len == 0U)    return des_param_len_err("ECB", "msg", len, ">0");
    if ((len % DES_ENTRY_BYTE_LEN) != 0U)
        return des_param_len_err("ECB", "msg", len, "N*16");

    des_ip_reset();

    /* 密钥: 64bit 按大端理解 (key[0] 为 k1/最高字节)
     * KEY0 = 密钥高 32bit = key[0..3], KEY1 = 密钥低 32bit = key[4..7],
     * 按小端打包写入(实测映射)。
     * KEY2~KEY7 为 3DES 的 K2/K3, DES 模式下清零 */
    DES_IP->KEY[0] = des_get_le32(key + 0U);
    DES_IP->KEY[1] = des_get_le32(key + 4U);
    for (i = 2U; i < 8U; i++) DES_IP->KEY[i] = 0U;

    /* ECB 不使用 IV, 清零 */
    for (i = 0U; i < 4U; i++) DES_IP->IV[i] = 0U;

    /* MODE: 算法=DES, 分组=ECB, 加解密方向 */
    DES_IP->MODE = DES_MODE_ALG_DES |
                   (is_encrypt ? 0U : DES_MODE_DECRYPT);

    /* 本 IP 每次 ENABLE 只处理 1 个 128bit 条目(2 个 DES 分组), 实测:
     * 预灌 N>1 个条目后启动, 只会输出 1 个条目(PKG_LEN 写 32/64/128 都一样)。
     * 因此按条目逐个处理: 写 1 条目 -> 启动 -> 等 BUSY 清零 -> 读 1 条目,
     * 这样包长不再受 FIFO 深度和 PKG_LEN 语义影响。 */
    nent = len / DES_ENTRY_BYTE_LEN;
    DES_IP->PKG_LEN = (DES_ENTRY_BYTE_LEN / DES_BLOCK_BYTE_LEN) << 4U;

    for (i = 0U; i < nent; i++)
    {
        ret = des_wait_ififo_writable();
        if (ret != RSP_OK) goto err;
        des_write_entry(in + i * DES_ENTRY_BYTE_LEN);

        /* 启动算核 */
        DES_IP->CTRL = DES_CTRL_HEADER_DEFAULT | DES_CTRL_ENABLE;

        /* 等本次处理结束 (ENABLE 在 BUSY 拉高后由硬件自清) */
        timeout = DES_POLL_TIMEOUT;
        while ((DES_IP->STATUS & DES_STATUS_BUSY) != 0U)
        {
            if (--timeout == 0U) { ret = RSP_ERR_TIMEOUT; goto err; }
        }

        ret = des_wait_ofifo_readable();
        if (ret != RSP_OK) goto err;
        des_read_entry(out + i * DES_ENTRY_BYTE_LEN);
    }

    DES_IP->CTRL = DES_CTRL_HEADER_DEFAULT;   /* 清零 ENABLE, 保留 HEADER */
    return RSP_OK;

err:
    DES_IP->CTRL = DES_CTRL_HEADER_DEFAULT;
    return ret;
}

/* ============================================================
 *  DES-CBC 批量加解密
 * ============================================================ */
RSP_StatusTypeDef des_cbc_hw(const uint8_t *key, const uint8_t *iv,
                             const uint8_t *in, uint8_t *out,
                             uint32_t len, int is_encrypt)
{
    uint32_t nent, i, timeout;
    uint8_t  chain[DES_BLOCK_BYTE_LEN];
    RSP_StatusTypeDef ret;

    /* ---- 参数校验 ---- */
    if (key == NULL)  return des_param_null_err("CBC", "key");
    if (iv == NULL)   return des_param_null_err("CBC", "iv");
    if (in == NULL)   return des_param_null_err("CBC", "in");
    if (out == NULL)  return des_param_null_err("CBC", "out");
    if (len == 0U)    return des_param_len_err("CBC", "msg", len, ">0");
    if ((len % DES_ENTRY_BYTE_LEN) != 0U)
        return des_param_len_err("CBC", "msg", len, "N*16");

    des_ip_reset();

    DES_IP->KEY[0] = des_get_le32(key + 0U);
    DES_IP->KEY[1] = des_get_le32(key + 4U);
    for (i = 2U; i < 8U; i++) DES_IP->KEY[i] = 0U;

    DES_IP->MODE = DES_MODE_ALG_DES | DES_MODE_GROUP_CBC |
                   (is_encrypt ? 0U : DES_MODE_DECRYPT);
    DES_IP->PKG_LEN = (DES_ENTRY_BYTE_LEN / DES_BLOCK_BYTE_LEN) << 4U;

    for (i = 0U; i < DES_BLOCK_BYTE_LEN; i++) chain[i] = iv[i];

    nent = len / DES_ENTRY_BYTE_LEN;
    for (i = 0U; i < nent; i++)
    {
        /* 每条目重装 IV: 前后两段都填同一个链值, 这样无论算核在条目内
         * 是"分组串行链接"还是"两个分组各取一段 IV", 第二个分组拿到的
         * 链值都等于上一段密文的最后一个分组。 */
        DES_IP->IV[0] = des_get_le32(chain);
        DES_IP->IV[1] = des_get_le32(chain + 4U);
        DES_IP->IV[2] = des_get_le32(chain);
        DES_IP->IV[3] = des_get_le32(chain + 4U);

        ret = des_wait_ififo_writable();
        if (ret != RSP_OK) goto err;
        des_write_entry(in + i * DES_ENTRY_BYTE_LEN);

        DES_IP->CTRL = DES_CTRL_HEADER_DEFAULT | DES_CTRL_ENABLE;

        timeout = DES_POLL_TIMEOUT;
        while ((DES_IP->STATUS & DES_STATUS_BUSY) != 0U)
        {
            if (--timeout == 0U) { ret = RSP_ERR_TIMEOUT; goto err; }
        }

        ret = des_wait_ofifo_readable();
        if (ret != RSP_OK) goto err;
        des_read_entry(out + i * DES_ENTRY_BYTE_LEN);

        /* 下一段链值 = 本段最后一个密文分组: 加密取输出, 解密取输入 */
        {
            const uint8_t *src = (is_encrypt ? out : in) +
                                 i * DES_ENTRY_BYTE_LEN + DES_BLOCK_BYTE_LEN;
            uint32_t k;
            for (k = 0U; k < DES_BLOCK_BYTE_LEN; k++) chain[k] = src[k];
        }
    }

    DES_IP->CTRL = DES_CTRL_HEADER_DEFAULT;
    return RSP_OK;

err:
    DES_IP->CTRL = DES_CTRL_HEADER_DEFAULT;
    return ret;
}
