#ifndef __RSP_IP_COMMON_H__
#define __RSP_IP_COMMON_H__

#include <stdint.h>


#ifndef NULL
#define NULL (void*)0
#endif

#ifndef __IO
#define __IO volatile
#endif
#ifndef __O
#define __O volatile
#endif
#ifndef __I
#define __I  volatile
#endif

#define ASSERT(x)                                                            \
do                                                                          \
{                                                                           \
    if (!(x))                                                               \
    {                                                                       \
        printf("ASSERT FAILED: %s:%d - %s\n", __FILE__, __LINE__, #x);  \
        while(1);                                                           \
    }                                                                       \
} while(0)

typedef enum
{
    RSP_OK                  = 0,
    RSP_ERR_NULL_PTR        = -1,   /* 空指针 */
    RSP_ERR_TIMEOUT         = -2,   /* 轮询超时 */
    RSP_ERR_FIFO            = -3,   /* FIFO满/空异常 */
    RSP_ERR_INVALID_PARAM   = -4,   /* 非法入参、对齐错误 */
    RSP_ERR_IP_BUSY         = -5,   /* IP一直忙无法启动 */
    RSP_ERR_CFG             = -6,   /* 寄存器配置非法 */
    RSP_ERR_MALLOC          = -7,   /* 内存分配失败 */
    RSP_ERR_DATA_CHECK      = -8,   /* 数据check错误 */
    RSP_ERR_INTR            = -9,   /* 中断模式异常 */

    RSP_ERR_UNKNOWN         = -100, /* 未知错误 */
} RSP_StatusTypeDef;


#define writel(a, v)	   (*(volatile uint32_t *)(a) = (v))
#define readl(a)		   (*(volatile uint32_t *)(a))

/* ============================================================
 *  全局 DMA 性能路径开关
 *
 *  定义 RSP_USE_DMA_PERF 后, 各 IP 驱动 (SM4 / AES / SHA2 / RSA / ...)
 *  将优先使用 DMA 读写 IFIFO / OFIFO, 否则走 CPU store/load。
 *  适用于性能对比测试, 默认关闭 (走 CPU)。
 *
 *  用法: 在编译选项 (CFLAGS) 或 rsp_ip_common.h 本文件里开启:
 *    -DRSP_USE_DMA_PERF
 * ============================================================ */

 #define RSP_USE_DMA_PERF 0   /* 如需默认开启, 取消注释 */


#endif