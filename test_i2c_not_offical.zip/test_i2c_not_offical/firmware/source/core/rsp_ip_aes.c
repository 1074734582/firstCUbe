/**
 * @file rsp_ip_aes.c
 * @brief AES hardware driver (based on aes.xlsx register map)
 *        Support ECB / CBC / CFB / OFB / CTR / XTS / CMAC / CBC_MAC / CCM / GCM
 */

#include "rsp_ip_aes.h"

#ifdef RSP_USE_DMA_PERF
#include "rsp_hal_dma.h"
#include "rsp_hal_misc.h"   /* rsp_hal_get_us() */
#include <stdio.h>
#endif

/* ============================================================
 *  Core inline helpers (zero call overhead, compiler -O2 fully expands)
 * ============================================================ */

/**
 * @brief Write a 128bit(16-byte) entry to IFIFO
 * @note  AES IFIFO/OFIFO only support base address access (IFIFO[0..3]/OFIFO[0..3]),
 *        do NOT use indexed addressing. Fixed write to base address, FIFO auto-push.
 */
static inline void AES_WriteIFIFO_128(const uint8_t *pData, uint32_t blk)
{
    (void)blk;
    const uint32_t *w = (const uint32_t *)pData;
    AES_IP->IFIFO[0] = w[0];
    AES_IP->IFIFO[1] = w[1];
    AES_IP->IFIFO[2] = w[2];
    AES_IP->IFIFO[3] = w[3];
}

/**
 * @brief Read a 128bit(16-byte) entry from OFIFO
 * @note  Fixed read from base address OFIFO[0..3], FIFO auto-pop oldest entry.
 */
static inline void AES_ReadOFIFO_128(uint8_t *pData, uint32_t blk)
{
    (void)blk;
    uint32_t *w = (uint32_t *)pData;
    w[0] = AES_IP->OFIFO[0];
    w[1] = AES_IP->OFIFO[1];
    w[2] = AES_IP->OFIFO[2];
    w[3] = AES_IP->OFIFO[3];
}

/**
 * @brief AES IP soft reset: disable core, clear config, clear FIFO
 * @note  0x10(PKG_LEN_CUR)/0x18(PKG_POS) are RW registers (confirmed by aes.xlsx and ECB test).
 *        FIFO clear uses CFG@0x08 bit28 (W1SC).
 */
static void aes_ip_reset(void)
{
    volatile uint32_t *base = (volatile uint32_t *)AES_IP_BASE;

    /* 1. Disable core first */
    base[0x1C / 4] = 0U;

    /* 2. Clear config registers */
    base[0x04 / 4] = 0U;   /* INTR        */
    base[0x08 / 4] = 0U;   /* CFG         */
    base[0x0C / 4] = 0U;   /* PKG_LEN_ALL */
    base[0x10 / 4] = 0U;   /* PKG_LEN_CUR */
    base[0x14 / 4] = 0U;   /* AAD_LEN     */
    base[0x18 / 4] = 0U;   /* PKG_POS     */

    /* 3. FIFO state clear: write bit28, wait, write 0 to restore */
    base[0x08 / 4] = AES_CFG_FIFO_STATE_CLEAR;
    for (volatile int d = 0; d < 2000; d++);
    base[0x08 / 4] = 0U;
}

/**
 * @brief Read remaining results from OFIFO
 */
static RSP_StatusTypeDef aes_read_remaining(uint8_t *out, uint32_t *rd_cnt, uint32_t blk_cnt)
{
    uint32_t timeout;
    for (; *rd_cnt < blk_cnt; (*rd_cnt)++)
    {
        timeout = AES_POLL_TIMEOUT;
        while ((AES_IP->STATE & AES_STATE_OFIFO_CNT_Msk) == 0U)
        {
            if (--timeout == 0U) { AES_IP->CFG = 0U; return RSP_ERR_FIFO; }
        }
        AES_ReadOFIFO_128(out + (*rd_cnt) * AES_BLOCK_BYTE_LEN, *rd_cnt);
    }
    return RSP_OK;
}

/* ============================================================
 *  Unified AES hardware processing entry
 * ============================================================ */
static RSP_StatusTypeDef aes_hw_process(aes_ctx_t *ctx)
{
    RSP_StatusTypeDef ret;
    uint32_t cfg_val;
    uint32_t blk_cnt;
    uint32_t i;
    uint32_t timeout;

    if ((ctx == NULL) || (ctx->key == NULL) ||
        (ctx->in == NULL) || (ctx->in_len == 0U))
    {
        return RSP_ERR_NULL_PTR;
    }
    /* MAC modes (CMAC/CBC-MAC) don't need out buffer for verify */
    if ((ctx->key_len != 16U) && (ctx->key_len != 24U) && (ctx->key_len != 32U))
    {
        return RSP_ERR_INVALID_PARAM;
    }
    if ((ctx->in_len % AES_BLOCK_BYTE_LEN) != 0U)
    {
        return RSP_ERR_INVALID_PARAM;
    }

    aes_ip_reset();

    cfg_val = 0U;

    switch (ctx->mode)
    {
    /* -------------------- ECB -------------------- */
    case AES_MODE_ECB:
    {
        uint32_t pre;
        uint32_t rd_cnt = 0U;

        /* AES ENCDEC: 0=encrypt, 1=decrypt (OPPOSITE to SM4!) */
        cfg_val = AES_SER_TYPE_ECB |
                  (ctx->key_len << AES_CFG_KEY_LEN_Pos) |
                  AES_PKG_FULL;
        if (!ctx->is_encrypt)
            cfg_val |= AES_CFG_ENCDEC;

        /* Configure IFIFO threshold: PROG_FULL=7, PROG_EMPTY=1 */
        AES_IP->INTR = (7U << AES_INTR_IFIFO_PROG_FULL_THRESH_Pos) |
                       (1U << AES_INTR_IFIFO_PROG_EMPTY_THRESH_Pos);

        AES_IP->CFG = cfg_val;
        AES_IP->PKG_LEN_ALL = ctx->key_len + ctx->in_len;
        AES_IP->PKG_LEN_CUR = ctx->key_len + ctx->in_len;

        blk_cnt = ctx->in_len / AES_BLOCK_BYTE_LEN;

        /* Preload: key + first min(blk_cnt, DEPTH-1) message blocks (before ENABLE)
         * Use IFIFO_FULL (true full) to fill up to 8 entries without overflow */
        {
            uint32_t key_blk = ctx->key_len / AES_BLOCK_BYTE_LEN;
            uint8_t key_pad[32] = {0};
            memcpy(key_pad, ctx->key, ctx->key_len);
            for (i = 0U; i < key_blk; i++)
                AES_WriteIFIFO_128(key_pad + i * AES_BLOCK_BYTE_LEN, i);
        }
        pre = (blk_cnt > (AES_IFIFO_DEPTH - 1U)) ? (AES_IFIFO_DEPTH - 1U) : blk_cnt;
        for (i = 0U; i < pre; i++)
        {
            timeout = AES_POLL_TIMEOUT;
            while ((AES_IP->STATE & AES_STATE_IFIFO_FULL) != 0U)
            {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            AES_WriteIFIFO_128(ctx->in + i * AES_BLOCK_BYTE_LEN, i + 1U);
        }

        /* Start core */
        AES_IP->ENABLE = 1U;

        /* Streaming write remaining message: PROG_FULL(7) backpressure + alternating OFIFO read */
        for (i = pre; i < blk_cnt; i++)
        {
            timeout = AES_POLL_TIMEOUT;
            while ((AES_IP->STATE & AES_STATE_IFIFO_PROG_FULL) != 0U)
            {
                if ((AES_IP->STATE & AES_STATE_OFIFO_CNT_Msk) != 0U)
                {
                    AES_ReadOFIFO_128(ctx->out + rd_cnt * AES_BLOCK_BYTE_LEN, rd_cnt);
                    rd_cnt++;
                    timeout = AES_POLL_TIMEOUT;
                }
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            AES_WriteIFIFO_128(ctx->in + i * AES_BLOCK_BYTE_LEN, i + 1U);
        }

        ret = aes_read_remaining(ctx->out, &rd_cnt, blk_cnt);
        if (ret != RSP_OK) goto err;
        break;
    }

    /* -------------------- CBC / CFB / OFB / CTR -------------------- */
    case AES_MODE_CBC:
    case AES_MODE_CTR:
    {
        uint32_t pre;
        uint32_t rd_cnt = 0U;
        uint32_t ser_type;

        if (ctx->iv == NULL)
            return RSP_ERR_NULL_PTR;

        switch (ctx->mode)
        {
        case AES_MODE_CBC: ser_type = AES_SER_TYPE_CBC; break;
        case AES_MODE_CTR: ser_type = AES_SER_TYPE_CTR; break;
        default: return RSP_ERR_INVALID_PARAM;
        }

        cfg_val = ser_type |
                  (ctx->key_len << AES_CFG_KEY_LEN_Pos) |
                  AES_PKG_FULL;
        /* CBC/CFB decryption: ENCDEC=1; OFB/CTR: XOR symmetric, no ENCDEC */
        if (!ctx->is_encrypt && (ctx->mode == AES_MODE_CBC))
            cfg_val |= AES_CFG_ENCDEC;

        AES_IP->INTR = (7U << AES_INTR_IFIFO_PROG_FULL_THRESH_Pos) |
                       (1U << AES_INTR_IFIFO_PROG_EMPTY_THRESH_Pos);

        AES_IP->CFG = cfg_val;
        AES_IP->PKG_LEN_ALL = ctx->key_len + AES_IV_BYTE_LEN + ctx->in_len;
        AES_IP->PKG_LEN_CUR = ctx->key_len + AES_IV_BYTE_LEN + ctx->in_len;

        blk_cnt = ctx->in_len / AES_BLOCK_BYTE_LEN;

        /* Preload: key + IV + first min(blk_cnt, DEPTH-2) message blocks */
        {
            uint32_t key_blk = ctx->key_len / AES_BLOCK_BYTE_LEN;
            uint8_t key_pad[32] = {0};
            memcpy(key_pad, ctx->key, ctx->key_len);
            for (i = 0U; i < key_blk; i++)
                AES_WriteIFIFO_128(key_pad + i * AES_BLOCK_BYTE_LEN, i);
        }
        AES_WriteIFIFO_128(ctx->iv, 1U);
        pre = (blk_cnt > (AES_IFIFO_DEPTH - 2U)) ? (AES_IFIFO_DEPTH - 2U) : blk_cnt;
        for (i = 0U; i < pre; i++)
        {
            timeout = AES_POLL_TIMEOUT;
            while ((AES_IP->STATE & AES_STATE_IFIFO_FULL) != 0U)
            {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            AES_WriteIFIFO_128(ctx->in + i * AES_BLOCK_BYTE_LEN, i + 2U);
        }

        AES_IP->ENABLE = 1U;

        for (i = pre; i < blk_cnt; i++)
        {
            timeout = AES_POLL_TIMEOUT;
            while ((AES_IP->STATE & AES_STATE_IFIFO_PROG_FULL) != 0U)
            {
                if ((AES_IP->STATE & AES_STATE_OFIFO_CNT_Msk) != 0U)
                {
                    AES_ReadOFIFO_128(ctx->out + rd_cnt * AES_BLOCK_BYTE_LEN, rd_cnt);
                    rd_cnt++;
                    timeout = AES_POLL_TIMEOUT;
                }
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            AES_WriteIFIFO_128(ctx->in + i * AES_BLOCK_BYTE_LEN, i + 2U);
        }

        ret = aes_read_remaining(ctx->out, &rd_cnt, blk_cnt);
        if (ret != RSP_OK) goto err;
        break;
    }

    /* -------------------- XTS -------------------- */

    /* -------------------- CCM -------------------- */

    /* -------------------- GCM -------------------- */
    case AES_MODE_GCM:
    {
        uint32_t rd_cnt = 0U;
        uint32_t blk_cnt = ctx->in_len / AES_BLOCK_BYTE_LEN;
        uint32_t aad_blk = (ctx->aad_len > 0U) ? ((ctx->aad_len + 15U) / 16U) : 0U;
        uint8_t tag_buf[16] = {0};
        int tag_cached = 0;
        uint8_t mid_tag[16] = {0};
        uint8_t tag2_pad[16] = {0};
        uint8_t iv_buf[16] = {0};

        if (ctx->iv == NULL)
            return RSP_ERR_NULL_PTR;
        if (ctx->tag == NULL)
            return RSP_ERR_NULL_PTR;

        /* IV: APP 给 12B nonce, 这里补成完整 J0 = nonce || 0x00000001
         * 与 SM4 GCM 的已验证实现保持一致 */
        memcpy(iv_buf, ctx->iv, 12U);
        iv_buf[15] = 1U;

        /* 注意: AES 的 TAG_LEN 与 SM4 不同, 是字面字节长度(非长度-1编码) */
        cfg_val = AES_SER_TYPE_GCM |
                  (ctx->key_len << AES_CFG_KEY_LEN_Pos) |
                  /* TAG_LEN@19:16: 单位BYTE, 4bit 最大只能写 15。
                   * 实测写 15 → 硬件只输出 15B TAG(第16字节补0, KAT 差最后1字节)。
                   * 写 0 = 16B (mod-16 编码, 4bit 字节长度域表达 16 的唯一方式) */
                  (0U << AES_CFG_TAG_LEN_Pos) |
                  AES_PKG_FULL;
        if (!ctx->is_encrypt)
            cfg_val |= AES_CFG_ENCDEC;

        AES_IP->INTR = (7U << AES_INTR_IFIFO_PROG_FULL_THRESH_Pos) |
                       (1U << AES_INTR_IFIFO_PROG_EMPTY_THRESH_Pos);

        AES_IP->CFG = cfg_val;
        /* PKG_LEN_ALL = GCM 长度块里的消息长度(只算 message),
         * PKG_LEN_CUR = 本包 IFIFO 实际消费的字节数(含 key/IV/MID_TAG/TAG2/AAD/msg)。
         * 两个寄存器语义不同: 之前都写成总包长, 会让 GHASH 的
         * [len(C)]64 变成 80B*8, TAG 与标准 GCM 不符(密文仍正确) */
        AES_IP->PKG_LEN_ALL = ctx->in_len;
        AES_IP->PKG_LEN_CUR = ctx->key_len + AES_IV_BYTE_LEN + 16U + 16U + (aad_blk * 16U) + ctx->in_len;
        /* AAD_LEN 必须是补零对齐后的字节数, 写原始未对齐长度会让硬件
         * 消费字节数不匹配, GHASH 边界错位 (与 SM4 一致) */
        AES_IP->AAD_LEN = aad_blk * 16U;

        /* Preload header: key + IV + MID_TAG + TAG2 */
        {
            uint32_t key_blk = ctx->key_len / AES_BLOCK_BYTE_LEN;
            uint8_t key_pad[32] = {0};
            memcpy(key_pad, ctx->key, ctx->key_len);
            for (i = 0U; i < key_blk; i++)
                AES_WriteIFIFO_128(key_pad + i * AES_BLOCK_BYTE_LEN, i);
        }
        AES_WriteIFIFO_128(iv_buf, 1U);
        AES_WriteIFIFO_128(mid_tag, 2U);
        if (!ctx->is_encrypt)
            memcpy(tag2_pad, ctx->tag, 16U);
        AES_WriteIFIFO_128(tag2_pad, 3U);

        {
            uint32_t header_blk = (ctx->key_len / AES_BLOCK_BYTE_LEN) + 3U;
            /* IFIFO 深度 8: ENABLE 前最多再灌 (DEPTH - header) 块 AAD,
             * 超过的部分放到 ENABLE 后靠 PROG_FULL 反压流式灌,
             * 否则第 9 块会卡在 IFIFO_FULL(GHASH 未启动, FULL 永不解除) */
            uint32_t room = (AES_IFIFO_DEPTH > header_blk) ? (AES_IFIFO_DEPTH - header_blk) : 0U;
            uint32_t aad_pre = (aad_blk > room) ? room : aad_blk;
            uint32_t aad_rem = aad_blk - aad_pre;
            uint32_t pre;

            /* AAD (ENABLE 前) */
            for (i = 0U; i < aad_pre; i++)
            {
                uint8_t aad_pad[16] = {0};
                uint32_t copy_len = (ctx->aad_len - i * 16U > 16U) ? 16U : (ctx->aad_len - i * 16U);
                memcpy(aad_pad, ctx->aad + i * 16U, copy_len);
                AES_WriteIFIFO_128(aad_pad, header_blk + i);
            }

            /* message 一律在 ENABLE 后流式写入, ENABLE 前只放 header + AAD。
             * 与 SM4 已验证实现一致: ENABLE 前混入 message 块会让 GHASH 把
             * 它当 AAD 参与认证, 导致密文正确但 TAG 与标准 GCM 不符 */
            pre = 0U;

            AES_IP->ENABLE = 1U;

            /* ENABLE 后流式灌剩余 AAD: GHASH 按 AAD_LEN 寄存器界限消费 */
            for (i = 0U; i < aad_rem; i++)
            {
                uint8_t aad_pad[16] = {0};
                uint32_t idx = aad_pre + i;
                uint32_t copy_len = (ctx->aad_len - idx * 16U > 16U) ? 16U : (ctx->aad_len - idx * 16U);
                memcpy(aad_pad, ctx->aad + idx * 16U, copy_len);
                timeout = AES_POLL_TIMEOUT;
                while ((AES_IP->STATE & AES_STATE_IFIFO_PROG_FULL) != 0U)
                {
                    if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
                }
                AES_WriteIFIFO_128(aad_pad, header_blk + idx);
            }

            /* Streaming write remaining message */
            for (i = pre; i < blk_cnt; i++)
            {
                timeout = AES_POLL_TIMEOUT;
                while ((AES_IP->STATE & AES_STATE_IFIFO_PROG_FULL) != 0U)
                {
                    if ((AES_IP->STATE & AES_STATE_OFIFO_CNT_Msk) != 0U)
                    {
                        if (rd_cnt < blk_cnt)
                        {
                            AES_ReadOFIFO_128(ctx->out + rd_cnt * AES_BLOCK_BYTE_LEN, rd_cnt);
                            rd_cnt++;
                        }
                        else if (!tag_cached)
                        {
                            AES_ReadOFIFO_128(tag_buf, 0);
                            tag_cached = 1;
                        }
                        timeout = AES_POLL_TIMEOUT;
                    }
                    if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
                }
                AES_WriteIFIFO_128(ctx->in + i * AES_BLOCK_BYTE_LEN, header_blk + aad_blk + i);
            }
        }

        /* Read remaining results */
        ret = aes_read_remaining(ctx->out, &rd_cnt, blk_cnt);
        if (ret != RSP_OK) goto err;

        /* Read TAG */
        if (!tag_cached)
        {
            timeout = AES_POLL_TIMEOUT;
            while ((AES_IP->STATE & AES_STATE_OFIFO_CNT_Msk) == 0U)
            {
                if (--timeout == 0U) { ret = RSP_ERR_FIFO; goto err; }
            }
            AES_ReadOFIFO_128(tag_buf, 0U);
        }

        if (ctx->is_encrypt)
        {
            memcpy(ctx->tag, tag_buf, 16U);
        }
        else
        {
            uint8_t all_ff = 1U;
            for (i = 0U; i < 16U; i++)
            {
                if (tag_buf[i] != 0xFFU) { all_ff = 0U; break; }
            }
            if (!all_ff) { ret = RSP_ERR_DATA_CHECK; goto err; }
        }
        break;
    }

    default:
        return RSP_ERR_INVALID_PARAM;
    }

    AES_IP->CFG = 0U;
    return RSP_OK;

err:
    AES_IP->CFG = 0U;
    return ret;
}

#ifdef RSP_USE_DMA_PERF
/* ============================================================
 *  AES DMA 路径
 *
 *  说明: 原 DMA 实现已删除, 当前统一回退 CPU 流式路径
 *        (aes_hw_process), 保证 RSP_USE_DMA_PERF=1 时也有正确结果。
 * ============================================================ */
RSP_StatusTypeDef aes_hw_process_dma(aes_ctx_t *ctx)
{
    return aes_hw_process(ctx);
}
#endif /* RSP_USE_DMA_PERF */

/* ============================================================
 *  Public API wrappers
 * ============================================================ */

/* ---- 参数校验辅助: 打印 LOG 并返回错误码 ---- */
static RSP_StatusTypeDef aes_param_null_err(const char *algo, const char *param)
{
    printf("[AES %s] %s_null_err\n", algo, param);
    return RSP_ERR_NULL_PTR;
}

static RSP_StatusTypeDef aes_param_len_err(const char *algo, const char *param,
                                           uint32_t got, const char *expect)
{
    printf("[AES %s] %s_len_err: got=%lu expect=%s\n", algo, param,
           (unsigned long)got, expect);
    return RSP_ERR_INVALID_PARAM;
}

RSP_StatusTypeDef aes_ecb(const uint8_t *key, uint32_t key_len,
                          const uint8_t *in, uint8_t *out, uint32_t len, int is_encrypt)
{
    aes_ctx_t ctx = {
        .mode = AES_MODE_ECB, .key = key, .key_len = key_len,
        .iv = NULL, .aad = NULL, .aad_len = 0,
        .in = in, .out = out, .in_len = len,
        .tag = NULL, .is_encrypt = is_encrypt
    };

    /* ---- 参数校验 ---- */
    if (key == NULL)   return aes_param_null_err("ECB", "key");
    if (in == NULL)    return aes_param_null_err("ECB", "in");
    if (out == NULL)   return aes_param_null_err("ECB", "out");
    if ((key_len != 16U) && (key_len != 24U) && (key_len != 32U))
        return aes_param_len_err("ECB", "key_len", key_len, "16/24/32");
    if (len == 0U)
        return aes_param_len_err("ECB", "msg", len, ">0");
    if ((len % AES_BLOCK_BYTE_LEN) != 0U)
        return aes_param_len_err("ECB", "msg", len, "N*16");

#if RSP_USE_DMA_PERF
    return aes_hw_process_dma(&ctx);
#else
    return aes_hw_process(&ctx);
#endif
}

RSP_StatusTypeDef aes_cbc(const uint8_t *key, uint32_t key_len,
                          const uint8_t *iv,
                          const uint8_t *in, uint8_t *out, uint32_t len, int is_encrypt)
{
    aes_ctx_t ctx = {
        .mode = AES_MODE_CBC, .key = key, .key_len = key_len,
        .iv = iv, .aad = NULL, .aad_len = 0,
        .in = in, .out = out, .in_len = len,
        .tag = NULL, .is_encrypt = is_encrypt
    };

    /* ---- 参数校验 ---- */
    if (key == NULL)   return aes_param_null_err("CBC", "key");
    if (iv == NULL)    return aes_param_null_err("CBC", "iv");
    if (in == NULL)    return aes_param_null_err("CBC", "in");
    if (out == NULL)   return aes_param_null_err("CBC", "out");
    if ((key_len != 16U) && (key_len != 24U) && (key_len != 32U))
        return aes_param_len_err("CBC", "key_len", key_len, "16/24/32");
    if (len == 0U)
        return aes_param_len_err("CBC", "msg", len, ">0");
    if ((len % AES_BLOCK_BYTE_LEN) != 0U)
        return aes_param_len_err("CBC", "msg", len, "N*16");

#if RSP_USE_DMA_PERF
    return aes_hw_process_dma(&ctx);
#else
    return aes_hw_process(&ctx);
#endif
}

RSP_StatusTypeDef aes_ctr(const uint8_t *key, uint32_t key_len,
                          const uint8_t *iv,
                          const uint8_t *in, uint8_t *out, uint32_t len, int is_encrypt)
{
    aes_ctx_t ctx = {
        .mode = AES_MODE_CTR, .key = key, .key_len = key_len,
        .iv = iv, .aad = NULL, .aad_len = 0,
        .in = in, .out = out, .in_len = len,
        .tag = NULL, .is_encrypt = is_encrypt
    };

    /* ---- 参数校验 ---- */
    if (key == NULL)   return aes_param_null_err("CTR", "key");
    if (iv == NULL)    return aes_param_null_err("CTR", "iv");
    if (in == NULL)    return aes_param_null_err("CTR", "in");
    if (out == NULL)   return aes_param_null_err("CTR", "out");
    if ((key_len != 16U) && (key_len != 24U) && (key_len != 32U))
        return aes_param_len_err("CTR", "key_len", key_len, "16/24/32");
    if (len == 0U)
        return aes_param_len_err("CTR", "msg", len, ">0");
    if ((len % AES_BLOCK_BYTE_LEN) != 0U)
        return aes_param_len_err("CTR", "msg", len, "N*16");

#if RSP_USE_DMA_PERF
    return aes_hw_process_dma(&ctx);
#else
    return aes_hw_process(&ctx);
#endif
}




RSP_StatusTypeDef aes_gcm(const uint8_t *key, uint32_t key_len,
                          const uint8_t *iv,
                          const uint8_t *aad, uint32_t aad_len,
                          const uint8_t *in, uint8_t *out, uint32_t len,
                          uint8_t *tag, int is_encrypt)
{
    aes_ctx_t ctx;
    uint32_t t_start, t_end, us, mbps, mbps_frac, mbs, frac;
    RSP_StatusTypeDef r;

    /* ---- 参数校验 ---- */
    if (key == NULL)   return aes_param_null_err("GCM", "key");
    if (iv == NULL)    return aes_param_null_err("GCM", "iv");
    if ((aad_len != 0U) && (aad == NULL))
        return aes_param_null_err("GCM", "aad");
    if (in == NULL)    return aes_param_null_err("GCM", "in");
    if (out == NULL)   return aes_param_null_err("GCM", "out");
    if (tag == NULL)   return aes_param_null_err("GCM", "tag");
    if ((key_len != 16U) && (key_len != 24U) && (key_len != 32U))
        return aes_param_len_err("GCM", "key_len", key_len, "16/24/32");
    if (len == 0U)
        return aes_param_len_err("GCM", "msg", len, ">0");
    if ((len % AES_BLOCK_BYTE_LEN) != 0U)
        return aes_param_len_err("GCM", "msg", len, "N*16");

    /* header(key+IV+MID_TAG+TAG2) 在 ENABLE 前灌, 超出 IFIFO 深度的 AAD
     * 由 aes_hw_process 在 ENABLE 后靠 PROG_FULL 流式灌, 因此 AAD 长度不受限 */

    memset(&ctx, 0, sizeof(ctx));
    ctx.mode = AES_MODE_GCM; ctx.key = key; ctx.key_len = key_len;
    ctx.iv = iv; ctx.aad = aad; ctx.aad_len = aad_len;
    ctx.in = in; ctx.out = out; ctx.in_len = len;
    ctx.tag = tag; ctx.is_encrypt = is_encrypt;

    /* DMA 路径(aes_hw_process_dma)目前为空壳, 统一走 CPU 流式路径 */
    t_start = rsp_hal_get_us();
    r = aes_hw_process(&ctx);
    t_end = rsp_hal_get_us();

    us = (t_end > t_start) ? (t_end - t_start) : 1U;
    if (us < 10U) us = 10U;
    mbps      = (uint32_t)(((uint64_t)len * 8ULL) / us);
    mbps_frac = (uint32_t)(((uint64_t)len * 8ULL * 1000ULL / us) % 1000ULL);
    mbs       = (uint32_t)((uint64_t)len / us);
    frac      = (uint32_t)(((uint64_t)len * 1000ULL / us) % 1000ULL);
    /* 性能打印已屏蔽 */
    (void)us; (void)mbps; (void)mbps_frac; (void)mbs; (void)frac;

    return r;
}
