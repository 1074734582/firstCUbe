/**
 * @file rsp_ip_chacha20.h
 * @brief ChaCha20-Poly1305 硬件 IP 驱动（基于 chacha20.xlsx / chacha20_输入输出数据格式.xlsx）
 *        加密/解密、AAD 认证、TAG 校验，支持整包与流式大数据
 */
#ifndef __RSP_IP_CHACHA20_H__
#define __RSP_IP_CHACHA20_H__

#include "rsp_ip_common.h"
#include <string.h>

/* ============================================================
 *  基地址
 * ============================================================ */
#define CHACHA20_IP_BASE (0x80080000UL)
#define CHACHA20_IP ((ChaCha20_TypeDef *)CHACHA20_IP_BASE)

/* ============================================================
 *  寄存器结构体（依据 chacha20.xlsx 寄存器表）
 *
 *  偏移     寄存器      宽度     说明
 *  0x00     STATE       32bit    状态/中断寄存器 (RO)
 *  0x04     INTR        32bit    中断配置/阈值 (RW)
 *  0x08     ADD_LEN     32bit    AAD 实际字节数
 *  0x0C     DATA_LEN    32bit    数据实际字节数
 *  0x10     START_CNT   32bit    初始计数器（RFC 标准=1）
 *  0x14     CFG         32bit    配置寄存器（START/MODE）
 *  0x18~    IFIFO       128bit   输入FIFO, 深度8, 写窗口 0x18~0x88
 *  0x98~    OFIFO       128bit   输出FIFO, 深度8, 读窗口 0x98~0x108
 * ============================================================ */
typedef struct
{
    __IO uint32_t STATE;          /*!< 0x00 RO: 状态/中断寄存器              */
    __IO uint32_t INTR;           /*!< 0x04 RW: 中断配置 + FIFO 阈值          */
    __IO uint32_t ADD_LEN;        /*!< 0x08 RW: AAD 实际字节数（0=无AAD）     */
    __IO uint32_t DATA_LEN;       /*!< 0x0C RW: 数据实际字节数（0=空数据）    */
    __IO uint32_t START_CNT;      /*!< 0x10 RW: 初始计数器（RFC 标准=1）      */
    __IO uint32_t CFG;            /*!< 0x14 RW: 配置寄存器（START/MODE）      */
    __O  uint32_t IFIFO[28];      /*!< 0x18~0x87 WO: 输入FIFO 写窗口 0x18~0x88 */
    __IO uint32_t RESERVED[4];    /*!< 0x88~0x97 保留                         */
    __I  uint32_t OFIFO[28];      /*!< 0x98~0x107 RO: 输出FIFO 读窗口 0x98~0x108 */
} ChaCha20_TypeDef;

/* ============================================================
 *  STATE 寄存器 (0x00) 位定义
 * ============================================================ */
#define CHACHA20_STATE_IFIFO_FULL (1U << 0)         /*!< IFIFO满状态 */
#define CHACHA20_STATE_IFIFO_EMPTY (1U << 1)        /*!< IFIFO空状态 */
#define CHACHA20_STATE_IFIFO_PROG_FULL (1U << 2)    /*!< IFIFO阈满状态 */
#define CHACHA20_STATE_IFIFO_PROG_EMPTY (1U << 3)   /*!< IFIFO阈空状态 */
#define CHACHA20_STATE_OFIFO_FULL (1U << 4)         /*!< OFIFO满状态 */
#define CHACHA20_STATE_OFIFO_EMPTY (1U << 5)        /*!< OFIFO空状态 */
#define CHACHA20_STATE_OFIFO_PROG_FULL (1U << 6)    /*!< OFIFO阈满状态 */
#define CHACHA20_STATE_OFIFO_PROG_EMPTY (1U << 7)   /*!< OFIFO阈空状态 */
#define CHACHA20_STATE_IFIFO_CNT_Pos (8U)
#define CHACHA20_STATE_IFIFO_CNT_Msk (0xFFU << 8)   /*!< IFIFO当前数据深度 */
#define CHACHA20_STATE_OFIFO_CNT_Pos (16U)
#define CHACHA20_STATE_OFIFO_CNT_Msk (0xFFU << 16)  /*!< OFIFO当前数据深度 */

/* ============================================================
 *  INTR 寄存器 (0x04) 位定义
 * ============================================================ */
#define CHACHA20_INTR_EN (1U << 0)                        /*!< 全局中断使能 */
#define CHACHA20_INTR_MASK_Pos (8U)
#define CHACHA20_INTR_MASK_Msk (0xFFU << 8)               /*!< 中断屏蔽，低有效 */
#define CHACHA20_INTR_CLRER (1U << 16)                    /*!< W1SC 清除全局中断 */
#define CHACHA20_INTR_IFIFO_STATE_CLEAR (1U << 17)        /*!< W1SC FIFO状态清零 */
#define CHACHA20_INTR_IFIFO_PROG_FULL_THRESH_Pos (20U)
#define CHACHA20_INTR_IFIFO_PROG_FULL_THRESH_Msk (0x7U << 20)
#define CHACHA20_INTR_IFIFO_PROG_EMPTY_THRESH_Pos (23U)
#define CHACHA20_INTR_IFIFO_PROG_EMPTY_THRESH_Msk (0x7U << 23)
#define CHACHA20_INTR_OFIFO_PROG_FULL_THRESH_Pos (26U)
#define CHACHA20_INTR_OFIFO_PROG_FULL_THRESH_Msk (0x7U << 26)
#define CHACHA20_INTR_OFIFO_PROG_EMPTY_THRESH_Pos (29U)
#define CHACHA20_INTR_OFIFO_PROG_EMPTY_THRESH_Msk (0x7U << 29)

/* ============================================================
 *  CFG 寄存器 (0x14) 位定义
 * ============================================================ */
#define CHACHA20_CFG_START (1U << 0)                      /*!< bit0 W1SC 算核开始 */
#define CHACHA20_CFG_MODE_Pos (8U)
#define CHACHA20_CFG_MODE_Msk (0x3U << 8)                 /*!< bit[9:8] 00=加密 01=解密 */
#define CHACHA20_CFG_MODE_ENC (0U << 8)
#define CHACHA20_CFG_MODE_DEC (1U << 8)

/* ============================================================
 *  OFIFO 状态字 (第 3 拍) 位定义
 * ============================================================ */
#define CHACHA20_STATUS_AUTH_PASS (1U << 0)               /*!< 认证结果：解密 1通过/0失败, 加密恒1 */
#define CHACHA20_STATUS_ERR_Pos (1U)
#define CHACHA20_STATUS_ERR_Msk (0x7U << 1)               /*!< 000无/001长度/010溢出/011非法mode/100内部/101超时 */

/* ============================================================
 *  常量定义
 * ============================================================ */
#define CHACHA20_KEY_BYTE_LEN (32U)      /*!< 密钥 256bit */
#define CHACHA20_NONCE_BYTE_LEN (12U)    /*!< nonce 96bit */
#define CHACHA20_TAG_BYTE_LEN (16U)      /*!< 认证 tag 128bit */
#define CHACHA20_ENTRY_BYTE_LEN (16U)    /*!< FIFO 条目宽度 128bit */
#define CHACHA20_IFIFO_DEPTH (8U)        /*!< IFIFO 深度 8×128bit */

#define CHACHA20_DEFAULT_START_CNT (1U)  /*!< RFC 8439 标准初始计数器 */
#define CHACHA20_POLL_TIMEOUT (1000000U)

/* IFIFO 映像缓冲容量：容纳 key(2)+nonce(1)+AAD+message+tag 的全部拍 */
#define CHACHA20_IMG_MAX_BYTE (4096U)

/* ============================================================
 *  类型定义
 * ============================================================ */
typedef struct
{
    const uint8_t *key;         /*!< 密钥 32B */
    const uint8_t *nonce;       /*!< nonce 12B */
    const uint8_t *aad;         /*!< 附加认证数据（可为 NULL） */
    uint32_t aad_len;           /*!< AAD 长度，0=无AAD */
    const uint8_t *in;          /*!< 输入：明文(加密)/密文(解密) */
    uint32_t in_len;            /*!< 输入长度 */
    uint8_t *out;               /*!< 输出：密文(加密)/明文(解密)，in_len 字节 */
    uint8_t *tag;               /*!< 加密：输出 tag；解密：输入待验证 tag */
    uint32_t start_cnt;         /*!< 初始计数器，0=默认 1 */
    int is_encrypt;             /*!< 1=加密 0=解密 */
} chacha20_ctx_t;

/* ============================================================
 *  API 函数
 * ============================================================ */

/**
 * @brief ChaCha20-Poly1305 硬件运算（自动选择整包/流式）
 * @param ctx 上下文
 * @return RSP_OK / RSP_ERR_xxx；解密认证失败返回 RSP_ERR_DATA_CHECK
 */
RSP_StatusTypeDef chacha20_hw(chacha20_ctx_t *ctx);

/**
 * @brief ChaCha20-Poly1305 便捷接口（对应软件中间件 chacha20_poly1305_encrypt/decrypt）
 * @param key      32B 密钥
 * @param nonce    12B nonce
 * @param aad      附加认证数据（aad_len=0 时可为 NULL）
 * @param aad_len  AAD 长度
 * @param in       输入明文(加密)/密文(解密)
 * @param in_len   输入长度
 * @param out      输出密文(加密)/明文(解密)，in_len 字节（in_len=0 时可为 NULL）
 * @param tag      加密：输出 tag；解密：输入待验证 tag
 * @param is_encrypt 1=加密 0=解密
 * @return RSP_OK / RSP_ERR_xxx
 */
RSP_StatusTypeDef chacha20_poly1305_hw(const uint8_t *key, const uint8_t *nonce,
                                       const uint8_t *aad, uint32_t aad_len,
                                       const uint8_t *in, uint32_t in_len,
                                       uint8_t *out, uint8_t *tag, int is_encrypt);

#endif /* __RSP_IP_CHACHA20_H__ */
