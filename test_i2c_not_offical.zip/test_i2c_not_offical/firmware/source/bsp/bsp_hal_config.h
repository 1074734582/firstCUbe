#ifndef __BSP_HAL_CONFIG_H__
#define __BSP_HAL_CONFIG_H__

#define  PKPU_RAM_SIZE 	(0x8FFFF)

RAMFUNC void PQC_IRQHandler(void);

void uart_init(void);

int pkpu_reset(void);
int pkpu_ram_clear(void);

#endif
