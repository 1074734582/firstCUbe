#include "bsp.h"

void TIMER_1_IRQHandler(void)
{
    uint32_t status = 0;
    status = rsp_hal_tim_get_interrupt_status(RSP_TIM_1);
    (void)status;


	printf("i am TIMER_1_IRQHandler\n");
    rsp_hal_tim_clear_interrupt_flag(RSP_TIM_1);
		
    rsp_hal_tim_clear_interrupt_status();
}



/* printf retarget */
#if defined(__CC_ARM) || defined(__ICCARM__)
RAMFUNC int fputc(int ch, FILE *f)
{
    /* UART1(0x30002000) 即硬件文档的 UART0; UART2(0x30003000) 本位流未挂载, 不再写 */
	rsp_hal_uart_send_data_ramfunc(UART1, (uint32_t)ch);
    return ch;
}
#elif defined(__GNUC__)
RAMFUNC int _write(int file, char *ptr, int len)
{
    int i;
	
    for (i = 0; i < len; i++)
    {
		rsp_hal_uart_send_data_ramfunc(UART1, (uint32_t)ptr[i]);
    }

    return len;
}
#endif

void uart_init(void)
{
    rsp_uart_param_t param;
	
#if defined(ASIC)
//    param.baudrate = 115200;
	param.baudrate = 9600;
#else
    param.baudrate = 9600;
#endif
    param.databits = UART_LCR_DATA_BITS_8;
    param.stopbits = UART_LCR_STOP_BITS_1;
    param.parity = UART_LCR_PARITY_DISABLE;
	
    rsp_hal_uart_init(UART1, &param);   /* 硬件文档 UART0 @0x30002000 */
//	rsp_hal_uart_init(UART2, &param);   /* 硬件文档 UART1 @0x30003000, 本位流未挂载 */
}

void gpio_init(void)
{
    rsp_hal_gpio_set_dir(GPIOA, RSP_GPIO_PIN_7, RSP_GPIO_OUTPUT);
	rsp_hal_gpio_set_pin(GPIOA, RSP_GPIO_PIN_7, RSP_GPIO_LOW);
	rsp_hal_gpio_set_dir(GPIOA, RSP_GPIO_PIN_5, RSP_GPIO_OUTPUT);
	rsp_hal_gpio_set_pin(GPIOA, RSP_GPIO_PIN_5, RSP_GPIO_HIGH);
}


void timer_init(void)
{
    uint32_t count = 0, apbclk = 0;

    apbclk = HSE_VALUE;//rsp_hal_clk_get_apb();

    count = apbclk/1000 * 1; /* 200 msecond timer */
        
    rsp_hal_tim_disable(RSP_TIM_0);
    rsp_hal_tim_set_div(RSP_TIM_0, RSP_TIM_DIV_1);
    
    rsp_hal_tim_set_load_counter(RSP_TIM_0, count);
    rsp_hal_tim_set_counter(RSP_TIM_0, 0);
    
    rsp_hal_tim_enable_irq(RSP_TIM_0);
    rsp_hal_tim_enable(RSP_TIM_0);
    // rsp_hal_nvic_enable_irq(RSP_IRQ_TIME0);
}

