/**
 * @file test_sm4.c
 * @brief SM4 hardware IP DMA perf test — ECB / CBC / CTR / GCM only
 */

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "rsp_ip_sm4.h"
#include "sm4.h" /* 软件参考实现 (CTR 正确性基准) */

/* ============================================================
 *  Big block test config (same as test_aes.c)
 * ============================================================ */
#define SM4_BIG_BLOCKS 100U /* 480 × 16B = 7680B */
#define SM4_BLOCK_LEN 16U
#define SM4_BIG_LEN (SM4_BIG_BLOCKS * SM4_BLOCK_LEN)
#define PRESSURE_TEST 1U /* 压力测试循环次数 */

/* ============================================================
 *  Test data
 * ============================================================ */
static const uint8_t test_key[16] = {
    0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 0xfe, 0xdc, 0xba, 0x98, 0x76, 0x54, 0x32, 0x10};
static const uint8_t test_iv[16] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f};
static const uint8_t test_aad[16] = {
    0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99};

/* 大数据测试缓冲 (7680B) */
static uint8_t big_plain[SM4_BIG_LEN];
static uint8_t big_cipher[SM4_BIG_LEN];
static uint8_t big_dec[SM4_BIG_LEN];

static void fill_pattern(void)
{
    uint32_t i;
    for (i = 0; i < SM4_BIG_LEN; i++)
        big_plain[i] = (uint8_t)(i & 0xFF);
}

/* ============================================================
 *  Input dump (debug)
 * ============================================================ */
#define DUMP_LINE 16U
#define DUMP_MAX 64U /* 每段最多打印64B, 防止刷屏 */

static void rsp_dump_buf(char *info, uint8_t *buf, uint32_t len)
{
    printf("%s[%d]", info, len);
    for (int i = 0; i < len; i++)
    {
        printf("%s0x%02x ", i % 16 == 0 ? "\n     " : " ", buf[i]);
    }
    printf("\n");
}
/* ============================================================
 *  ECB test
 * ============================================================ */
static int test_sm4_ecb(void)
{
    sm4_ctx sctx;
    uint8_t buf[32] = {0};

    fill_pattern();

    sm4_ecb_hw(NULL, 16, buf, buf, 16, 1);
    sm4_ecb_hw(test_key, 15, buf, buf, 16, 1);
    sm4_ecb_hw(test_key, 16, NULL, buf, 16, 1);
    sm4_ecb_hw(test_key, 16, buf, NULL, 16, 1);
    sm4_ecb_hw(test_key, 16, buf, buf, 0, 1);
    sm4_ecb_hw(test_key, 16, buf, buf, 17, 1);

    /* ---- 1. 软件参考: 同 key 对明文做 ECB 加密 ---- */

   
    sm4_setkey_enc(&sctx, (uint8_t *)test_key);
    sm4_ecb(&sctx, SM4_ENCRYPT, big_plain, (int32_t)SM4_BIG_LEN, big_dec);


       /* ---- 2. 硬件加密 ---- */
    
    
    if (sm4_ecb_hw(test_key, SM4_KEY_BYTE_LEN, big_plain, big_cipher,
                   SM4_BIG_LEN, 1) != RSP_OK)
    {
        printf("FAIL (encrypt error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %u x 16B = %uB\n",(unsigned)SM4_BIG_BLOCKS, (unsigned)SM4_BIG_LEN);
  
    rsp_dump_buf("msg", big_plain, SM4_BIG_LEN >DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    rsp_dump_buf("soft output:", big_dec, SM4_BIG_LEN >DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    rsp_dump_buf("hw output:", big_cipher, SM4_BIG_LEN >DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    if (memcmp(big_cipher, big_dec, SM4_BIG_LEN) != 0)
    {
        return -1;
    }
    printf("SM4 ECB ENC PASS\n");

    if (sm4_ecb_hw(test_key, SM4_KEY_BYTE_LEN, big_cipher, big_dec,
                   SM4_BIG_LEN, 0) != RSP_OK)
    {
        printf("FAIL (decrypt error)\n");
        return -1;
    }
    if (memcmp(big_plain, big_dec, SM4_BIG_LEN) != 0)
    {
        printf("FAIL (round-trip mismatch)\n");
        return -1;
    }
    rsp_dump_buf("hw ECB DEC output:", big_dec, SM4_BIG_LEN >DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    printf("SM4 ECB DEC PASS\n");

    return 0;
}

/* ============================================================
 *  CBC test
 * ============================================================ */
static int test_sm4_cbc(void)
{
    sm4_ctx sctx;
    uint8_t iv_soft[16];
    uint8_t buf[32] = {0};

    fill_pattern();

    sm4_cbc_hw(NULL, 16, test_iv, buf, buf, 16, 1);
    sm4_cbc_hw(test_key, 15, test_iv, buf, buf, 16, 1);
    sm4_cbc_hw(test_key, 16, NULL, buf, buf, 16, 1);
    sm4_cbc_hw(test_key, 16, test_iv, NULL, buf, 16, 1);
    sm4_cbc_hw(test_key, 16, test_iv, buf, NULL, 16, 1);
    sm4_cbc_hw(test_key, 16, test_iv, buf, buf, 0, 1);

    /* ---- 1. 软件参考: 同 key/iv 对明文做 CBC 加密 (iv 会被软件实现推进, 用副本) ---- */

    memcpy(iv_soft, test_iv, 16);
    sm4_setkey_enc(&sctx, (uint8_t *)test_key);
    sm4_cbc(&sctx, SM4_ENCRYPT, iv_soft, big_plain,
            (int32_t)SM4_BIG_LEN, big_dec);

    /* ---- 2. 硬件加密 ---- */

    if (sm4_cbc_hw(test_key, SM4_KEY_BYTE_LEN, test_iv, big_plain, big_cipher,
                   SM4_BIG_LEN, 1) != RSP_OK)
    {
        printf("FAIL (encrypt error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %u x 16B = %uB\n", (unsigned)SM4_BIG_BLOCKS, (unsigned)SM4_BIG_LEN);

    rsp_dump_buf("msg", big_plain, SM4_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    rsp_dump_buf("soft output:", big_dec, SM4_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    rsp_dump_buf("hw output:", big_cipher, SM4_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    if (memcmp(big_cipher, big_dec, SM4_BIG_LEN) != 0)
    {
        return -1;
    }
    printf("SM4 CBC ENC PASS\n");

    if (sm4_cbc_hw(test_key, SM4_KEY_BYTE_LEN, test_iv, big_cipher, big_dec,
                   SM4_BIG_LEN, 0) != RSP_OK)
    {
        printf("FAIL (decrypt error)\n");
        return -1;
    }
    if (memcmp(big_plain, big_dec, SM4_BIG_LEN) != 0)
    {
        printf("FAIL (round-trip mismatch)\n");
        return -1;
    }
    rsp_dump_buf("hw CBC DEC output:", big_dec, SM4_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    printf("SM4 CBC DEC PASS\n");

    return 0;
}

/* ============================================================
 *  CTR test
 * ============================================================ */
static int test_sm4_ctr(void)
{
    sm4_ctx sctx;
    uint8_t buf[32] = {0};

    fill_pattern();

    sm4_ctr_hw(NULL, 16, test_iv, buf, buf, 16, 1);
    sm4_ctr_hw(test_key, 15, test_iv, buf, buf, 16, 1);
    sm4_ctr_hw(test_key, 16, NULL, buf, buf, 16, 1);
    sm4_ctr_hw(test_key, 16, test_iv, NULL, buf, 16, 1);
    sm4_ctr_hw(test_key, 16, test_iv, buf, NULL, 16, 1);
    sm4_ctr_hw(test_key, 16, test_iv, buf, buf, 17, 1);

    /* ---- 1. 软件参考: 同 key/iv 对明文做 CTR ---- */
    if (sm4_ctr_init(&sctx, test_key, test_iv) != 0)
    {
        printf("FAIL (soft init)\n");
        return -1;
    }
    if (sm4_ctr_update(&sctx, big_plain, SM4_BIG_LEN, big_dec) != 0)
    {
        printf("FAIL (soft update)\n");
        return -1;
    }

    /* ---- 2. 硬件加密 ---- */
    if (sm4_ctr_hw(test_key, SM4_KEY_BYTE_LEN, test_iv, big_plain, big_cipher,
                   SM4_BIG_LEN, 1) != RSP_OK)
    {
        printf("FAIL (hw encrypt error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %u x 16B = %uB\n", (unsigned)SM4_BIG_BLOCKS, (unsigned)SM4_BIG_LEN);

    rsp_dump_buf("msg", big_plain, SM4_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    rsp_dump_buf("soft output:", big_dec, SM4_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    rsp_dump_buf("hw output:", big_cipher, SM4_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    if (memcmp(big_cipher, big_dec, SM4_BIG_LEN) != 0)
    {
        return -1;
    }
    printf("SM4 CTR ENC PASS\n");

    /* ---- 3. 硬件解密 (CTR 加解密同向) ---- */
    if (sm4_ctr_hw(test_key, SM4_KEY_BYTE_LEN, test_iv, big_cipher, big_dec,
                   SM4_BIG_LEN, 1) != RSP_OK)
    {
        printf("FAIL (hw decrypt error)\n");
        return -1;
    }
    if (memcmp(big_plain, big_dec, SM4_BIG_LEN) != 0)
    {
        printf("FAIL (round-trip mismatch)\n");
        return -1;
    }
    rsp_dump_buf("hw CTR DEC output:", big_dec, SM4_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    printf("SM4 CTR DEC PASS\n");

    return 0;
}

/* ============================================================
 *  GCM big block test (整包流式路径)
 *  软件参考直接用 sm4.c 的 sm4_gcm_encrypt / sm4_gcm_decrypt
 * ============================================================ */
static int test_sm4_gcm(void)
{
    uint8_t tag[16];
    uint8_t sw_tag[16];
    uint8_t tag_tampered[16];
    uint8_t tmp_dec[SM4_BIG_LEN];
    uint8_t buf[32] = {0};
    uint32_t i;

    fill_pattern();

    sm4_gcm_hw(NULL, 16, test_iv, test_aad, 16, buf, buf, 16, tag, 1);
    sm4_gcm_hw(test_key, 15, test_iv, test_aad, 16, buf, buf, 16, tag, 1);
    sm4_gcm_hw(test_key, 16, NULL, test_aad, 16, buf, buf, 16, tag, 1);
    sm4_gcm_hw(test_key, 16, test_iv, test_aad, 16, NULL, buf, 16, tag, 1);
    sm4_gcm_hw(test_key, 16, test_iv, test_aad, 16, buf, NULL, 16, tag, 1);
    sm4_gcm_hw(test_key, 16, test_iv, test_aad, 16, buf, buf, 16, NULL, 1);
    sm4_gcm_hw(test_key, 16, test_iv, NULL, 16, buf, buf, 16, tag, 1);
    sm4_gcm_hw(test_key, 16, test_iv, test_aad, 16, buf, buf, 0, tag, 1);
    sm4_gcm_hw(test_key, 16, test_iv, test_aad, 16, buf, buf, 17, tag, 1);

    /* ---- 1. 硬件加密 ---- */
    if (sm4_gcm_hw(test_key, SM4_KEY_BYTE_LEN, test_iv, test_aad, 16,
                   big_plain, big_cipher, SM4_BIG_LEN, tag, 1) != RSP_OK)
    {
        printf("FAIL (encrypt error)\n");
        return -1;
    }

    /* ---- 2. 软件参考：sm4.c 的 sm4_gcm_encrypt（12B nonce），对比密文与 TAG ---- */
    if (sm4_gcm_encrypt(test_key, test_iv, 12, test_aad, 16,
                        big_plain, SM4_BIG_LEN, tmp_dec, sw_tag) != SM4_OK)
    {
        printf("FAIL (soft gcm error)\n");
        return -1;
    }

    printf("\n");
    printf("DATE SIZE = %u x 16B = %uB\n", (unsigned)SM4_BIG_BLOCKS, (unsigned)SM4_BIG_LEN);

    rsp_dump_buf("msg", big_plain, SM4_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    rsp_dump_buf("soft output:", tmp_dec, SM4_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    rsp_dump_buf("hw output:", big_cipher, SM4_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    rsp_dump_buf("soft tag:", sw_tag, 16);
    rsp_dump_buf("hw tag:", tag, 16);
    if (memcmp(big_cipher, tmp_dec, SM4_BIG_LEN) != 0)
    {
        return -1;
    }
    if (memcmp(tag, sw_tag, 16) != 0)
    {
        return -1;
    }
    printf("SM4 GCM ENC PASS\n");

    if (sm4_gcm_hw(test_key, SM4_KEY_BYTE_LEN, test_iv, test_aad, 16,
                   big_cipher, big_dec, SM4_BIG_LEN, tag, 0) != RSP_OK)
    {
        printf("FAIL (decrypt error)\n");
        return -1;
    }
    if (memcmp(big_plain, big_dec, SM4_BIG_LEN) != 0)
    {
        printf("FAIL (plaintext mismatch)\n");
        return -1;
    }
    rsp_dump_buf("hw GCM DEC output:", big_dec, SM4_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM4_BIG_LEN);
    printf("SM4 GCM DEC PASS\n");

    /* Tamper test: flip one byte of the TAG to forge it, then decrypt again.
     * GCM must verify the TAG and reject the forged one (return != RSP_OK). */
    memcpy(tag_tampered, tag, 16);
    tag_tampered[0] ^= 0xFF;
    if (sm4_gcm_hw(test_key, SM4_KEY_BYTE_LEN, test_iv, test_aad, 16,
                   big_cipher, tmp_dec, SM4_BIG_LEN, tag_tampered, 0) == RSP_OK)
    {
        /* Security bug: HW accepted a forged TAG, authentication is broken. */
        printf("  tamper-reject FAIL (accepted tampered TAG)\n");
        return -1;
    }
    /* PASS: HW detected the TAG mismatch and rejected the forged TAG. */
    printf("  tamper-reject PASS\n");

    return 0;
}

/* ============================================================
 *  Main test entry
 * ============================================================ */
int sm4_test(void)
{
    int ok = 0;

   

 

    for (uint32_t i = 0; i < PRESSURE_TEST; i++)
    {
        test_sm4_ecb();
        test_sm4_cbc();
        test_sm4_ctr();
         test_sm4_gcm();
    }


    return 0;
}
