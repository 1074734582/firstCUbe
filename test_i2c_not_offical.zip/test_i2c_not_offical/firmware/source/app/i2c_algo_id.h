/**
 * @file i2c_algo_id.h
 * @brief I2C 协议使用的算法 ID 枚举
 *
 * data payload 布局（按顺序拼接，无长度字段，各段长度固定；
 * 具体见 i2c_recv_pkg.c 中 rsp_hal_algo_execute 的注释）：
 *   - SM4_ECB_*   : key(16) + message
 *   - SM4_CBC_*   : key(16) + iv(16) + message
 *   - SM4_CTR_*   : key(16) + iv(16) + message
 *   - SM4_GCM_*   : key(16) + nonce(12) + aad_len(2,LE) + aad + tag(16) + message
 *   - AES_*       : 同上，key 长度由包头 templen 指定(16/24/32)
 *   - SM1_* / DES_* : key + [iv] + message
 *   - SM3_HASH / SHA*_HASH : message
 *   - *_HMAC      : key(templen,默认16) + message
 *   - SM2 / RSA / CHACHA20 : 见 rsp_hal_algo_execute 注释
 */
#ifndef __I2C_ALGO_ID_H__
#define __I2C_ALGO_ID_H__

#include <stdint.h>

typedef enum
{
    RSP_SM4_ECB_ENC = 0,
    RSP_SM4_ECB_DEC,
    RSP_SM4_CBC_ENC,
    RSP_SM4_CBC_DEC,
    RSP_SM4_CTR_ENC,
    RSP_SM4_CTR_DEC,
    RSP_SM4_GCM_ENC,
    RSP_SM4_GCM_DEC,

    RSP_AES_ECB_ENC,
    RSP_AES_ECB_DEC,
    RSP_AES_CBC_ENC,
    RSP_AES_CBC_DEC,
    RSP_AES_CTR_ENC,
    RSP_AES_CTR_DEC,
    RSP_AES_GCM_ENC,
    RSP_AES_GCM_DEC,

    RSP_SM1_ECB_ENC,
    RSP_SM1_ECB_DEC,
    RSP_SM1_CBC_ENC,
    RSP_SM1_CBC_DEC,
    RSP_DES_ECB_ENC,
    RSP_DES_ECB_DEC,
    RSP_DES_CBC_ENC,
    RSP_DES_CBC_DEC,

    RSP_SM3_HASH,
    RSP_SM3_HMAC,
    RSP_SHA256_HASH,
    RSP_SHA256_HMAC,
    RSP_SHA384_HASH,
    RSP_SHA384_HMAC,
    RSP_SHA512_HASH,
    RSP_SHA512_HMAC,

    RSP_SM2_ENC,                
    RSP_SM2_DEC, 
    RSP_SM2_SIGN,               
    RSP_SM2_VERIFY,          
    RSP_SM2_KP,                  
    RSP_SM2_KG,                

    RSP_ECC_ENC,                
    RSP_ECC_DEC, 
    RSP_ECC_SIGN,               
    RSP_ECC_VERIFY,          
    RSP_ECC_KP,                  
    RSP_ECC_KG,    

    RSP_RSA_ENC,                
    RSP_RSA_DEC, 
    RSP_RSA_SIGN,               
    RSP_RSA_VERIFY,          
    RSP_RSA_KP,                  
    RSP_RSA_KG,    

    CHACHA20_STREAM,

    RSP_PQC203_KEYGEN,
    RSP_PQC203_ENC,
    RSP_PQC203_DEC,

} algo_id_t;

#endif /* __I2C_ALGO_ID_H__ */
