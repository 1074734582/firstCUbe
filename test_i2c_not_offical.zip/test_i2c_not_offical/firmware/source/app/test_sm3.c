/**
 * @file test_sm3.c
 * @brief SM3 / HMAC-SM3 hardware IP test — hash / streaming / multi-package / hmac
 */

#include "sm3.h"
#include "rsp_ip_sm3.h"
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>

/* ============================================================
 *  Big block test config
 * ============================================================ */
#define SM3_BIG_LEN 1024U /* 1024B test message */
#define SM3_DIGEST_LEN 32U
#define SM3_KEY_LEN 64U
#define PRESSURE_TEST 1U /* 压力测试循环次数 */
/* ============================================================
 *  Test data
 * ============================================================ */
static const uint8_t test_key[SM3_KEY_LEN] = {
    0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 0xfe, 0xdc, 0xba, 0x98, 0x76, 0x54, 0x32, 0x10,
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f,
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f,
    0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f};

/* 大数据测试缓冲 */
static uint8_t big_msg[SM3_BIG_LEN];

static void fill_pattern(void)
{
    uint32_t i;
    for (i = 0; i < SM3_BIG_LEN; i++)
        big_msg[i] = (uint8_t)(i & 0xFF);
}

/* ============================================================
 *  Input dump (debug)
 * ============================================================ */
#define DUMP_LINE 16U
#define DUMP_MAX 64U /* 每段最多打印64B, 防止刷屏 */

static void rsp_dump_buf(char *info, uint8_t *buf, uint32_t len)
{
    printf("%s[%d]", info, len);
    for (int i = 0; i < len; i++)
    {
        printf("%s0x%02x ", i % 16 == 0 ? "\n     " : " ", buf[i]);
    }
    printf("\n");
}

/* ============================================================
 *  Software reference
 * ============================================================ */
static int32_t sm3_test_hash(const uint8_t *pInData, uint32_t inByteLen, uint8_t *pOutDigest)
{
    /* 输出 SM3-256 固定为 32 字节 */
    if (pOutDigest == NULL)
    {
        return -1;
    }

    /* SM3 支持空消息: pInData == NULL 且 inByteLen == 0 时允许 */
    if ((pInData == NULL) && (inByteLen != 0))
    {
        return -1;
    }

    if (sm3(pInData, inByteLen, pOutDigest) != 0)
    {
        return -1;
    }

    return 0;
}

static int32_t sm3_test_hmac(const uint8_t *pKey, uint32_t keyByteLen,
                             const uint8_t *pMsg, uint32_t msgByteLen,
                             uint8_t *pOutHmac)
{
/*
 * HMAC-SM3 输出固定为 32 字节（SM3 摘要长度）
 * 块大小 B = 64 字节（SM3 分组长度）
 */
#define HMAC_SM3_BLOCK_LEN 64U
#define HMAC_SM3_DIGEST_LEN 32U

    /* 输出指针不能为空 */
    if (pOutHmac == NULL)
    {
        return -1;
    }

    /* 允许空密钥、空消息, 但 NULL 指针搭配非 0 长度非法 */
    if ((pKey == NULL) && (keyByteLen != 0))
    {
        return -1;
    }
    if ((pMsg == NULL) && (msgByteLen != 0))
    {
        return -1;
    }

    /*
     * Step 1: 密钥预处理得到 K0（64 字节）
     *   - keyByteLen > 64 : K0 = SM3(key) 后面补 0 到 64 字节
     *   - keyByteLen <= 64: K0 = key 后面补 0 到 64 字节
     */
    uint8_t k0[HMAC_SM3_BLOCK_LEN];
    memset(k0, 0, sizeof(k0));

    if (keyByteLen > HMAC_SM3_BLOCK_LEN)
    {
        if (sm3(pKey, keyByteLen, k0) != 0)
        {
            return -1;
        }
        /* sm3() 写入前 32 字节，后 32 字节保持 0 */
    }
    else if (keyByteLen > 0U)
    {
        memcpy(k0, pKey, keyByteLen);
    }

    /*
     * Step 2: 生成 ipad / opad
     *   ipad = K0 XOR 0x36
     *   opad = K0 XOR 0x5C
     */
    uint8_t ipad[HMAC_SM3_BLOCK_LEN];
    uint8_t opad[HMAC_SM3_BLOCK_LEN];
    for (uint32_t i = 0; i < HMAC_SM3_BLOCK_LEN; i++)
    {
        ipad[i] = (uint8_t)(k0[i] ^ 0x36U);
        opad[i] = (uint8_t)(k0[i] ^ 0x5CU);
    }

    /*
     * Step 3: 内层哈希  inner = SM3(ipad || msg)
     * 用流式 API：init -> update(ipad) -> update(msg) -> final
     */
    uint8_t inner[HMAC_SM3_DIGEST_LEN];
    sm3_ctx_t ctx;

    if (sm3_init(&ctx, NULL, 0) != 0)
    {
        return -1;
    }
    if (sm3_update(&ctx, ipad, HMAC_SM3_BLOCK_LEN) != 0)
    {
        return -1;
    }
    if (msgByteLen > 0U)
    {
        if (sm3_update(&ctx, pMsg, msgByteLen) != 0)
        {
            return -1;
        }
    }
    if (sm3_final(&ctx, inner) != 0)
    {
        return -1;
    }

    /*
     * Step 4: 外层哈希  HMAC = SM3(opad || inner)
     */
    if (sm3_init(&ctx, NULL, 0) != 0)
    {
        return -1;
    }
    if (sm3_update(&ctx, opad, HMAC_SM3_BLOCK_LEN) != 0)
    {
        return -1;
    }
    if (sm3_update(&ctx, inner, HMAC_SM3_DIGEST_LEN) != 0)
    {
        return -1;
    }
    if (sm3_final(&ctx, pOutHmac) != 0)
    {
        return -1;
    }

    return 0;
}

/* ============================================================
 *  HASH test (single package, perf path)
 * ============================================================ */
static int test_sm3_hash(void)
{
    uint8_t soft_hash[SM3_DIGEST_LEN] = {0};
    uint8_t hard_hash[SM3_DIGEST_LEN] = {0};
    uint8_t buf[SM3_DIGEST_LEN] = {0};

    fill_pattern();

    SM3_IP_PerfHash(NULL, 16, buf);
    SM3_IP_PerfHash(big_msg, 16, NULL);

    /* ---- 1. 软件参考 ---- */
    if (sm3_test_hash(big_msg, SM3_BIG_LEN, soft_hash) != 0)
    {
        printf("FAIL (soft hash error)\n");
        return -1;
    }

    /* ---- 2. 硬件 ---- */
    if (SM3_IP_PerfHash(big_msg, SM3_BIG_LEN, hard_hash) != RSP_OK)
    {
        printf("FAIL (hard hash error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %uB\n", (unsigned)SM3_BIG_LEN);

    rsp_dump_buf("msg", big_msg, SM3_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM3_BIG_LEN);
    rsp_dump_buf("soft output:", soft_hash, SM3_DIGEST_LEN);
    rsp_dump_buf("hw output:", hard_hash, SM3_DIGEST_LEN);
    if (memcmp(soft_hash, hard_hash, SM3_DIGEST_LEN) != 0)
    {
        return -1;
    }
    printf("SM3 HASH PASS\n");

    return 0;
}

/* ============================================================
 *  HASH test (streaming path, software padding)
 * ============================================================ */
static int test_sm3_hash_stream(void)
{
    uint8_t soft_hash[SM3_DIGEST_LEN] = {0};
    uint8_t hard_hash[SM3_DIGEST_LEN] = {0};
    uint8_t buf[SM3_DIGEST_LEN] = {0};

    fill_pattern();

    SM3_IP_StreamingHash(NULL, 16, buf);
    SM3_IP_StreamingHash(big_msg, 16, NULL);

    /* ---- 1. 软件参考 ---- */
    if (sm3_test_hash(big_msg, SM3_BIG_LEN, soft_hash) != 0)
    {
        printf("FAIL (soft hash error)\n");
        return -1;
    }

    /* ---- 2. 硬件 ---- */
    if (SM3_IP_StreamingHash(big_msg, SM3_BIG_LEN, hard_hash) != RSP_OK)
    {
        printf("FAIL (hard hash error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %uB\n", (unsigned)SM3_BIG_LEN);

    rsp_dump_buf("msg", big_msg, SM3_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM3_BIG_LEN);
    rsp_dump_buf("soft output:", soft_hash, SM3_DIGEST_LEN);
    rsp_dump_buf("hw output:", hard_hash, SM3_DIGEST_LEN);
    if (memcmp(soft_hash, hard_hash, SM3_DIGEST_LEN) != 0)
    {
        return -1;
    }
    printf("SM3 HASH STREAM PASS\n");

    return 0;
}

/* ============================================================
 *  HASH test (multi-package path, head/mid/tail)
 * ============================================================ */
static int test_sm3_hash_mulpackage(void)
{
    uint8_t soft_hash[SM3_DIGEST_LEN] = {0};
    uint8_t hard_hash[SM3_DIGEST_LEN] = {0};
    uint8_t buf[SM3_DIGEST_LEN] = {0};

    fill_pattern();

    SM3_IP_MultiPackage(NULL, 16, buf);
    SM3_IP_MultiPackage(big_msg, 16, NULL);

    /* ---- 1. 软件参考 ---- */
    if (sm3_test_hash(big_msg, SM3_BIG_LEN, soft_hash) != 0)
    {
        printf("FAIL (soft hash error)\n");
        return -1;
    }

    /* ---- 2. 硬件 ---- */
    if (SM3_IP_MultiPackage(big_msg, SM3_BIG_LEN, hard_hash) != RSP_OK)
    {
        printf("FAIL (hard hash error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %uB\n", (unsigned)SM3_BIG_LEN);

    rsp_dump_buf("msg", big_msg, SM3_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM3_BIG_LEN);
    rsp_dump_buf("soft output:", soft_hash, SM3_DIGEST_LEN);
    rsp_dump_buf("hw output:", hard_hash, SM3_DIGEST_LEN);
    if (memcmp(soft_hash, hard_hash, SM3_DIGEST_LEN) != 0)
    {
        return -1;
    }
    printf("SM3 HASH MULTI-PKG PASS\n");

    return 0;
}

/* ============================================================
 *  HMAC-SM3 test (single package, hw padding)
 * ============================================================ */
static int test_sm3_hmac(void)
{
    uint8_t soft_hmac[SM3_DIGEST_LEN] = {0};
    uint8_t hard_hmac[SM3_DIGEST_LEN] = {0};
    uint8_t buf[SM3_DIGEST_LEN] = {0};

    fill_pattern();

    SM3_IP_PerfHMAC(NULL, SM3_KEY_LEN, big_msg, 16, buf);
    SM3_IP_PerfHMAC(test_key, 0, big_msg, 16, buf);
    SM3_IP_PerfHMAC(test_key, SM3_KEY_LEN, NULL, 16, buf);
    SM3_IP_PerfHMAC(test_key, SM3_KEY_LEN, big_msg, 16, NULL);

    /* ---- 1. 软件参考 ---- */
    if (sm3_test_hmac(test_key, SM3_KEY_LEN, big_msg, SM3_BIG_LEN, soft_hmac) != 0)
    {
        printf("FAIL (soft hmac error)\n");
        return -1;
    }

    /* ---- 2. 硬件 ---- */
    if (SM3_IP_PerfHMAC(test_key, SM3_KEY_LEN, big_msg, SM3_BIG_LEN, hard_hmac) != RSP_OK)
    {
        printf("FAIL (hard hmac error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %uB, KEY SIZE = %uB\n",
           (unsigned)SM3_BIG_LEN, (unsigned)SM3_KEY_LEN);

    rsp_dump_buf("msg", big_msg, SM3_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM3_BIG_LEN);
    rsp_dump_buf("key", (uint8_t *)test_key, SM3_KEY_LEN);
    rsp_dump_buf("soft hmac:", soft_hmac, SM3_DIGEST_LEN);
    rsp_dump_buf("hw hmac:", hard_hmac, SM3_DIGEST_LEN);
    if (memcmp(soft_hmac, hard_hmac, SM3_DIGEST_LEN) != 0)
    {
        return -1;
    }
    printf("SM3 HMAC PASS\n");

    return 0;
}

/* ============================================================
 *  HMAC-SM3 test (multi-package path)
 * ============================================================ */
static int test_sm3_hmac_mulpackage(void)
{
    uint8_t soft_hmac[SM3_DIGEST_LEN] = {0};
    uint8_t hard_hmac[SM3_DIGEST_LEN] = {0};
    uint8_t buf[SM3_DIGEST_LEN] = {0};

    fill_pattern();

    SM3_IP_HMAC_MultiPackage(NULL, SM3_KEY_LEN, big_msg, 16, buf);
    SM3_IP_HMAC_MultiPackage(test_key, 0, big_msg, 16, buf);
    SM3_IP_HMAC_MultiPackage(test_key, SM3_KEY_LEN, NULL, 16, buf);
    SM3_IP_HMAC_MultiPackage(test_key, SM3_KEY_LEN, big_msg, 16, NULL);

    /* ---- 1. 软件参考 ---- */
    if (sm3_test_hmac(test_key, SM3_KEY_LEN, big_msg, SM3_BIG_LEN, soft_hmac) != 0)
    {
        printf("FAIL (soft hmac error)\n");
        return -1;
    }

    /* ---- 2. 硬件 ---- */
    if (SM3_IP_HMAC_MultiPackage(test_key, SM3_KEY_LEN, big_msg,
                                 SM3_BIG_LEN, hard_hmac) != RSP_OK)
    {
        printf("FAIL (hard hmac error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %uB, KEY SIZE = %uB\n",
           (unsigned)SM3_BIG_LEN, (unsigned)SM3_KEY_LEN);

    rsp_dump_buf("msg", big_msg, SM3_BIG_LEN > DUMP_MAX ? DUMP_MAX : SM3_BIG_LEN);
    rsp_dump_buf("key", (uint8_t *)test_key, SM3_KEY_LEN);
    rsp_dump_buf("soft hmac:", soft_hmac, SM3_DIGEST_LEN);
    rsp_dump_buf("hw hmac:", hard_hmac, SM3_DIGEST_LEN);
    if (memcmp(soft_hmac, hard_hmac, SM3_DIGEST_LEN) != 0)
    {
        return -1;
    }
    printf("SM3 HMAC MULTI-PKG PASS\n");

    return 0;
}

/* ============================================================
 *  Main test entry
 * ============================================================ */
int sm3_test(void)
{
 for (uint32_t i = 0; i < PRESSURE_TEST; i++)
    {
    test_sm3_hash();
    test_sm3_hash_mulpackage();
    test_sm3_hmac();
    test_sm3_hmac_mulpackage();
    }
    return 0;
}
