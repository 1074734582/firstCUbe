/**
 * @file test_ecc.c
 * @brief ECC P-256 / P-384 硬件快速验证
 *
 * 接口:
 *   ecc_256_keygen() / ecc_256_sign() / ecc_256_verify()  — P-256 独立测试
 *   ecc_384_keygen() / ecc_384_sign() / ecc_384_verify()  — P-384 独立测试
 *   ecc_test()      — 统一入口, 依次调用 P-256 / P-384 的 keygen/sign/verify
 *
 * 每个测试:
 *   [1]  HW sign    vs FINAL vectors (tinyec 预计算, 100% 数学正确)
 *   [1b] HW verify  good sig pass / tampered sig reject
 *   [2]  HW keygen + 随机化闭环 (当前 bitstream KG 全 BLOCKED, 视为正常)
 *
 * 当前硬件:
 *   P-384 bitstream: P-384 PASS / P-256 sign 可能也能跑 (CFG bit11=0)
 *   P-256 bitstream: P-256 PASS / P-384 会 FAIL
 *   KG (MODE=2): 两个 bitstream 都没实现, BLOCKED 视为正常
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "rsp_ip_ecc.h"
#define PRESSURE_TEST 1U
/* ============================================================
 * P-256 FINAL vectors (32B operands, secp256r1)
 *   d/k/msg 字节模式和 P-384 完全相同, 方便对比
 *   verify self-check: True (tinyec)
 * ============================================================ */
static const uint8_t P256_FINAL_MSG[32] = {
    0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff,
    0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
static const uint8_t P256_FINAL_D[32] = {
    0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef, 0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef,
    0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef, 0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef};
static const uint8_t P256_FINAL_K[32] = {
    0xfe, 0xdc, 0xba, 0x09, 0x87, 0x65, 0x43, 0x21, 0xfe, 0xdc, 0xba, 0x09, 0x87, 0x65, 0x43, 0x21,
    0xfe, 0xdc, 0xba, 0x09, 0x87, 0x65, 0x43, 0x21, 0xfe, 0xdc, 0xba, 0x09, 0x87, 0x65, 0x43, 0x21};
static const uint8_t P256_FINAL_R[32] = {
    0x58, 0x89, 0x3c, 0xc6, 0x5c, 0xc5, 0xc0, 0xda, 0x46, 0xa1, 0x4c, 0x5a, 0x42, 0x87, 0x8d, 0x87,
    0x70, 0x03, 0x62, 0x3c, 0xdc, 0xee, 0xc6, 0x2c, 0xb9, 0xa9, 0x06, 0x9f, 0xa2, 0xc0, 0x2e, 0xa4};
static const uint8_t P256_FINAL_S[32] = {
    0x87, 0xd4, 0x57, 0x0c, 0xb1, 0x2a, 0x04, 0x26, 0xb9, 0x4b, 0x7d, 0xee, 0x35, 0x60, 0x1f, 0xc3,
    0x01, 0xcd, 0xea, 0x32, 0x9a, 0x77, 0x67, 0x54, 0x1b, 0x6c, 0x69, 0x11, 0x92, 0x7a, 0x24, 0x39};
static const uint8_t P256_QX[32] = {
    0x47, 0x1c, 0x3e, 0x75, 0x8c, 0x49, 0x04, 0x28, 0x5b, 0xba, 0x7e, 0x53, 0x11, 0x8e, 0xd0, 0xf5,
    0x24, 0xad, 0xeb, 0x07, 0x57, 0xd2, 0x5b, 0xd2, 0xf8, 0xe7, 0xb0, 0xd7, 0x6d, 0xfa, 0x71, 0x4c};
static const uint8_t P256_QY[32] = {
    0xdd, 0x52, 0x0f, 0x7a, 0xca, 0x8a, 0x8b, 0x91, 0x7a, 0xcc, 0x37, 0xf5, 0x1d, 0xe8, 0xf0, 0xc9,
    0xbb, 0xe3, 0xad, 0x85, 0x83, 0x82, 0xe7, 0x02, 0xdc, 0x25, 0xa1, 0x2d, 0x09, 0xf7, 0xa8, 0x58};

/* ============================================================
 * P-384 FINAL vectors (48B operands, secp384r1)
 *   d/k/msg 字节模式和 P-256 完全相同, 方便对比
 *   verify self-check: True (tinyec)
 * ============================================================ */
static const uint8_t P384_FINAL_MSG[48] = {
    0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff,
    0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff,
    0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
static const uint8_t P384_FINAL_D[48] = {
    0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef, 0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef,
    0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef, 0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef,
    0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef, 0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef};
static const uint8_t P384_FINAL_K[48] = {
    0xfe, 0xdc, 0xba, 0x09, 0x87, 0x65, 0x43, 0x21, 0xfe, 0xdc, 0xba, 0x09, 0x87, 0x65, 0x43, 0x21,
    0xfe, 0xdc, 0xba, 0x09, 0x87, 0x65, 0x43, 0x21, 0xfe, 0xdc, 0xba, 0x09, 0x87, 0x65, 0x43, 0x21,
    0xfe, 0xdc, 0xba, 0x09, 0x87, 0x65, 0x43, 0x21, 0xfe, 0xdc, 0xba, 0x09, 0x87, 0x65, 0x43, 0x21};
static const uint8_t P384_FINAL_R[48] = {
    0xb2, 0x01, 0x83, 0x50, 0xd7, 0xe3, 0x25, 0x51, 0xfa, 0xcf, 0x2f, 0x61, 0x3c, 0x5e, 0xc2, 0x6f,
    0x67, 0xda, 0x49, 0x2f, 0xea, 0xbd, 0x19, 0x76, 0x05, 0x6a, 0x72, 0xbb, 0x75, 0xf9, 0x17, 0x2c,
    0x36, 0x49, 0x85, 0xfa, 0xb4, 0xc1, 0x9c, 0x8d, 0xf2, 0x42, 0x82, 0x5c, 0x39, 0x26, 0x87, 0xdf};
static const uint8_t P384_FINAL_S[48] = {
    0xb3, 0x18, 0x9f, 0xf9, 0x47, 0x78, 0x0d, 0x86, 0x44, 0xba, 0x64, 0x46, 0x9a, 0x31, 0x36, 0x60,
    0x07, 0x66, 0xc3, 0xce, 0xe0, 0x62, 0xad, 0x88, 0xe2, 0xe7, 0x89, 0xd7, 0x7d, 0x61, 0x12, 0x6a,
    0x99, 0x84, 0xd7, 0x7d, 0x32, 0xec, 0x1d, 0xce, 0x21, 0x06, 0x2c, 0xe9, 0x62, 0x84, 0x26, 0x7f};
static const uint8_t P384_QX[48] = {
    0xa1, 0x4a, 0xad, 0x95, 0x67, 0x3d, 0x51, 0x51, 0x3a, 0x38, 0x53, 0x09, 0x15, 0x1e, 0xe5, 0x7b,
    0x66, 0xf8, 0xef, 0x6d, 0x80, 0xa0, 0x3a, 0xe5, 0x4b, 0x26, 0x87, 0x67, 0xb2, 0x8c, 0xb3, 0x7f,
    0x72, 0xf2, 0x72, 0xaa, 0x5f, 0xb5, 0xd1, 0x1d, 0x73, 0x95, 0x15, 0x7d, 0x98, 0x5b, 0x5f, 0x33};
static const uint8_t P384_QY[48] = {
    0x22, 0x9d, 0x41, 0x34, 0xd1, 0xa6, 0x3d, 0x2a, 0x1a, 0xfa, 0x18, 0x4a, 0x2d, 0x09, 0xe5, 0x2b,
    0x2d, 0x71, 0x52, 0x7e, 0x66, 0xfb, 0x14, 0x27, 0xc1, 0x3e, 0x6b, 0x1c, 0xb1, 0x97, 0x8d, 0x47,
    0x4a, 0x7b, 0x7b, 0x73, 0x5d, 0x79, 0x2c, 0xda, 0xa0, 0x99, 0x63, 0x32, 0xdb, 0x96, 0x8a, 0xb4};

/* ============================================================
 * 公共工具函数
 * ============================================================ */

static void hd(const char *tag, const uint8_t *p, uint32_t blen)
{
    printf("    %-10s: ", tag);
    for (uint32_t i = 0; i < blen; i++)
        printf("%02x", p[i]);
    printf("\n");
}

#define DUMP_LINE 16U

static void rsp_dump_buf(const char *info, const uint8_t *buf, uint32_t len)
{
    printf("%s[%lu]", info, (unsigned long)len);
    for (uint32_t i = 0; i < len; i++)
        printf("%s0x%02x ", (i % DUMP_LINE) == 0 ? "\n     " : " ", buf[i]);
    printf("\n");
}

/* ---- Cortex-M3 cycle counter ---- */
#define ECC_DEMCR (*(volatile uint32_t *)0xE000EDFC)
#define ECC_DWT_CTRL (*(volatile uint32_t *)0xE0001000)
#define ECC_DWT_CYCCNT (*(volatile uint32_t *)0xE0001004)

static void ecc_cyc_init(void)
{
    ECC_DEMCR |= (1u << 24);
    ECC_DWT_CYCCNT = 0;
    ECC_DWT_CTRL |= 1u;
}
static uint32_t ecc_cyc(void) { return ECC_DWT_CYCCNT; }

static uint32_t ecc_ms(uint32_t cyc)
{
#if defined(HSE_VALUE) && (HSE_VALUE > 0)
    return cyc / (HSE_VALUE / 1000u);
#else
    return cyc / 2000u;
#endif
}

/* ---- 公共工具函数 ---- */
struct ecc_test_ctx
{
    const char *name; /* "P-256" or "P-384" */
    uint32_t curve;   /* ECC_CURVE_P256 / ECC_CURVE_P384 */
    uint32_t blen;    /* 32 / 48 */
    /* FINAL vectors */
    const uint8_t *final_msg;
    const uint8_t *final_d;
    const uint8_t *final_k;
    const uint8_t *final_r;
    const uint8_t *final_s;
    const uint8_t *qx;
    const uint8_t *qy;
};

/* 单个测试接口返回 0=PASS, -1=FAIL/BLOCKED */

/* ---- [1] HW sign vs FINAL vectors ---- */
static int ecc_sign(const struct ecc_test_ctx *ctx)
{
    uint32_t blen = ctx->blen;
    uint32_t t0 = ecc_cyc();

    printf("\n====== ECC %s sign ======\n", ctx->name);

    uint8_t hw_r[48] = {0}, hw_s[48] = {0};

    /* 错误测试: 非法曲线 / NULL 指针 / 非法长度 */
    ecc_hw_sign(0xFFFFU, ctx->final_d, ctx->final_k, ctx->final_msg, blen, hw_r, hw_s);
    ecc_hw_sign(ctx->curve, NULL, ctx->final_k, ctx->final_msg, blen, hw_r, hw_s);
    ecc_hw_sign(ctx->curve, ctx->final_d, NULL, ctx->final_msg, blen, hw_r, hw_s);
    ecc_hw_sign(ctx->curve, ctx->final_d, ctx->final_k, NULL, blen, hw_r, hw_s);
    ecc_hw_sign(ctx->curve, ctx->final_d, ctx->final_k, ctx->final_msg, blen, NULL, hw_s);
    ecc_hw_sign(ctx->curve, ctx->final_d, ctx->final_k, ctx->final_msg, blen, hw_r, NULL);
    ecc_hw_sign(ctx->curve, ctx->final_d, ctx->final_k, ctx->final_msg, 0U, hw_r, hw_s);
    ecc_hw_sign(ctx->curve, ctx->final_d, ctx->final_k, ctx->final_msg, blen - 1U, hw_r, hw_s);
    ecc_hw_sign(ctx->curve, ctx->final_d, ctx->final_k, ctx->final_msg, blen + 1U, hw_r, hw_s);

    rsp_dump_buf("in  d  ", ctx->final_d, blen);
    rsp_dump_buf("in  k  ", ctx->final_k, blen);
    rsp_dump_buf("in  msg", ctx->final_msg, blen);

    RSP_StatusTypeDef ret = ecc_hw_sign(ctx->curve, ctx->final_d, ctx->final_k,
                                        ctx->final_msg, blen, hw_r, hw_s);

    rsp_dump_buf("out r  ", hw_r, blen);
    rsp_dump_buf("out s  ", hw_s, blen);

    int hw_ok = (ret == RSP_OK);
    int hw_r_exp = (hw_ok && memcmp(hw_r, ctx->final_r, blen) == 0);
    int hw_s_exp = (hw_ok && memcmp(hw_s, ctx->final_s, blen) == 0);

    if (hw_r_exp && hw_s_exp) {
        printf("[1] sign    : PASS (%lu ms)\n", (unsigned long)ecc_ms(ecc_cyc() - t0));
        return 0;
    }

    printf("[1] sign    : FAIL (hw_ok=%d, r_match=%d, s_match=%d)\n",
           hw_ok, hw_r_exp, hw_s_exp);
    hd("exp_r", ctx->final_r, blen);
    hd("hw_r ", hw_r, blen);
    hd("exp_s", ctx->final_s, blen);
    hd("hw_s ", hw_s, blen);
    /* probe 已修复: 接受 curve 参数, 不会再污染算核曲线锁存 */
    ecc_probe_sign_order(ctx->curve, ctx->final_d, ctx->final_k, ctx->final_msg);
    ecc_probe_scalar_map(ctx->curve, ctx->final_d, ctx->final_msg);
    return -1;
}

/* ---- [1b] HW verify: good sig pass / tampered sig reject ---- */
static int ecc_verify(const struct ecc_test_ctx *ctx)
{
    uint32_t blen = ctx->blen;
    uint32_t t0 = ecc_cyc();

    printf("\n====== ECC %s verify ======\n", ctx->name);

    uint8_t pub_buf[96];
    uint8_t sig_good[96];
    uint8_t sig_bad[96];
    memcpy(pub_buf, ctx->qx, blen);
    memcpy(pub_buf + blen, ctx->qy, blen);
    memcpy(sig_good, ctx->final_r, blen);
    memcpy(sig_good + blen, ctx->final_s, blen);

    /* 错误测试: 非法曲线 / NULL 指针 / 非法长度 */
    ecc_hw_verify(0xFFFFU, pub_buf, ctx->final_msg, blen, sig_good);
    ecc_hw_verify(ctx->curve, NULL, ctx->final_msg, blen, sig_good);
    ecc_hw_verify(ctx->curve, pub_buf, NULL, blen, sig_good);
    ecc_hw_verify(ctx->curve, pub_buf, ctx->final_msg, blen, NULL);
    ecc_hw_verify(ctx->curve, pub_buf, ctx->final_msg, 0U, sig_good);
    ecc_hw_verify(ctx->curve, pub_buf, ctx->final_msg, blen - 1U, sig_good);
    ecc_hw_verify(ctx->curve, pub_buf, ctx->final_msg, blen + 1U, sig_good);

    memcpy(sig_bad, sig_good, 2U * blen);
    sig_bad[2U * blen - 1] ^= 0x01U;

    rsp_dump_buf("in  pub", pub_buf, 2U * blen);
    rsp_dump_buf("in  msg", ctx->final_msg, blen);
    rsp_dump_buf("in  sig", sig_good, 2U * blen);

    RSP_StatusTypeDef v_ok = ecc_hw_verify(ctx->curve, pub_buf, ctx->final_msg, blen, sig_good);
    RSP_StatusTypeDef v_bad = ecc_hw_verify(ctx->curve, pub_buf, ctx->final_msg, blen, sig_bad);
    int ver_ok = (v_ok == RSP_OK) && (v_bad != RSP_OK);

    printf("out verify good=%d\n", (int)v_ok);

    printf("[1b] verify  : %s (%lu ms)\n",
           ver_ok ? "PASS" : "FAIL",
           (unsigned long)ecc_ms(ecc_cyc() - t0));
    return ver_ok ? 0 : -1;
}

/* ---- [2] HW keygen (d * G) ---- */
static int ecc_keygen(const struct ecc_test_ctx *ctx)
{
    uint32_t blen = ctx->blen;
    uint32_t t0 = ecc_cyc();

    printf("\n====== ECC %s keygen ======\n", ctx->name);

    uint8_t kg_q[96] = {0};

    /* 错误测试: 非法曲线 / NULL 指针必须被拦截 */
    ecc_hw_keygen(0xFFFFU, ctx->final_d, kg_q);
    ecc_hw_keygen(ctx->curve, NULL, kg_q);
    ecc_hw_keygen(ctx->curve, ctx->final_d, NULL);

    rsp_dump_buf("in  d  ", ctx->final_d, blen);

    RSP_StatusTypeDef kret = ecc_hw_keygen(ctx->curve, ctx->final_d, kg_q);

    rsp_dump_buf("out Q  ", kg_q, 2U * blen);

    int kg_ok = (kret == RSP_OK);
    int kg_qx_exp = 0, kg_qy_exp = 0;

    if (kg_ok) {
        kg_qx_exp = (memcmp(kg_q, ctx->qx, blen) == 0);
        kg_qy_exp = (memcmp(kg_q + blen, ctx->qy, blen) == 0);
        kg_ok = kg_qx_exp && kg_qy_exp;
    }

    if (kret != RSP_OK) {
        printf("keygen  : BLOCKED (ret=%d)\n", (int)kret);
        return -1;
    }
    if (kg_ok) {
        printf("keygen  : PASS (%lu ms)\n", (unsigned long)ecc_ms(ecc_cyc() - t0));
        return 0;
    }

    printf("keygen  : FAIL (qx=%d, qy=%d)\n", kg_qx_exp, kg_qy_exp);
    hd("exp_Qx", ctx->qx, blen);
    hd("hw_Qx ", kg_q, blen);
    hd("exp_Qy", ctx->qy, blen);
    hd("hw_Qy ", kg_q + blen, blen);
    return -1;
}

/* ============================================================
 * 对外接口
 * ============================================================ */

static const struct ecc_test_ctx ECC_CTX_P256 = {
    .name = "P-256",
    .curve = ECC_CURVE_P256,
    .blen = 32U,
    .final_msg = P256_FINAL_MSG,
    .final_d = P256_FINAL_D,
    .final_k = P256_FINAL_K,
    .final_r = P256_FINAL_R,
    .final_s = P256_FINAL_S,
    .qx = P256_QX,
    .qy = P256_QY,
};

static const struct ecc_test_ctx ECC_CTX_P384 = {
    .name = "P-384",
    .curve = ECC_CURVE_P384,
    .blen = 48U,
    .final_msg = P384_FINAL_MSG,
    .final_d = P384_FINAL_D,
    .final_k = P384_FINAL_K,
    .final_r = P384_FINAL_R,
    .final_s = P384_FINAL_S,
    .qx = P384_QX,
    .qy = P384_QY,
};

/* ---- P-256 ---- */
int ecc_256_keygen(void)
{
    return ecc_keygen(&ECC_CTX_P256);
}

int ecc_256_sign(void)
{
    return ecc_sign(&ECC_CTX_P256);
}

int ecc_256_verify(void)
{
    return ecc_verify(&ECC_CTX_P256);
}

/* ---- P-384 ---- */
int ecc_384_keygen(void)
{
    return ecc_keygen(&ECC_CTX_P384);
}

int ecc_384_sign(void)
{
    return ecc_sign(&ECC_CTX_P384);
}

int ecc_384_verify(void)
{
    return ecc_verify(&ECC_CTX_P384);
}

/* main.c 继续调 ecc_test(), 依次跑 P-256 / P-384 的 keygen/sign/verify */
int ecc_test(void)
{
    for (uint32_t i = 0; i < PRESSURE_TEST; i++)
    {
        ecc_256_keygen();
        ecc_256_sign();
        ecc_256_verify();
    }
    return 0;
}
