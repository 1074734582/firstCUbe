/**
 * @file test_sm1.c
 * @brief SM1 硬件 IP 测试 (基址 0x80000000, 参考 sm1_soc_test.txt)
 *
 * 仅测 ECB / CBC 模式. 验证方式:
 *   1. 第 0 组: 硬件加密 vs SOC 参考输出
 *   2. 其他组 + 全部组: 硬件加密 → 硬件解密 → 原明文 (roundtrip 自证)
 *
 * SM1 分组 16B, 密钥 16B, IV 16B.
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "rsp_ip_sm1.h"
#define PRESSURE_TEST 1U
/* ============================================================
 * 工具
 * ============================================================ */
static void banner(const char *title)
{
    printf("\n============================================================\n");
    printf("%s\n", title);
    printf("============================================================\n");
}

static void rsp_dump_buf(char *info, uint8_t *buf, uint32_t len)
{
    printf("%s[%d]", info, len);
    for (int i = 0; i < len; i++)
    {
        printf("%s0x%02x ", i % 16 == 0 ? "\n     " : " ", buf[i]);
    }
    printf("\n");
}

/* 反向参数校验：实际返回码与期望值一致则通过, 否则打印实际值并置失败 */
static int sm1_expect_ret(const char *tag, RSP_StatusTypeDef ret,
                          RSP_StatusTypeDef expect)
{
    if (ret == expect) return 0;
    printf("  %-12s: expect=%d got=%d\n", tag, (int)expect, (int)ret);
    return -1;
}

static int run_case_ecb(const char *tag, const uint8_t *key,
                        const uint8_t *msg, uint32_t len,
                        const uint8_t *expect_out)  /* NULL 则不比对 */
{
    uint8_t enc[128];
    uint8_t dec[128];
    int pass = 1;

    printf("  %-24s len=%u\n", tag, (unsigned)len);

    rsp_dump_buf("  key", (uint8_t *)key, 16);
    rsp_dump_buf("  msg", (uint8_t *)msg, len);

    if (sm1_hw_ecb(key, msg, enc, len, 0) != RSP_OK)
    {
        printf("hw_enc FAIL\n"); return 0;
    }
    if (sm1_hw_ecb(key, enc, dec, len, 1) != RSP_OK)
    {
        printf("hw_dec FAIL\n"); return 0;
    }

    /* roundtrip */
    if (memcmp(dec, msg, len) != 0) pass = 0;

    /* 参考输出 */
    if (pass && expect_out != NULL)
    {
        if (memcmp(enc, expect_out, len) != 0)
        {
            pass = 0;
            printf("ref NG, ");
        }
    }

    rsp_dump_buf("  enc", enc, len);
    if (expect_out) rsp_dump_buf("  exp", (uint8_t *)expect_out, len);
    rsp_dump_buf("  dec", dec, len);

    printf("enc/dec %s%s: %s\n",
           expect_out ? "ref " : "",
           pass ? "OK  " : "NG  ",
           pass ? "PASS" : "FAIL");
    return pass;
}

static int run_case_cbc(const char *tag, const uint8_t *key,
                        const uint8_t *iv, const uint8_t *msg,
                        uint32_t len)
{
    uint8_t enc[128];
    uint8_t dec[128];
    int pass = 1;

    printf("  %-24s len=%u\n", tag, (unsigned)len);

    rsp_dump_buf("  key", (uint8_t *)key, 16);
    rsp_dump_buf("  iv", (uint8_t *)iv, 16);
    rsp_dump_buf("  msg", (uint8_t *)msg, len);

    if (sm1_hw_cbc(key, iv, msg, enc, len, 0) != RSP_OK)
    {
        printf("hw_enc FAIL\n"); return 0;
    }
    if (sm1_hw_cbc(key, iv, enc, dec, len, 1) != RSP_OK)
    {
        printf("hw_dec FAIL\n"); return 0;
    }
    if (memcmp(dec, msg, len) != 0) pass = 0;

    rsp_dump_buf("  enc", enc, len);
    rsp_dump_buf("  dec", dec, len);

    printf("roundtrip %s: %s\n", pass ? "OK  " : "NG  ", pass ? "PASS" : "FAIL");
    return pass;
}

/* ============================================================
 * TEST 16: SM1 ECB (多组, 含 SOC 参考向量)
 * ============================================================ */

/* SOC 参考 (sm1_soc_test.txt, 你给的验证过的数据) */
static const uint8_t k0[16] = {
    0x40,0xBB,0x12,0xDD,0x6A,0x82,0x73,0x86,
    0x7F,0x35,0x29,0xD3,0x54,0xB4,0xA0,0x26
};
static const uint8_t m0[64] = {
    0xFF,0xEE,0xDD,0xCC,0xBB,0xAA,0x99,0x88,
    0x77,0x66,0x55,0x44,0x33,0x22,0x11,0x00,
    0xFF,0xEE,0xDD,0xCC,0xBB,0xAA,0x99,0x88,
    0x77,0x66,0x55,0x44,0x33,0x22,0x11,0x00,
    0xFF,0xEE,0xDD,0xCC,0xBB,0xAA,0x99,0x88,
    0x77,0x66,0x55,0x44,0x33,0x22,0x11,0x00,
    0xFF,0xEE,0xDD,0xCC,0xBB,0xAA,0x99,0x88,
    0x77,0x66,0x55,0x44,0x33,0x22,0x11,0x00
};
static const uint8_t c0[64] = {
    0x6D,0x7F,0x45,0xB0,0x8B,0xC4,0xD9,0x66,
    0x44,0x4C,0x86,0xC2,0xB0,0x7D,0x29,0x93,
    0x6D,0x7F,0x45,0xB0,0x8B,0xC4,0xD9,0x66,
    0x44,0x4C,0x86,0xC2,0xB0,0x7D,0x29,0x93,
    0x6D,0x7F,0x45,0xB0,0x8B,0xC4,0xD9,0x66,
    0x44,0x4C,0x86,0xC2,0xB0,0x7D,0x29,0x93,
    0x6D,0x7F,0x45,0xB0,0x8B,0xC4,0xD9,0x66,
    0x44,0x4C,0x86,0xC2,0xB0,0x7D,0x29,0x93
};

/* 其他组 (无参考值, 只验 roundtrip) */
static const uint8_t k1[16] = { 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0 };
static const uint8_t k2[16] = { 0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
                                0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF };
static const uint8_t k3[16] = { 0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF,
                                0xFE,0xDC,0xBA,0x98,0x76,0x54,0x32,0x10 };

static int test_sm1_ecb(void)
{
    int pass = 0, total = 0;
    uint8_t buf[32] = {0};

    banner("TEST 16: SM1 ECB encrypt/decrypt  (mode=0x00)");
    printf("  cfg: ENCDEC | ECB | KEY_LEN(16) | PKG_FULL(5)\n\n");

    /* ---- 参数校验 ---- */
    if (sm1_expect_ret("key=NULL", sm1_hw_ecb(NULL, m0, buf, 16, 0),  RSP_ERR_NULL_PTR))    return -1;
    if (sm1_expect_ret("in=NULL",  sm1_hw_ecb(k0, NULL, buf, 16, 0),  RSP_ERR_NULL_PTR))    return -1;
    if (sm1_expect_ret("out=NULL", sm1_hw_ecb(k0, m0, NULL, 16, 0),   RSP_ERR_NULL_PTR))    return -1;
    if (sm1_expect_ret("len=17",   sm1_hw_ecb(k0, m0, buf, 17, 0),    RSP_ERR_INVALID_PARAM)) return -1;

    /* 第 0 组: 有 SOC 参考输出 */
    total++;
    if (run_case_ecb("SOC ref (64B)", k0, m0, 64, c0)) pass++;

    /* 其他组: 不同长度 + 不同 key, 只验 roundtrip (必须 16B 对齐) */
    total++; if (run_case_ecb("all-zero key 16B", k1, m0, 16, NULL)) pass++;
    total++; if (run_case_ecb("all-zero key 32B", k1, m0, 32, NULL)) pass++;
    total++; if (run_case_ecb("all-FF key   16B", k2, m0, 16, NULL)) pass++;
    total++; if (run_case_ecb("all-FF key   64B", k2, m0, 64, NULL)) pass++;
    total++; if (run_case_ecb("pattern key  16B", k3, m0, 16, NULL)) pass++;
    total++; if (run_case_ecb("pattern key  48B", k3, m0, 48, NULL)) pass++;

    printf("\n  ECB: %s (%d/%d)\n",
           (pass == total) ? "PASS" : "FAIL", pass, total);
    return (pass == total) ? 0 : -1;
}

/* ============================================================
 * TEST 17: SM1 CBC (多组, 全 roundtrip)
 * ============================================================ */

static int test_sm1_cbc(void)
{
    static const uint8_t iv_zero[16] = {
        0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0
    };
    static const uint8_t iv_ff[16]   = {
        0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
        0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF
    };
    static const uint8_t iv_pat[16]  = {
        0xE8,0x3D,0x17,0x15,0xAC,0xF3,0x48,0x63,
        0x6B,0x9A,0x0C,0x7E,0x2F,0x51,0xD4,0x88
    };

    static const uint8_t msg_pat[64] = {
        0xFF,0xEE,0xDD,0xCC,0xBB,0xAA,0x99,0x88,
        0x77,0x66,0x55,0x44,0x33,0x22,0x11,0x00,
        0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,
        0x88,0x99,0xAA,0xBB,0xCC,0xDD,0xEE,0xFF,
        0xFF,0xEE,0xDD,0xCC,0xBB,0xAA,0x99,0x88,
        0x77,0x66,0x55,0x44,0x33,0x22,0x11,0x00,
        0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,
        0x88,0x99,0xAA,0xBB,0xCC,0xDD,0xEE,0xFF
    };

    int pass = 0, total = 0;
    uint8_t buf[32] = {0};

    banner("TEST 17: SM1 CBC encrypt/decrypt  (mode=0x01)");
    printf("  cfg: ENCDEC | CBC | KEY_LEN(16) | PKG_FULL(5)\n\n");

    /* ---- 参数校验 ---- */
    if (sm1_expect_ret("key=NULL", sm1_hw_cbc(NULL, iv_pat, m0, buf, 16, 1),  RSP_ERR_NULL_PTR))    return -1;
    if (sm1_expect_ret("iv=NULL",  sm1_hw_cbc(k0, NULL, m0, buf, 16, 1),      RSP_ERR_NULL_PTR))    return -1;
    if (sm1_expect_ret("in=NULL",  sm1_hw_cbc(k0, iv_pat, NULL, buf, 16, 1),  RSP_ERR_NULL_PTR))    return -1;
    if (sm1_expect_ret("out=NULL", sm1_hw_cbc(k0, iv_pat, m0, NULL, 16, 1),   RSP_ERR_NULL_PTR))    return -1;
    if (sm1_expect_ret("len=17",   sm1_hw_cbc(k0, iv_pat, m0, buf, 17, 1),    RSP_ERR_INVALID_PARAM)) return -1;

    /* 用 k0 (SOC key) 跑多组, 不同 IV + 不同长度 */
    total++; if (run_case_cbc("zero iv   16B    ", k0, iv_zero, msg_pat, 16)) pass++;
    total++; if (run_case_cbc("zero iv   32B    ", k0, iv_zero, msg_pat, 32)) pass++;
    total++; if (run_case_cbc("zero iv   64B    ", k0, iv_zero, msg_pat, 64)) pass++;
    total++; if (run_case_cbc("0xFF iv   32B    ", k0, iv_ff,   msg_pat, 32)) pass++;
    total++; if (run_case_cbc("pattern iv 64B   ", k0, iv_pat,  msg_pat, 64)) pass++;

    /* 不同 key (长度均 16B 对齐) */
    total++; if (run_case_cbc("zero key  zero iv 16B", k1, iv_zero, msg_pat, 16)) pass++;
    total++; if (run_case_cbc("0xFF key 0xFF iv 32B", k2, iv_ff,   msg_pat, 32)) pass++;
    total++; if (run_case_cbc("pattern k pattern iv 48B", k3, iv_pat, msg_pat, 48)) pass++;

    printf("\n  CBC: %s (%d/%d)\n",
           (pass == total) ? "PASS" : "FAIL", pass, total);
    return (pass == total) ? 0 : -1;
}

/* ============================================================
 * 入口
 * ============================================================ */
int sm1_test(void)
{
      for (uint32_t i = 0; i < PRESSURE_TEST; i++)
    {
        test_sm1_ecb();
        test_sm1_cbc();
    }


    return 0;
}


