/**
 * @file test_sha.c
 * @brief SHA2 硬件 IP 测试
 *        1. sha256_test         单包模式，硬件padding，32包1-1024随机
 *        2. sha256_pkg_test     多包模式，32包每次分3包
 *        3. sha256_hard_pad     硬件padding，32包1-1024随机（stream）
 *        4. sha256_soft_pad     软件padding，32包1-1024随机
 *        5. sha256_length_test  128包从1-128长度遍历
 */

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "rsp_ip_sha.h"
#include "sha.h"

/* ============================================================
 *  辅助
 * ============================================================ */

/* 最大测试消息长度 */
#define MAX_MSG_LEN 1024

/* 压力测试循环次数 */
#define PRESSURE_TEST 1U

/* 测试消息缓冲区 */
static uint8_t test_msg[MAX_MSG_LEN];

/* HMAC 测试 key（64B） */
static const uint8_t hmac_key[] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
    0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
    0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
    0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F
};

/* HMAC-SHA384 测试 key（128B，SHA384/512 的 key 块为 128B） */
static const uint8_t hmac_key_384[128] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
    0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
    0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
    0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,
    0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
    0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,
    0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57,
    0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,
    0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
    0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,
    0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77,
    0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F
};

/* 简单 LCG 伪随机数（可复现） */
static uint32_t rand_seed = 0x12345678U;
static uint32_t simple_rand(void)
{
    rand_seed = rand_seed * 1103515245U + 12345U;
    return (rand_seed >> 16) & 0x7FFF;
}

/* 初始化测试消息（可复现的伪随机内容） */
static void init_test_msg(void)
{
    uint32_t seed = rand_seed;
    for (uint32_t i = 0; i < MAX_MSG_LEN; i++) {
        test_msg[i] = (uint8_t)(simple_rand() & 0xFF);
    }
    rand_seed = seed;  /* 恢复种子，保证每次测试用相同数据 */
}

static void print_hex(const char *label, const uint8_t *data, uint32_t len)
{
    printf("%s: ", label);
    for (uint32_t i = 0; i < len && i < 16; i++) {
        printf("%02X ", data[i]);
    }
    if (len > 16) printf("...");
    printf("\n");
}

/* 参考 SM3 测试接口的 dump 风格: 最多打印 DUMP_MAX 字节, 防止刷屏 */
#define DUMP_MAX 64U
static void sha_dump_buf(const char *info, const uint8_t *buf, uint32_t len)
{
    printf("%s[%u]:", info, (unsigned)len);
    for (uint32_t i = 0; i < len; i++) {
        if ((i % 16U) == 0U) printf("\n  ");
        printf("%02X ", buf[i]);
    }
    printf("\n");
}

/* ============================================================
 *  1. sha256_test — 单包模式，硬件padding，32包1-1024随机
 *     用 sha2_hw 接口（≤128B走one-pkg，>128B走stream自动分包）
 * ============================================================ */
static int sha256_test(void)
{
    uint8_t soft_hash[32] = {0};
    uint8_t hard_hash[32] = {0};
    uint8_t buf[32] = {0};

    init_test_msg();

    /* 边界探测: NULL 入参 / NULL 出参, 不校验返回值 */
    sha2_hw(SHA2_MODE_SHA256, NULL, 16, buf, sizeof(buf));
    sha2_hw(SHA2_MODE_SHA256, test_msg, 16, NULL, 16);

    /* ---- 1. 软件参考 ---- */
    sha256(test_msg, MAX_MSG_LEN, soft_hash);

    /* ---- 2. 硬件 ---- */
    if (sha2_hw(SHA2_MODE_SHA256, test_msg, MAX_MSG_LEN, hard_hash, sizeof(hard_hash)) != RSP_OK)
    {
        printf("FAIL (hard hash error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %uB\n", (unsigned)MAX_MSG_LEN);

    sha_dump_buf("msg", test_msg, MAX_MSG_LEN > DUMP_MAX ? DUMP_MAX : MAX_MSG_LEN);
    sha_dump_buf("soft output:", soft_hash, 32);
    sha_dump_buf("hw output:", hard_hash, 32);
    if (memcmp(soft_hash, hard_hash, 32) != 0)
    {
        return -1;
    }
    printf("SHA256 HASH PASS\n");

    return 0;
}

/* ============================================================
 *  2. sha256_pkg_test — 多包模式，32包每次分3包
 *     用 sha2_hw_stream，chunk_size = ceil(in_len/3)
 * ============================================================ */
static void sha256_pkg_test(void)
{
    uint8_t hw_digest[32], sw_digest[32];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha256_pkg_test (stream, 3-pkg split, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;  /* 1-1024 */
        uint32_t chunk = (len + 2) / 3;  /* ceil(len/3) */

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA256;
        ctx.padding = SHA2_PAD_HARD;
        ctx.chunk_size = chunk;
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        sha256(test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 32) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u chunk=%u ret=%d\n", (unsigned)len, (unsigned)chunk, ret);
                print_hex("    HW", hw_digest, 32);
                print_hex("    SW", sw_digest, 32);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  3. sha256_hard_pad — 硬件padding stream，32包1-1024随机
 *     用 sha2_hw_stream，chunk_size=64（默认块大小）
 * ============================================================ */
static void sha256_hard_pad_test(void)
{
    uint8_t hw_digest[32], sw_digest[32];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha256_hard_pad (stream, hard pad, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA256;
        ctx.padding = SHA2_PAD_HARD;
        ctx.chunk_size = 0;  /* 自动=block_size=64 */
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        sha256(test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 32) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u ret=%d\n", (unsigned)len, ret);
                print_hex("    HW", hw_digest, 32);
                print_hex("    SW", sw_digest, 32);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  4. sha256_soft_pad_test — 软件padding，32包1-1024随机
 *     用 sha2_hw_stream，软件 padding
 * ============================================================ */
static void sha256_soft_pad_test(void)
{
    uint8_t hw_digest[32], sw_digest[32];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha256_soft_pad (stream, soft pad, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA256;
        ctx.padding = SHA2_PAD_SOFT;
        ctx.chunk_size = 0;
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        sha256(test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 32) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u ret=%d\n", (unsigned)len, ret);
                print_hex("    HW", hw_digest, 32);
                print_hex("    SW", sw_digest, 32);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  5. sha256_length_test — 128包从1-128长度遍历
 * ============================================================ */
static void sha256_length_test(void)
{
    uint8_t hw_digest[32], sw_digest[32];
    RSP_StatusTypeDef ret;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha256_length_test (1-128 bytes, 128 iterations)\n");
    printf("============================================================\n");

    for (uint32_t len = 1; len <= 128; len++) {
        ret = sha2_hw(SHA2_MODE_SHA256, test_msg, len, hw_digest, sizeof(hw_digest));
        sha256(test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 32) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u ret=%d\n", (unsigned)len, ret);
                print_hex("    HW", hw_digest, 32);
                print_hex("    SW", sw_digest, 32);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  HMAC-SHA256 软件参考实现
 * ============================================================ */
static void hmac_sha256_sw(const uint8_t *key, uint32_t key_len,
                           const uint8_t *msg, uint32_t msg_len,
                           uint8_t *out)
{
    uint8_t k_ipad[64], k_opad[64];
    uint8_t inner[32];
    static uint8_t temp[64 + MAX_MSG_LEN];

    /* key > 64B 时先 hash */
    if (key_len > 64U) {
        uint8_t k_hash[32];
        sha256(key, key_len, k_hash);
        memset(k_ipad, 0x36, 64);
        memset(k_opad, 0x5C, 64);
        for (uint32_t i = 0; i < 32U; i++) {
            k_ipad[i] ^= k_hash[i];
            k_opad[i] ^= k_hash[i];
        }
    } else {
        memset(k_ipad, 0x36, 64);
        memset(k_opad, 0x5C, 64);
        for (uint32_t i = 0; i < key_len; i++) {
            k_ipad[i] ^= key[i];
            k_opad[i] ^= key[i];
        }
    }

    /* inner = H(k_ipad || msg) */
    memcpy(temp, k_ipad, 64);
    memcpy(temp + 64, msg, msg_len);
    sha256(temp, 64 + msg_len, inner);

    /* outer = H(k_opad || inner) */
    memcpy(temp, k_opad, 64);
    memcpy(temp + 64, inner, 32);
    sha256(temp, 96, out);
}

/* ============================================================
 *  6. sha256_hmac_test — 单包/自动，硬件padding，32×1-1024随机
 * ============================================================ */
static int sha256_hmac_test(void)
{
    uint8_t soft_hmac[32] = {0};
    uint8_t hard_hmac[32] = {0};
    uint8_t buf[32] = {0};

    init_test_msg();

    /* 边界探测: key=NULL / key_len=0 / msg=NULL / out=NULL, 不校验返回值 */
    hmac_sha2_hw(SHA2_MODE_SHA256, NULL, 64, test_msg, 16, buf, sizeof(buf));
    hmac_sha2_hw(SHA2_MODE_SHA256, hmac_key, 0, test_msg, 16, buf, sizeof(buf));
    hmac_sha2_hw(SHA2_MODE_SHA256, hmac_key, 64, NULL, 16, buf, sizeof(buf));
    hmac_sha2_hw(SHA2_MODE_SHA256, hmac_key, 64, test_msg, 16, NULL, 16);

    /* ---- 1. 软件参考 ---- */
    hmac_sha256_sw(hmac_key, 64, test_msg, MAX_MSG_LEN, soft_hmac);

    /* ---- 2. 硬件 ---- */
    if (hmac_sha2_hw(SHA2_MODE_SHA256, hmac_key, 64, test_msg, MAX_MSG_LEN,
                     hard_hmac, sizeof(hard_hmac)) != RSP_OK)
    {
        printf("FAIL (hard hmac error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %uB, KEY SIZE = %uB\n", (unsigned)MAX_MSG_LEN, 64U);

    sha_dump_buf("msg", test_msg, MAX_MSG_LEN > DUMP_MAX ? DUMP_MAX : MAX_MSG_LEN);
    sha_dump_buf("key", hmac_key, 64);
    sha_dump_buf("soft hmac:", soft_hmac, 32);
    sha_dump_buf("hw hmac:", hard_hmac, 32);
    if (memcmp(soft_hmac, hard_hmac, 32) != 0)
    {
        return -1;
    }
    printf("HMAC-SHA256 PASS\n");

    return 0;
}

/* ============================================================
 *  7. sha256_hmac_pkg_test — 多包分3包，32×1-1024随机
 * ============================================================ */
static void sha256_hmac_pkg_test(void)
{
    uint8_t hw_digest[32], sw_digest[32];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha256_hmac_pkg_test (stream, 3-pkg split, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;
        uint32_t chunk = (len + 2) / 3;  /* ceil(len/3) */

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA256;
        ctx.padding = SHA2_PAD_HARD;
        ctx.is_hmac = 1U;
        ctx.chunk_size = chunk;
        ctx.key = hmac_key;
        ctx.key_len = 64;
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        hmac_sha256_sw(hmac_key, 64, test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 32) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u chunk=%u ret=%d\n", (unsigned)len, (unsigned)chunk, ret);
                print_hex("    HW", hw_digest, 32);
                print_hex("    SW", sw_digest, 32);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  8. sha256_hmac_soft_pad_test — 软件padding，32×1-1024随机
 * ============================================================ */
static void sha256_hmac_soft_pad_test(void)
{
    uint8_t hw_digest[32], sw_digest[32];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha256_hmac_soft_pad (stream, soft pad, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA256;
        ctx.padding = SHA2_PAD_SOFT;
        ctx.is_hmac = 1U;
        ctx.chunk_size = 0;
        ctx.key = hmac_key;
        ctx.key_len = 64;
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        hmac_sha256_sw(hmac_key, 64, test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 32) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u ret=%d\n", (unsigned)len, ret);
                print_hex("    HW", hw_digest, 32);
                print_hex("    SW", sw_digest, 32);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  HMAC-SHA384 软件参考实现（块大小 128B，摘要 48B）
 * ============================================================ */
static void hmac_sha384_sw(const uint8_t *key, uint32_t key_len,
                           const uint8_t *msg, uint32_t msg_len,
                           uint8_t *out)
{
    uint8_t k_ipad[128], k_opad[128];
    uint8_t inner[48];
    static uint8_t temp[128 + MAX_MSG_LEN];

    if (key_len > 128U) {
        uint8_t k_hash[48];
        sha384(key, key_len, k_hash);
        memset(k_ipad, 0x36, 128);
        memset(k_opad, 0x5C, 128);
        for (uint32_t i = 0; i < 48U; i++) {
            k_ipad[i] ^= k_hash[i];
            k_opad[i] ^= k_hash[i];
        }
    } else {
        memset(k_ipad, 0x36, 128);
        memset(k_opad, 0x5C, 128);
        for (uint32_t i = 0; i < key_len; i++) {
            k_ipad[i] ^= key[i];
            k_opad[i] ^= key[i];
        }
    }

    memcpy(temp, k_ipad, 128);
    memcpy(temp + 128, msg, msg_len);
    sha384(temp, 128 + msg_len, inner);

    memcpy(temp, k_opad, 128);
    memcpy(temp + 128, inner, 48);
    sha384(temp, 176, out);
}

/* ============================================================
 *  9. sha384_test — 单包/自动，硬件padding，32×1-1024随机
 * ============================================================ */
static int sha384_test(void)
{
    uint8_t soft_hash[48] = {0};
    uint8_t hard_hash[48] = {0};
    uint8_t buf[48] = {0};

    init_test_msg();

    /* 边界探测: NULL 入参 / NULL 出参, 不校验返回值 */
    sha2_hw(SHA2_MODE_SHA384, NULL, 16, buf, sizeof(buf));
    sha2_hw(SHA2_MODE_SHA384, test_msg, 16, NULL, 16);

    /* ---- 1. 软件参考 ---- */
    sha384(test_msg, MAX_MSG_LEN, soft_hash);

    /* ---- 2. 硬件 ---- */
    if (sha2_hw(SHA2_MODE_SHA384, test_msg, MAX_MSG_LEN, hard_hash, sizeof(hard_hash)) != RSP_OK)
    {
        printf("FAIL (hard hash error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %uB\n", (unsigned)MAX_MSG_LEN);

    sha_dump_buf("msg", test_msg, MAX_MSG_LEN > DUMP_MAX ? DUMP_MAX : MAX_MSG_LEN);
    sha_dump_buf("soft output:", soft_hash, 48);
    sha_dump_buf("hw output:", hard_hash, 48);
    if (memcmp(soft_hash, hard_hash, 48) != 0)
    {
        return -1;
    }
    printf("SHA384 HASH PASS\n");

    return 0;
}

/* ============================================================
 *  10. sha384_pkg_test — 多包模式，32包每次分3包
 * ============================================================ */
static void sha384_pkg_test(void)
{
    uint8_t hw_digest[48], sw_digest[48];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha384_pkg_test (stream, 3-pkg split, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;
        uint32_t chunk = (len + 2) / 3;

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA384;
        ctx.padding = SHA2_PAD_HARD;
        ctx.chunk_size = chunk;
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        sha384(test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 48) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u chunk=%u ret=%d\n", (unsigned)len, (unsigned)chunk, ret);
                print_hex("    HW", hw_digest, 48);
                print_hex("    SW", sw_digest, 48);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  11. sha384_soft_padding_test — 软件padding，32包1-1024随机
 * ============================================================ */
static void sha384_soft_padding_test(void)
{
    uint8_t hw_digest[48], sw_digest[48];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha384_soft_padding_test (stream, soft pad, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA384;
        ctx.padding = SHA2_PAD_SOFT;
        ctx.chunk_size = 0;
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        sha384(test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 48) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u ret=%d\n", (unsigned)len, ret);
                print_hex("    HW", hw_digest, 48);
                print_hex("    SW", sw_digest, 48);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  12. sha384_lenth_test — 128包从1-128长度遍历
 * ============================================================ */
static void sha384_lenth_test(void)
{
    uint8_t hw_digest[48], sw_digest[48];
    RSP_StatusTypeDef ret;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha384_lenth_test (1-128 bytes, 128 iterations)\n");
    printf("============================================================\n");

    for (uint32_t len = 1; len <= 128; len++) {
        ret = sha2_hw(SHA2_MODE_SHA384, test_msg, len, hw_digest, sizeof(hw_digest));
        sha384(test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 48) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u ret=%d\n", (unsigned)len, ret);
                print_hex("    HW", hw_digest, 48);
                print_hex("    SW", sw_digest, 48);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  13. sha384_hmac_test — 单包/自动，硬件padding，32×1-1024随机
 * ============================================================ */
static int sha384_hmac_test(void)
{
    uint8_t soft_hmac[48] = {0};
    uint8_t hard_hmac[48] = {0};
    uint8_t buf[48] = {0};

    init_test_msg();

    /* 边界探测: key=NULL / key_len=0 / msg=NULL / out=NULL, 不校验返回值 */
    hmac_sha2_hw(SHA2_MODE_SHA384, NULL, 128, test_msg, 16, buf, sizeof(buf));
    hmac_sha2_hw(SHA2_MODE_SHA384, hmac_key_384, 0, test_msg, 16, buf, sizeof(buf));
    hmac_sha2_hw(SHA2_MODE_SHA384, hmac_key_384, 128, NULL, 16, buf, sizeof(buf));
    hmac_sha2_hw(SHA2_MODE_SHA384, hmac_key_384, 128, test_msg, 16, NULL, 16);

    /* ---- 1. 软件参考 ---- */
    hmac_sha384_sw(hmac_key_384, 128, test_msg, MAX_MSG_LEN, soft_hmac);

    /* ---- 2. 硬件 ---- */
    if (hmac_sha2_hw(SHA2_MODE_SHA384, hmac_key_384, 128, test_msg, MAX_MSG_LEN,
                     hard_hmac, sizeof(hard_hmac)) != RSP_OK)
    {
        printf("FAIL (hard hmac error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %uB, KEY SIZE = %uB\n", (unsigned)MAX_MSG_LEN, 128U);

    sha_dump_buf("msg", test_msg, MAX_MSG_LEN > DUMP_MAX ? DUMP_MAX : MAX_MSG_LEN);
    sha_dump_buf("key", hmac_key_384, 128);
    sha_dump_buf("soft hmac:", soft_hmac, 48);
    sha_dump_buf("hw hmac:", hard_hmac, 48);
    if (memcmp(soft_hmac, hard_hmac, 48) != 0)
    {
        return -1;
    }
    printf("HMAC-SHA384 PASS\n");

    return 0;
}

/* ============================================================
 *  14. sha384_hmac_pkg_test — 多包分3包，32×1-1024随机
 * ============================================================ */
static void sha384_hmac_pkg_test(void)
{
    uint8_t hw_digest[48], sw_digest[48];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha384_hmac_pkg_test (stream, 3-pkg split, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;
        uint32_t chunk = (len + 2) / 3;

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA384;
        ctx.padding = SHA2_PAD_HARD;
        ctx.is_hmac = 1U;
        ctx.chunk_size = chunk;
        ctx.key = hmac_key_384;
        ctx.key_len = 128;
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        hmac_sha384_sw(hmac_key_384, 128, test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 48) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u chunk=%u ret=%d\n", (unsigned)len, (unsigned)chunk, ret);
                print_hex("    HW", hw_digest, 48);
                print_hex("    SW", sw_digest, 48);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  15. sha384_hmac_soft_padding_test — 软件padding，32×1-1024随机
 * ============================================================ */
static void sha384_hmac_soft_padding_test(void)
{
    uint8_t hw_digest[48], sw_digest[48];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha384_hmac_soft_padding_test (stream, soft pad, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA384;
        ctx.padding = SHA2_PAD_SOFT;
        ctx.is_hmac = 1U;
        ctx.chunk_size = 0;
        ctx.key = hmac_key_384;
        ctx.key_len = 128;
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        hmac_sha384_sw(hmac_key_384, 128, test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 48) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u ret=%d\n", (unsigned)len, ret);
                print_hex("    HW", hw_digest, 48);
                print_hex("    SW", sw_digest, 48);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  HMAC-SHA512 软件参考实现（块大小 128B，摘要 64B）
 * ============================================================ */
static void hmac_sha512_sw(const uint8_t *key, uint32_t key_len,
                           const uint8_t *msg, uint32_t msg_len,
                           uint8_t *out)
{
    uint8_t k_ipad[128], k_opad[128];
    uint8_t inner[64];
    static uint8_t temp[128 + MAX_MSG_LEN];

    if (key_len > 128U) {
        uint8_t k_hash[64];
        sha512(key, key_len, k_hash);
        memset(k_ipad, 0x36, 128);
        memset(k_opad, 0x5C, 128);
        for (uint32_t i = 0; i < 64U; i++) {
            k_ipad[i] ^= k_hash[i];
            k_opad[i] ^= k_hash[i];
        }
    } else {
        memset(k_ipad, 0x36, 128);
        memset(k_opad, 0x5C, 128);
        for (uint32_t i = 0; i < key_len; i++) {
            k_ipad[i] ^= key[i];
            k_opad[i] ^= key[i];
        }
    }

    memcpy(temp, k_ipad, 128);
    memcpy(temp + 128, msg, msg_len);
    sha512(temp, 128 + msg_len, inner);

    memcpy(temp, k_opad, 128);
    memcpy(temp + 128, inner, 64);
    sha512(temp, 192, out);
}

/* ============================================================
 *  16. sha512_test — 单包/自动，硬件padding，32×1-1024随机
 * ============================================================ */
static int sha512_test(void)
{
    uint8_t soft_hash[64] = {0};
    uint8_t hard_hash[64] = {0};
    uint8_t buf[64] = {0};

    init_test_msg();

    /* 边界探测: NULL 入参 / NULL 出参, 不校验返回值 */
    sha2_hw(SHA2_MODE_SHA512, NULL, 16, buf, sizeof(buf));
    sha2_hw(SHA2_MODE_SHA512, test_msg, 16, NULL, 16);

    /* ---- 1. 软件参考 ---- */
    sha512(test_msg, MAX_MSG_LEN, soft_hash);

    /* ---- 2. 硬件 ---- */
    if (sha2_hw(SHA2_MODE_SHA512, test_msg, MAX_MSG_LEN, hard_hash, sizeof(hard_hash)) != RSP_OK)
    {
        printf("FAIL (hard hash error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %uB\n", (unsigned)MAX_MSG_LEN);

    sha_dump_buf("msg", test_msg, MAX_MSG_LEN > DUMP_MAX ? DUMP_MAX : MAX_MSG_LEN);
    sha_dump_buf("soft output:", soft_hash, 64);
    sha_dump_buf("hw output:", hard_hash, 64);
    if (memcmp(soft_hash, hard_hash, 64) != 0)
    {
        return -1;
    }
    printf("SHA512 HASH PASS\n");

    return 0;
}

/* ============================================================
 *  17. sha512_pkg_test — 多包模式，32包每次分3包
 * ============================================================ */
static void sha512_pkg_test(void)
{
    uint8_t hw_digest[64], sw_digest[64];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha512_pkg_test (stream, 3-pkg split, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;
        uint32_t chunk = (len + 2) / 3;

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA512;
        ctx.padding = SHA2_PAD_HARD;
        ctx.chunk_size = chunk;
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        sha512(test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 64) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u chunk=%u ret=%d\n", (unsigned)len, (unsigned)chunk, ret);
                print_hex("    HW", hw_digest, 64);
                print_hex("    SW", sw_digest, 64);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  18. sha512_soft_padding_test — 软件padding，32包1-1024随机
 * ============================================================ */
static void sha512_soft_padding_test(void)
{
    uint8_t hw_digest[64], sw_digest[64];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha512_soft_padding_test (stream, soft pad, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA512;
        ctx.padding = SHA2_PAD_SOFT;
        ctx.chunk_size = 0;
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        sha512(test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 64) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u ret=%d\n", (unsigned)len, ret);
                print_hex("    HW", hw_digest, 64);
                print_hex("    SW", sw_digest, 64);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  19. sha512_lenth_test — 128包从1-128长度遍历
 * ============================================================ */
static void sha512_lenth_test(void)
{
    uint8_t hw_digest[64], sw_digest[64];
    RSP_StatusTypeDef ret;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha512_lenth_test (1-128 bytes, 128 iterations)\n");
    printf("============================================================\n");

    for (uint32_t len = 1; len <= 128; len++) {
        ret = sha2_hw(SHA2_MODE_SHA512, test_msg, len, hw_digest, sizeof(hw_digest));
        sha512(test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 64) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u ret=%d\n", (unsigned)len, ret);
                print_hex("    HW", hw_digest, 64);
                print_hex("    SW", sw_digest, 64);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  20. sha512_hmac_test — 单包/自动，硬件padding，32×1-1024随机
 * ============================================================ */
static int sha512_hmac_test(void)
{
    uint8_t soft_hmac[64] = {0};
    uint8_t hard_hmac[64] = {0};
    uint8_t buf[64] = {0};

    init_test_msg();

    /* 边界探测: key=NULL / key_len=0 / msg=NULL / out=NULL, 不校验返回值 */
    hmac_sha2_hw(SHA2_MODE_SHA512, NULL, 128, test_msg, 16, buf, sizeof(buf));
    hmac_sha2_hw(SHA2_MODE_SHA512, hmac_key_384, 0, test_msg, 16, buf, sizeof(buf));
    hmac_sha2_hw(SHA2_MODE_SHA512, hmac_key_384, 128, NULL, 16, buf, sizeof(buf));
    hmac_sha2_hw(SHA2_MODE_SHA512, hmac_key_384, 128, test_msg, 16, NULL, 16);

    /* ---- 1. 软件参考 ---- */
    hmac_sha512_sw(hmac_key_384, 128, test_msg, MAX_MSG_LEN, soft_hmac);

    /* ---- 2. 硬件 ---- */
    if (hmac_sha2_hw(SHA2_MODE_SHA512, hmac_key_384, 128, test_msg, MAX_MSG_LEN,
                     hard_hmac, sizeof(hard_hmac)) != RSP_OK)
    {
        printf("FAIL (hard hmac error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %uB, KEY SIZE = %uB\n", (unsigned)MAX_MSG_LEN, 128U);

    sha_dump_buf("msg", test_msg, MAX_MSG_LEN > DUMP_MAX ? DUMP_MAX : MAX_MSG_LEN);
    sha_dump_buf("key", hmac_key_384, 128);
    sha_dump_buf("soft hmac:", soft_hmac, 64);
    sha_dump_buf("hw hmac:", hard_hmac, 64);
    if (memcmp(soft_hmac, hard_hmac, 64) != 0)
    {
        return -1;
    }
    printf("HMAC-SHA512 PASS\n");

    return 0;
}

/* ============================================================
 *  21. sha512_hmac_pkg_test — 多包分3包，32×1-1024随机
 * ============================================================ */
static void sha512_hmac_pkg_test(void)
{
    uint8_t hw_digest[64], sw_digest[64];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha512_hmac_pkg_test (stream, 3-pkg split, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;
        uint32_t chunk = (len + 2) / 3;

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA512;
        ctx.padding = SHA2_PAD_HARD;
        ctx.is_hmac = 1U;
        ctx.chunk_size = chunk;
        ctx.key = hmac_key_384;
        ctx.key_len = 128;
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        hmac_sha512_sw(hmac_key_384, 128, test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 64) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u chunk=%u ret=%d\n", (unsigned)len, (unsigned)chunk, ret);
                print_hex("    HW", hw_digest, 64);
                print_hex("    SW", sw_digest, 64);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  22. sha512_hmac_soft_padding_test — 软件padding，32×1-1024随机
 * ============================================================ */
static void sha512_hmac_soft_padding_test(void)
{
    uint8_t hw_digest[64], sw_digest[64];
    RSP_StatusTypeDef ret;
    sha2_ctx_t ctx;
    int pass_cnt = 0, fail_cnt = 0;

    printf("\n============================================================\n");
    printf("TEST: sha512_hmac_soft_padding_test (stream, soft pad, 32x 1-1024 random)\n");
    printf("============================================================\n");

    for (int i = 0; i < 32; i++) {
        uint32_t len = (simple_rand() % 1024) + 1;

        memset(&ctx, 0, sizeof(ctx));
        ctx.mode = SHA2_MODE_SHA512;
        ctx.padding = SHA2_PAD_SOFT;
        ctx.is_hmac = 1U;
        ctx.chunk_size = 0;
        ctx.key = hmac_key_384;
        ctx.key_len = 128;
        ctx.in = test_msg;
        ctx.in_len = len;
        ctx.out = hw_digest;
        ctx.out_len = sizeof(hw_digest);

        ret = sha2_hw_stream(&ctx);
        hmac_sha512_sw(hmac_key_384, 128, test_msg, len, sw_digest);
        if (ret == RSP_OK && memcmp(hw_digest, sw_digest, 64) == 0) {
            pass_cnt++;
        } else {
            fail_cnt++;
            if (fail_cnt <= 3) {
                printf("  FAIL: len=%u ret=%d\n", (unsigned)len, ret);
                print_hex("    HW", hw_digest, 64);
                print_hex("    SW", sw_digest, 64);
            }
        }
    }
    printf("  Result: %d PASS, %d FAIL\n", pass_cnt, fail_cnt);
}

/* ============================================================
 *  主测试入口
 * ============================================================ */
int sha2_test(void)
{
    for (uint32_t i = 0; i < PRESSURE_TEST; i++)
    {
        sha256_test();
        sha256_hmac_test();

        sha384_test();
        sha384_hmac_test();

        sha512_test();
        sha512_hmac_test();
    }
    return 0;
}
