// #include "rsp_ip_sm3.h"
// #include "rsp_ip_sm4.h"
// #include "rsp_ip_aes.h"
#include <stdint.h>

int pkpu_e203_keygen_512_test(void);
int pkpu_e203_enc_512_test(void);
int pkpu_e203_dec_512_test(void);

#define PRESSURE_TEST 1U    


void pkpu_e203_test()
{
       for (uint32_t i = 0; i < PRESSURE_TEST; i++)
    {
    pkpu_e203_keygen_512_test();
    pkpu_e203_enc_512_test();
    pkpu_e203_dec_512_test();
    }
}
