#include <stdio.h>
#include "rsp_hal.h"
#include "i2c_algo_id.h"
#include "rsp_ip_sm4.h"
#include "rsp_ip_aes.h"
#include "rsp_ip_sm3.h"
#include "rsp_ip_sha.h"
#include "rsp_ip_sm2.h"
#include "rsp_ip_rsa.h"
#include "rsp_ip_chacha20.h"
#include "sm4.h"
#include "sm3.h"
#include "sha.h"
#include "sm1.h"
#include "des.h"

/* pqc_203 helpers defined in source/app/e203/512/e203_512_test.c */
int pqc_203_set_algo(uint8_t algoid);
int pqc_203_run_algo(uint8_t algoid, uint8_t *data, uint32_t len, uint8_t *out, uint32_t *outlen);

/* 各算法输入偏移常量 */
#define SM4_KEY_OFF 0
#define SM4_IV_OFF (SM4_KEY_OFF + 16)
#define SM4_MSG_OFF (SM4_IV_OFF + 16)


int i2c_sample()
{
	int cmd[2];

	uint8_t raw_data[128];
	uint8_t raw_recv_data[128];

	i2c_handle_t ns300_i2c_handle;
	rsp_i2c_param_t i2c_param;
	ns300_i2c_handle.port = RSP_IIC_0;
	ns300_i2c_handle.param = &i2c_param;

	printf("I2C SLAVE ...\r\n");

	i2c_param.mode = I2C_MODE_SLAVE;
	i2c_param.speed = I2C_SPEED_FAST_1000K;
	i2c_param.address_bits = I2C_MASTER_ADDRESS_7BIT;
	i2c_param.address = 0x1e;
	rsp_hal_i2c_dw_init(&ns300_i2c_handle);

	while (1)
	{
		rsp_hal_i2c_dw_slave_receive(ns300_i2c_handle.port, (uint8_t *)&cmd, 2);
		switch (cmd[0])
		{
		case 0x01:
			printf("M->S: \r\n");
			while (0 == rsp_hal_i2c_dw_slave_receive(ns300_i2c_handle.port, raw_recv_data, cmd[1]))
				;
			printf("M->S-E: \r\n");
			break;
		case 0x02:
			printf("M<-S: \r\n");
			rsp_hal_i2c_dw_slave_transmit(ns300_i2c_handle.port, raw_data, cmd[1]);
			printf("M<-S-E: \r\n");
			break;
		}
	}
}

/************************************************/

// 命令码规划
#define CMD_REG_WRITE 0x01
#define CMD_REG_READ 0x02
#define CMD_LONG_WRITE 0x03
#define CMD_LONG_READ 0x04
#define CMD_PQC_CHOOSE_ALG 0x05

#define DATA_ENDFLAG_OFF 0x00
#define DATA_ENDFLAG_ON 0x01

typedef struct __attribute__((packed))
{
	uint8_t magic;
	uint8_t cmd : 4;
	uint8_t seq : 3;
	uint8_t endflag : 1;
	uint16_t len;
	uint16_t templen;
	uint8_t algoid;
} i2c_packet_header;

uint8_t calc_crc8(uint8_t *data, int len)
{
	uint8_t crc = 0x00;
	int i, j;
	for (i = 0; i < len; i++)
	{
		crc ^= data[i];
		for (j = 0; j < 8; j++)
		{
			if (crc & 0x80)
				crc = (crc << 1) ^ 0x07;
			else
				crc <<= 1;
		}
	}
	return crc;
}

typedef struct __attribute__((packed))
{
	uint8_t ret_code;
	uint8_t seq;
} i2c_ack_t;

// 错误码定义
#define I2C_RET_OK 0x00
#define I2C_RET_ERR_CRC 0x01
#define I2C_RET_ERR_CMD 0x02
#define I2C_RET_ERR_ADDR 0x03
#define I2C_RET_ERR_ALGID 0x04
#define I2C_RET_ERR_LEN 0x05
#define I2C_RET_ERR_TIMEOUT 0x06
#define I2C_RET_ERR_UNSUPPORT 0x07
#define I2C_RET_ERR_AUTH      0x08   /* GCM TAG 验证失败 */

int rsp_hal_algo_status(uint8_t algoid, uint32_t *data)
{
	data[0] = 1;
	return 0;
}

/* AES 密钥长度: templen 指定 24/32，其余按 16 */
static uint32_t aes_key_len(uint32_t templen)
{
	return (templen == 24U || templen == 32U) ? templen : 16U;
}

/* SM2 默认用户 ID */
static const uint8_t sm2_id_default[] = SM2_ID_DEFAULT;

/**
 * SM4/AES GCM 硬件 IFIFO 原生格式解析
 *
 * payload（硬件 IFIFO 顺序，AAD/message 不补零, 由 IP 内部做）：
 *   key(klen) + iv16(16) + MID_TAG(16) + TAG2(16) + aad + message
 *
 * 长度不由 payload 携带，由 templen 的低 16 位传入：
 *   templen & 0xFF        = aad_len  (字节, ≤255)
 *   (templen >> 8) & 0xFF = msg_len  (字节, ≤255)
 *
 * 加密: TAG2 块在 payload 中填 0，硬件算完把 TAG 追加到密文之后输出
 * 解密: TAG2 块放待验证 TAG，硬件验证后只输出明文
 */
static int algo_gcm(uint32_t key_len, int is_aes, int is_encrypt, uint32_t templen,
					uint8_t *data, uint32_t len, uint8_t *out, uint32_t *outlen)
{
	uint32_t aad_len, msg_len;
	const uint8_t *aad;
	const uint8_t *msg;

	/* 所有长度都是 APP 补零后的值, firmware 不做任何 ceil.
	 * templen 低 16 位 = msg_pad (补零后)
	 * MID_TAG[0..1] (offset 32..33, LE) = aad_pad (补零后)
	 * 两者保证都是 16 的倍数 */
	msg_len = templen & 0xFFFFU;
	aad_len = (uint32_t)data[32] | ((uint32_t)data[33] << 8);

	/* 先设 outlen=0, 避免后续 LONG_READ 用 sizeof(outdata) 等待 */
	*outlen = 0;

	/* payload 长度检查: 64 头 + aad_pad + msg_pad */
	if (len < (64U + aad_len + msg_len))
	{
		printf("GCM ERR_LEN: got=%lu expect>=%lu (aad=%lu msg=%lu templen=%04lX)\r\n",
			   (unsigned long)len, (unsigned long)(64U + aad_len + msg_len),
			   (unsigned long)aad_len, (unsigned long)msg_len, (unsigned long)templen);
		return I2C_RET_ERR_LEN;
	}

	/* 偏移: key(16) + iv16(16) + MID_TAG(16) + TAG2(16) = 64B */
	/* aad_len / msg_len 本身就是对齐后的, 直接当偏移 */
	aad = (aad_len > 0U) ? &data[64U] : NULL;
	msg = &data[64U + aad_len];
	/* TAG 指针:
	 *   加密: driver 会把硬件生成的 TAG 写到 tag_out, 指向 out[msg_len]
	 *   解密: 从 payload TAG2 槽读待验证 TAG (driver 内部 tag_in) */
	uint8_t *tag_out = out + msg_len;     /* 加密时 driver 写这里 */
	const uint8_t *tag_in = &data[48U];   /* 解密时 driver 读这里 */

	*outlen = is_encrypt ? (msg_len + 16U) : msg_len;

	/* AES 密钥长度不能从 templen 推: GCM 的 templen 是 msg_pad,
	 * msg_pad 恰好等于 24/32 时会被误判成 AES-192/256。
	 * 用 payload 反推: len = key_len + 16(iv) + 16(MID_TAG) + 16(TAG2) + aad + msg */
	if (is_aes)
	{
		uint32_t klen = len - (48U + aad_len + msg_len);
		if (klen == 16U || klen == 24U || klen == 32U)
			key_len = klen;
		/* 加密: 硬件 TAG 写到 out 尾部(驱动按 outlen 读回);
		 * 解密: 从 payload TAG2 槽读待验证 TAG */
		return (int)aes_gcm(data, key_len, &data[key_len],
							aad, aad_len, msg, out, msg_len,
							(uint8_t *)(is_encrypt ? tag_out : tag_in), is_encrypt);
	}

	/* sm4_gcm_hw: 加密时 tag 写 ctx.tag_out (=out+msg_len), 解密时从 ctx.tag_in 读 */
	return (int)sm4_gcm_hw(data, key_len, &data[key_len],
						   aad, aad_len, msg, out, msg_len,
						   (uint8_t*)(is_encrypt ? tag_out : tag_in), is_encrypt);
}

/**
 * @brief 根据 algoid 分发调用对应硬件/软件算核（顺序与 i2c_algo_id.h 枚举一致）
 *
 * data 布局（按枚举顺序，各段固定长度拼接）：
 *   SM4/AES ECB : key(klen) + message
 *   SM4/AES CBC : key(klen) + iv(16) + message
 *   SM4/AES CTR : key(klen) + iv(16) + message
 *   SM4/AES GCM : key(klen) + nonce(12) + aad_len(2,LE) + aad + tag(16) + message
 *   SM1 ECB/CBC : key(16) + [iv(8)] + message
 *   DES ECB/CBC : key(8)  + [iv(8)] + message
 *   SM3/SHA* HASH : message
 *   SM3/SHA* HMAC : key(klen) + message
 *   SM2_ENC     : k(32) + pub(64) + message
 *   SM2_DEC     : d(32) + cipher(C1|C2|C3)
 *   SM2_SIGN    : k(32) + d(32) + pub(64) + message
 *   SM2_VERIFY  : r(32) + s(32) + pub(64) + message
 *   SM2_KP      : id(16) + k(32) + pub(64)
 *   SM2_KG      : k(32)
 *   RSA_ENC     : e(256) + n(256) + msg(256)
 *   RSA_DEC     : n(256) + d(256) + msg(256)
 *   RSA_SIGN    : n(256) + d(256) + message
 *   RSA_VERIFY  : e(256) + n(256) + message
 *   CHACHA20_STREAM : key(32) + nonce(12) + aad_len(2,LE) + aad + tag(16) + message
 *
 * klen: SM4 固定 16；AES/HMAC 由 templen 指定(24/32)，其余按 16
 *
 * @param algoid 算法 ID（见 i2c_algo_id.h）
 * @param data   I2C 接收到的完整 payload
 * @param len    payload 字节长度
 * @param out    算核输出缓冲
 * @param outlen [in/out] 输入 out 缓冲容量，输出实际产出字节数
 * @return 0=成功；负数=RSP_ERR；正数=I2C_RET_ERR_*
 */
int rsp_hal_algo_execute(uint8_t algoid, uint8_t *data, uint32_t len,
						 uint8_t *out, uint32_t *outlen, uint32_t templen)
{
	uint32_t klen;
	int ret;

	if (!data || !out || !outlen)
		return -1;

	switch (algoid)
	{
	/* ==================== 1. SM4 ECB / CBC / CTR / GCM ==================== */
	case RSP_SM4_ECB_ENC:
	case RSP_SM4_ECB_DEC:
		if (len < 16U)
			return I2C_RET_ERR_LEN;
		/* MSG 任意长度: 驱动末块补0, 输出长度为16的整数倍 */
		*outlen = (len - 16U + SM4_BLOCK_BYTE_LEN - 1U) &
				  ~(SM4_BLOCK_BYTE_LEN - 1U);
		return (int)sm4_ecb_hw(&data[SM4_KEY_OFF], SM4_KEY_BYTE_LEN,
							   &data[16], out, *outlen,
							   algoid == RSP_SM4_ECB_ENC);

	case RSP_SM4_CBC_ENC:
	case RSP_SM4_CBC_DEC:
		if (len < 32U)
			return I2C_RET_ERR_LEN;
		/* MSG 任意长度: 驱动末块补0, 输出长度为16的整数倍 */
		*outlen = (len - 32U + SM4_BLOCK_BYTE_LEN - 1U) &
				  ~(SM4_BLOCK_BYTE_LEN - 1U);
		return (int)sm4_cbc_hw(&data[SM4_KEY_OFF], SM4_KEY_BYTE_LEN,
							   &data[SM4_IV_OFF], &data[SM4_MSG_OFF],
							   out, *outlen, algoid == RSP_SM4_CBC_ENC);

	case RSP_SM4_CTR_ENC:
	case RSP_SM4_CTR_DEC:
		if (len < 32U)
			return I2C_RET_ERR_LEN;
		*outlen = len - 32U;
		return (int)sm4_ctr_hw(&data[SM4_KEY_OFF], SM4_KEY_BYTE_LEN,
							   &data[SM4_IV_OFF], &data[SM4_MSG_OFF],
							   out, *outlen, algoid == RSP_SM4_CTR_ENC);

	case RSP_SM4_GCM_ENC:
	case RSP_SM4_GCM_DEC:
		return algo_gcm(16U, 0, algoid == RSP_SM4_GCM_ENC, templen,
						data, len, out, outlen);

	/* ==================== 2. AES ECB / CBC / CTR / GCM ==================== */
	case RSP_AES_ECB_ENC:
	case RSP_AES_ECB_DEC:
		klen = aes_key_len(templen);
		if (len < klen)
			return I2C_RET_ERR_LEN;
		*outlen = len - klen;
		return (int)aes_ecb(data, klen, &data[klen], out, *outlen,
							algoid == RSP_AES_ECB_ENC);

	case RSP_AES_CBC_ENC:
	case RSP_AES_CBC_DEC:
		klen = aes_key_len(templen);
		if (len < klen + 16U)
			return I2C_RET_ERR_LEN;
		*outlen = len - klen - 16U;
		return (int)aes_cbc(data, klen, &data[klen], &data[klen + 16U],
							out, *outlen, algoid == RSP_AES_CBC_ENC);

	case RSP_AES_CTR_ENC:
	case RSP_AES_CTR_DEC:
		klen = aes_key_len(templen);
		if (len < klen + 16U)
			return I2C_RET_ERR_LEN;
		*outlen = len - klen - 16U;
		return (int)aes_ctr(data, klen, &data[klen], &data[klen + 16U],
							out, *outlen, algoid == RSP_AES_CTR_ENC);

	case RSP_AES_GCM_ENC:
	case RSP_AES_GCM_DEC:
		return algo_gcm(aes_key_len(templen), 1, algoid == RSP_AES_GCM_ENC, templen,
						data, len, out, outlen);

	/* ==================== 3. SM1 / DES ==================== */
	case RSP_SM1_ECB_ENC:
	case RSP_SM1_ECB_DEC:
	{
		sm1_ctx_t sctx;

		if (len < 16U)
			return I2C_RET_ERR_LEN;
		if (sm1_init(&sctx, data, NULL) != 0)
			return I2C_RET_ERR_ALGID;
		*outlen = len - 16U;
		ret = (algoid == RSP_SM1_ECB_ENC)
				  ? (int)sm1_encrypt_ecb(&sctx, &data[16], out, *outlen)
				  : (int)sm1_decrypt_ecb(&sctx, &data[16], out, *outlen);
		return ret;
	}

	case RSP_SM1_CBC_ENC:
	case RSP_SM1_CBC_DEC:
	{
		sm1_ctx_t sctx;

		if (len < 24U)
			return I2C_RET_ERR_LEN;
		if (sm1_init(&sctx, data, &data[16]) != 0)
			return I2C_RET_ERR_ALGID;
		*outlen = len - 24U;
		ret = (algoid == RSP_SM1_CBC_ENC)
				  ? (int)sm1_encrypt_cbc(&sctx, &data[24], out, *outlen)
				  : (int)sm1_decrypt_cbc(&sctx, &data[24], out, *outlen);
		return ret;
	}

	case RSP_DES_ECB_ENC:
	case RSP_DES_ECB_DEC:
	{
		des_key_schedule dks;

		if (len < 8U)
			return I2C_RET_ERR_LEN;
		des_key(data, &dks);
		*outlen = len - 8U;
		ret = (algoid == RSP_DES_ECB_ENC)
				  ? des_ecb_encrypt(&data[8], out, *outlen, &dks)
				  : des_ecb_decrypt(&data[8], out, *outlen, &dks);
		return ret;
	}

	case RSP_DES_CBC_ENC:
	case RSP_DES_CBC_DEC:
	{
		des_key_schedule dks;

		if (len < 16U)
			return I2C_RET_ERR_LEN;
		des_key(data, &dks);
		*outlen = len - 16U;
		ret = (algoid == RSP_DES_CBC_ENC)
				  ? des_cbc_encrypt(&data[16], out, *outlen, &data[8], &dks)
				  : des_cbc_decrypt(&data[16], out, *outlen, &data[8], &dks);
		return ret;
	}

	/* ==================== 4. SM3 / SHA2 杂凑与 HMAC ==================== */
	case RSP_SM3_HASH:
		*outlen = 32;
		return (int)SM3_IP_PerfHash(data, len, out);

	case RSP_SM3_HMAC:
		klen = templen;//(templen != 0U && templen <= 64U) ? templen : 16U;
		if (len < klen)
			return I2C_RET_ERR_LEN;
		*outlen = 32;
		return (int)SM3_IP_PerfHMAC(data, klen, &data[klen], len - klen, out);

	case RSP_SHA256_HASH:
		*outlen = 32;
		return (int)sha2_hw(SHA2_MODE_SHA256, data, len, out, 32);

	case RSP_SHA256_HMAC:
		klen =  (templen != 0U && templen <= 64U) ? templen : 16U;
		if (len < klen)
			return I2C_RET_ERR_LEN;
		*outlen = 32;
		return (int)hmac_sha2_hw(SHA2_MODE_SHA256, data, klen,
								 &data[klen], len - klen, out, 32);

	case RSP_SHA384_HASH:
		*outlen = 48;
		return (int)sha2_hw(SHA2_MODE_SHA384, data, len, out, 48);

	case RSP_SHA384_HMAC:
		klen = (templen != 0U && templen <= 128U) ? templen : 16U;
		if (len < klen)
			return I2C_RET_ERR_LEN;
		*outlen = 48;
		return (int)hmac_sha2_hw(SHA2_MODE_SHA384, data, klen,
								 &data[klen], len - klen, out, 48);

	case RSP_SHA512_HASH:
		*outlen = 64;
		return (int)sha2_hw(SHA2_MODE_SHA512, data, len, out, 64);

	case RSP_SHA512_HMAC:
		klen = (templen != 0U && templen <= 128U) ? templen : 16U;
		if (len < klen)
			return I2C_RET_ERR_LEN;
		*outlen = 64;
		return (int)hmac_sha2_hw(SHA2_MODE_SHA512, data, klen,
								 &data[klen], len - klen, out, 64);

	/* ==================== 5. SM2 ==================== */
	/* SM2_ENC    : k(32) + pub(64) + message            -> C1(64)+C2(n)+C3(32) */
	case RSP_SM2_ENC:
	{
		uint32_t clen = 0U;

		if (len < 96U)
			return I2C_RET_ERR_LEN;
		ret = (int)sm2_hw_encrypt(&data[0], &data[32],
								  &data[96], len - 96U, out, &clen);
		*outlen = clen;
		return ret;
	}

	/* SM2_DEC    : d(32) + cipher(C1||C2||C3)          -> plaintext(n) */
	case RSP_SM2_DEC:
	{
		uint32_t mlen = 0U;

		if (len < 128U)
			return I2C_RET_ERR_LEN;
		ret = (int)sm2_hw_decrypt(&data[0], &data[32], len - 32U, out, &mlen);
		*outlen = mlen;
		return ret;
	}

	/* SM2_SIGN   : k(32) + d(32) + pub(64) + message    -> r||s(64) */
	case RSP_SM2_SIGN:
		if (len < 128U)
			return I2C_RET_ERR_LEN;
		*outlen = 64;
		return (int)sm2_hw_sign_msg(sm2_id_default, 16U,
									&data[64], &data[128], len - 128U,
									&data[32], &data[0], out);

	/* SM2_VERIFY : r(32) + s(32) + pub(64) + message    -> 1B 结果 */
	case RSP_SM2_VERIFY:
	{
		int valid = 0;

		if (len < 128U)
			return I2C_RET_ERR_LEN;
		ret = (int)sm2_hw_verify_msg(sm2_id_default, 16U,
									 &data[128], len - 128U,
									 &data[0], &data[32], &data[64], &valid);
		out[0] = (uint8_t)valid;
		*outlen = 1U;
		return ret;
	}

	/* SM2_KP     : id(16) + k(32) + pub(64)             -> x||y(64) */
	case RSP_SM2_KP:
		if (len < 112U)
			return I2C_RET_ERR_LEN;
		*outlen = 64;
		return (int)sm2_hw_kp(&data[16], &data[48], &data[80], out);

	case RSP_SM2_KG:
		if (len < 32U)
			return I2C_RET_ERR_LEN;
		*outlen = 64;
		return (int)sm2_hw_kg(data, out);

	/* ==================== 6. ECC（硬件暂不支持） ==================== */
	case RSP_ECC_ENC:
	case RSP_ECC_DEC:
	case RSP_ECC_SIGN:
	case RSP_ECC_VERIFY:
	case RSP_ECC_KP:
	case RSP_ECC_KG:
		*outlen = 0;
		return I2C_RET_ERR_UNSUPPORT;

	/* ==================== 7. RSA-2048 ==================== */
	case RSP_RSA_ENC:
		if (len != 768U)
			return I2C_RET_ERR_LEN;
		*outlen = 256;
		return (int)rsa2048_verify_hw(data, &data[256], &data[512], out);

	case RSP_RSA_DEC:
		if (len != 768U)
			return I2C_RET_ERR_LEN;
		*outlen = 256;
		return (int)rsa2048_sign_hw(data, &data[256], &data[512], out);

	case RSP_RSA_SIGN:
		if (len < 576U)
			return I2C_RET_ERR_LEN;
		*outlen = 256;
		return (int)rsa2048_sign_pkcs_hw(data, &data[256],
										  &data[512], len - 512U, out);

	case RSP_RSA_VERIFY:
		if (len < 576U)
			return I2C_RET_ERR_LEN;
		*outlen = 128;
		return (int)rsa2048_verify_pkcs_hw(data, &data[256],
											&data[512], len - 512U, out);

	case RSP_RSA_KP:
	case RSP_RSA_KG:
		*outlen = 0;
		return I2C_RET_ERR_UNSUPPORT;

	/* ==================== 8. ChaCha20-Poly1305 ==================== */
	case CHACHA20_STREAM:
	{
		uint32_t aad_len, msg_off, msg_len;
		const uint8_t *aad;
		uint8_t *tag;

		if (len < (32U + 12U + 2U + 16U))
			return I2C_RET_ERR_LEN;
		aad_len = (uint32_t)data[44] | ((uint32_t)data[45] << 8);
		msg_off = 32U + 12U + 2U + aad_len + 16U;
		if (len < msg_off)
			return I2C_RET_ERR_LEN;
		aad = aad_len ? &data[46] : NULL;
		msg_len = len - msg_off;
		/* 密文 + TAG(16) 一起输出 */
		tag = out + msg_len;
		*outlen = msg_len + 16U;
		return (int)chacha20_poly1305_hw(data, &data[32],
										 aad, aad_len, &data[msg_off],
										 msg_len, out, tag, 1);
	}

	case RSP_PQC203_KEYGEN:
	case RSP_PQC203_ENC:
	case RSP_PQC203_DEC:
		return pqc_203_run_algo(algoid, data, len, out, outlen);
	default:
		return I2C_RET_ERR_ALGID;
	}
}

/* ============================================================
 * 自测试数：rsp_hal_algo_execute 正确性验证
 * 固件里加 -DI2C_ALGO_SELFTEST 编译时生效
 * ============================================================ */
#ifdef I2C_ALGO_SELFTEST

#include <string.h>

static void hex_dump(const char *tag, const uint8_t *buf, uint32_t len)
{
	printf("%s (%u bytes):", tag, len);
	for (uint32_t i = 0; i < len && i < 32; i++)
		printf(" %02X", buf[i]);
	if (len > 32)
		printf(" ...");
	printf("\r\n");
}

static int buffer_equal(const uint8_t *a, const uint8_t *b, uint32_t len)
{
	for (uint32_t i = 0; i < len; i++)
		if (a[i] != b[i])
			return 0;
	return 1;
}

static int test_sm4_ecb_enc(void)
{
	uint8_t key[16] = {0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10};
	uint8_t msg[48] = {0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99,
					   0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00,
					   0xDE, 0xAD, 0xBE, 0xEF, 0xCA, 0xFE, 0xBA, 0xBE, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77};
	uint8_t data[64], soft[48], out[48];
	uint32_t outlen;
	sm4_ctx sctx;
	int ret;

	memcpy(data + SM4_KEY_OFF, key, 16);
	memcpy(data + 16, msg, 48);
	/* data 总长 = 16(key) + 48(msg) = 64 */

	/* 软件参考 */
	sm4_setkey_enc(&sctx, key);
	sm4_ecb(&sctx, SM4_ENCRYPT, msg, 48, soft);

	/* 被测函数 */
	outlen = sizeof(out);
	ret = rsp_hal_algo_execute(SM4_ECB_ENC, data, 64, out, &outlen);

	printf("[SM4_ECB_ENC] ret=%d outlen=%u ", ret, outlen);
	if (ret == 0 && outlen == 48 && buffer_equal(soft, out, 48))
	{
		printf("PASS\r\n");
		return 1;
	}
	printf("FAIL\r\n");
	hex_dump("  soft ", soft, 48);
	hex_dump("  got  ", out, 48);
	return 0;
}

static int test_sm4_ecb_dec(void)
{
	uint8_t key[16] = {0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10};
	uint8_t msg[48] = {0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99,
					   0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00,
					   0xDE, 0xAD, 0xBE, 0xEF, 0xCA, 0xFE, 0xBA, 0xBE, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77};
	uint8_t data[64], cipher[48], soft[48], out[48];
	uint32_t outlen;
	sm4_ctx sctx;
	int ret;

	memcpy(data + SM4_KEY_OFF, key, 16);
	/* 先软件加密得到密文，塞到 data+16 去测解密 */
	sm4_setkey_enc(&sctx, key);
	sm4_ecb(&sctx, SM4_ENCRYPT, msg, 48, cipher);
	memcpy(data + 16, cipher, 48);

	/* 软件参考解密 */
	sm4_setkey_dec(&sctx, key);
	sm4_ecb(&sctx, SM4_DECRYPT, cipher, 48, soft);

	outlen = sizeof(out);
	ret = rsp_hal_algo_execute(SM4_ECB_DEC, data, 64, out, &outlen);

	printf("[SM4_ECB_DEC] ret=%d outlen=%u ", ret, outlen);
	if (ret == 0 && outlen == 48 && buffer_equal(soft, out, 48))
	{
		printf("PASS\r\n");
		return 1;
	}
	printf("FAIL\r\n");
	hex_dump("  expect msg", msg, 48);
	hex_dump("  got       ", out, 48);
	return 0;
}

static int test_sm4_cbc_enc(void)
{
	uint8_t key[16] = {0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10};
	uint8_t iv[16] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F};
	uint8_t msg[48] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00,
					   0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99,
					   0xDE, 0xAD, 0xBE, 0xEF, 0xCA, 0xFE, 0xBA, 0xBE, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77};
	uint8_t data[80], soft[48], out[48];
	uint32_t outlen;
	sm4_ctx sctx;
	int ret;

	memcpy(data + SM4_KEY_OFF, key, 16);
	memcpy(data + SM4_IV_OFF, iv, 16);
	memcpy(data + SM4_MSG_OFF, msg, 48);
	/* data 总长 = 16(key)+16(iv)+48(msg) = 80 */

	sm4_setkey_enc(&sctx, key);
	sm4_cbc(&sctx, SM4_ENCRYPT, iv, msg, 48, soft);

	outlen = sizeof(out);
	ret = rsp_hal_algo_execute(SM4_CBC_ENC, data, 80, out, &outlen);

	printf("[SM4_CBC_ENC] ret=%d outlen=%u ", ret, outlen);
	if (ret == 0 && outlen == 48 && buffer_equal(soft, out, 48))
	{
		printf("PASS\r\n");
		return 1;
	}
	printf("FAIL\r\n");
	hex_dump("  soft ", soft, 48);
	hex_dump("  got  ", out, 48);
	return 0;
}

static int test_sm4_ctr(void)
{
	uint8_t key[16] = {0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10};
	uint8_t iv[16] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F};
	uint8_t msg[32] = {0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99,
					   0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00};
	uint8_t data[64], soft[32], out[32];
	uint32_t outlen;
	sm4_ctx sctx;
	int ret;

	memcpy(data + SM4_KEY_OFF, key, 16);
	memcpy(data + SM4_IV_OFF, iv, 16);
	memcpy(data + SM4_MSG_OFF, msg, 32);
	/* 总长 = 16+16+32 = 64 */

	/* 软件参考：CTR 加解密同一方向 */
	sm4_ctr_init(&sctx, key, iv);
	sm4_ctr_update(&sctx, msg, 32, soft);

	outlen = sizeof(out);
	ret = rsp_hal_algo_execute(SM4_CTR_ENC, data, 64, out, &outlen);

	printf("[SM4_CTR_ENC] ret=%d outlen=%u ", ret, outlen);
	if (ret == 0 && outlen == 32 && buffer_equal(soft, out, 32))
	{
		printf("PASS\r\n");
		return 1;
	}
	printf("FAIL\r\n");
	hex_dump("  soft ", soft, 32);
	hex_dump("  got  ", out, 32);
	return 0;
}

static int test_sm3_hash(void)
{
	uint8_t msg[] = "hello world, this is a sm3 selftest message 1234567890";
	uint32_t msg_len = sizeof(msg) - 1; /* 不含 \0 */
	uint8_t soft[32], out[32];
	uint32_t outlen;
	int ret;

	sm3(msg, msg_len, soft);

	outlen = sizeof(out);
	ret = rsp_hal_algo_execute(SM3_HASH, msg, msg_len, out, &outlen);

	printf("[SM3_HASH] ret=%d outlen=%u ", ret, outlen);
	if (ret == 0 && outlen == 32 && buffer_equal(soft, out, 32))
	{
		printf("PASS\r\n");
		return 1;
	}
	printf("FAIL\r\n");
	hex_dump("  soft ", soft, 32);
	hex_dump("  got  ", out, 32);
	return 0;
}

static int test_sha256(void)
{
	uint8_t msg[] = "hello world, this is a sha256 selftest";
	uint32_t msg_len = sizeof(msg) - 1;
	uint8_t soft[32], out[32];
	uint32_t outlen;
	int ret;

	sha256(msg, msg_len, soft);

	outlen = sizeof(out);
	ret = rsp_hal_algo_execute(SHA256_HASH, msg, msg_len, out, &outlen);

	printf("[SHA256_HASH] ret=%d outlen=%u ", ret, outlen);
	if (ret == 0 && outlen == 32 && buffer_equal(soft, out, 32))
	{
		printf("PASS\r\n");
		return 1;
	}
	printf("FAIL\r\n");
	hex_dump("  soft ", soft, 32);
	hex_dump("  got  ", out, 32);
	return 0;
}

static int test_invalid_algoid(void)
{
	uint8_t dummy[16];
	uint8_t out[16];
	uint32_t outlen = sizeof(out);
	int ret;

	ret = rsp_hal_algo_execute(0xEE, dummy, 16, out, &outlen);

	printf("[INVALID_ALGID] ret=%d ", ret);
	if (ret == I2C_RET_ERR_ALGID)
	{
		printf("PASS\r\n");
		return 1;
	}
	printf("FAIL (expect %d)\r\n", I2C_RET_ERR_ALGID);
	return 0;
}

static int test_null_ptr(void)
{
	int r1 = rsp_hal_algo_execute(SM4_ECB_ENC, NULL, 16, (uint8_t *)1, (uint32_t *)1);
	int r2 = rsp_hal_algo_execute(SM4_ECB_ENC, (uint8_t *)1, 16, NULL, (uint32_t *)1);
	int r3 = rsp_hal_algo_execute(SM4_ECB_ENC, (uint8_t *)1, 16, (uint8_t *)1, NULL);

	printf("[NULL_PTR] r1=%d r2=%d r3=%d ", r1, r2, r3);
	if (r1 == -1 && r2 == -1 && r3 == -1)
	{
		printf("PASS\r\n");
		return 1;
	}
	printf("FAIL\r\n");
	return 0;
}

int i2c_algo_selftest(void)
{
	int pass = 0, total = 0;
	int ok;

	printf("\r\n========== rsp_hal_algo_execute SELFTEST ==========\r\n");

	total++;
	ok = test_sm4_ecb_enc();
	if (ok)
		pass++;
	total++;
	ok = test_sm4_ecb_dec();
	if (ok)
		pass++;
	total++;
	ok = test_sm4_cbc_enc();
	if (ok)
		pass++;
	total++;
	ok = test_sm4_ctr();
	if (ok)
		pass++;
	total++;
	ok = test_sm3_hash();
	if (ok)
		pass++;
	total++;
	ok = test_sha256();
	if (ok)
		pass++;
	total++;
	ok = test_invalid_algoid();
	if (ok)
		pass++;
	total++;
	ok = test_null_ptr();
	if (ok)
		pass++;

	printf("---------- %d / %d PASS ----------\r\n", pass, total);
	return (pass == total) ? 0 : -1;
}

#endif /* I2C_ALGO_SELFTEST */

int rsp_hal_i2c_transmit_ack(I2C_NUM_E port, uint8_t err, uint8_t seq)
{
	i2c_ack_t ack;
	ack.ret_code = err;
	ack.seq = seq;
	rsp_hal_i2c_dw_slave_transmit(port, (uint8_t *)&ack, sizeof(ack));
	return 0;
}


#define POLL_DEFAULT		0
#define POLL_ALGO_START		1
#define POLL_ALGO_END		2

uint32_t g_flag, g_poll;
int      g_algo_ret;   /* 最近一次算法执行的返回值, ISR poll 时回传 host */

void I2C_IRQHandler(void)
{
	// printf("0\n");

	uint32_t valid;
	rsp_i2c_t *i2c = (rsp_i2c_t *)I2C0;
	if(i2c->IC_INTR_STAT && I2C_INTR_RD_REQ_MASK)
	{
		valid = i2c->IC_CLR_RD_REQ; //clear
		g_flag = 1;

		// printf("1\n");
		if(g_poll == POLL_ALGO_START)
		{		
			// printf("2\n");

			valid = 0;
			rsp_hal_i2c_dw_slave_transmit(RSP_IIC_0, (uint8_t *)&valid, 4);
			//写数据
		}else if(g_poll == POLL_ALGO_END)
		{
			/* valid=1 成功, valid=2 算法失败(含 TAG 验证失败) */
			valid = (g_algo_ret == 0) ? 1U : 2U;
			rsp_hal_i2c_dw_slave_transmit(RSP_IIC_0, (uint8_t *)&valid, 4);
			g_poll = POLL_DEFAULT;
		}
	}
}

#define I2C_DATA_BLOCK 8192

/* 三个 8KB 缓冲放 .bss, 别放栈 — 24KB 栈会爆 Cortex-M3 默认 16~32KB 栈 */
static uint8_t raw_recv_data[I2C_DATA_BLOCK];
static uint8_t raw_send_data[I2C_DATA_BLOCK];
static uint8_t outdata[I2C_DATA_BLOCK];

int i2c_recv()
{
	int offset = 0;
	int errnum, ret;
	uint32_t outlen = 0;

	i2c_packet_header i2c_head;

	i2c_handle_t handle;
	rsp_i2c_param_t i2c_param;
	handle.port = RSP_IIC_0;
	handle.param = &i2c_param;

	i2c_param.mode = I2C_MODE_SLAVE;
	i2c_param.speed = I2C_SPEED_NORMAL_100K;
	i2c_param.address_bits = I2C_MASTER_ADDRESS_7BIT;
	i2c_param.address = 0x55;

	rsp_hal_i2c_dw_init(&handle);
	rsp_hal_nvic_enable_irq(RSP_IRQ_I2C);

	printf("I2C SLAVE ...\r\n");
	g_flag = POLL_DEFAULT;
	g_poll = POLL_DEFAULT;

	/* 用会话状态替代 seq==0 判断 LONG_WRITE 新会话 —
	 * driver 的 header.seq 只有 3bit, 当包数 > 8 时 seq 会 wrap 回 0,
	 * 导致最后一包被误判为新会话起点 */
	int in_long_write = 0;

	while (1)
	{
		errnum = I2C_RET_OK;
		memset(&i2c_head, 0x0, sizeof(i2c_head));

		/* 每轮收新 header 前, 先把 I2C 从机 RX FIFO 读空 —
		 * 上一轮 LONG_READ transmit 1024B 后 RX FIFO 可能残留
		 * 导致下一轮 LONG_WRITE 的 payload 被错收为翻倍大小 */
		{
			rsp_i2c_t *i2c_reg = (handle.port == RSP_IIC_0) ? I2C0 : I2C1;
			while (i2c_reg->IC_RXFLR > 0) {
				volatile uint32_t dummy = i2c_reg->IC_DATA_CMD;
				(void)dummy;
			}
		}

		ret = rsp_hal_i2c_dw_slave_receive(handle.port, (uint8_t *)&i2c_head, sizeof(i2c_head));
		if (ret != HAL_OK)
		{
			errnum = I2C_RET_ERR_TIMEOUT;
			offset = 0;
			rsp_hal_i2c_transmit_ack(handle.port, errnum, i2c_head.seq);
			continue;
		}

		switch (i2c_head.cmd)
		{
		case CMD_REG_WRITE:
			rsp_hal_i2c_dw_slave_receive(handle.port, raw_recv_data, 4);
			rsp_hal_i2c_transmit_ack(handle.port, errnum, i2c_head.seq);
			break;

		case CMD_REG_READ:
			rsp_hal_algo_status(i2c_head.algoid, (uint32_t *)raw_send_data);
			rsp_hal_i2c_dw_slave_transmit(handle.port, raw_send_data, 4);
			break;

		case CMD_LONG_WRITE:
			/* 新 LONG_WRITE 会话: in_long_write==0 → 清零 offset,
			 * 上一轮 LONG_READ transmit 累加的残留必须丢,
			 * 但后续包继续累加, 不重置.
			 * 不用 seq==0 判断 — driver seq 只有 3bit, >8 包时 wrap 成 0 */
			if (!in_long_write) {
				in_long_write = 1;
				offset = 0;
				memset(raw_recv_data, 0, 64);
				outlen = 0;
			}

			ret = rsp_hal_i2c_dw_slave_receive(handle.port, raw_recv_data + offset, i2c_head.len);
			if (ret != HAL_OK)
			{
				errnum = I2C_RET_ERR_TIMEOUT;
				in_long_write = 0;
				offset = 0;
				rsp_hal_i2c_transmit_ack(handle.port, errnum, i2c_head.seq);
				break;
			}

			offset += i2c_head.len;
			if (offset > I2C_DATA_BLOCK || (int)offset < 0)
			{
				in_long_write = 0;
				offset = 0;
				errnum = I2C_RET_ERR_LEN;
			}

			/* 先立即发 ACK, 再异步跑算法 — 避免大消息时算法耗时盖过 ACK 导致 host 协议错乱 */
			rsp_hal_i2c_transmit_ack(handle.port, errnum, i2c_head.seq);

			if (i2c_head.endflag == DATA_ENDFLAG_ON && errnum == I2C_RET_OK)
			{
				g_poll = POLL_ALGO_START;
				outlen = sizeof(outdata);
				ret = rsp_hal_algo_execute(i2c_head.algoid, raw_recv_data, offset,
										   outdata, &outlen, i2c_head.templen);
				g_algo_ret = ret;   /* 算法结果给 ISR poll 机制回传 host */

				if (ret != 0)
				{
					/* 算法失败: outlen=0 让 LONG_READ 返回空 ("仅输出认证失败结果") */
					outlen = 0;
				}

				g_poll = POLL_ALGO_END;
				offset = 0;
				in_long_write = 0;
			}
			break;

		case CMD_LONG_READ:
			rsp_hal_i2c_dw_slave_transmit(handle.port, outdata + offset, i2c_head.len);
			offset += i2c_head.len;
			if (i2c_head.endflag == DATA_ENDFLAG_ON)
			{
				if (offset != outlen)
					printf("read data len error: expect %u got %d\r\n", (unsigned)outlen, offset);
				offset = 0;
				in_long_write = 0;
				outlen = 0;
			}
			else if (offset >= I2C_DATA_BLOCK)
			{
				/* 无 endflag 但 offset 溢出: driver 可能 abort 了本轮, 强制归零
				 * 避免下一轮 LONG_WRITE 继承脏 offset 导致 payload 写错位置 */
				offset = 0;
				in_long_write = 0;
				outlen = 0;
			}
			break;

		case CMD_PQC_CHOOSE_ALG:
			rsp_hal_i2c_dw_slave_receive(handle.port, raw_recv_data, 4);
			g_poll = POLL_ALGO_START;
			pqc_203_set_algo(raw_recv_data[0]);
			g_poll = POLL_ALGO_END;
			break;
		}
	}
}




void dump_buf1(char *info, uint8_t *buf, uint32_t len)
{
	int i;
	printf("%s[%u]", info, (unsigned)len);
	for (i = 0; i < len; i++) {
	printf("%s%02X%s", i % 16 == 0 ? "\n":" ", 
	buf[i], i == len - 1 ? "\n":"");
	}
}

int i2c_recv_test_loopback()
{
	uint8_t raw_recv_data[I2C_DATA_BLOCK];

	i2c_handle_t handle;
	rsp_i2c_param_t i2c_param;
	handle.port = RSP_IIC_0;
	handle.param = &i2c_param;

	i2c_param.mode = I2C_MODE_SLAVE;
	i2c_param.speed = I2C_SPEED_NORMAL_100K;
	i2c_param.address_bits = I2C_MASTER_ADDRESS_7BIT;
	i2c_param.address = 0x32;

	rsp_hal_i2c_dw_init(&handle);
	
	while (1)
	{
		rsp_hal_i2c_dw_slave_receive(handle.port, (uint8_t *)&raw_recv_data[0], 16);
		dump_buf1("recv data", raw_recv_data, 16);
		rsp_hal_i2c_dw_slave_transmit_ok(handle.port, raw_recv_data, 16);
	}

}