/**
 * @file test_des.c
 * @brief DES hardware IP test — ECB / CBC
 *        每条通路均含 hw vs soft 软件参考比对 + 加解密回环
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "rsp_ip_des.h"
#include "des.h"        /* 软件参考实现 (Phil Karn DES386) */

/* ============================================================
 *  Big block test config
 * ============================================================ */
#define DES_BIG_BLOCKS   100U    /* 100 × 16B = 1600B */
#define DES_BLOCK_LEN    16U
#define DES_BIG_LEN      (DES_BIG_BLOCKS * DES_BLOCK_LEN)
#define PRESSURE_TEST    1U      /* 压力测试循环次数 */

/* ============================================================
 *  Test data
 * ============================================================ */
static const uint8_t test_key[8] = {
    0x01,0x23,0x45,0x67,0x89,0xab,0xcd,0xef
};
static const uint8_t test_iv[8] = {
    0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07
};

/* 大数据测试缓冲（复用 big_dec 作为软件参考输出） */
static uint8_t big_plain[DES_BIG_LEN];
static uint8_t big_cipher[DES_BIG_LEN];
static uint8_t big_dec[DES_BIG_LEN];

static void fill_pattern(void)
{
    uint32_t i;
    for (i = 0; i < DES_BIG_LEN; i++) big_plain[i] = (uint8_t)(i & 0xFF);
}

/* ============================================================
 *  Input dump (debug)
 * ============================================================ */
#define DUMP_LINE 16U
#define DUMP_MAX 64U /* 每段最多打印64B, 防止刷屏 */

static void rsp_dump_buf(char *info, uint8_t *buf, uint32_t len)
{
    printf("%s[%d]", info, len);
    for (uint32_t i = 0; i < len; i++)
    {
        printf("%s0x%02x ", i % 16 == 0 ? "\n     " : " ", buf[i]);
    }
    printf("\n");
}

/* 反向参数校验：实际返回码与期望值一致则通过, 否则打印实际值并置失败
 * (DES 驱动本身不打印错误原因, 与 SM4 驱动的 param_xxx_err 对应) */
static int des_expect_ret(const char *tag, RSP_StatusTypeDef ret,
                          RSP_StatusTypeDef expect)
{
    if (ret == expect) return 0;
    printf("  %-12s: expect=%d got=%d\n", tag, (int)expect, (int)ret);
    return -1;
}

/* ============================================================
 *  ECB test
 * ============================================================ */
static int test_des_ecb(void)
{
    des_key_schedule ks;
    uint8_t buf[32] = {0};
    uint32_t i;

    fill_pattern();

    /* ---- 参数校验 ---- */
     des_ecb_hw(NULL, buf, buf, 16, 1);
     des_ecb_hw(test_key, NULL, buf, 16, 1);
     des_ecb_hw(test_key, buf, NULL, 16, 1);
     des_ecb_hw(test_key, buf, buf, 0, 1);
     des_ecb_hw(test_key, buf, buf, 17, 1);


    /* ---- 1. 软件参考：des_key + des_ecb_encrypt ---- */
    des_key((uint8_t *)test_key, &ks);
    des_ecb_encrypt(big_plain, big_dec, DES_BIG_LEN, &ks);

    /* ---- 2. 硬件加密 ---- */
;
    if (des_ecb_hw(test_key, big_plain, big_cipher, DES_BIG_LEN, 1) != RSP_OK)
    {
        printf("FAIL (encrypt error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %u x 8B = %uB\n",
           (unsigned)DES_BIG_BLOCKS, (unsigned)DES_BIG_LEN);

    rsp_dump_buf("msg", big_plain, DES_BIG_LEN > DUMP_MAX ? DUMP_MAX : DES_BIG_LEN);
    rsp_dump_buf("soft output:", big_dec, DES_BIG_LEN > DUMP_MAX ? DUMP_MAX : DES_BIG_LEN);
    rsp_dump_buf("hw output:", big_cipher, DES_BIG_LEN > DUMP_MAX ? DUMP_MAX : DES_BIG_LEN);
    if (memcmp(big_cipher, big_dec, DES_BIG_LEN) != 0)
    {
        for (i = 0; i < DES_BIG_LEN; i++)
            if (big_cipher[i] != big_dec[i]) break;
        printf("  hw != soft at offset %lu: hw=%02X sw=%02X\n",
               (unsigned long)i, big_cipher[i], big_dec[i]);
        return -1;
    }
    printf("DES ECB ENC PASS\n");

    /* ---- 3. 硬件解密 ---- */
    if (des_ecb_hw(test_key, big_cipher, big_dec, DES_BIG_LEN, 0) != RSP_OK)
    {
        printf("FAIL (decrypt error)\n");
        return -1;
    }
    if (memcmp(big_plain, big_dec, DES_BIG_LEN) != 0)
    {
        printf("FAIL (round-trip mismatch)\n");
        return -1;
    }
    rsp_dump_buf("hw ECB DEC output:", big_dec, DES_BIG_LEN > DUMP_MAX ? DUMP_MAX : DES_BIG_LEN);
    printf("DES ECB DEC PASS\n");

    return 0;
}

/* ============================================================
 *  CBC test
 * ============================================================ */
static int test_des_cbc(void)
{
    des_key_schedule ks;
    uint8_t iv_soft[8];
    uint8_t buf[32] = {0};
    uint32_t i;

    fill_pattern();

    /* ---- 参数校验 ---- */
    if (des_expect_ret("key=NULL", des_cbc_hw(NULL, test_iv, buf, buf, 16, 1),       RSP_ERR_NULL_PTR))    return -1;
    if (des_expect_ret("iv=NULL",  des_cbc_hw(test_key, NULL, buf, buf, 16, 1),      RSP_ERR_NULL_PTR))    return -1;
    if (des_expect_ret("in=NULL",  des_cbc_hw(test_key, test_iv, NULL, buf, 16, 1),  RSP_ERR_NULL_PTR))    return -1;
    if (des_expect_ret("out=NULL", des_cbc_hw(test_key, test_iv, buf, NULL, 16, 1),  RSP_ERR_NULL_PTR))    return -1;
    if (des_expect_ret("len=0",    des_cbc_hw(test_key, test_iv, buf, buf, 0, 1),    RSP_ERR_INVALID_PARAM)) return -1;
    if (des_expect_ret("len=17",   des_cbc_hw(test_key, test_iv, buf, buf, 17, 1),   RSP_ERR_INVALID_PARAM)) return -1;

    /* ---- 1. 软件参考：des_key + des_cbc_encrypt（iv 会被软件实现推进, 用副本） ---- */
    memcpy(iv_soft, test_iv, 8);
    des_key((uint8_t *)test_key, &ks);
    des_cbc_encrypt(big_plain, big_dec, DES_BIG_LEN, iv_soft, &ks);

    /* ---- 2. 硬件加密 ---- */
    if (des_cbc_hw(test_key, test_iv, big_plain, big_cipher, DES_BIG_LEN, 1) != RSP_OK)
    {
        printf("FAIL (encrypt error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %u x 8B = %uB\n",
           (unsigned)DES_BIG_BLOCKS, (unsigned)DES_BIG_LEN);

    rsp_dump_buf("msg", big_plain, DES_BIG_LEN > DUMP_MAX ? DUMP_MAX : DES_BIG_LEN);
    rsp_dump_buf("soft output:", big_dec, DES_BIG_LEN > DUMP_MAX ? DUMP_MAX : DES_BIG_LEN);
    rsp_dump_buf("hw output:", big_cipher, DES_BIG_LEN > DUMP_MAX ? DUMP_MAX : DES_BIG_LEN);
    if (memcmp(big_cipher, big_dec, DES_BIG_LEN) != 0)
    {
        for (i = 0; i < DES_BIG_LEN; i++)
            if (big_cipher[i] != big_dec[i]) break;
        printf("  hw != soft at offset %lu: hw=%02X sw=%02X\n",
               (unsigned long)i, big_cipher[i], big_dec[i]);
        return -1;
    }
    printf("DES CBC ENC PASS\n");

    /* ---- 3. 硬件解密 ---- */
    if (des_cbc_hw(test_key, test_iv, big_cipher, big_dec, DES_BIG_LEN, 0) != RSP_OK)
    {
        printf("FAIL (decrypt error)\n");
        return -1;
    }
    if (memcmp(big_plain, big_dec, DES_BIG_LEN) != 0)
    {
        printf("FAIL (round-trip mismatch)\n");
        return -1;
    }
    rsp_dump_buf("hw CBC DEC output:", big_dec, DES_BIG_LEN > DUMP_MAX ? DUMP_MAX : DES_BIG_LEN);
    printf("DES CBC DEC PASS\n");

    return 0;
}

/* ============================================================
 *  Main test entry
 * ============================================================ */
int des_test(void)
{

    for (uint32_t i = 0; i < PRESSURE_TEST; i++)
    {
         test_des_ecb();
         test_des_cbc();
    }

    return 0;
}
