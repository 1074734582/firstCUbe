// **********************************************************
// Project  Powerby RSP
// File     main.c
// Author   Tesla
// Address  https://www.mucse.com/
// Copyright(C) 2022~2050 @ Mucse Wuxi
// **********************************************************
#include "rsp_ip_sm3.h"
// #include "rsp_ip_common.h"
#include "stdint.h"
#include "bsp.h"
#include "rsp_ip_ecc.h"

int sm2_test(void);
int rsa_2048_test(void);
int ecc_test(void);

void sys_show_info(void)
{
	char *boot[8] = {"ROM BOOT", "SFC BOOT", "SD BOOT", "SPI BOOT", "RAM DEBUG", "RAM DEBUG", "RAM DEBUG", "RAM DEBUG"};
	(void)boot;
	printf("\rCGRA Firmware (Build: %s %s, TARGET: %s)\r\n", __DATE__, __TIME__, TARGET);
	// printf("Boot Mode   : %s\r\n", boot[(SYSCTRL->STAT2&0x7)]);  //
#if defined(__GNUC__q)
	printf("Compiler    : GCC\r\n");
#endif
}

void TIMER_0_IRQHandler(void)
{
	printf("TIMER_0\n");
	rsp_hal_tim_clear_interrupt_status();
}

int main(int argc, char const *argv[])
{
	// rsp_hal_clk_init();
	rsp_hal_delay_init();

	rsp_hal_nvic_enable_all_irq_flag();
	// rsp_hal_nvic_disable_all_irq_flag();
	// rsp_hal_nvic_enable_irq(RSP_IRQ_I2C);

	uart_init();
	sys_show_info();
	//

	//  aes_test();
	// chacha20_test();
	des_test();
	//  ecc_test();
	// sm1_test();

		//   sm3_test();
		// sm4_test();
		// sha2_test();
		//   rsa_2048_test();//
	// pkpu_e203_test();//P

	 	//   sm2_test();

	// i2c_recv();
	//  i2c_recv_test_loopback();

	while (1)
	{

		rsp_hal_mdelay(1000);
		//	printf("11\n");
	}

	// gpio_init();
	// timer_init();
	// pkpu_e203_test();
	// sm4_test();
	return 0;
}