/**
 * @file test_sm2.c
 * @brief SM2 硬件 IP 测试套件 (对照 sm2_输入输出数据格式.xlsx)
 *
 * 测试项:
 *   1.  kG          基点点乘        hw vs GB/T 32918.5 向量
 *   2.  madd        模加            (4+4)%5, (p-1+2)%p
 *   3.  msub        模减            (1-2)%5, (2-5)%7
 *   4.  mmul        模乘            3*4, 2*2
 *   5.  minv_p      mod p 模逆      1, 2
 *   6.  minv_n      mod n 模逆      1, 2
 *   7.  pdouble     点倍(雅可比)    G -> 2G, 与 kG(2) 比对
 *   8.  padd        点加(雅可比)    G + 2G -> 3G, 与 kG(3) 比对
 *   9.  kp          任意点点乘      V_K * V_PUB vs sm2_kp_sw
 *   10. sign(摘要)  签名            e,d,k -> r||s vs 标准向量
 *   11. sign(原始)  签名(含ID)      hw vs sm2_sign_message
 *   12. verify(摘要)验签            hw 正向 + 篡改 e 负向
 *   13. verify(原始)验签(含ID)      hw vs sm2_verify_message + 篡改消息负向
 *   14. encrypt     加密            hw vs sm2_encrypt_message (C1/C2/C3 分段比对)
 *   15. decrypt     解密            软件密文喂硬件解
 *   16. kexch       密钥交换        A/B 两侧同输入, 比较共享密钥与 CR
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "rsp_ip_sm2.h"
#include "sm2.h"
#include "sm3.h"
#include "mpi.h"

#define PRESSURE_TEST 1U

/* sm2.c 内部实现, 未在 sm2.h 声明: 雅可比 -> 仿射 */
void sm2_jacobian_2_stand(sm2_ctx_t *ctx, mpi_t *x, mpi_t *y, mpi_t *z);

/* ============================================================
 * 测试向量 (GB/T 32918.5-2017)
 * ============================================================ */
static const uint8_t V_D[32] = {
    0x39,0x45,0x20,0x8F,0x7B,0x21,0x44,0xB1,
    0x3F,0x36,0xE3,0x8A,0xC6,0xD3,0x9F,0x95,
    0x88,0x93,0x93,0x69,0x28,0x60,0xB5,0x1A,
    0x42,0xFB,0x81,0xEF,0x4D,0xF7,0xC5,0xB8
};
static const uint8_t V_PUB[64] = {
    0x09,0xF9,0xDF,0x31,0x1E,0x54,0x21,0xA1,
    0x50,0xDD,0x7D,0x16,0x1E,0x4B,0xC5,0xC6,
    0x72,0x17,0x9F,0xAD,0x18,0x33,0xFC,0x07,
    0x6B,0xB0,0x8F,0xF3,0x56,0xF3,0x50,0x20,
    0xCC,0xEA,0x49,0x0C,0xE2,0x67,0x75,0xA5,
    0x2D,0xC6,0xEA,0x71,0x8C,0xC1,0xAA,0x60,
    0x0A,0xED,0x05,0xFB,0xF3,0x5E,0x08,0x4A,
    0x66,0x32,0xF6,0x07,0x2D,0xA9,0xAD,0x13
};
static const uint8_t V_K[32] = {
    0x59,0x27,0x6E,0x27,0xD5,0x06,0x86,0x1A,
    0x16,0x68,0x0F,0x3A,0xD9,0xC0,0x2D,0xCC,
    0xEF,0x3C,0xC1,0xFA,0x3C,0xDB,0xE4,0xCE,
    0x6D,0x54,0xB8,0x0D,0xEA,0xC1,0xBC,0x21
};
static const uint8_t V_E[32] = {
    0xF0,0xB4,0x3E,0x94,0xBA,0x45,0xAC,0xCA,
    0xAC,0xE6,0x92,0xED,0x53,0x43,0x82,0xEB,
    0x17,0xE6,0xAB,0x5A,0x19,0xCE,0x7B,0x31,
    0xF4,0x48,0x6F,0xDF,0xC0,0xD2,0x86,0x40
};
static const uint8_t V_R[32] = {
    0xF5,0xA0,0x3B,0x06,0x48,0xD2,0xC4,0x63,
    0x0E,0xEA,0xC5,0x13,0xE1,0xBB,0x81,0xA1,
    0x59,0x44,0xDA,0x38,0x27,0xD5,0xB7,0x41,
    0x43,0xAC,0x7E,0xAC,0xEE,0xE7,0x20,0xB3
};
static const uint8_t V_S[32] = {
    0xB1,0xB6,0xAA,0x29,0xDF,0x21,0x2F,0xD8,
    0x76,0x31,0x82,0xBC,0x0D,0x42,0x1C,0xA1,
    0xBB,0x90,0x38,0xFD,0x1F,0x7F,0x42,0xD4,
    0x84,0x0B,0x69,0xC4,0x85,0xBB,0xC1,0xAA
};

#define TEST_ID         "1234567812345678"
#define TEST_ID_LEN     16

/* 密钥交换测试用的 B 侧静态私钥与临时随机数 */
static const uint8_t KEX_B_D[32] = {
    0x3A,0xC5,0x18,0x7E,0x91,0x24,0x6B,0xD3,
    0x88,0x0F,0x52,0xA9,0x44,0xE7,0x1C,0x75,
    0xB2,0x30,0x9D,0x66,0x4F,0x81,0xC8,0x2A,
    0x17,0x95,0xEC,0x53,0x7B,0x0D,0xA6,0x39
};
static const uint8_t KEX_B_K[32] = {
    0x6D,0x12,0x8B,0xF4,0x27,0x59,0xC3,0x0E,
    0xA7,0x35,0xE1,0x48,0x9C,0x02,0x76,0xD5,
    0x1F,0x84,0x3B,0xB9,0x50,0xCA,0x63,0x2E,
    0x97,0x0A,0xDD,0x41,0x8F,0x64,0xB0,0x25
};
#define KEX_ID_B        "ABCDEFGHABCDEFGH"
#define KEX_ID_B_LEN    16

/* ============================================================
 * 工具函数
 * ============================================================ */
static void hex_dump(const char *name, const uint8_t *p, int len)
{
    printf("%s [%d]:", name, len);
    for (int i = 0; i < len; i++)
    {
        if ((i % 16) == 0) printf("\n  ");
        printf("%02X ", p[i]);
    }
    printf("\n");
}

static int buf_eq(const uint8_t *a, const uint8_t *b, int len)
{
    return memcmp(a, b, (size_t)len) == 0;
}

/* 小端 uint32 -> 32B 大端 */
static void be32_set(uint8_t b[32], uint32_t v)
{
    memset(b, 0, 32);
    b[28] = (uint8_t)(v >> 24);
    b[29] = (uint8_t)(v >> 16);
    b[30] = (uint8_t)(v >> 8);
    b[31] = (uint8_t)v;
}

/* out = in - d (大端 32B) */
static void be32_sub_u32(const uint8_t in[32], uint32_t d, uint8_t out[32])
{
    mpi_t a, b;

    mpi_import(&a, (uint8_t *)in, 32);
    mpi_copy_d(&b, d);
    mpi_sub(&a, &b);
    mpi_export(&a, out, 32);
}

/* out = (in + 1) / 2 (大端 32B) */
static void be32_add1_div2(const uint8_t in[32], uint8_t out[32])
{
    mpi_t a, one;

    mpi_import(&a, (uint8_t *)in, 32);
    mpi_copy_d(&one, 1);
    mpi_add(&a, &one);
    mpi_bsr(&a, 1);
    mpi_export(&a, out, 32);
}

/* 导出曲线参数 p / n */
static void get_curve_pn(uint8_t p[32], uint8_t n[32])
{
    sm2_ctx_t ctx;

    sm2_init(&ctx);
    if (p) mpi_export(&ctx.p, p, 32);
    if (n) mpi_export(&ctx.n, n, 32);
}

/* 导出基点 G (Gx / Gy) */
static void get_curve_g(uint8_t gx[32], uint8_t gy[32])
{
    sm2_ctx_t ctx;

    sm2_init(&ctx);
    mpi_export(&ctx.x, gx, 32);
    mpi_export(&ctx.y, gy, 32);
}

/* 雅可比 (X||Y||Z) -> 仿射 (x||y) */
static void jac_to_affine(const uint8_t jac[96], uint8_t out_xy[64])
{
    sm2_ctx_t ctx;
    mpi_t x, y, z;

    sm2_init(&ctx);
    mpi_import(&x, (uint8_t *)jac, 32);
    mpi_import(&y, (uint8_t *)jac + 32, 32);
    mpi_import(&z, (uint8_t *)jac + 64, 32);
    sm2_jacobian_2_stand(&ctx, &x, &y, &z);
    mpi_export(&x, out_xy, 32);
    mpi_export(&y, out_xy + 32, 32);
}

/* 单个 32B 结果判定, 打印并返回 0=匹配 / -1=不匹配 */
static int check32(const char *tag, const uint8_t *got, const uint8_t *exp)
{
    if (buf_eq(got, exp, 32))
    {
        printf("  %-22s PASS\n", tag);
        return 0;
    }
    printf("  %-22s FAIL\n", tag);
    hex_dump("    expect", exp, 32);
    hex_dump("    got   ", got, 32);
    return -1;
}

static void banner(const char *title)
{
    printf("\n============================================================\n");
    printf("%s\n", title);
    printf("============================================================\n");
}

/* ============================================================
 * 1. 基点点乘 kG
 * ============================================================ */
static int test_sm2_kg(void)
{
    uint8_t hw_pub[64] = {0};
    int ret;

    banner(" kG  (hw-only, golden V_D -> V_PUB)");

    /* 参数错误校验: NULL 入参必须被拦截并打印 LOG */
    sm2_hw_kg(NULL, hw_pub);
    sm2_hw_kg(V_D, NULL);

    hex_dump("  in  k", V_D, 32);
    ret = sm2_hw_kg(V_D, hw_pub);
    if (ret != RSP_OK) { printf("  hw_kg ret=%d\n", ret); return -1; }

    hex_dump("  out pub", hw_pub, 64);
    hex_dump("  exp pub", V_PUB, 64);

    if (buf_eq(hw_pub, V_PUB, 64))
    {
        printf("  kG: PASS\n");
        return 0;
    }
    hex_dump("  expect", V_PUB, 64);
    hex_dump("  got   ", hw_pub, 64);
    printf("  kG: FAIL\n");
    return -1;
}

/* ============================================================
 * 2. 模加 madd
 * ============================================================ */
static int test_sm2_madd(void)
{
    uint8_t p[32], pm1[32];
    uint8_t a[32], b[32], mod[32], out[32], exp[32];
    int fail = 0, ret;

    banner("madd  out = (a + b) mod p");

    get_curve_pn(p, NULL);

    /* (4 + 4) mod 5 = 3 */
    be32_set(a, 4); be32_set(b, 4); be32_set(mod, 5); be32_set(exp, 3);
    ret = sm2_hw_madd(a, b, mod, out);
    if (ret != RSP_OK) { printf("  hw_madd ret=%d\n", ret); return -1; }
    fail += check32("(4+4) mod 5", out, exp);

    /* (p-1 + 2) mod p = 1 */
    be32_sub_u32(p, 1, pm1);
    be32_set(b, 2); be32_set(exp, 1);
    ret = sm2_hw_madd(pm1, b, p, out);
    if (ret != RSP_OK) { printf("  hw_madd ret=%d\n", ret); return -1; }
    fail += check32("(p-1+2) mod p", out, exp);

    printf("  madd: %s\n", (fail == 0) ? "PASS" : "FAIL");
    return (fail == 0) ? 0 : -1;
}

/* ============================================================
 * 3. 模减 msub
 * ============================================================ */
static int test_sm2_msub(void)
{
    uint8_t a[32], b[32], mod[32], out[32], exp[32];
    int fail = 0, ret;

    banner(" msub  out = (a - b) mod p");

    /* (1 - 2) mod 5 = 4 */
    be32_set(a, 1); be32_set(b, 2); be32_set(mod, 5); be32_set(exp, 4);
    ret = sm2_hw_msub(a, b, mod, out);
    if (ret != RSP_OK) { printf("  hw_msub ret=%d\n", ret); return -1; }
    fail += check32("(1-2) mod 5", out, exp);

    /* (2 - 5) mod 7 = 4 */
    be32_set(a, 2); be32_set(b, 5); be32_set(mod, 7);
    ret = sm2_hw_msub(a, b, mod, out);
    if (ret != RSP_OK) { printf("  hw_msub ret=%d\n", ret); return -1; }
    fail += check32("(2-5) mod 7", out, exp);

    printf("  msub: %s\n", (fail == 0) ? "PASS" : "FAIL");
    return (fail == 0) ? 0 : -1;
}

/* ============================================================
 * 4. 模乘 mmul (模数由硬件内部固定, 数据格式不带 P)
 * ============================================================ */
static int test_sm2_mmul(void)
{
    uint8_t a[32], b[32], out[32], exp[32];
    int fail = 0, ret;

    banner(" mmul  out = (a * b) mod p (internal modulus)");

    /* 3 * 4 = 12 */
    be32_set(a, 3); be32_set(b, 4); be32_set(exp, 12);
    ret = sm2_hw_mmul(a, b, out);
    if (ret != RSP_OK) { printf("  hw_mmul ret=%d\n", ret); return -1; }
    fail += check32("3 * 4", out, exp);

    /* 2 * 2 = 4 */
    be32_set(a, 2); be32_set(b, 2); be32_set(exp, 4);
    ret = sm2_hw_mmul(a, b, out);
    if (ret != RSP_OK) { printf("  hw_mmul ret=%d\n", ret); return -1; }
    fail += check32("2 * 2", out, exp);

    printf("  mmul: %s\n", (fail == 0) ? "PASS" : "FAIL");
    return (fail == 0) ? 0 : -1;
}

/* ============================================================
 * 5. mod p 模逆 minv_p
 * ============================================================ */
static int test_sm2_minv_p(void)
{
    uint8_t p[32], a[32], out[32], exp[32];
    int fail = 0, ret;

    banner("minv_p  out = a^-1 mod p");

    get_curve_pn(p, NULL);

    /* 1^-1 = 1 */
    be32_set(a, 1); be32_set(exp, 1);
    ret = sm2_hw_minv_p(a, out);
    if (ret != RSP_OK) { printf("  hw_minv_p ret=%d\n", ret); return -1; }
    fail += check32("1^-1 mod p", out, exp);

    /* 2^-1 = (p+1)/2 */
    be32_set(a, 2);
    be32_add1_div2(p, exp);
    ret = sm2_hw_minv_p(a, out);
    if (ret != RSP_OK) { printf("  hw_minv_p ret=%d\n", ret); return -1; }
    fail += check32("2^-1 mod p", out, exp);

    printf("  minv_p: %s\n", (fail == 0) ? "PASS" : "FAIL");
    return (fail == 0) ? 0 : -1;
}

/* ============================================================
 * 6. mod n 模逆 minv_n
 * ============================================================ */
static int test_sm2_minv_n(void)
{
    uint8_t n[32], a[32], out[32], exp[32];
    int fail = 0, ret;

    banner("minv_n  out = a^-1 mod n");

    get_curve_pn(NULL, n);

    /* 1^-1 = 1 */
    be32_set(a, 1); be32_set(exp, 1);
    ret = sm2_hw_minv_n(a, out);
    if (ret != RSP_OK) { printf("  hw_minv_n ret=%d\n", ret); return -1; }
    fail += check32("1^-1 mod n", out, exp);

    /* 2^-1 = (n+1)/2 */
    be32_set(a, 2);
    be32_add1_div2(n, exp);
    ret = sm2_hw_minv_n(a, out);
    if (ret != RSP_OK) { printf("  hw_minv_n ret=%d\n", ret); return -1; }
    fail += check32("2^-1 mod n", out, exp);

    printf("  minv_n: %s\n", (fail == 0) ? "PASS" : "FAIL");
    return (fail == 0) ? 0 : -1;
}

/* ============================================================
 * 7. 点倍 pdouble (Jacobian)  G -> 2G
 * ============================================================ */
static int test_sm2_pdouble(void)
{
    /* golden 2G affine (gen_sm2_enc_golden.py, 标准 GM/T 0003 曲线) */
    static const uint8_t golden_2g[64] = {
        0x56,0xCE,0xFD,0x60,0xD7,0xC8,0x7C,0x00,
        0x0D,0x58,0xEF,0x57,0xFA,0x73,0xBA,0x4D,
        0x9C,0x0D,0xFA,0x08,0xC0,0x8A,0x73,0x31,
        0x49,0x5C,0x2E,0x1D,0xA3,0xF2,0xBD,0x52,
        0x31,0xB7,0xE7,0xE6,0xCC,0x81,0x89,0xF6,
        0x68,0x53,0x5C,0xE0,0xF8,0xEA,0xF1,0xBD,
        0x6D,0xE8,0x4C,0x18,0x2F,0x6C,0x8E,0x71,
        0x6F,0x78,0x0D,0x3A,0x97,0x0A,0x23,0xC3,
    };
    uint8_t gx[32], gy[32];
    uint8_t pa[96], pc[96], affine[64];
    int ret;

    banner("pdouble  G -> 2G (Jacobian in, affine out vs golden 2G)");

    get_curve_g(gx, gy);
    memcpy(pa, gx, 32);
    memcpy(pa + 32, gy, 32);
    be32_set(pa + 64, 1);          /* Z = 1 即仿射点 (Gx,Gy) */

    ret = sm2_hw_pdouble(pa, pc);
    if (ret != RSP_OK) { printf("  hw_pdouble ret=%d\n", ret); return -1; }

    jac_to_affine(pc, affine);

    if (buf_eq(affine, golden_2g, 64))
    {
        printf("  pdouble: PASS\n");
        return 0;
    }
    hex_dump("  expect 2G", golden_2g, 64);
    hex_dump("  got    2G", affine, 64);
    printf("  pdouble: FAIL\n");
    return -1;
}

/* ============================================================
 * 8. 点加 padd (Jacobian)  G + 2G -> 3G
 * ============================================================ */
static int test_sm2_padd(void)
{
    /* golden 3G affine (gen_sm2_enc_golden.py) */
    static const uint8_t golden_3g[64] = {
        0xA9,0x7F,0x7C,0xD4,0xB3,0xC9,0x93,0xB4,
        0xBE,0x2D,0xAA,0x8C,0xDB,0x41,0xE2,0x4C,
        0xA1,0x3F,0x6B,0xD9,0x45,0x30,0x22,0x44,
        0xE2,0x69,0x18,0xF1,0xD0,0x50,0x9E,0xBF,
        0x53,0x0B,0x5D,0xD8,0x8C,0x68,0x8E,0xF5,
        0xCC,0xC5,0xCE,0xC0,0x8A,0x72,0x15,0x0F,
        0x7C,0x40,0x0E,0xE5,0xCD,0x04,0x52,0x92,
        0xAA,0xAC,0xDD,0x03,0x74,0x58,0xF6,0xE6,
    };
    uint8_t gx[32], gy[32];
    uint8_t pa[96], pb[96], pc[96], affine[64];
    int ret;

    banner("padd  G + 2G -> 3G (Jacobian in, affine out vs golden 3G)");

    get_curve_g(gx, gy);
    memcpy(pa, gx, 32);
    memcpy(pa + 32, gy, 32);
    be32_set(pa + 64, 1);

    ret = sm2_hw_pdouble(pa, pb);          /* pb = 2G (Jacobian) */
    if (ret != RSP_OK) { printf("  hw_pdouble ret=%d\n", ret); return -1; }

    ret = sm2_hw_padd(pa, pb, pc);         /* pc = G + 2G */
    if (ret != RSP_OK) { printf("  hw_padd ret=%d\n", ret); return -1; }

    jac_to_affine(pc, affine);

    if (buf_eq(affine, golden_3g, 64))
    {
        printf("  padd: PASS\n");
        return 0;
    }
    hex_dump("  expect 3G", golden_3g, 64);
    hex_dump("  got    3G", affine, 64);
    printf("  padd: FAIL\n");
    return -1;
}

/* ============================================================
 * 9. 任意点点乘 kp  V_K * V_PUB  vs golden
 *    golden 由 gen_sm2_enc_golden.py 离线生成 (标准 GM/T 0003)
 * ============================================================ */
static int test_sm2_kp(void)
{
    static const uint8_t golden_xy[64] = {
        0x33,0x5E,0x18,0xD7,0x51,0xE5,0x1F,0x04,
        0x0E,0x27,0xD4,0x68,0x13,0x8B,0x7A,0xB1,
        0xDC,0x86,0xAD,0x7F,0x98,0x1D,0x7D,0x41,
        0x62,0x22,0xFD,0x6A,0xB3,0xED,0x23,0x0D,
        0xAB,0x74,0x3E,0xBC,0xFB,0x22,0xD6,0x4F,
        0x7B,0x6A,0xB7,0x91,0xF7,0x06,0x58,0xF2,
        0x5B,0x48,0xFA,0x93,0xE5,0x40,0x64,0xFD,
        0xBF,0xBE,0xD3,0xF0,0xBD,0x84,0x7A,0xC9,
    };
    uint8_t hw_xy[64] = {0};
    int ret;

    banner("kp  V_K * V_PUB  (hw-only, golden)");

    /* 参数错误校验: NULL 入参必须被拦截并打印 LOG */
    sm2_hw_kp(NULL, V_PUB, V_PUB + 32, hw_xy);
    sm2_hw_kp(V_K, NULL, V_PUB + 32, hw_xy);
    sm2_hw_kp(V_K, V_PUB, NULL, hw_xy);
    sm2_hw_kp(V_K, V_PUB, V_PUB + 32, NULL);

    hex_dump("  in  k", V_K, 32);
    hex_dump("  in  pub", V_PUB, 64);
    ret = sm2_hw_kp(V_K, V_PUB, V_PUB + 32, hw_xy);
    if (ret != RSP_OK) { printf("  hw_kp ret=%d\n", ret); return -1; }

    hex_dump("  out xy", hw_xy, 64);
    hex_dump("  exp xy", golden_xy, 64);

    if (buf_eq(golden_xy, hw_xy, 64))
    {
        printf("  kp: PASS\n");
        return 0;
    }
    hex_dump("  golden", golden_xy, 64);
    hex_dump("  hw    ", hw_xy, 64);
    printf("  kp: FAIL\n");
    return -1;
}

/* ============================================================
 * 10. 签名(摘要)  e,d,k -> r||s  与标准向量比对
 * ============================================================ */

/* 临时诊断: 绕过驱动, 按指定 MODE + PKG_LEN 手打一遍时序.
 * 用于区分 "PKG_LEN 填错导致算核等不满输入" 与 "该比特流某模式不工作". */
static int raw_probe(uint32_t mode, uint32_t pkg_len,
                     const uint8_t *const *ins, uint32_t n_ins,
                     uint8_t *out, uint32_t out_bytes)
{
    uint32_t i, j, t;

    /* 复位: 关算核 -> 清中断/长度 -> FIFO 状态清零 -> 排空 OFIFO */
    SM2_IP->CFG     = 0U;
    SM2_IP->INTR    = 0U;
    SM2_IP->PKG_LEN = 0U;
    SM2_IP->INTR    = SM2_INTR_FIFO_STATE_CLEAR;
    for (volatile int d = 0; d < 2000; d++);
    SM2_IP->INTR    = 0U;
    t = SM2_POLL_TIMEOUT;
    while ((SM2_IP->STATE & SM2_STATE_OFIFO_EMPTY) == 0U)
    {
        volatile uint32_t dump = SM2_IP->OFIFO[0];
        (void)dump;
        if (--t == 0U) break;
    }

    SM2_IP->PKG_LEN = pkg_len;
    SM2_IP->CFG     = mode | SM2_CFG_ENABLE;

    /* 写输入: 每个 32B 参数拆 2 个 128bit 条目(高 16B 先) */
    for (i = 0U; i < n_ins; i++)
    {
        for (j = 0U; j < 32U; j += 16U)
        {
            uint32_t w[4];

            memcpy(w, ins[i] + j, 16);
            t = SM2_POLL_TIMEOUT;
            while ((SM2_IP->STATE & SM2_STATE_IFIFO_FULL) != 0U)
            {
                if (--t == 0U)
                {
                    printf("  probe(mode=%u PKG_LEN=%u): IFIFO write timeout STATE=0x%08X\n",
                           (unsigned)(mode >> SM2_CFG_MODE_Pos),
                           (unsigned)pkg_len, (unsigned)SM2_IP->STATE);
                    SM2_IP->CFG = 0U;
                    return -1;
                }
            }
            SM2_IP->IFIFO[0] = w[0];
            SM2_IP->IFIFO[1] = w[1];
            SM2_IP->IFIFO[2] = w[2];
            SM2_IP->IFIFO[3] = w[3];
        }
    }

    /* 读输出 */
    for (i = 0U; i < out_bytes; i += 16U)
    {
        uint32_t w[4];

        t = SM2_OUT_WAIT;
        while ((SM2_IP->STATE & SM2_STATE_OFIFO_EMPTY) != 0U)
        {
            if (--t == 0U)
            {
                uint32_t st = SM2_IP->STATE;
                printf("  probe(mode=%u PKG_LEN=%u): OFIFO read timeout STATE=0x%08X IF_CNT=%u OF_CNT=%u\n",
                       (unsigned)(mode >> SM2_CFG_MODE_Pos), (unsigned)pkg_len,
                       (unsigned)st,
                       (unsigned)((st & SM2_STATE_IFIFO_CNT_Msk) >> SM2_STATE_IFIFO_CNT_Pos),
                       (unsigned)((st & SM2_STATE_OFIFO_CNT_Msk) >> SM2_STATE_OFIFO_CNT_Pos));
                SM2_IP->CFG = 0U;
                return -1;
            }
        }
        w[0] = SM2_IP->OFIFO[0];
        w[1] = SM2_IP->OFIFO[1];
        w[2] = SM2_IP->OFIFO[2];
        w[3] = SM2_IP->OFIFO[3];
        memcpy(out + i, w, 16);
    }

    SM2_IP->CFG = 0U;
    return 0;
}

static int test_sm2_sign(void)
{
    uint8_t hw_rs[64] = {0};
    uint8_t exp_rs[64];
    int ret;

    banner("sign(digest)  V_E,V_D,V_K -> V_R||V_S  (hw-only, golden)");

    memcpy(exp_rs, V_R, 32);
    memcpy(exp_rs + 32, V_S, 32);

    /* 参数错误校验: NULL 入参必须被拦截并打印 LOG */
    sm2_hw_sign(NULL, V_D, V_K, hw_rs);
    sm2_hw_sign(V_E, NULL, V_K, hw_rs);
    sm2_hw_sign(V_E, V_D, NULL, hw_rs);
    sm2_hw_sign(V_E, V_D, V_K, NULL);

    hex_dump("  in  e", V_E, 32);
    hex_dump("  in  d", V_D, 32);
    hex_dump("  in  k", V_K, 32);

    /* 硬件: 新格式输入顺序为 e, d, k */
    ret = sm2_hw_sign(V_E, V_D, V_K, hw_rs);
    if (ret != RSP_OK)
    {
        printf("  hw_sign ret=%d\n", ret);
        printf("  dbg: stage=%u STATE=0x%08X PKG_LEN=%u CFG=0x%08X IF_CNT=%u OF_CNT=%u\n",
               (unsigned)sm2_dbg[0], (unsigned)sm2_dbg[1], (unsigned)sm2_dbg[2],
               (unsigned)sm2_dbg[3], (unsigned)sm2_dbg[4], (unsigned)sm2_dbg[5]);

        /* 诊断 1: PKG_LEN=0 / 96 各手打一遍签名 */
        {
            const uint8_t *in[3] = { V_E, V_D, V_K };
            uint32_t pl[2] = { 0U, 3U * SM2_NUM_BYTES };
            uint32_t n;

            for (n = 0U; n < 2U; n++)
            {
                memset(hw_rs, 0, 64);
                if (raw_probe(SM2_MODE_SIGN, pl[n], in, 3U, hw_rs, 64U) == 0)
                {
                    printf("  probe(sign, PKG_LEN=%u) vs V_R||V_S: %s\n",
                           (unsigned)pl[n], buf_eq(hw_rs, exp_rs, 64) ? "OK" : "MISMATCH");
                    hex_dump("    got r||s", hw_rs, 64);
                }
            }
        }

        /* 诊断 2: kG 走同一套手打时序, 判断 IP 核本身是否工作 */
        {
            const uint8_t *in1[1] = { V_D };
            uint8_t pub[64];

            memset(pub, 0, 64);
            if (raw_probe(SM2_MODE_KG, SM2_NUM_BYTES, in1, 1U, pub, 64U) == 0)
            {
                printf("  probe(kg) vs V_PUB: %s\n",
                       buf_eq(pub, V_PUB, 64) ? "OK" : "MISMATCH");
                hex_dump("    got pub", pub, 64);
            }
        }

        return -1;
    }

    hex_dump("  out r||s", hw_rs, 64);
    if (buf_eq(exp_rs, hw_rs, 64))
    {
        printf("  sign: PASS\n");
        return 0;
    }
    hex_dump("  expect r||s", exp_rs, 64);
    hex_dump("  hw     r||s", hw_rs, 64);
    printf("  sign: FAIL\n");
    return -1;
}

/* ============================================================
 * 11. 签名(原始消息)  hw vs sm2_sign_message
 * ============================================================ */
static int test_sm2_sign_msg(void)
{
    const uint8_t msg[] = "message digest";
    uint32_t msg_len = (uint32_t)(sizeof(msg) - 1);
    /* golden: ZA=SM3(ENTL||ID||a||b||Gx||Gy||Px||Py), e=SM3(ZA||msg),
     * r=(e+x1)%n, s=(1+d)^-1*(k-r*d)%n  (gen_sm2_enc_golden.py,
     * 与 GB/T 32918.5 标准向量一致) */
    static const uint8_t golden_rs[64] = {
        0xF5,0xA0,0x3B,0x06,0x48,0xD2,0xC4,0x63,
        0x0E,0xEA,0xC5,0x13,0xE1,0xBB,0x81,0xA1,
        0x59,0x44,0xDA,0x38,0x27,0xD5,0xB7,0x41,
        0x43,0xAC,0x7E,0xAC,0xEE,0xE7,0x20,0xB3,
        0xB1,0xB6,0xAA,0x29,0xDF,0x21,0x2F,0xD8,
        0x76,0x31,0x82,0xBC,0x0D,0x42,0x1C,0xA1,
        0xBB,0x90,0x38,0xFD,0x1F,0x7F,0x42,0xD4,
        0x84,0x0B,0x69,0xC4,0x85,0xBB,0xC1,0xAA,
    };
    uint8_t hw_rs[64] = {0};
    int ret;

    banner("sign(raw msg)  hw-only, golden r||s");

    /* 硬件 */
    ret = sm2_hw_sign_msg((const uint8_t *)TEST_ID, TEST_ID_LEN, V_PUB,
                          msg, msg_len, V_D, V_K, hw_rs);
    if (ret != RSP_OK)
    {
        printf("  hw_sign_msg ret=%d  dbg: stage=%u STATE=0x%08X PKG_LEN=%u CFG=0x%08X IF_CNT=%u OF_CNT=%u\n",
               ret, (unsigned)sm2_dbg[0], (unsigned)sm2_dbg[1],
               (unsigned)sm2_dbg[2], (unsigned)sm2_dbg[3],
               (unsigned)sm2_dbg[4], (unsigned)sm2_dbg[5]);
        return -1;
    }

    if (buf_eq(golden_rs, hw_rs, 64))
    {
        printf("  sign_msg: PASS\n");
        return 0;
    }
    hex_dump("  golden r||s", golden_rs, 64);
    hex_dump("  hw     r||s", hw_rs, 64);
    printf("  sign_msg: FAIL\n");
    return -1;
}

/* ============================================================
 * 12. 验签(摘要)  正向 + 篡改 e 负向
 * ============================================================ */
static int test_sm2_verify(void)
{
    uint8_t e_bad[32];
    int valid = 0, ret;

    banner("verify(digest)  e,r,s,pub");

    /* 参数错误校验: NULL 入参必须被拦截并打印 LOG */
    sm2_hw_verify(NULL, V_R, V_S, V_PUB, &valid);
    sm2_hw_verify(V_E, NULL, V_S, V_PUB, &valid);
    sm2_hw_verify(V_E, V_R, NULL, V_PUB, &valid);
    sm2_hw_verify(V_E, V_R, V_S, NULL, &valid);
    sm2_hw_verify(V_E, V_R, V_S, V_PUB, NULL);

    hex_dump("  in  e", V_E, 32);
    hex_dump("  in  r", V_R, 32);
    hex_dump("  in  s", V_S, 32);
    hex_dump("  in  pub", V_PUB, 64);

    ret = sm2_hw_verify(V_E, V_R, V_S, V_PUB, &valid);
    if (ret != RSP_OK)
    {
        printf("  hw_verify ret=%d  dbg: stage=%u STATE=0x%08X PKG_LEN=%u CFG=0x%08X IF_CNT=%u OF_CNT=%u\n",
               ret, (unsigned)sm2_dbg[0], (unsigned)sm2_dbg[1],
               (unsigned)sm2_dbg[2], (unsigned)sm2_dbg[3],
               (unsigned)sm2_dbg[4], (unsigned)sm2_dbg[5]);
        return -1;
    }
    printf("  valid = %d (expect 1)\n", valid);
    if (valid != 1)
    {
        printf("  verify: FAIL\n");
        return -1;
    }

    /* 篡改 e 后应验签失败 */
    memcpy(e_bad, V_E, 32);
    e_bad[31] ^= 0x01;
    valid = 0;
    ret = sm2_hw_verify(e_bad, V_R, V_S, V_PUB, &valid);
    if (ret != RSP_OK) { printf("  hw_verify(bad e) ret=%d\n", ret); return -1; }
    printf("  valid(tampered e) = %d (expect 0)\n", valid);

    if (valid == 0)
    {
        printf("  verify: PASS\n");
        return 0;
    }
    printf("  verify: FAIL\n");
    return -1;
}

/* ============================================================
 * 13. 验签(原始消息)  hw vs soft + 篡改消息负向
 * ============================================================ */
static int test_sm2_verify_msg(void)
{
    const uint8_t msg[] = "message digest";
    const uint8_t msg_bad[] = "message digesT";
    uint32_t msg_len = (uint32_t)(sizeof(msg) - 1);
    int valid = 0, ret;

    banner("verify(raw msg)  hw-only, valid + tampered negative");

    /* 硬件正向: V_R||V_S 是 msg/ID 的标准签名 (GB/T 32918.5) */
    ret = sm2_hw_verify_msg((const uint8_t *)TEST_ID, TEST_ID_LEN, msg, msg_len,
                            V_R, V_S, V_PUB, &valid);
    if (ret != RSP_OK)
    {
        printf("  hw_verify_msg ret=%d  dbg: stage=%u STATE=0x%08X PKG_LEN=%u CFG=0x%08X IF_CNT=%u OF_CNT=%u\n",
               ret, (unsigned)sm2_dbg[0], (unsigned)sm2_dbg[1],
               (unsigned)sm2_dbg[2], (unsigned)sm2_dbg[3],
               (unsigned)sm2_dbg[4], (unsigned)sm2_dbg[5]);
        return -1;
    }
    printf("  valid = %d (expect 1)\n", valid);

    int fail = 0;
    if (valid != 1) fail++;

    /* 篡改消息后应验签失败 */
    valid = 1;
    ret = sm2_hw_verify_msg((const uint8_t *)TEST_ID, TEST_ID_LEN, msg_bad, msg_len,
                            V_R, V_S, V_PUB, &valid);
    if (ret != RSP_OK) { printf("  hw_verify_msg(bad msg) ret=%d\n", ret); return -1; }
    printf("  valid(tampered msg) = %d (expect 0)\n", valid);
    if (valid != 0) fail++;

    printf("  verify_msg: %s\n", (fail == 0) ? "PASS" : "FAIL");
    return (fail == 0) ? 0 : -1;
}

/* ============================================================
 * 14. 加密  hw vs sm2_encrypt_message
 *     软件密文: 04||x1(32)||y1(32)||c2(n)||c3(32)
 *     硬件密文: c1(64)||c2(n)||c3(32)
 * ============================================================ */

/* ============================================================
 * 14. 加密  (golden 数据, 纯硬件测试, 无软件交叉)
 *     硬件: PKG_LEN=明文字节数n, CFG=0x501(MODE=5),
 *           IFIFO 顺序 krand(32) -> pubkey(64) -> msg(n)
 *     输出: C1(64) || C2(n) || C3(32), 共 n+96 字节
 *     golden 由 scripts/gen_sm2_enc_golden.py 离线生成
 *     (标准 GM/T 0003: C1=k*G, C2=M^KDF(x2||y2), C3=SM3(x2||M||y2),
 *      实现已经过 d*G==V_PUB 自校验)
 *     注: 原软硬件交叉验证版本耗时约8分钟, 已移除软件调用;
 *         如需重新交叉验证软件中间件, 参考 git 历史版本.
 * ============================================================ */
static int test_sm2_enc(void)
{
    static const uint8_t m32[] = "0123456789ABCDEF0123456789ABCDEF";
    /* golden: V_K, V_PUB, m32 -> C1(64)||C2(32)||C3(32) */
    static const uint8_t golden_ct[128] = {
        0x04,0xEB,0xFC,0x71,0x8E,0x8D,0x17,0x98,
        0x62,0x04,0x32,0x26,0x8E,0x77,0xFE,0xB6,
        0x41,0x5E,0x2E,0xDE,0x0E,0x07,0x3C,0x0F,
        0x4F,0x64,0x0E,0xCD,0x2E,0x14,0x9A,0x73,
        0xE8,0x58,0xF9,0xD8,0x1E,0x54,0x30,0xA5,
        0x7B,0x36,0xDA,0xAB,0x8F,0x95,0x0A,0x3C,
        0x64,0xE6,0xEE,0x6A,0x63,0x09,0x4D,0x99,
        0x28,0x3A,0xFF,0x76,0x7E,0x12,0x4D,0xF0,
        0x74,0xD7,0x3D,0xE8,0xC4,0x8F,0xDE,0x23,
        0x0F,0x5F,0x12,0x36,0xFD,0xB6,0x22,0x0F,
        0x34,0x5D,0xAC,0x30,0xB2,0x56,0x1F,0x7D,
        0x1C,0xCA,0xAD,0x8E,0x10,0x7A,0x12,0xDC,
        0xEF,0x30,0x56,0xFA,0xDE,0x0D,0x26,0xC7,
        0x20,0x2B,0xDD,0xFB,0xF9,0x4E,0x9B,0xFB,
        0x3B,0x0C,0x36,0x47,0xFD,0xCB,0xCB,0xA8,
        0x94,0x80,0x7B,0x37,0x67,0xFF,0x60,0x68,
    };
    uint8_t hw_cipher[256];
    uint8_t plain_hw[256];
    uint32_t hw_clen = 0, hw_plen = 0;
    const uint32_t n = 32;
    int ret, c_ok, d_ok;

    banner("encrypt  (golden vector, hw-only)");
    printf("  in : k(32) + pub_x(32) + pub_y(32) + plaintext(32)\n");
    printf("  out: C1(64)||C2(32)||C3(32), golden compare + hw decrypt\n\n");

    /* 参数错误校验: NULL 入参必须被拦截并打印 LOG */
    sm2_hw_encrypt(NULL, V_PUB, m32, n, hw_cipher, &hw_clen);
    sm2_hw_encrypt(V_K, NULL, m32, n, hw_cipher, &hw_clen);
    sm2_hw_encrypt(V_K, V_PUB, NULL, n, hw_cipher, &hw_clen);
    sm2_hw_encrypt(V_K, V_PUB, m32, n, NULL, &hw_clen);
    sm2_hw_encrypt(V_K, V_PUB, m32, n, hw_cipher, NULL);

    hex_dump("  in  k", V_K, 32);
    hex_dump("  in  pub", V_PUB, 64);
    hex_dump("  in  msg", m32, (int)n);

    /* 1. 硬件加密, 全量比对 golden */
    ret = sm2_hw_encrypt(V_K, V_PUB, m32, n, hw_cipher, &hw_clen);
    c_ok = (ret == RSP_OK) && (hw_clen == (n + 96U)) &&
           buf_eq(hw_cipher, golden_ct, (int)(n + 96U));

    /* 2. 硬件解密 golden 密文, 明文还原 */
    ret = sm2_hw_decrypt(V_D, golden_ct, (n + 96U), plain_hw, &hw_plen);
    d_ok = (ret == RSP_OK) && (hw_plen == n) &&
           buf_eq(plain_hw, m32, (int)n);

    if (c_ok && d_ok)
    {
        hex_dump("  out ct", hw_cipher, (int)(n + 96U));
        hex_dump("  out pt", plain_hw, (int)hw_plen);
        printf("  enc==golden OK, hwdec OK : PASS\n");
        printf("\n  encrypt: PASS (1/1)\n");
        return 0;
    }

    if (!c_ok)
    {
        printf("  enc: ret=%d clen=%lu\n", ret, (unsigned long)hw_clen);
        hex_dump("  golden", golden_ct, (int)(n + 96U));
        hex_dump("  hw    ", hw_cipher, (int)hw_clen);
    }
    if (!d_ok)
    {
        printf("  dec: ret=%d plen=%lu\n", ret, (unsigned long)hw_plen);
        hex_dump("  expect", m32, (int)n);
        hex_dump("  got   ", plain_hw, (int)hw_plen);
    }
    printf("\n  encrypt: FAIL (0/1)\n");
    return -1;
}

/* ============================================================
 * 15. 解密  golden 密文 -> 硬件解 (无软件调用)
 *     golden: msg="message digest", k=V_K, pub=V_PUB,
 *             C1(64)||C2(14)||C3(32), 同 gen_sm2_enc_golden.py
 * ============================================================ */
static int test_sm2_dec(void)
{
    const uint8_t msg[] = "message digest";
    uint32_t msg_len = (uint32_t)(sizeof(msg) - 1);
    static const uint8_t golden_ct[110] = {
        0x04,0xEB,0xFC,0x71,0x8E,0x8D,0x17,0x98,
        0x62,0x04,0x32,0x26,0x8E,0x77,0xFE,0xB6,
        0x41,0x5E,0x2E,0xDE,0x0E,0x07,0x3C,0x0F,
        0x4F,0x64,0x0E,0xCD,0x2E,0x14,0x9A,0x73,
        0xE8,0x58,0xF9,0xD8,0x1E,0x54,0x30,0xA5,
        0x7B,0x36,0xDA,0xAB,0x8F,0x95,0x0A,0x3C,
        0x64,0xE6,0xEE,0x6A,0x63,0x09,0x4D,0x99,
        0x28,0x3A,0xFF,0x76,0x7E,0x12,0x4D,0xF0,
        0x29,0x83,0x7C,0xA8,0x91,0xDD,0x8D,0x34,
        0x53,0x0F,0x34,0x11,0xCD,0x86,0xE5,0xDC,
        0x2C,0xFA,0x22,0xCD,0xE5,0x49,0xD1,0x33,
        0x25,0x74,0x10,0xDC,0x86,0x83,0xD5,0xB4,
        0xE1,0x05,0xC0,0x41,0xFA,0x6A,0xFB,0xAB,
        0x73,0x0D,0x03,0x00,0xF0,0x28,
    };
    uint8_t hw_plain[256] = {0};
    uint32_t hw_plen = 0;
    int ret;

    banner("decrypt  golden ct -> hw decrypt (hw-only)");

    /* 参数错误校验: NULL 入参必须被拦截并打印 LOG */
    sm2_hw_decrypt(NULL, golden_ct, (uint32_t)sizeof(golden_ct), hw_plain, &hw_plen);
    sm2_hw_decrypt(V_D, NULL, (uint32_t)sizeof(golden_ct), hw_plain, &hw_plen);
    sm2_hw_decrypt(V_D, golden_ct, (uint32_t)sizeof(golden_ct), NULL, &hw_plen);
    sm2_hw_decrypt(V_D, golden_ct, (uint32_t)sizeof(golden_ct), hw_plain, NULL);

    hex_dump("  in  d", V_D, 32);
    hex_dump("  in  ct", golden_ct, (int)sizeof(golden_ct));

    ret = sm2_hw_decrypt(V_D, golden_ct, (uint32_t)sizeof(golden_ct),
                         hw_plain, &hw_plen);
    if (ret != RSP_OK) { printf("  hw_decrypt ret=%d\n", ret); return -1; }

    hex_dump("  out pt", hw_plain, (int)hw_plen);

    printf("  hw plain len = %lu (expect %lu)\n",
           (unsigned long)hw_plen, (unsigned long)msg_len);

    if ((hw_plen == msg_len) && buf_eq(msg, hw_plain, (int)msg_len))
    {
        printf("  decrypt: PASS\n");
        return 0;
    }
    hex_dump("  expect", msg, (int)msg_len);
    hex_dump("  got   ", hw_plain, (int)hw_plen);
    printf("  decrypt: FAIL\n");
    return -1;
}

/* ============================================================
 * 16. 密钥交换  A/B 两侧同参数, 共享密钥应一致
 * ============================================================ */
static int test_sm2_kexch(void)
{
    /* golden: KEX_B_D * G (gen_sm2_enc_golden.py), 替代软件 soft_pub_from_d */
    static const uint8_t golden_pub_b[64] = {
        0x4C,0x69,0x7F,0x16,0x03,0xB5,0x70,0x6B,
        0xE7,0x77,0x22,0x01,0xC4,0x6A,0x16,0x70,
        0x71,0xA9,0x3B,0xA5,0x9F,0x51,0x53,0x31,
        0x94,0x05,0xB9,0x14,0x9F,0xBF,0x1F,0x4C,
        0x83,0x63,0xE1,0xD3,0xA3,0x08,0x8B,0x9D,
        0x1D,0x2E,0xA8,0xDE,0x5D,0xD8,0x75,0xE3,
        0x5E,0x8F,0xD9,0x89,0x0A,0x18,0x4C,0x1F,
        0xF2,0x76,0x42,0x42,0xDB,0x1C,0x15,0x67,
    };
    uint8_t pub_a[64], pub_b[64];
    uint8_t tmp_a[64], tmp_b[64];
    sm2_kexch_in_t in;
    sm2_kexch_out_t outa, outb;
    int fail = 0, ret;

    banner("kexch  A/B shared-key agreement (hw-only, golden)");

    memcpy(pub_a, V_PUB, 64);
    memcpy(pub_b, golden_pub_b, 64);

    ret = sm2_hw_kg(V_K, tmp_a);
    if (ret != RSP_OK) { printf("  hw_kg(A tmp) ret=%d\n", ret); return -1; }
    ret = sm2_hw_kg(KEX_B_K, tmp_b);
    if (ret != RSP_OK) { printf("  hw_kg(B tmp) ret=%d\n", ret); return -1; }

    /* A 侧 (发送端) */
    memset(&in, 0, sizeof(in));
    in.self_id = (const uint8_t *)TEST_ID;
    in.self_id_len = TEST_ID_LEN;
    in.peer_id = (const uint8_t *)KEX_ID_B;
    in.peer_id_len = KEX_ID_B_LEN;
    memcpy(in.self_pub, pub_a, 64);
    memcpy(in.peer_pub, pub_b, 64);
    memcpy(in.self_d, V_D, 32);
    memcpy(in.k, V_K, 32);
    memcpy(in.peer_tmp, tmp_b, 64);
    in.klen_bits = 128;

    ret = sm2_hw_kexch(&in, 1, 1, 0, &outa);
    if (ret != RSP_OK) { printf("  kexch(A) ret=%d\n", ret); return -1; }

    /* B 侧 (响应端) */
    memset(&in, 0, sizeof(in));
    in.self_id = (const uint8_t *)KEX_ID_B;
    in.self_id_len = KEX_ID_B_LEN;
    in.peer_id = (const uint8_t *)TEST_ID;
    in.peer_id_len = TEST_ID_LEN;
    memcpy(in.self_pub, pub_b, 64);
    memcpy(in.peer_pub, pub_a, 64);
    memcpy(in.self_d, KEX_B_D, 32);
    memcpy(in.k, KEX_B_K, 32);
    memcpy(in.peer_tmp, tmp_a, 64);
    in.klen_bits = 128;

    ret = sm2_hw_kexch(&in, 0, 1, 0, &outb);
    if (ret != RSP_OK) { printf("  kexch(B) ret=%d\n", ret); return -1; }

    printf("  KA len=%lu KB len=%lu\n",
           (unsigned long)outa.key_len, (unsigned long)outb.key_len);

    /* 临时公钥输出应与 kG 结果一致 */
    if (!buf_eq(outa.tmp_pub, tmp_a, 64))
    {
        printf("  A tmp pubkey MISMATCH\n");
        fail++;
    }
    if (!buf_eq(outb.tmp_pub, tmp_b, 64))
    {
        printf("  B tmp pubkey MISMATCH\n");
        fail++;
    }

    /* 共享密钥一致 */
    if ((outa.key_len == outb.key_len) && buf_eq(outa.key, outb.key, (int)outa.key_len))
    {
        printf("  KA == KB: OK\n");
    }
    else
    {
        hex_dump("  KA", outa.key, (int)outa.key_len);
        hex_dump("  KB", outb.key, (int)outb.key_len);
        printf("  KA == KB: MISMATCH\n");
        fail++;
    }

    /* CR: 非 0 表示协商成功 */
    int cr_a = 0, cr_b = 0;
    for (int i = 0; i < 16; i++)
    {
        if (outa.cr[i]) cr_a = 1;
        if (outb.cr[i]) cr_b = 1;
    }
    printf("  CR_A=%d CR_B=%d (expect 1 1)\n", cr_a, cr_b);
    if (!cr_a || !cr_b) fail++;

    printf("  kexch: %s\n", (fail == 0) ? "PASS" : "FAIL");
    return (fail == 0) ? 0 : -1;
}

/* ============================================================
 * 统一入口
 * ============================================================ */
int sm2_test(void)
{

    for (uint32_t i = 0U; i < PRESSURE_TEST; i++)
    {

        test_sm2_kg();
        test_sm2_kp();
        test_sm2_sign();
        test_sm2_enc();
        test_sm2_dec();
        test_sm2_verify();
    }


    return 0;
}
