/**
 * @file test_chacha20.c
 * @brief ChaCha20-Poly1305 HW IP test (vs software middleware chacha20_poly1305)
 *        1. chacha20_enc_test    single-packet, 32x random AAD 1-64 + msg 1-1024, enc+dec
 *        2. chacha20_dec_test    decrypt with AAD, 32x random 1-1024
 *        3. chacha20_aad_test    AAD length 1/16/17/32/64, enc+dec
 *        4. chacha20_len_test    length 1-128 sweep, enc+dec
 *        5. chacha20_big_test    large packets 1024/1536/2048 + AAD 32, enc+dec
 *        6. chacha20_tamper_test tamper tag/ct/AAD must fail authentication
 *        7. chacha20_swref_test  feed SW-produced ct+tag to HW decrypt
 */

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "rsp_ip_chacha20.h"
#include "chacha20_poly1305.h"

/* ============================================================
 *  Big block test config
 * ============================================================ */
#define MAX_MSG_LEN (2048U)
#define MAX_AAD_LEN (64U)
#define PRESSURE_TEST 120U

/* ============================================================
 *  Test data
 * ============================================================ */
static uint8_t test_msg[MAX_MSG_LEN];   /* plaintext */
static uint8_t hw_out[MAX_MSG_LEN];     /* HW output (ciphertext/plaintext) */
static uint8_t sw_out[MAX_MSG_LEN];     /* SW output (ciphertext/plaintext) */
static uint8_t ct_buf[MAX_MSG_LEN];     /* ciphertext from encryption */
static uint8_t aad_buf[MAX_AAD_LEN];    /* AAD buffer */

static uint8_t hw_tag[CHACHA20_TAG_BYTE_LEN];
static uint8_t sw_tag[CHACHA20_TAG_BYTE_LEN];
static uint8_t dec_tag[CHACHA20_TAG_BYTE_LEN];

/* fixed key(32B) / nonce(12B): 0x00..0x1F / 0x00..0x0B */
static const uint8_t cha_key[CHACHA20_KEY_BYTE_LEN] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
    0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F
};

static const uint8_t cha_nonce[CHACHA20_NONCE_BYTE_LEN] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05,
    0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B
};

/* simple reproducible LCG PRNG */
static uint32_t rand_seed = 0x12345678U;
static uint32_t simple_rand(void)
{
    rand_seed = rand_seed * 1103515245U + 12345U;
    return (rand_seed >> 16) & 0x7FFF;
}

static void init_test_msg(void)
{
    uint32_t seed = rand_seed;
    for (uint32_t i = 0; i < MAX_MSG_LEN; i++)
    {
        test_msg[i] = (uint8_t)(simple_rand() & 0xFF);
    }
    rand_seed = seed;  /* restore seed so every run uses the same data */
}

static void init_aad(void)
{
    for (uint32_t i = 0; i < MAX_AAD_LEN; i++)
    {
        aad_buf[i] = (uint8_t)(0xA0U + i);
    }
}

/* ============================================================
 *  Input dump (debug)
 * ============================================================ */
#define DUMP_LINE 16U
#define DUMP_MAX 64U /* 每段最多打印64B, 防止刷屏 */

static void rsp_dump_buf(char *info, uint8_t *buf, uint32_t len)
{
    printf("%s[%d]", info, len);
    for (uint32_t i = 0; i < len; i++)
    {
        printf("%s0x%02x ", i % 16 == 0 ? "\n     " : " ", buf[i]);
    }
    printf("\n");
}

/* HW vs SW result comparison: ciphertext and tag must both match. */
static int hw_matches_sw(uint32_t len)
{
    if (memcmp(hw_out, sw_out, len) != 0)
    {
        return 0;
    }
    return (memcmp(hw_tag, sw_tag, CHACHA20_TAG_BYTE_LEN) == 0) ? 1 : 0;
}

/* 参数错误: 故意传 NULL, 驱动应打印对应错误并返回 RSP_ERR_NULL_PTR */
static void chacha20_param_err(void)
{
    chacha20_poly1305_hw(NULL, cha_nonce, aad_buf, MAX_AAD_LEN,
                         test_msg, 16, hw_out, hw_tag, 1);
    chacha20_poly1305_hw(cha_key, NULL, aad_buf, MAX_AAD_LEN,
                         test_msg, 16, hw_out, hw_tag, 1);
    chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, MAX_AAD_LEN,
                         test_msg, 16, hw_out, NULL, 1);
    chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, MAX_AAD_LEN,
                         NULL, 16, hw_out, hw_tag, 1);
    chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, MAX_AAD_LEN,
                         test_msg, 16, NULL, hw_tag, 1);
    chacha20_poly1305_hw(cha_key, cha_nonce, NULL, MAX_AAD_LEN,
                         test_msg, 16, hw_out, hw_tag, 1);
}

/* ============================================================
 *  1. chacha20_enc_test -- single-packet, 32x random AAD 1-64 + msg 1-1024
 * ============================================================ */
static int chacha20_enc_test(void)
{
    RSP_StatusTypeDef enc_ret, dec_ret;
    int sw_ret;
    int pass_cnt = 0, fail_cnt = 0;

    init_test_msg();
    init_aad();
    chacha20_param_err();

    printf("DATE SIZE = 1~1024B (random 32x), AAD SIZE = 1~64B\n");

    for (int i = 0; i < 32; i++)
    {
        uint32_t len = (simple_rand() % 1024) + 1;   /* 1-1024 */
        uint32_t aad_len = (simple_rand() % 64) + 1; /* 1-64 */
        const uint8_t *aad = aad_buf;
        int ok = 1;

        /* ---- 1) 硬件加密 vs 软件参考 ---- */
        enc_ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad, aad_len,
                                       test_msg, len, hw_out, hw_tag, 1);
        sw_ret = chacha20_poly1305_encrypt(cha_key, cha_nonce, aad, aad_len,
                                           test_msg, len, sw_out, sw_tag);
        if (enc_ret != RSP_OK || sw_ret != 0 || hw_matches_sw(len) == 0)
        {
            ok = 0;
        }

        if (i == 0)
        {
            rsp_dump_buf("msg", test_msg, len > DUMP_MAX ? DUMP_MAX : len);
            rsp_dump_buf("soft output:", sw_out, len > DUMP_MAX ? DUMP_MAX : len);
            rsp_dump_buf("hw output:", hw_out, len > DUMP_MAX ? DUMP_MAX : len);
            rsp_dump_buf("soft tag:", sw_tag, CHACHA20_TAG_BYTE_LEN);
            rsp_dump_buf("hw tag:", hw_tag, CHACHA20_TAG_BYTE_LEN);
        }

        /* ---- 2) 硬件解密: 用 HW 自己的密文+TAG, 明文必须还原且认证通过 ---- */
        memcpy(ct_buf, hw_out, len);
        memcpy(dec_tag, hw_tag, CHACHA20_TAG_BYTE_LEN);
        dec_ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad, aad_len,
                                       ct_buf, len, hw_out, dec_tag, 0);
        if (dec_ret != RSP_OK || memcmp(hw_out, test_msg, len) != 0)
        {
            ok = 0;
        }

        if (ok)
        {
            pass_cnt++;
        }
        else
        {
            fail_cnt++;
            if (fail_cnt <= 3)
            {
                printf("  FAIL: aad_len=%u len=%u enc_ret=%d dec_ret=%d sw=%d\n",
                       (unsigned)aad_len, (unsigned)len, enc_ret, dec_ret, sw_ret);
                rsp_dump_buf("    HW tag", hw_tag, CHACHA20_TAG_BYTE_LEN);
                rsp_dump_buf("    SW tag", sw_tag, CHACHA20_TAG_BYTE_LEN);
                rsp_dump_buf("    HW ct", hw_out, len > DUMP_MAX ? DUMP_MAX : len);
                rsp_dump_buf("    SW ct", sw_out, len > DUMP_MAX ? DUMP_MAX : len);
            }
        }
    }

    if (fail_cnt != 0)
    {
        printf("CHACHA20 ENC/DEC SINGLE-PKT FAIL (%d PASS, %d FAIL)\n", pass_cnt, fail_cnt);
        return -1;
    }
    printf("CHACHA20 ENC/DEC SINGLE-PKT PASS (%d cases)\n", pass_cnt);
    return 0;
}

/* ============================================================
 *  2. chacha20_dec_test -- decrypt 32x random 1-1024 (AAD 32)
 *     encrypt with HW to get ct+tag, then HW decrypt and check auth
 * ============================================================ */
static int chacha20_dec_test(void)
{
    RSP_StatusTypeDef ret;
    int sw_ret;
    int pass_cnt = 0, fail_cnt = 0;

    init_test_msg();
    init_aad();
    chacha20_param_err();

    printf("DATE SIZE = 1~1024B (random 32x), AAD SIZE = 32B\n");

    for (int i = 0; i < 32; i++)
    {
        uint32_t len = (simple_rand() % 1024) + 1;
        const uint32_t aad_len = 32U;

        ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, aad_len,
                                   test_msg, len, ct_buf, hw_tag, 1);
        if (ret != RSP_OK)
        {
            fail_cnt++;
            if (fail_cnt <= 3)
            {
                printf("  FAIL(enc): len=%u ret=%d\n", (unsigned)len, ret);
            }
            continue;
        }

        sw_ret = chacha20_poly1305_encrypt(cha_key, cha_nonce, aad_buf, aad_len,
                                           test_msg, len, sw_out, sw_tag);
        if (sw_ret == 0 && memcmp(ct_buf, sw_out, len) != 0)
        {
            fail_cnt++;
            if (fail_cnt <= 3)
            {
                printf("  FAIL(ct): len=%u\n", (unsigned)len);
                rsp_dump_buf("    HW ct", ct_buf, len > DUMP_MAX ? DUMP_MAX : len);
                rsp_dump_buf("    SW ct", sw_out, len > DUMP_MAX ? DUMP_MAX : len);
            }
            continue;
        }

        if (i == 0)
        {
            rsp_dump_buf("msg", test_msg, len > DUMP_MAX ? DUMP_MAX : len);
            rsp_dump_buf("hw ct:", ct_buf, len > DUMP_MAX ? DUMP_MAX : len);
            rsp_dump_buf("sw ct:", sw_out, len > DUMP_MAX ? DUMP_MAX : len);
        }

        memcpy(dec_tag, hw_tag, CHACHA20_TAG_BYTE_LEN);
        ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, aad_len,
                                   ct_buf, len, hw_out, dec_tag, 0);

        if (ret == RSP_OK && memcmp(hw_out, test_msg, len) == 0)
        {
            pass_cnt++;
        }
        else
        {
            fail_cnt++;
            if (fail_cnt <= 3)
            {
                printf("  FAIL(dec): len=%u ret=%d\n", (unsigned)len, ret);
                rsp_dump_buf("    HW pt", hw_out, len > DUMP_MAX ? DUMP_MAX : len);
                rsp_dump_buf("    PT", test_msg, len > DUMP_MAX ? DUMP_MAX : len);
            }
        }
    }

    if (fail_cnt != 0)
    {
        printf("CHACHA20 DEC FAIL (%d PASS, %d FAIL)\n", pass_cnt, fail_cnt);
        return -1;
    }
    printf("CHACHA20 DEC PASS (%d cases)\n", pass_cnt);
    return 0;
}

/* ============================================================
 *  3. chacha20_aad_test -- AAD length 1/16/17/32/64, enc+dec
 * ============================================================ */
static int chacha20_aad_test(void)
{
    static const uint32_t aad_lens[] = { 1U, 16U, 17U, 32U, 64U };
    static const uint32_t msg_lens[] = { 16U, 100U, 258U };
    RSP_StatusTypeDef ret;
    int sw_ret;
    int pass_cnt = 0, fail_cnt = 0;

    init_test_msg();
    init_aad();
    chacha20_param_err();

    printf("DATE SIZE = 16/100/258B, AAD SIZE = 1/16/17/32/64B\n");

    for (uint32_t ai = 0; ai < sizeof(aad_lens) / sizeof(aad_lens[0]); ai++)
    {
        uint32_t aad_len = aad_lens[ai];
        const uint8_t *aad = aad_buf;

        for (uint32_t mi = 0; mi < sizeof(msg_lens) / sizeof(msg_lens[0]); mi++)
        {
            uint32_t len = msg_lens[mi];
            int ok = 1;

            /* ---- 1) 硬件加密 vs 软件参考 ---- */
            ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad, aad_len,
                                       test_msg, len, hw_out, hw_tag, 1);
            sw_ret = chacha20_poly1305_encrypt(cha_key, cha_nonce, aad, aad_len,
                                               test_msg, len, sw_out, sw_tag);
            if (ret != RSP_OK || sw_ret != 0 || hw_matches_sw(len) == 0)
            {
                ok = 0;
            }

            if (ai == 0 && mi == 0)
            {
                rsp_dump_buf("msg", test_msg, len > DUMP_MAX ? DUMP_MAX : len);
                rsp_dump_buf("soft output:", sw_out, len > DUMP_MAX ? DUMP_MAX : len);
                rsp_dump_buf("hw output:", hw_out, len > DUMP_MAX ? DUMP_MAX : len);
                rsp_dump_buf("soft tag:", sw_tag, CHACHA20_TAG_BYTE_LEN);
                rsp_dump_buf("hw tag:", hw_tag, CHACHA20_TAG_BYTE_LEN);
            }

            /* ---- 2) 硬件解密 (用 HW 自己的 ct + tag) ---- */
            memcpy(ct_buf, hw_out, len);
            memcpy(dec_tag, hw_tag, CHACHA20_TAG_BYTE_LEN);
            ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad, aad_len,
                                       ct_buf, len, hw_out, dec_tag, 0);
            if (ret != RSP_OK || memcmp(hw_out, test_msg, len) != 0)
            {
                ok = 0;
            }

            if (ok)
            {
                pass_cnt++;
            }
            else
            {
                fail_cnt++;
                if (fail_cnt <= 3)
                {
                    printf("  FAIL: aad_len=%u len=%u ret=%d sw=%d\n",
                           (unsigned)aad_len, (unsigned)len, ret, sw_ret);
                    rsp_dump_buf("    HW tag", hw_tag, CHACHA20_TAG_BYTE_LEN);
                    rsp_dump_buf("    SW tag", sw_tag, CHACHA20_TAG_BYTE_LEN);
                }
            }
        }
    }

    if (fail_cnt != 0)
    {
        printf("CHACHA20 AAD FAIL (%d PASS, %d FAIL)\n", pass_cnt, fail_cnt);
        return -1;
    }
    printf("CHACHA20 AAD PASS (%d cases)\n", pass_cnt);
    return 0;
}

/* ============================================================
 *  4. chacha20_len_test -- length 1-128 sweep, enc+dec
 * ============================================================ */
static int chacha20_len_test(void)
{
    RSP_StatusTypeDef ret;
    int sw_ret;
    int pass_cnt = 0, fail_cnt = 0;

    init_test_msg();
    init_aad();
    chacha20_param_err();

    printf("DATE SIZE = 1~128B, AAD SIZE = 32B\n");

    for (uint32_t len = 1; len <= 128; len++)
    {
        const uint32_t aad_len = 32U;

        /* ---- 1) 硬件加密 vs 软件参考 ---- */
        ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, aad_len,
                                   test_msg, len, hw_out, hw_tag, 1);
        sw_ret = chacha20_poly1305_encrypt(cha_key, cha_nonce, aad_buf, aad_len,
                                           test_msg, len, sw_out, sw_tag);

        memcpy(ct_buf, hw_out, len);

        if (len == 16U)
        {
            rsp_dump_buf("msg", test_msg, len);
            rsp_dump_buf("soft output:", sw_out, len);
            rsp_dump_buf("hw output:", hw_out, len);
            rsp_dump_buf("soft tag:", sw_tag, CHACHA20_TAG_BYTE_LEN);
            rsp_dump_buf("hw tag:", hw_tag, CHACHA20_TAG_BYTE_LEN);
        }

        if (ret == RSP_OK && sw_ret == 0 && hw_matches_sw(len) != 0)
        {
            /* ---- 2) 硬件解密 ---- */
            memcpy(dec_tag, hw_tag, CHACHA20_TAG_BYTE_LEN);
            ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, aad_len,
                                       ct_buf, len, hw_out, dec_tag, 0);
            if (ret == RSP_OK && memcmp(hw_out, test_msg, len) == 0)
            {
                pass_cnt++;
            }
            else
            {
                fail_cnt++;
                if (fail_cnt <= 3)
                {
                    printf("  FAIL(dec): len=%u ret=%d\n", (unsigned)len, ret);
                }
            }
        }
        else
        {
            fail_cnt++;
            if (fail_cnt <= 3)
            {
                printf("  FAIL(enc): len=%u ret=%d sw=%d\n", (unsigned)len, ret, sw_ret);
                rsp_dump_buf("    HW tag", hw_tag, CHACHA20_TAG_BYTE_LEN);
                rsp_dump_buf("    SW tag", sw_tag, CHACHA20_TAG_BYTE_LEN);
            }
        }
    }

    if (fail_cnt != 0)
    {
        printf("CHACHA20 LEN FAIL (%d PASS, %d FAIL)\n", pass_cnt, fail_cnt);
        return -1;
    }
    printf("CHACHA20 LEN PASS (%d cases)\n", pass_cnt);
    return 0;
}

/* ============================================================
 *  5. chacha20_big_test -- large packets 1024/1536/2048 + AAD 32, enc+dec
 * ============================================================ */
static int chacha20_big_test(void)
{
    static const uint32_t msg_lens[] = { 1024U, 1536U, 2048U };
    const uint32_t aad_len = 32U;
    RSP_StatusTypeDef ret;
    int sw_ret;
    int pass_cnt = 0, fail_cnt = 0;

    init_test_msg();
    init_aad();
    chacha20_param_err();

    printf("DATE SIZE = 1024/1536/2048B, AAD SIZE = %uB\n", (unsigned)aad_len);

    for (uint32_t mi = 0; mi < sizeof(msg_lens) / sizeof(msg_lens[0]); mi++)
    {
        uint32_t len = msg_lens[mi];
        int ok = 1;

        /* ---- 1) 硬件加密 vs 软件参考 ---- */
        ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, aad_len,
                                   test_msg, len, hw_out, hw_tag, 1);
        sw_ret = chacha20_poly1305_encrypt(cha_key, cha_nonce, aad_buf, aad_len,
                                           test_msg, len, sw_out, sw_tag);
        if (ret != RSP_OK || sw_ret != 0 || hw_matches_sw(len) == 0)
        {
            ok = 0;
        }

        printf("\n");
        printf("DATE SIZE = %uB, AAD SIZE = %uB\n", (unsigned)len, (unsigned)aad_len);
        rsp_dump_buf("msg", test_msg, len > DUMP_MAX ? DUMP_MAX : len);
        rsp_dump_buf("aad", aad_buf, DUMP_MAX);
        rsp_dump_buf("soft output:", sw_out, len > DUMP_MAX ? DUMP_MAX : len);
        rsp_dump_buf("hw output:", hw_out, len > DUMP_MAX ? DUMP_MAX : len);
        rsp_dump_buf("soft tag:", sw_tag, CHACHA20_TAG_BYTE_LEN);
        rsp_dump_buf("hw tag:", hw_tag, CHACHA20_TAG_BYTE_LEN);

        /* ---- 2) 硬件解密 ---- */
        memcpy(ct_buf, hw_out, len);
        memcpy(dec_tag, hw_tag, CHACHA20_TAG_BYTE_LEN);
        ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, aad_len,
                                   ct_buf, len, hw_out, dec_tag, 0);
        if (ret != RSP_OK || memcmp(hw_out, test_msg, len) != 0)
        {
            ok = 0;
        }

        if (ok)
        {
            pass_cnt++;
            printf("CHACHA20 BIG %uB PASS\n", (unsigned)len);
        }
        else
        {
            fail_cnt++;
            printf("FAIL: len=%u ret=%d sw=%d\n", (unsigned)len, ret, sw_ret);
            rsp_dump_buf("    HW tag", hw_tag, CHACHA20_TAG_BYTE_LEN);
            rsp_dump_buf("    SW tag", sw_tag, CHACHA20_TAG_BYTE_LEN);
        }
    }

    if (fail_cnt != 0)
    {
        printf("CHACHA20 BIG FAIL (%d PASS, %d FAIL)\n", pass_cnt, fail_cnt);
        return -1;
    }
    printf("CHACHA20 BIG PASS (%d cases)\n", pass_cnt);
    return 0;
}

/* ============================================================
 *  6. chacha20_tamper_test -- tamper tag/ct/AAD must fail auth
 * ============================================================ */
static int chacha20_tamper_test(void)
{
    const uint32_t len = 128U;
    const uint32_t aad_len = 32U;
    RSP_StatusTypeDef ret;
    int sw_ret;
    int fail_cnt = 0;

    init_test_msg();
    init_aad();
    chacha20_param_err();

    printf("DATE SIZE = %uB, AAD SIZE = %uB\n", (unsigned)len, (unsigned)aad_len);

    /* 软件加密生成标准 ct + tag */
    sw_ret = chacha20_poly1305_encrypt(cha_key, cha_nonce, aad_buf, aad_len,
                                       test_msg, len, ct_buf, sw_tag);
    if (sw_ret != 0)
    {
        printf("FAIL (soft encrypt error)\n");
        return -1;
    }
    rsp_dump_buf("msg", test_msg, len > DUMP_MAX ? DUMP_MAX : len);
    rsp_dump_buf("soft output:", ct_buf, len > DUMP_MAX ? DUMP_MAX : len);
    rsp_dump_buf("sw tag:", sw_tag, CHACHA20_TAG_BYTE_LEN);

    /* 6.1 tamper tag */
    memcpy(dec_tag, sw_tag, CHACHA20_TAG_BYTE_LEN);
    dec_tag[0] ^= 0x01U;
    ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, aad_len,
                               ct_buf, len, hw_out, dec_tag, 0);
    if (ret == RSP_ERR_DATA_CHECK)
    {
        printf("  tamper tag PASS\n");
    }
    else
    {
        printf("  tamper tag FAIL: ret=%d (expect %d)\n", ret, RSP_ERR_DATA_CHECK);
        fail_cnt++;
    }

    /* 6.2 tamper ciphertext */
    memcpy(dec_tag, sw_tag, CHACHA20_TAG_BYTE_LEN);
    ct_buf[5] ^= 0x80U;
    ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, aad_len,
                               ct_buf, len, hw_out, dec_tag, 0);
    if (ret == RSP_ERR_DATA_CHECK)
    {
        printf("  tamper ct PASS\n");
    }
    else
    {
        printf("  tamper ct FAIL: ret=%d (expect %d)\n", ret, RSP_ERR_DATA_CHECK);
        fail_cnt++;
    }
    ct_buf[5] ^= 0x80U;  /* restore */

    /* 6.3 tamper AAD (decrypt side AAD differs from encrypt side) */
    memcpy(dec_tag, sw_tag, CHACHA20_TAG_BYTE_LEN);
    aad_buf[0] ^= 0xFFU;
    ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, aad_len,
                               ct_buf, len, hw_out, dec_tag, 0);
    if (ret == RSP_ERR_DATA_CHECK)
    {
        printf("  tamper aad PASS\n");
    }
    else
    {
        printf("  tamper aad FAIL: ret=%d (expect %d)\n", ret, RSP_ERR_DATA_CHECK);
        fail_cnt++;
    }
    aad_buf[0] ^= 0xFFU;  /* restore */

    /* 6.4 valid tag must authenticate */
    memcpy(dec_tag, sw_tag, CHACHA20_TAG_BYTE_LEN);
    ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad_buf, aad_len,
                               ct_buf, len, hw_out, dec_tag, 0);
    if (ret == RSP_OK && memcmp(hw_out, test_msg, len) == 0)
    {
        printf("  valid tag PASS\n");
    }
    else
    {
        printf("  valid tag FAIL: ret=%d (expect %d)\n", ret, RSP_OK);
        fail_cnt++;
    }
    rsp_dump_buf("hw dec output:", hw_out, len > DUMP_MAX ? DUMP_MAX : len);

    if (fail_cnt != 0)
    {
        printf("CHACHA20 TAMPER FAIL (%d checks failed)\n", fail_cnt);
        return -1;
    }
    printf("CHACHA20 TAMPER PASS\n");
    return 0;
}

/* ============================================================
 *  7. chacha20_swref_test -- feed SW-produced ct+tag to HW decrypt
 * ============================================================ */
static int chacha20_swref_test(void)
{
    static const uint32_t aad_lens[] = { 1U, 16U, 17U, 32U, 64U };
    static const uint32_t msg_lens[] = { 1U, 16U, 100U, 256U };
    int sw_ret;
    RSP_StatusTypeDef ret;
    int pass_cnt = 0, fail_cnt = 0;

    init_test_msg();
    init_aad();
    chacha20_param_err();

    printf("DATE SIZE = 1/16/100/256B, AAD SIZE = 1/16/17/32/64B\n");

    for (uint32_t ai = 0; ai < sizeof(aad_lens) / sizeof(aad_lens[0]); ai++)
    {
        uint32_t aad_len = aad_lens[ai];
        const uint8_t *aad = aad_buf;

        for (uint32_t mi = 0; mi < sizeof(msg_lens) / sizeof(msg_lens[0]); mi++)
        {
            uint32_t len = msg_lens[mi];

            /* SW encrypt: get standard ct + standard tag */
            sw_ret = chacha20_poly1305_encrypt(cha_key, cha_nonce, aad, aad_len,
                                               test_msg, len, ct_buf, sw_tag);
            if (sw_ret != 0)
            {
                fail_cnt++;
                if (fail_cnt <= 3)
                {
                    printf("  FAIL(sw): aad=%u len=%u sw=%d\n",
                           (unsigned)aad_len, (unsigned)len, sw_ret);
                }
                continue;
            }

            /* HW decrypt */
            memcpy(dec_tag, sw_tag, CHACHA20_TAG_BYTE_LEN);
            ret = chacha20_poly1305_hw(cha_key, cha_nonce, aad, aad_len,
                                       ct_buf, len, hw_out, dec_tag, 0);

            if (ai == 0 && mi == 0)
            {
                rsp_dump_buf("msg", test_msg, len > DUMP_MAX ? DUMP_MAX : len);
                rsp_dump_buf("sw ct:", ct_buf, len > DUMP_MAX ? DUMP_MAX : len);
                rsp_dump_buf("sw tag:", sw_tag, CHACHA20_TAG_BYTE_LEN);
                rsp_dump_buf("hw tag:", dec_tag, CHACHA20_TAG_BYTE_LEN);
            }

            /* should auth pass and plaintext restore */
            if (ret == RSP_OK && memcmp(hw_out, test_msg, len) == 0)
            {
                pass_cnt++;
            }
            else
            {
                fail_cnt++;
                if (fail_cnt <= 3)
                {
                    printf("  FAIL: aad=%u len=%u ret=%d\n",
                           (unsigned)aad_len, (unsigned)len, ret);
                    rsp_dump_buf("    SW tag", sw_tag, CHACHA20_TAG_BYTE_LEN);
                    rsp_dump_buf("    HW pt", hw_out, len > DUMP_MAX ? DUMP_MAX : len);
                }
            }
        }
    }

    if (fail_cnt != 0)
    {
        printf("CHACHA20 SWREF FAIL (%d PASS, %d FAIL)\n", pass_cnt, fail_cnt);
        return -1;
    }
    printf("CHACHA20 SWREF PASS (%d cases)\n", pass_cnt);
    return 0;
}

/* ============================================================
 *  Main test entry
 * ============================================================ */
int chacha20_test(void)
{

    for (uint32_t i = 0; i < PRESSURE_TEST; i++)
    {
        chacha20_enc_test();
        chacha20_dec_test();
    }

    return 0;
}
