/**
 * @file test_rsa2048.c
 * @brief RSA2048 硬件 IP 自测程序
 *
 *  测试 9 种模式 (基址 0x80070000):
 *    Sign2048 / sign2048_CRT / verify2048
 *    Sign2048_pkcs / sign2048_CRT_pkcs
 *    Sign2048_pass / sign2048_CRT_pass / verify2048_pkcs / verify2048_pass
 *
 *  测试向量由 scripts/gen_rsa_test.py 用固定随机种子生成,
 *  软件签名/验签用 PyCryptodome 作为 oracle.
 *
 *  三种自洽检查:
 *    1. 硬件 Sign  输出 vs Python 软件签名 (逐字节对比)
 *    2. 硬件 Sign -> 硬件 verify (恢复 m 与原始 256B 对比)
 *    3. 硬件 pkcs Sign -> 硬件 pkcs verify (看 128B 结果标志)
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "rsp_ip_rsa.h"

/* ===== 测试向量 (Python 预生成) ===== */
#include "rsa_test_vectors.h"

/* ============================================================
 *  Test utilities
 * ============================================================ */

#define TEST_PASS() do { printf(" [PASS]\n"); } while(0)
#define TEST_FAIL() do { printf(" [FAIL]\n"); } while(0)
#define TEST_RET(x) do { if ((x) == RSP_OK) TEST_PASS(); else { TEST_FAIL(); printf("  ret=%d\n", (int)(x)); } } while(0)
#define PRESSURE_TEST 1U
static void print_hex(const char *name, const uint8_t *data, size_t len)
{
    printf("%s (%u bytes):\n", name, (unsigned)len);
    for (size_t i = 0; i < len; i++)
    {
        printf("%02X", data[i]);
        if ((i + 1) % 16 == 0) printf("\n");
        else printf(" ");
    }
    if (len % 16) printf("\n");
}

static void print_diff(const uint8_t *a, const uint8_t *b, size_t len)
{
    for (size_t i = 0; i < len; i++)
    {
        if (a[i] != b[i])
        {
            printf("  MISMATCH at byte %u: got 0x%02X, expect 0x%02X\n",
                   (unsigned)i, a[i], b[i]);
            return;
        }
    }
    printf("  FULL MATCH\n");
}

/* ---- 输入/输出 dump (参照 test_sm4.c, 每段最多打印 DUMP_MAX 字节) ---- */
#define DUMP_MAX 64U

static void rsp_dump_buf(const char *info, const uint8_t *buf, uint32_t len)
{
    printf("%s[%d]", info, len);
    for (uint32_t i = 0; i < len; i++)
    {
        printf("%s0x%02x ", i % 16 == 0 ? "\n     " : " ", buf[i]);
    }
    printf("\n");
}



/* ============================================================
 *  1. Sign2048 逐向量 vs Python oracle
 * ============================================================ */

static void test_sign2048_vectors(void)
{
    static const uint8_t *TEST_EM_256[] = {
        TEST_EM_256_0, TEST_EM_256_1, TEST_EM_256_2, TEST_EM_256_3
    };
    static const uint8_t *TEST_SIG_256[] = {
        TEST_SIG_256_0, TEST_SIG_256_1, TEST_SIG_256_2, TEST_SIG_256_3
    };
    const int N = 1;
    uint8_t err_sig[256];

    printf("\n=== Test 1: Sign2048 (pre-padded EM) vs Python oracle ===\n");

    /* 参数校验测试: NULL 入参必须被拦截并打印 LOG */
    rsa2048_sign_hw(NULL, TEST_D_256, TEST_EM_256[0], err_sig);
    rsa2048_sign_hw(TEST_N_256, NULL, TEST_EM_256[0], err_sig);
    rsa2048_sign_hw(TEST_N_256, TEST_D_256, NULL, err_sig);
    rsa2048_sign_hw(TEST_N_256, TEST_D_256, TEST_EM_256[0], NULL);

    for (int i = 0; i < N; i++)
    {
        uint8_t hw_sig[256];
        RSP_StatusTypeDef ret = rsa2048_sign_hw(TEST_N_256, TEST_D_256,
                                                 TEST_EM_256[i], hw_sig);
        printf("  Sign2048[%d]", i);
        if (ret != RSP_OK) { TEST_FAIL(); printf("  ret=%d\n", ret); continue; }
        rsp_dump_buf("msg", TEST_EM_256[i], 256U > DUMP_MAX ? DUMP_MAX : 256U);
        rsp_dump_buf("hw output:", hw_sig, 256U > DUMP_MAX ? DUMP_MAX : 256U);
        rsp_dump_buf("expect output:", TEST_SIG_256[i], 256U > DUMP_MAX ? DUMP_MAX : 256U);
        if (memcmp(hw_sig, TEST_SIG_256[i], 256) != 0)
        {
            TEST_FAIL();
            print_diff(hw_sig, TEST_SIG_256[i], 256);
            printf("    got[0..7] =");
            for (int k = 0; k < 8; k++) printf(" %02X", hw_sig[k]);
            printf("\n    exp[0..7] =");
            for (int k = 0; k < 8; k++) printf(" %02X", TEST_SIG_256[i][k]);
            printf("\n");
            if (i == 0)
            {
                print_hex("    hw_sig", hw_sig, 256);
            }
        }
        else
        {
            TEST_PASS();
        }
    }
}

/* ============================================================
 *  2. sign2048_CRT 逐向量 vs Python oracle (同 oracle)
 * ============================================================ */

static void test_sign2048_crt_vectors(void)
{
    static const uint8_t *TEST_EM_256[] = {
        TEST_EM_256_0, TEST_EM_256_1, TEST_EM_256_2, TEST_EM_256_3
    };
    static const uint8_t *TEST_SIG_256[] = {
        TEST_SIG_256_0, TEST_SIG_256_1, TEST_SIG_256_2, TEST_SIG_256_3
    };
    const int N = 1;
    uint8_t err_sig[256];

    printf("\n=== Test 2: sign2048_CRT (pre-padded EM) vs Python oracle ===\n");

    /* 参数校验测试: NULL 入参必须被拦截并打印 LOG */
    rsa2048_sign_crt_hw(NULL, TEST_DQ_128, TEST_P_128, TEST_Q_128, TEST_QINV_128,
                        TEST_EM_256[0], err_sig);
    rsa2048_sign_crt_hw(TEST_DP_128, NULL, TEST_P_128, TEST_Q_128, TEST_QINV_128,
                        TEST_EM_256[0], err_sig);
    rsa2048_sign_crt_hw(TEST_DP_128, TEST_DQ_128, NULL, TEST_Q_128, TEST_QINV_128,
                        TEST_EM_256[0], err_sig);
    rsa2048_sign_crt_hw(TEST_DP_128, TEST_DQ_128, TEST_P_128, NULL, TEST_QINV_128,
                        TEST_EM_256[0], err_sig);
    rsa2048_sign_crt_hw(TEST_DP_128, TEST_DQ_128, TEST_P_128, TEST_Q_128, NULL,
                        TEST_EM_256[0], err_sig);
    rsa2048_sign_crt_hw(TEST_DP_128, TEST_DQ_128, TEST_P_128, TEST_Q_128, TEST_QINV_128,
                        NULL, err_sig);
    rsa2048_sign_crt_hw(TEST_DP_128, TEST_DQ_128, TEST_P_128, TEST_Q_128, TEST_QINV_128,
                        TEST_EM_256[0], NULL);

    for (int i = 0; i < N; i++)
    {
        uint8_t hw_sig[256];
        RSP_StatusTypeDef ret = rsa2048_sign_crt_hw(
            TEST_DP_128, TEST_DQ_128, TEST_P_128, TEST_Q_128, TEST_QINV_128,
            TEST_EM_256[i], hw_sig);
        printf("  sign2048_CRT[%d]", i);
        if (ret != RSP_OK) { TEST_FAIL(); printf("  ret=%d\n", ret); continue; }
        rsp_dump_buf("msg", TEST_EM_256[i], 256U > DUMP_MAX ? DUMP_MAX : 256U);
        rsp_dump_buf("hw output:", hw_sig, 256U > DUMP_MAX ? DUMP_MAX : 256U);
        rsp_dump_buf("expect output:", TEST_SIG_256[i], 256U > DUMP_MAX ? DUMP_MAX : 256U);
        if (memcmp(hw_sig, TEST_SIG_256[i], 256) != 0)
        {
            TEST_FAIL();
            print_diff(hw_sig, TEST_SIG_256[i], 256);
        }
        else
        {
            TEST_PASS();
        }
    }
}

/* ============================================================
 *  3. verify2048 (对硬件 Sign2048 输出做 s^e mod n)
 *     应该恢复原始的 256B EM
 * ============================================================ */

static void test_verify2048_roundtrip(void)
{
    static const uint8_t *TEST_EM_256[] = {
        TEST_EM_256_0, TEST_EM_256_1, TEST_EM_256_2, TEST_EM_256_3
    };
    const int N = 1;
    uint8_t err_m[256];

    printf("\n=== Test 3: verify2048 roundtrip (Sign -> Verify recover EM) ===\n");

    /* 参数校验测试: NULL 入参必须被拦截并打印 LOG */
    rsa2048_verify_hw(NULL, TEST_N_256, TEST_EM_256[0], err_m);
    rsa2048_verify_hw(TEST_E_256, NULL, TEST_EM_256[0], err_m);
    rsa2048_verify_hw(TEST_E_256, TEST_N_256, NULL, err_m);
    rsa2048_verify_hw(TEST_E_256, TEST_N_256, TEST_EM_256[0], NULL);

    for (int i = 0; i < N; i++)
    {
        uint8_t hw_sig[256], hw_m[256];

        RSP_StatusTypeDef ret = rsa2048_sign_hw(TEST_N_256, TEST_D_256,
                                                 TEST_EM_256[i], hw_sig);
        if (ret != RSP_OK) { printf("  Sign[%d] fail ret=%d\n", i, ret); continue; }

        ret = rsa2048_verify_hw(TEST_E_256, TEST_N_256, hw_sig, hw_m);
        printf("  verify2048 roundtrip[%d]", i);
        if (ret != RSP_OK) { TEST_FAIL(); printf("  Verify ret=%d\n", ret); continue; }
        rsp_dump_buf("sig", hw_sig, 256U > DUMP_MAX ? DUMP_MAX : 256U);
        rsp_dump_buf("hw output:", hw_m, 256U > DUMP_MAX ? DUMP_MAX : 256U);
        rsp_dump_buf("expect output:", TEST_EM_256[i], 256U > DUMP_MAX ? DUMP_MAX : 256U);
        if (memcmp(hw_m, TEST_EM_256[i], 256) != 0)
        {
            TEST_FAIL();
            print_diff(hw_m, TEST_EM_256[i], 256);
        }
        else
        {
            TEST_PASS();
        }
    }
}

/* ============================================================
 *  主测试入口
 * ============================================================ */

int rsa_2048_test(void)
{
  for (uint32_t i = 0U; i < PRESSURE_TEST; i++)
    {

    test_sign2048_vectors();          /* 1. Sign2048 vs Python oracle */
    test_sign2048_crt_vectors();      /* 2. sign2048_CRT vs Python oracle */
    test_verify2048_roundtrip();      /* 3. Sign -> Verify roundtrip */
    }
    return 0;
}
