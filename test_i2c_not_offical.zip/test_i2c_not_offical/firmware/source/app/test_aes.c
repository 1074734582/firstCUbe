/**
 * @file test_aes.c
 * @brief AES hardware IP test — ECB / CBC / CTR / GCM
 *        每条通路均含 hw vs soft 软件参考比对：
 *          ECB/CBC/CTR 用 aes_cipher_ecb_enc 单块原语拼装软参考；
 *          GCM 用 aes_gcm_encrypt/aes_gcm_decrypt 完整软参考（密文+TAG 比对）。
 */

#include <stdio.h>
#include <string.h>
#include "rsp_ip_aes.h"
#include "aes.h"        /* 软件参考实现（FIPS PUB 197 + NIST SP 800-38D） */

/* ============================================================
 *  Big block test config (same as test_sm4.c)
 * ============================================================ */
#define AES_BIG_BLOCKS   100U    /* 100 × 16B = 1600B */
#define AES_BLOCK_LEN    16U
#define AES_BIG_LEN      (AES_BIG_BLOCKS * AES_BLOCK_LEN)
#define PRESSURE_TEST   1U
/* ============================================================
 *  Test data
 * ============================================================ */
static const uint8_t test_key_128[16] = {
    0x2b,0x7e,0x15,0x16,0x28,0xd2,0xa6,0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c,0x58
};
static const uint8_t test_iv[16] = {
    0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f
};
static const uint8_t test_aad[16] = {
    0xaa,0xbb,0xcc,0xdd,0xee,0xff,0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99
};

/* 大数据测试缓冲
 * 注意: 复用 big_dec 作为软件参考输出缓冲，避免 .bss 溢出 (RAM 128KB 限制) */
static uint8_t big_plain[AES_BIG_LEN];
static uint8_t big_cipher[AES_BIG_LEN];
static uint8_t big_dec[AES_BIG_LEN];

static void fill_pattern(void)
{
    uint32_t i;
    for (i = 0; i < AES_BIG_LEN; i++) big_plain[i] = (uint8_t)(i & 0xFF);
}

/* ============================================================
 *  Input dump (debug)
 * ============================================================ */
#define DUMP_LINE 16U
#define DUMP_MAX 64U /* 每段最多打印64B, 防止刷屏 */

static void rsp_dump_buf(char *info, uint8_t *buf, uint32_t len)
{
    printf("%s[%d]", info, len);
    for (uint32_t i = 0; i < len; i++)
    {
        printf("%s0x%02x ", i % 16 == 0 ? "\n     " : " ", buf[i]);
    }
    printf("\n");
}

/* ============================================================
 *  软件参考实现（基于 Middleware/aes/aes.c 单块 ECB 拼装）
 * ============================================================ */

/* ECB 软件加密（直接调用库函数） */
static void aes_ecb_soft(const uint8_t *key, uint32_t key_len,
                         const uint8_t *in, uint8_t *out, uint32_t len)
{
    aes_cipher_ecb_enc((uint8_t *)key, key_len, (uint8_t *)in, len, out);
}

/* CBC 软件加密：C[i] = E(P[i] XOR C[i-1])，C[-1] = IV */
static void aes_cbc_soft(const uint8_t *key, uint32_t key_len,
                         const uint8_t *iv,
                         const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint8_t prev[16];
    uint8_t tmp[16];
    uint32_t i, j, nblk = len / 16;

    memcpy(prev, iv, 16);
    for (i = 0; i < nblk; i++)
    {
        for (j = 0; j < 16; j++) tmp[j] = in[i * 16 + j] ^ prev[j];
        aes_cipher_ecb_enc((uint8_t *)key, key_len, tmp, 16, out + i * 16);
        memcpy(prev, out + i * 16, 16);
    }
}

/* CTR 软件加密：keystream[i] = E(IV + i)，C[i] = P[i] XOR keystream[i]；
 * 计数器 inc32 大端末 4 字节（字节 15 是 LSB，向 12 进位）— 与 SM4 GCM 已验证实现一致 */
static void aes_ctr_soft(const uint8_t *key, uint32_t key_len,
                         const uint8_t *iv,
                         const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint8_t ctr[16];
    uint8_t ks[16];
    uint32_t i, j, nblk = len / 16;

    memcpy(ctr, iv, 16);
    for (i = 0; i < nblk; i++)
    {
        aes_cipher_ecb_enc((uint8_t *)key, key_len, ctr, 16, ks);
        for (j = 0; j < 16; j++) out[i * 16 + j] = in[i * 16 + j] ^ ks[j];
        /* inc32: 字节 15 是 LSB, 向 12 进位 */
        ctr[15]++;
        if (ctr[15] == 0) {
            ctr[14]++;
            if (ctr[14] == 0) {
                ctr[13]++;
                if (ctr[13] == 0) {
                    ctr[12]++;
                }
            }
        }
    }
}

/* ============================================================
 *  ECB test
 * ============================================================ */
static int test_aes_ecb(void)
{
    uint8_t buf[32] = {0};
    uint32_t i;

    fill_pattern();

    aes_ecb(NULL, 16, buf, buf, 16, 1);
    aes_ecb(test_key_128, 15, buf, buf, 16, 1);
    aes_ecb(test_key_128, 16, NULL, buf, 16, 1);
    aes_ecb(test_key_128, 16, buf, buf, 0, 1);
    aes_ecb(test_key_128, 16, buf, buf, 17, 1);

    /* ---- 1. 软件参考（结果写入 big_dec，比对完后 big_dec 会被 hw 解密覆盖） ---- */
    aes_ecb_soft(test_key_128, 16, big_plain, big_dec, AES_BIG_LEN);

    /* ---- 2. 硬件加密 ---- */
    if (aes_ecb(test_key_128, 16, big_plain, big_cipher, AES_BIG_LEN, 1) != RSP_OK)
    {
        printf("FAIL (encrypt error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %u x 16B = %uB\n",
           (unsigned)AES_BIG_BLOCKS, (unsigned)AES_BIG_LEN);

    rsp_dump_buf("key", (uint8_t *)test_key_128, 16);
    rsp_dump_buf("msg", big_plain, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    rsp_dump_buf("soft output:", big_dec, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    rsp_dump_buf("hw output:", big_cipher, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    if (memcmp(big_cipher, big_dec, AES_BIG_LEN) != 0)
    {
        for (i = 0; i < AES_BIG_LEN; i++)
            if (big_cipher[i] != big_dec[i]) break;
        printf("  hw != soft at offset %lu: hw=%02X sw=%02X\n",
               (unsigned long)i, big_cipher[i], big_dec[i]);
        return -1;
    }
    printf("AES ECB ENC PASS\n");

    /* ---- 3. 硬件解密 ---- */
    if (aes_ecb(test_key_128, 16, big_cipher, big_dec, AES_BIG_LEN, 0) != RSP_OK)
    {
        printf("FAIL (decrypt error)\n");
        return -1;
    }
    if (memcmp(big_plain, big_dec, AES_BIG_LEN) != 0)
    {
        printf("FAIL (round-trip mismatch)\n");
        return -1;
    }
    rsp_dump_buf("hw ECB DEC output:", big_dec, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    printf("AES ECB DEC PASS\n");

    return 0;
}

/* ============================================================
 *  CBC test
 * ============================================================ */
static int test_aes_cbc(void)
{
    uint8_t buf[32] = {0};
    uint32_t i;

    fill_pattern();

    aes_cbc(NULL, 16, test_iv, buf, buf, 16, 1);
    aes_cbc(test_key_128, 15, test_iv, buf, buf, 16, 1);
    aes_cbc(test_key_128, 16, NULL, buf, buf, 16, 1);
    aes_cbc(test_key_128, 16, test_iv, NULL, buf, 16, 1);
    aes_cbc(test_key_128, 16, test_iv, buf, buf, 0, 1);
    aes_cbc(test_key_128, 16, test_iv, buf, buf, 17, 1);

    /* ---- 1. 软件参考 ---- */
    aes_cbc_soft(test_key_128, 16, test_iv, big_plain, big_dec, AES_BIG_LEN);

    /* ---- 2. 硬件加密 ---- */
    if (aes_cbc(test_key_128, 16, test_iv, big_plain, big_cipher, AES_BIG_LEN, 1) != RSP_OK)
    {
        printf("FAIL (encrypt error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %u x 16B = %uB\n",
           (unsigned)AES_BIG_BLOCKS, (unsigned)AES_BIG_LEN);

    rsp_dump_buf("key", (uint8_t *)test_key_128, 16);
    rsp_dump_buf("iv", (uint8_t *)test_iv, 16);
    rsp_dump_buf("msg", big_plain, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    rsp_dump_buf("soft output:", big_dec, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    rsp_dump_buf("hw output:", big_cipher, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    if (memcmp(big_cipher, big_dec, AES_BIG_LEN) != 0)
    {
        for (i = 0; i < AES_BIG_LEN; i++)
            if (big_cipher[i] != big_dec[i]) break;
        printf("  hw != soft at offset %lu: hw=%02X sw=%02X\n",
               (unsigned long)i, big_cipher[i], big_dec[i]);
        return -1;
    }
    printf("AES CBC ENC PASS\n");

    /* ---- 3. 硬件解密 ---- */
    if (aes_cbc(test_key_128, 16, test_iv, big_cipher, big_dec, AES_BIG_LEN, 0) != RSP_OK)
    {
        printf("FAIL (decrypt error)\n");
        return -1;
    }
    if (memcmp(big_plain, big_dec, AES_BIG_LEN) != 0)
    {
        printf("FAIL (round-trip mismatch)\n");
        return -1;
    }
    rsp_dump_buf("hw CBC DEC output:", big_dec, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    printf("AES CBC DEC PASS\n");

    return 0;
}

/* ============================================================
 *  CTR test
 * ============================================================ */
static int test_aes_ctr(void)
{
    uint8_t buf[32] = {0};
    uint32_t i;

    fill_pattern();

    aes_ctr(NULL, 16, test_iv, buf, buf, 16, 1);
    aes_ctr(test_key_128, 15, test_iv, buf, buf, 16, 1);
    aes_ctr(test_key_128, 16, NULL, buf, buf, 16, 1);
    aes_ctr(test_key_128, 16, test_iv, NULL, buf, 16, 1);
    aes_ctr(test_key_128, 16, test_iv, buf, buf, 0, 1);
    aes_ctr(test_key_128, 16, test_iv, buf, buf, 17, 1);

    /* ---- 1. 软件参考 ---- */
    aes_ctr_soft(test_key_128, 16, test_iv, big_plain, big_dec, AES_BIG_LEN);

    /* ---- 2. 硬件加密 ---- */
    if (aes_ctr(test_key_128, 16, test_iv, big_plain, big_cipher, AES_BIG_LEN, 1) != RSP_OK)
    {
        printf("FAIL (encrypt error)\n");
        return -1;
    }
    printf("\n");
    printf("DATE SIZE = %u x 16B = %uB\n",
           (unsigned)AES_BIG_BLOCKS, (unsigned)AES_BIG_LEN);

    rsp_dump_buf("key", (uint8_t *)test_key_128, 16);
    rsp_dump_buf("iv", (uint8_t *)test_iv, 16);
    rsp_dump_buf("msg", big_plain, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    rsp_dump_buf("soft output:", big_dec, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    rsp_dump_buf("hw output:", big_cipher, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    if (memcmp(big_cipher, big_dec, AES_BIG_LEN) != 0)
    {
        for (i = 0; i < AES_BIG_LEN; i++)
            if (big_cipher[i] != big_dec[i]) break;
        printf("  hw != soft at offset %lu: hw=%02X sw=%02X\n",
               (unsigned long)i, big_cipher[i], big_dec[i]);
        return -1;
    }
    printf("AES CTR ENC PASS\n");

    /* ---- 3. 硬件解密（CTR 加解密同向，均为 keystream XOR） ---- */
    if (aes_ctr(test_key_128, 16, test_iv, big_cipher, big_dec, AES_BIG_LEN, 1) != RSP_OK)
    {
        printf("FAIL (decrypt error)\n");
        return -1;
    }
    if (memcmp(big_plain, big_dec, AES_BIG_LEN) != 0)
    {
        printf("FAIL (round-trip mismatch)\n");
        return -1;
    }
    rsp_dump_buf("hw CTR DEC output:", big_dec, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    printf("AES CTR DEC PASS\n");

    return 0;
}

/* ============================================================
 *  GCM big block test
 *    1) 硬件加密 → 软件参考加密 → 密文+TAG 比对
 *    2) 硬件解密 → 明文回环
 *    3) 篡改 TAG → 硬件必须拒绝
 * ============================================================ */
static int test_aes_gcm(void)
{
    uint8_t tag[16];
    uint8_t sw_tag[16];
    uint8_t tag_tampered[16];
    uint8_t buf[32] = {0};
    uint32_t i;

    fill_pattern();

    aes_gcm(NULL, 16, test_iv, test_aad, 16, buf, buf, 16, tag, 1);
    aes_gcm(test_key_128, 15, test_iv, test_aad, 16, buf, buf, 16, tag, 1);
    aes_gcm(test_key_128, 16, NULL, test_aad, 16, buf, buf, 16, tag, 1);
    aes_gcm(test_key_128, 16, test_iv, NULL, 16, buf, buf, 16, tag, 1);
    aes_gcm(test_key_128, 16, test_iv, test_aad, 16, NULL, buf, 16, tag, 1);
    aes_gcm(test_key_128, 16, test_iv, test_aad, 16, buf, NULL, 16, tag, 1);
    aes_gcm(test_key_128, 16, test_iv, test_aad, 16, buf, buf, 16, NULL, 1);
    aes_gcm(test_key_128, 16, test_iv, test_aad, 16, buf, buf, 0, tag, 1);
    aes_gcm(test_key_128, 16, test_iv, test_aad, 16, buf, buf, 17, tag, 1);

    /* ---- 1. 硬件加密 ---- */
    if (aes_gcm(test_key_128, 16, test_iv, test_aad, 16,
                big_plain, big_cipher, AES_BIG_LEN, tag, 1) != RSP_OK)
    {
        printf("FAIL (encrypt error)\n");
        return -1;
    }

    /* ---- 2. 软件参考加密 → big_dec，比对密文 + TAG ---- */
    aes_gcm_encrypt(test_key_128, 16, test_iv, test_aad, 16,
                    big_plain, AES_BIG_LEN, big_dec, sw_tag);

    printf("\n");
    printf("DATE SIZE = %u x 16B = %uB\n",
           (unsigned)AES_BIG_BLOCKS, (unsigned)AES_BIG_LEN);

    rsp_dump_buf("key", (uint8_t *)test_key_128, 16);
    rsp_dump_buf("iv", (uint8_t *)test_iv, 16);
    rsp_dump_buf("aad", (uint8_t *)test_aad, 16);
    rsp_dump_buf("msg", big_plain, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    rsp_dump_buf("soft output:", big_dec, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    rsp_dump_buf("hw output:", big_cipher, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    rsp_dump_buf("soft tag:", sw_tag, 16);
    rsp_dump_buf("hw tag:", tag, 16);
    if (memcmp(big_cipher, big_dec, AES_BIG_LEN) != 0)
    {
        for (i = 0; i < AES_BIG_LEN; i++)
            if (big_cipher[i] != big_dec[i]) break;
        printf("  hw != soft at offset %lu: hw=%02X sw=%02X\n",
               (unsigned long)i, big_cipher[i], big_dec[i]);
        return -1;
    }
    if (memcmp(tag, sw_tag, 16) != 0)
    {
        for (i = 0; i < 16; i++)
            if (tag[i] != sw_tag[i]) break;
        printf("  TAG hw != soft at byte %lu: hw=%02X sw=%02X\n",
               (unsigned long)i, tag[i], sw_tag[i]);
        return -1;
    }
    printf("AES GCM ENC PASS\n");

    /* ---- 3. 硬件解密 + 明文回环（big_dec 复用） ---- */
    if (aes_gcm(test_key_128, 16, test_iv, test_aad, 16,
                big_cipher, big_dec, AES_BIG_LEN, tag, 0) != RSP_OK)
    {
        printf("FAIL (decrypt error)\n");
        return -1;
    }
    if (memcmp(big_plain, big_dec, AES_BIG_LEN) != 0)
    {
        printf("FAIL (round-trip mismatch)\n");
        return -1;
    }
    rsp_dump_buf("hw GCM DEC output:", big_dec, AES_BIG_LEN > DUMP_MAX ? DUMP_MAX : AES_BIG_LEN);
    printf("AES GCM DEC PASS\n");

    /* ---- 4. 篡改 TAG 拒绝（big_dec 作解密输出即可） ---- */
    memcpy(tag_tampered, tag, 16);
    tag_tampered[0] ^= 0xFF;
    if (aes_gcm(test_key_128, 16, test_iv, test_aad, 16,
                big_cipher, big_dec, AES_BIG_LEN, tag_tampered, 0) == RSP_OK)
    {
        printf("  tamper-reject FAIL (accepted tampered TAG)\n");
        return -1;
    }
    printf("  tamper-reject PASS\n");

    return 0;
}

/* ============================================================
 *  Main test entry
 * ============================================================ */
int aes_test(void)
{
    for(int i=0;i<PRESSURE_TEST;i++)
    {
        test_aes_ecb();
        test_aes_cbc();
        test_aes_ctr();
        test_aes_gcm();
    }
    
    return 0;
}
