

#include "rsp.h"
#include "rsp_hal.h"
#include "e203_512_data.h"
#include "rsp_hal_dma.h"
#include "stdint.h"
#include <stdio.h>


int dma_test333()
{
	int i;
	int ret;
	rsp_dma_transmit_t ctx;

	// 使用DMA读取数据到本地缓冲区
	uint32_t ct_buf[sizeof(e203_512_enc_ct) / sizeof(e203_512_enc_ct[0])];
	uint32_t ss_buf[sizeof(e203_512_enc_ss) / sizeof(e203_512_enc_ss[0])];
	// 初始化DMA(只需一次)
	ret = rsp_hal_dma_init(&ctx, 0, TT_M2M_DFC, DWIDTH_32, DWIDTH_32, MSIZE_4, ADDR_INC, ADDR_INC, HANDSHANKE_SOFT, HANDSHANKE_SOFT, DMAC_REQ_DEFAULT, DMAC_REQ_DEFAULT);
	if (ret != 0)
	{
		printf("DMA init failed\n");
		return ret;
	}

	for (i = 0; i < sizeof(e203_512_enc_const) / sizeof(e203_512_enc_const[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 3136 * 8 + 4 * i, e203_512_enc_const[i]);
	}
	for (i = 0; i < sizeof(e203_512_enc_task) / sizeof(e203_512_enc_task[0]); i++)
	{
		rsp_writel(PQC0_TASK_ADDR + 4 * i, e203_512_enc_task[i]);
	}
	for (i = 0; i < sizeof(e203_512_enc_const) / sizeof(e203_512_enc_const[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 3136 * 8 + 4 * i, e203_512_enc_const[i]);
	}


	// 使用DMA批量搬运数据
	// for (int k = 0; k < CIRCLE_TIME; k++)
	// {
		dma_transfer_t transfers[] = {
			{(uint32_t)e203_512_enc_seed, PQC0_MEM_ADDR, sizeof(e203_512_enc_seed)},
			{(uint32_t)e203_512_pk, PQC0_MEM_ADDR + 3200 * 8, sizeof(e203_512_pk)},
		};

		ret = dma_transfer_batch(&ctx, transfers, sizeof(transfers) / sizeof(transfers[0]));
		if (ret != 0)
		{
			printf("DMA transfer failed\n");
			return ret;
		}

		rsp_writel(PQC0_BASE_ADDR, 0);
		while (rsp_readl(PQC0_BASE_ADDR + 4) != 0x1)
			;

		// DMA读取ct数据
		ret = rsp_hal_dma_read(&ctx, PQC0_MEM_ADDR + 6144 * 8, (uint32_t)ct_buf, sizeof(ct_buf));
		if (ret != 0)
		{
			printf("DMA read ct failed\n");
			return ret;
		}

		// DMA读取ss数据
		ret = rsp_hal_dma_read(&ctx, PQC0_MEM_ADDR + 3200 * 8, (uint32_t)ss_buf, sizeof(ss_buf));
		if (ret != 0)
		{
			printf("DMA read ss failed\n");
			return ret;
		}
	// }
	// uint32_t us = rsp_hal_timer_get_us();            
        // dump_buf2("ct_buf", (uint8_t *)ct_buf, sizeof(ct_buf));
        // dump_buf2("ss_buf", (uint8_t *)ss_buf, sizeof(ss_buf));
	// printf("CIRCLE_TIME = %d, us = %d, perf = %dtimes/s\n", CIRCLE_TIME, us, 1000000 * CIRCLE_TIME / us);
	// 比较ct数据
	for (i = 0; i < sizeof(e203_512_enc_ct) / sizeof(e203_512_enc_ct[0]); i++)
	{
		if (ct_buf[i] != e203_512_enc_ct[i])
		{
			printf("compare failed\n");
			printf(" gold0[%i] = %08x , rdata = %08x : compare faild\n", i, e203_512_enc_ct[i], (unsigned)ct_buf[i]);
		}
	}

	// 比较ss数据
	for (i = 0; i < sizeof(e203_512_enc_ss) / sizeof(e203_512_enc_ss[0]); i++)
	{
		if (ss_buf[i] != e203_512_enc_ss[i])
		{
			printf("compare failed\n");
			printf(" gold0[%i] = %08x , rdata = %08x : compare faild\n", i, e203_512_enc_ss[i], (unsigned)ss_buf[i]);
		}
	}
	printf("pkpu_e203_enc_512_dma_test DMA_PERF done\n");
	return 0;
}
