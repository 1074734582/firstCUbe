#include "rsp_hal.h"
#include "e203_1024_data.h"

#define CIRCLE_TIME  1
/* 重新开关中断 */
int pkpu_e203_keygen_1024_test(void)
{
	int i, rdata;
	int32_t str_ustime_cnt = 0;
	int32_t end_ustime_cnt = 0;
	int32_t cost_ustime_cnt = 0;

	for (i = 0; i < sizeof(e203_1024_keygen_const) / sizeof(e203_1024_keygen_const[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 4736 * 8 + 4 * i, e203_1024_keygen_const[i]);
	}

	for (i = 0; i < sizeof(e203_1024_keygen_task) / sizeof(e203_1024_keygen_task[0]); i++)
	{
		rsp_writel(PQC0_TASK_ADDR + 4 * i, e203_1024_keygen_task[i]);
	}

	for (int i = 0; i < sizeof(e203_1024_keygen_seed) / sizeof(e203_1024_keygen_seed[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 4 * i, e203_1024_keygen_seed[i]);
	}

	str_ustime_cnt = rsp_hal_get_us();
	for (int k = 0; k < CIRCLE_TIME; k++)
	{
		rsp_writel(PQC0_BASE_ADDR, 0);
		while (rsp_readl(PQC0_BASE_ADDR + 4) != 0x1)
			;
	}
	end_ustime_cnt = rsp_hal_get_us();
	cost_ustime_cnt = end_ustime_cnt - str_ustime_cnt;

	printf("CIRCLE_TIME = %d, us = %d, perf = %dtimes/s\n", CIRCLE_TIME, cost_ustime_cnt, 1000000 * CIRCLE_TIME / cost_ustime_cnt);
	
	for (i = 0; i < sizeof(e203_1024_pk) / sizeof(e203_1024_pk[0]); i++)
	{
		rdata = rsp_readl(PQC0_MEM_ADDR + 1216 * 8 + 4 * i);

		if (rdata != e203_1024_pk[i])
		{
			printf("compare failed\n");
			printf("pk gold0[%i] = %08x , rdata = %08x : compare faild\n", i, e203_1024_pk[i], rdata);
		}
	}
	int temlen = 3136;
	for (i = 0; i < temlen / sizeof(e203_1024_sk[0]) - 8; i++)
	{
		rdata = rsp_readl(PQC0_MEM_ADDR + 1024 * 8 + 4 * i);
		if (rdata != e203_1024_sk[i])
		{
			printf("compare failed\n");
			printf("203 sk gold0[%i] = %08x , rdata = %08x : compare faild\n", i, e203_1024_sk[i], rdata);
		}
	}

	printf("pkpu_e203_keygen_1024_test ALGO_FUN done\n");

	return 0;
}

int pkpu_e203_enc_1024_test(void)
{
	int i, rdata;
	int32_t str_ustime_cnt = 0;
	int32_t end_ustime_cnt = 0;
	int32_t cost_ustime_cnt = 0;

	for (i = 0; i < sizeof(e203_1024_enc_task) / sizeof(e203_1024_enc_task[0]); i++)
	{
		rsp_writel(PQC0_TASK_ADDR + 4 * i, e203_1024_enc_task[i]);
	}

	for (i = 0; i < sizeof(e203_1024_enc_const) / sizeof(e203_1024_enc_const[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 3136 * 8 + 4 * i, e203_1024_enc_const[i]);
	}

	for (i = 0; i < sizeof(e203_1024_enc_seed) / sizeof(e203_1024_enc_seed[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 4 * i, e203_1024_enc_seed[i]);
	}

	for (i = 0; i < sizeof(e203_1024_pk) / sizeof(e203_1024_pk[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 3200 * 8 + 4 * i, e203_1024_pk[i]);
	}

	str_ustime_cnt = rsp_hal_get_us();
	for (int k = 0; k < CIRCLE_TIME; k++)
	{
		rsp_writel(PQC0_BASE_ADDR, 0);
		while (rsp_readl(PQC0_BASE_ADDR + 4) != 0x1)
			;
	}
	end_ustime_cnt = rsp_hal_get_us();
	cost_ustime_cnt = end_ustime_cnt - str_ustime_cnt;

	printf("CIRCLE_TIME = %d, us = %d, perf = %dtimes/s\n", CIRCLE_TIME, cost_ustime_cnt, 1000000 * CIRCLE_TIME / cost_ustime_cnt);
	
	for (i = 0; i < sizeof(e203_1024_enc_ct) / sizeof(e203_1024_enc_ct[0]); i++)
	{
		rdata = rsp_readl(PQC0_MEM_ADDR + 6144 * 8 + 4 * i);
		if (rdata != e203_1024_enc_ct[i])
		{
			printf("compare failed\n");
			printf(" gold0[%i] = %08x , rdata = %08x : compare faild\n", i, e203_1024_enc_ct[i], rdata);
		}
	}
	for (i = 0; i < sizeof(e203_1024_enc_ss) / sizeof(e203_1024_enc_ss[0]); i++)
	{
		rdata = rsp_readl(PQC0_MEM_ADDR + 3200 * 8 + 4 * i);
		if (rdata != e203_1024_enc_ss[i])
		{
			printf("compare failed\n");
			printf(" gold0[%i] = %08x , rdata = %08x : compare faild\n", i, e203_1024_enc_ss[i], rdata);
		}
	}

	printf("pkpu_e203_enc_1024_test  done\n");
	return 0;
}

int pkpu_e203_dec_1024_test(void)
{
	int i, rdata;
	int32_t str_ustime_cnt = 0;
	int32_t end_ustime_cnt = 0;
	int32_t cost_ustime_cnt = 0;

	
	for (i = 0; i < sizeof(e203_1024_dec_const) / sizeof(e203_1024_dec_const[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 3136 * 8 + 4 * i, e203_1024_dec_const[i]);
	}

	for (i = 0; i < sizeof(e203_1024_dec_task) / sizeof(e203_1024_dec_task[0]); i++)
	{
		rsp_writel(PQC0_TASK_ADDR + 4 * i, e203_1024_dec_task[i]);
	}
	for (i = 0; i < sizeof(e203_1024_sk) / sizeof(e203_1024_sk[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 3712 * 8 + 4 * i, e203_1024_sk[i]);
	}

	for (i = 0; i < sizeof(e203_1024_enc_ct) / sizeof(e203_1024_enc_ct[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 4160 * 8 + 4 * i, e203_1024_enc_ct[i]);
	}

	str_ustime_cnt = rsp_hal_get_us();
	for (int k = 0; k < CIRCLE_TIME; k++)
	{
		rsp_writel(PQC0_BASE_ADDR, 0);
		while (rsp_readl(PQC0_BASE_ADDR + 4) != 0x1)
			;
	}
	end_ustime_cnt = rsp_hal_get_us();
	cost_ustime_cnt = end_ustime_cnt - str_ustime_cnt;

	printf("CIRCLE_TIME = %d, us = %d, perf = %dtimes/s\n", CIRCLE_TIME, cost_ustime_cnt, 1000000 * CIRCLE_TIME / cost_ustime_cnt);
	
	for (i = 0; i < sizeof(e203_1024_enc_ss) / sizeof(e203_1024_enc_ss[0]); i++)
	{
		rdata = rsp_readl(PQC0_MEM_ADDR + 3200 * 8 + 4 * i);
		if (rdata != e203_1024_enc_ss[i])
		{
			printf("compare failed\n");
			printf(" gold0[%i] = %08x , rdata = %08x : compare faild\n", i, e203_1024_enc_ss[i], rdata);
		}
	}

	printf("pkpu_e203_dec_1024_test ALGO_FUN done\n");
	return 0;
}