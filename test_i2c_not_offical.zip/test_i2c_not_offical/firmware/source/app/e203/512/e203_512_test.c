#include <stdio.h>
#include "rsp_hal.h"
#include "e203_512_data.h"

#define CIRCLE_TIME  1

#define DUMP_MAX 64U /* 每段最多打印 64B, 防止刷屏 */

static void rsp_dump_buf(char *info, uint8_t *buf, uint32_t len)
{
    printf("%s[%d]", info, len);
    for (int i = 0; i < len; i++)
    {
        printf("%s0x%02x ", i % 16 == 0 ? "\n     " : " ", buf[i]);
    }
    printf("\n");
}

/* 输入向量打印: 最多 DUMP_MAX 字节 */
static void e203_dump_in(const char *tag, const int *buf, int words)
{
    uint32_t bytes = (uint32_t)words * 4U;

    if (bytes > DUMP_MAX)
        bytes = DUMP_MAX;
    rsp_dump_buf((char *)tag, (uint8_t *)buf, bytes);
}

/* 输出结果打印: 从 PQC0_MEM_ADDR 起读取, 最多 DUMP_MAX 字节 */
static void e203_dump_mem(const char *tag, uint32_t addr, int words)
{
    static uint32_t tmp[DUMP_MAX / 4];
    uint32_t n = (uint32_t)words;
    uint32_t i;

    if (n > DUMP_MAX / 4U)
        n = DUMP_MAX / 4U;
    for (i = 0; i < n; i++)
        tmp[i] = rsp_readl(addr + 4 * i);
    rsp_dump_buf((char *)tag, (uint8_t *)tmp, n * 4U);
}

/* 重新开关中断 */
int pkpu_e203_keygen_512_test(void)
{
	int i, rdata;
	int32_t str_ustime_cnt = 0;
	int32_t end_ustime_cnt = 0;
	int32_t cost_ustime_cnt = 0;

	printf("\n====== PKPU E203 keygen (512) ======\n");
	e203_dump_in("in seed", e203_512_keygen_seed,
	             (int)(sizeof(e203_512_keygen_seed) / sizeof(e203_512_keygen_seed[0])));
	e203_dump_in("in task", e203_512_keygen_task,
	             (int)(sizeof(e203_512_keygen_task) / sizeof(e203_512_keygen_task[0])));
	e203_dump_in("in const", e203_512_keygen_const,
	             (int)(sizeof(e203_512_keygen_const) / sizeof(e203_512_keygen_const[0])));

	for (i = 0; i < sizeof(e203_512_keygen_const) / sizeof(e203_512_keygen_const[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 4736 * 8 + 4 * i, e203_512_keygen_const[i]);
	}

	for (i = 0; i < sizeof(e203_512_keygen_task) / sizeof(e203_512_keygen_task[0]); i++)
	{
		rsp_writel(PQC0_TASK_ADDR + 4 * i, e203_512_keygen_task[i]);
	}

	for (int i = 0; i < sizeof(e203_512_keygen_seed) / sizeof(e203_512_keygen_seed[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 4 * i, e203_512_keygen_seed[i]);
	}

	str_ustime_cnt = rsp_hal_get_us();
	for (int k = 0; k < CIRCLE_TIME; k++)
	{
		rsp_writel(PQC0_BASE_ADDR, 0);
		while (rsp_readl(PQC0_BASE_ADDR + 4) != 0x1)
			;
	}
	end_ustime_cnt = rsp_hal_get_us();
	cost_ustime_cnt = end_ustime_cnt - str_ustime_cnt;

	// printf("CIRCLE_TIME = %d, us = %d, perf = %dtimes/s\n", CIRCLE_TIME, cost_ustime_cnt, 1000000 * CIRCLE_TIME / cost_ustime_cnt);

	e203_dump_mem("out pk", PQC0_MEM_ADDR + 6240 * 8,
	              (int)(sizeof(e203_512_pk) / sizeof(e203_512_pk[0])));
	e203_dump_mem("out sk", PQC0_MEM_ADDR + 6144 * 8, 1600 / (int)sizeof(e203_512_sk[0]) - 8);
	e203_dump_in("exp pk", e203_512_pk,
	             (int)(sizeof(e203_512_pk) / sizeof(e203_512_pk[0])));

	for (i = 0; i < sizeof(e203_512_pk) / sizeof(e203_512_pk[0]); i++)
	{
		rdata = rsp_readl(PQC0_MEM_ADDR + 6240 * 8 + 4 * i);

		if (rdata != e203_512_pk[i])
		{
			printf("compare failed\n");
			printf("pk gold0[%i] = %08x , rdata = %08x : compare faild\n", i, e203_512_pk[i], rdata);
		}
	}
	int temlen = 1600;
	for (i = 0; i < 1600 / sizeof(e203_512_sk[0]) - 8; i++)
	{
		rdata = rsp_readl(PQC0_MEM_ADDR + 6144 * 8 + 4 * i);
		if (rdata != e203_512_sk[i])
		{
			printf("compare failed\n");
			printf("203 sk gold0[%i] = %08x , rdata = %08x : compare faild\n", i, e203_512_sk[i], rdata);
		}
	}

	printf("pkpu_e203_keygen_512_test ALGO_FUN PASS\n");

	return 0;
}

int pkpu_e203_enc_512_test(void)
{
	int i, rdata;
	int32_t str_ustime_cnt = 0;
	int32_t end_ustime_cnt = 0;
	int32_t cost_ustime_cnt = 0;

	printf("\n====== PKPU E203 enc (512) ======\n");
	e203_dump_in("in seed", e203_512_enc_seed,
	             (int)(sizeof(e203_512_enc_seed) / sizeof(e203_512_enc_seed[0])));
	e203_dump_in("in task", e203_512_enc_task,
	             (int)(sizeof(e203_512_enc_task) / sizeof(e203_512_enc_task[0])));
	e203_dump_in("in const", e203_512_enc_const,
	             (int)(sizeof(e203_512_enc_const) / sizeof(e203_512_enc_const[0])));
	e203_dump_in("in pk", e203_512_pk,
	             (int)(sizeof(e203_512_pk) / sizeof(e203_512_pk[0])));

	for (i = 0; i < sizeof(e203_512_enc_task) / sizeof(e203_512_enc_task[0]); i++)
	{
		rsp_writel(PQC0_TASK_ADDR + 4 * i, e203_512_enc_task[i]);
	}

	for (i = 0; i < sizeof(e203_512_enc_const) / sizeof(e203_512_enc_const[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 3136 * 8 + 4 * i, e203_512_enc_const[i]);
	}

	for (i = 0; i < sizeof(e203_512_enc_seed) / sizeof(e203_512_enc_seed[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 4 * i, e203_512_enc_seed[i]);
	}

	for (i = 0; i < sizeof(e203_512_pk) / sizeof(e203_512_pk[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 3200 * 8 + 4 * i, e203_512_pk[i]);
	}

	str_ustime_cnt = rsp_hal_get_us();
	for (int k = 0; k < CIRCLE_TIME; k++)
	{
		rsp_writel(PQC0_BASE_ADDR, 0);
		while (rsp_readl(PQC0_BASE_ADDR + 4) != 0x1)
			;
	}
	end_ustime_cnt = rsp_hal_get_us();
	cost_ustime_cnt = end_ustime_cnt - str_ustime_cnt;

	// printf("CIRCLE_TIME = %d, us = %d, perf = %dtimes/s\n", CIRCLE_TIME, cost_ustime_cnt, 1000000 * CIRCLE_TIME / cost_ustime_cnt);
	
	e203_dump_mem("out ct", PQC0_MEM_ADDR + 6144 * 8,
	              (int)(sizeof(e203_512_enc_ct) / sizeof(e203_512_enc_ct[0])));
	e203_dump_mem("out ss", PQC0_MEM_ADDR + 3200 * 8,
	              (int)(sizeof(e203_512_enc_ss) / sizeof(e203_512_enc_ss[0])));
	e203_dump_in("exp ct", e203_512_enc_ct,
	             (int)(sizeof(e203_512_enc_ct) / sizeof(e203_512_enc_ct[0])));
	e203_dump_in("exp ss", e203_512_enc_ss,
	             (int)(sizeof(e203_512_enc_ss) / sizeof(e203_512_enc_ss[0])));

	for (i = 0; i < sizeof(e203_512_enc_ct) / sizeof(e203_512_enc_ct[0]); i++)
	{
		rdata = rsp_readl(PQC0_MEM_ADDR + 6144 * 8 + 4 * i);
		if (rdata != e203_512_enc_ct[i])
		{
			printf("compare failed\n");
			printf(" gold0[%i] = %08x , rdata = %08x : compare faild\n", i, e203_512_enc_ct[i], rdata);
		}
	}
	for (i = 0; i < sizeof(e203_512_enc_ss) / sizeof(e203_512_enc_ss[0]); i++)
	{
		rdata = rsp_readl(PQC0_MEM_ADDR + 3200 * 8 + 4 * i);
		if (rdata != e203_512_enc_ss[i])
		{
			printf("compare failed\n");
			printf(" gold0[%i] = %08x , rdata = %08x : compare faild\n", i, e203_512_enc_ss[i], rdata);
		}
	}

	printf("pkpu_e203_enc_512_test  PASS\n");
	return 0;
}

int pkpu_e203_dec_512_test(void)
{
	int i, rdata;
	int32_t str_ustime_cnt = 0;
	int32_t end_ustime_cnt = 0;
	int32_t cost_ustime_cnt = 0;

	printf("\n====== PKPU E203 dec (512) ======\n");
	e203_dump_in("in task", e203_512_dec_task,
	             (int)(sizeof(e203_512_dec_task) / sizeof(e203_512_dec_task[0])));
	e203_dump_in("in const", e203_512_dec_const,
	             (int)(sizeof(e203_512_dec_const) / sizeof(e203_512_dec_const[0])));
	e203_dump_in("in sk", e203_512_sk,
	             (int)(sizeof(e203_512_sk) / sizeof(e203_512_sk[0])));
	e203_dump_in("in ct", e203_512_enc_ct,
	             (int)(sizeof(e203_512_enc_ct) / sizeof(e203_512_enc_ct[0])));

	
	for (i = 0; i < sizeof(e203_512_dec_const) / sizeof(e203_512_dec_const[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 3136 * 8 + 4 * i, e203_512_dec_const[i]);
	}

	for (i = 0; i < sizeof(e203_512_dec_task) / sizeof(e203_512_dec_task[0]); i++)
	{
		rsp_writel(PQC0_TASK_ADDR + 4 * i, e203_512_dec_task[i]);
	}
	for (i = 0; i < sizeof(e203_512_sk) / sizeof(e203_512_sk[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 3712 * 8 + 4 * i, e203_512_sk[i]);
	}

	for (i = 0; i < sizeof(e203_512_enc_ct) / sizeof(e203_512_enc_ct[0]); i++)
	{
		rsp_writel(PQC0_MEM_ADDR + 4160 * 8 + 4 * i, e203_512_enc_ct[i]);
	}

	str_ustime_cnt = rsp_hal_get_us();
	for (int k = 0; k < CIRCLE_TIME; k++)
	{
		rsp_writel(PQC0_BASE_ADDR, 0);
		while (rsp_readl(PQC0_BASE_ADDR + 4) != 0x1)
			;
	}
	end_ustime_cnt = rsp_hal_get_us();
	cost_ustime_cnt = end_ustime_cnt - str_ustime_cnt;

	// printf("CIRCLE_TIME = %d, us = %d, perf = %dtimes/s\n", CIRCLE_TIME, cost_ustime_cnt, 1000000 * CIRCLE_TIME / cost_ustime_cnt);
	
	e203_dump_mem("out ss", PQC0_MEM_ADDR + 3200 * 8,
	              (int)(sizeof(e203_512_enc_ss) / sizeof(e203_512_enc_ss[0])));
	e203_dump_in("exp ss", e203_512_enc_ss,
	             (int)(sizeof(e203_512_enc_ss) / sizeof(e203_512_enc_ss[0])));

	for (i = 0; i < sizeof(e203_512_enc_ss) / sizeof(e203_512_enc_ss[0]); i++)
	{
		rdata = rsp_readl(PQC0_MEM_ADDR + 3200 * 8 + 4 * i);
		if (rdata != e203_512_enc_ss[i])
		{
			printf("compare failed\n");
			printf(" gold0[%i] = %08x , rdata = %08x : compare faild\n", i, e203_512_enc_ss[i], rdata);
		}
	}

	printf("pkpu_e203_dec_512_test ALGO_FUN PASS\n");
	return 0;
}