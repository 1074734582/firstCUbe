#include "sm3.h"
#include <stddef.h>
#include <string.h>
#define ROTL(x,y)	((((x)<<(y&(32-1))) | ((x)>>(32-(y&(32-1))))) & 0xffffffff)

void sm3_ms(uint32_t *pW, const uint32_t *pMsg)
{
    int32_t j;
	
    for (j = 0; j < 16; j++)
    {
        pW[j] = pMsg[j];
		}

    for (; j < 68; j++)
    {
        pW[j] = pW[j-16] ^ pW[j-9] ^ ROTL(pW[j-3], 15);
        pW[j] ^= (ROTL(pW[j], 15) ^ ROTL(pW[j], 23));
        pW[j] ^= ((ROTL(pW[j-13], 7) ^ pW[j-6]));
    }

    for (j = 0; j < 64; j++)
		{
        pW[68+j] = pW[j] ^ pW[j+4];
		}
}

void sm3_cf(uint32_t *pH, const uint8_t *pMsg)
{
    uint32_t A = pH[0], B = pH[1], C = pH[2], D = pH[3], E = pH[4], F = pH[5], G = pH[6], H = pH[7];
    uint32_t w[68+64];

    // w[0..67] for W
    // w[68+0 .. 68+63] for W'

    int32_t j;
    // unsigned char --> uint32_t
    uint32_t BB[16];
    for (j = 0; j < 16; j++)
    {
        BB[j] = ((uint32_t)pMsg[4*j] << 24) |
                 ((uint32_t)pMsg[4*j+1] << 16) |
                 ((uint32_t)pMsg[4*j+2] << 8) |
                 (uint32_t)pMsg[4*j+3];
		}

    sm3_ms(w, BB);

    uint32_t SS1, SS2, TT1, TT2;
    uint32_t T = 0x79CC4519;
    for (j = 0; j < 16; j++)
    {
        SS1 = (ROTL(A, 12) + E + ROTL(T, j))%0x100000000;
        SS1 = ROTL(SS1, 7);
        SS2 = SS1 ^ ROTL(A, 12);
        TT1 = (((A^B^C) + D + SS2) + w[j+68])%0x100000000;
        TT2 = (((E^F^G) + H + SS1) + w[j])%0x100000000;
        D = C;
        C = ROTL(B, 9);
        B = A;
        A = TT1;
        H = G;
        G = ROTL(F, 19);
        F = E;
        E = TT2 ^ ROTL(TT2, 9) ^ ROTL(TT2, 17);
    }

    T = 0x7A879D8A;
    for (; j < 64; j++)
    {
        SS1 = (ROTL(A, 12) + E + ROTL(T, j))%0x100000000;
        SS1 = ROTL(SS1, 7);
        SS2 = SS1 ^ ROTL(A, 12);
        TT1 = ((((A&B) | (A&C) | (B&C)) + D + SS2) + w[j+68])%0x100000000;
        TT2 = ((((E&F) | ((~E)&G)) + H + SS1) + w[j])%0x100000000;
        D = C;
        C = ROTL(B, 9);
        B = A;
        A = TT1;
        H = G;
        G = ROTL(F, 19);
        F = E;
        E = TT2 ^ ROTL(TT2, 9) ^ ROTL(TT2, 17);
    }

    pH[0] ^= A;
    pH[1] ^= B;
    pH[2] ^= C;
    pH[3] ^= D;
    pH[4] ^= E;
    pH[5] ^= F;
    pH[6] ^= G;
    pH[7] ^= H;
}

static void sm3_store_be64(uint8_t *dst, uint64_t v)
{
    dst[0] = (uint8_t)(v >> 56);
    dst[1] = (uint8_t)(v >> 48);
    dst[2] = (uint8_t)(v >> 40);
    dst[3] = (uint8_t)(v >> 32);
    dst[4] = (uint8_t)(v >> 24);
    dst[5] = (uint8_t)(v >> 16);
    dst[6] = (uint8_t)(v >> 8);
    dst[7] = (uint8_t)v;
}

uint32_t sm3_kdf(unsigned char *pKeyOut, uint32_t iLenOfOut, const unsigned char *pSecret, uint32_t iLenOfSecret, uint32_t ct)
{
    unsigned char acHashResult[SM3_HASH_256];
    struct sm3_ctx state;
    uint32_t tmp;
    uint32_t i, iRound = iLenOfOut/SM3_HASH_256;
    for (i = 0; i < iRound; i++)
    {
        sm3_init(&state, pSecret, iLenOfSecret);
        tmp = (ct << 24) | ((ct&0x0000ff00) << 8) | ((ct&0x00ff0000) >> 8) | (ct >> 24);
        sm3_update(&state, (unsigned char *)&tmp, sizeof(tmp));
        sm3_final(&state, pKeyOut + i*SM3_HASH_256);
        ct++;
    }

    if (0 != (iLenOfOut % SM3_HASH_256))
    {
        sm3_init(&state, pSecret, iLenOfSecret);
        tmp = (ct << 24) | ((ct&0x0000ff00) << 8) | ((ct&0x00ff0000) >> 8) | (ct >> 24);
        sm3_update(&state, (unsigned char *)&tmp, sizeof(tmp));
        sm3_final(&state, acHashResult);

        for (i = 0; i < iLenOfOut % SM3_HASH_256; i++)
        {
            pKeyOut[iLenOfOut - (iLenOfOut % SM3_HASH_256) + i] = acHashResult[i];
				}
        ct++;
    }

    return iLenOfOut;
}

int32_t sm3_init(struct sm3_ctx *ctx, const uint8_t *in, uint32_t inlen)
{
    uint32_t i = 0;

    ctx->h[0] = 0x7380166F;
    ctx->h[1] = 0x4914B2B9;
    ctx->h[2] = 0x172442D7;
    ctx->h[3] = 0xDA8A0600;
    ctx->h[4] = 0xA96F30BC;
    ctx->h[5] = 0x163138AA;
    ctx->h[6] = 0xE38DEE4D;
    ctx->h[7] = 0xB0FB0E4E;

    ctx->len = inlen;

    for (i = 0; i < inlen/64; i++)
    {
        sm3_cf(ctx->h, in+i*64);
    }

    for (i = 0; i < (inlen & 63); i++)
    {
        ctx->bb[i] = in[(inlen&0xffffffc0)+i];
    }

    return 0;
}

int32_t sm3_update(struct sm3_ctx *ctx, const uint8_t *in, uint32_t inlen)
{
    uint32_t i, iCurPos = (uint32_t)(ctx->len % 64);
    uint32_t iMin = (64-iCurPos < inlen) ? (64-iCurPos) : (inlen);

    for (i = 0; i < iMin; i++)
    {
        ctx->bb[i+iCurPos] = in[i];
    }
	
    ctx->len += inlen;

    if (inlen >= 64-iCurPos)
    {
        sm3_cf(ctx->h, ctx->bb);

        inlen -= (64-iCurPos);
        in += (64-iCurPos);
        for (i = 0; i < inlen/64; i++)
        {
            sm3_cf(ctx->h, in+i*64);
        }

        for (i = 0; i < (inlen & 63); i++)
        {
            ctx->bb[i] = in[(inlen&0xffffffc0)+i];
        }
    }

    return 0;
}

int32_t sm3_final(struct sm3_ctx *ctx, uint8_t *hash)
{
    uint32_t i;
    uint8_t bb[128];

    for (i = 0; i < sizeof(bb); i++)
    {
        bb[i] = 0x00;
    }

    for (i = 0; i < (ctx->len & 63); i++)
    {
        bb[i] = ctx->bb[i];
    }

    uint64_t bitlen = ctx->len << 3;

    if ((ctx->len & 63) < 56)
    {
        // 1 block
        bb[i] = 0x80;

        // BB[56 .. 63]
        sm3_store_be64(bb + 56, bitlen);

        sm3_cf(ctx->h, bb);
    }
    else
    {
        // 2 block
        bb[i] = 0x80;
        sm3_cf(ctx->h, bb);

        // BB[120 .. 127]
        sm3_store_be64(bb + 120, bitlen);

        sm3_cf(ctx->h, bb+64);
    }

    for (i = 0; i < 8; i++)
    {
		    hash[i*4] = (unsigned char)(ctx->h[i] >> 24);
		    hash[i*4+1] = (unsigned char)(ctx->h[i] >> 16);
		    hash[i*4+2] = (unsigned char)(ctx->h[i] >> 8);
		    hash[i*4+3] = (unsigned char)(ctx->h[i]);
    }

    return 0;
}

int32_t sm3(const uint8_t *in, uint32_t inlen, uint8_t *hash)
{
    uint32_t i;

    uint32_t H[8] =
    {
        0x7380166F,
        0x4914B2B9,
        0x172442D7,
        0xDA8A0600,
        0xA96F30BC,
        0x163138AA,
        0xE38DEE4D,
        0xB0FB0E4E,
    };

    for (i = 0; i < inlen/64; i++)
    {
        sm3_cf(H, in+i*64);
    }

    unsigned char BB2[128];
    for (i = 0; i < sizeof(BB2); i++)
		{
        BB2[i] = 0x00;
		}

    for (i = 0; i < (inlen & 63); i++)
    {
        BB2[i] = in[(inlen&0xffffffc0)+i];
    }

    // in bytes ==> in bits
    uint64_t bitlen = (uint64_t)inlen << 3;

    if ((inlen & 63) < 56)
    {
        // 1 block
        BB2[i] = 0x80;

        // BB[56 .. 63]
        sm3_store_be64(BB2 + 56, bitlen);

        sm3_cf(H, BB2);
    }
    else
    {
        // 2 block
        BB2[i] = 0x80;
        sm3_cf(H, BB2);

        // BB[120 .. 127]
        sm3_store_be64(BB2 + 120, bitlen);

        sm3_cf(H, BB2+64);
    }

    for (i = 0; i < 8; i++)
    {
        hash[i*4] = (unsigned char)(H[i] >> 24);
        hash[i*4+1] = (unsigned char)(H[i] >> 16);
        hash[i*4+2] = (unsigned char)(H[i] >> 8);
        hash[i*4+3] = (unsigned char)H[i];
    }

    return 0;
}


int32_t sm3_hmac(const uint8_t *pKey, uint32_t keyByteLen, const uint8_t *pMsg, uint32_t msgByteLen, uint8_t *pOutHmac)
{
/*
 * HMAC-SM3 输出固定为 32 字节（SM3 摘要长度）
 * 块大小 B = 64 字节（SM3 分组长度）
 */
#define HMAC_SM3_BLOCK_LEN 64U
#define HMAC_SM3_DIGEST_LEN 32U

    /*
     * 输出指针不能为空
     */
    if (pOutHmac == NULL)
    {
        return -1;
    }

    /*
     * 允许空密钥、空消息：
     *
     *   pKey == NULL && keyByteLen == 0
     *   pMsg == NULL && msgByteLen == 0
     *
     * 但 NULL 指针搭配非 0 长度非法。
     */
    if ((pKey == NULL) && (keyByteLen != 0))
    {
        return -1;
    }
    if ((pMsg == NULL) && (msgByteLen != 0))
    {
        return -1;
    }

    /*
     * Step 1: 密钥预处理得到 K0（64 字节）
     *
     *   - keyByteLen > 64 : K0 = SM3(key) 后面补 0 到 64 字节
     *   - keyByteLen <= 64: K0 = key 后面补 0 到 64 字节
     */
    uint8_t k0[HMAC_SM3_BLOCK_LEN];
    memset(k0, 0, sizeof(k0));

    if (keyByteLen > HMAC_SM3_BLOCK_LEN)
    {
        if (sm3(pKey, keyByteLen, k0) != 0)
        {
            return -1;
        }
        /* sm3() 写入前 32 字节，后 32 字节保持 0 */
    }
    else if (keyByteLen > 0U)
    {
        memcpy(k0, pKey, keyByteLen);
    }

    /*
     * Step 2: 生成 ipad / opad
     *   ipad = K0 XOR 0x36
     *   opad = K0 XOR 0x5C
     */
    uint8_t ipad[HMAC_SM3_BLOCK_LEN];
    uint8_t opad[HMAC_SM3_BLOCK_LEN];
    for (uint32_t i = 0; i < HMAC_SM3_BLOCK_LEN; i++)
    {
        ipad[i] = (uint8_t)(k0[i] ^ 0x36U);
        opad[i] = (uint8_t)(k0[i] ^ 0x5CU);
    }

    /*
     * Step 3: 内层哈希  inner = SM3(ipad || msg)
     * 用流式 API：init -> update(ipad) -> update(msg) -> final
     */
    uint8_t inner[HMAC_SM3_DIGEST_LEN];
    sm3_ctx_t ctx;

    if (sm3_init(&ctx, NULL, 0) != 0)
    {
        return -1;
    }
    if (sm3_update(&ctx, ipad, HMAC_SM3_BLOCK_LEN) != 0)
    {
        return -1;
    }
    if (msgByteLen > 0U)
    {
        if (sm3_update(&ctx, pMsg, msgByteLen) != 0)
        {
            return -1;
        }
    }
    if (sm3_final(&ctx, inner) != 0)
    {
        return -1;
    }

    /*
     * Step 4: 外层哈希  HMAC = SM3(opad || inner)
     */
    if (sm3_init(&ctx, NULL, 0) != 0)
    {
        return -1;
    }
    if (sm3_update(&ctx, opad, HMAC_SM3_BLOCK_LEN) != 0)
    {
        return -1;
    }
    if (sm3_update(&ctx, inner, HMAC_SM3_DIGEST_LEN) != 0)
    {
        return -1;
    }
    if (sm3_final(&ctx, pOutHmac) != 0)
    {
        return -1;
    }

    return 0;
}


