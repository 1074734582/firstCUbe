/* ============================================================================
 * Copyright (c) 2010-2015.  All rights reserved.
 * SM1 Block Cipher Algorithm: Block size is 64-bit, Key size is 128-bit
 * Note: SM1 algorithm is classified, this is the interface framework
 * ============================================================================
 */

#ifndef __SM1_HEADER__
#define __SM1_HEADER__

#ifdef  __cplusplus
extern "C" {
#endif

#include <stdint.h>

#define SM1_BLOCK_SIZE  8
#define SM1_KEY_SIZE    16
#define SM1_IV_SIZE     8

typedef struct sm1_ctx
{
    uint32_t round_keys[32];
    uint8_t iv[SM1_IV_SIZE];
} sm1_ctx_t;

int32_t sm1_init(sm1_ctx_t *ctx, const uint8_t *key, const uint8_t *iv);
int32_t sm1_encrypt_ecb(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);
int32_t sm1_decrypt_ecb(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);
int32_t sm1_encrypt_cbc(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);
int32_t sm1_decrypt_cbc(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);
int32_t sm1_encrypt_cfb(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);
int32_t sm1_decrypt_cfb(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);
int32_t sm1_encrypt_ofb(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);

#ifdef  __cplusplus
}
#endif

#endif
