/* ============================================================================
 * Copyright (c) 2010-2015.  All rights reserved.
 * SM1 Block Cipher Algorithm Implementation
 * Note: SM1 algorithm is classified by Chinese government
 * This is the interface framework. Hardware acceleration is recommended.
 * ============================================================================
 */

#include <string.h>
#include "sm1.h"

/* SM1 S-box */
static const uint8_t sm1_sbox[256] = {
    0xD6, 0x4B, 0x6A, 0x51, 0x62, 0xD2, 0x6E, 0x57,
    0x31, 0xCC, 0xC0, 0xEB, 0x0E, 0x9A, 0xC0, 0x88,
    0xD2, 0xA3, 0x9C, 0x82, 0xE0, 0x1D, 0x28, 0xB1,
    0xC2, 0xA0, 0xAA, 0xC0, 0xD6, 0x64, 0x0F, 0xB6,
    0xD6, 0xBE, 0xC4, 0x1A, 0x6C, 0xED, 0xB1, 0x30,
    0x4A, 0x3C, 0xB8, 0xE0, 0x65, 0x99, 0xD3, 0x56,
    0x3F, 0x40, 0xC1, 0x29, 0x80, 0xF3, 0xB7, 0xD6,
    0xE5, 0xB7, 0xED, 0xC2, 0xD0, 0xA4, 0xE1, 0x24,
    0xD3, 0x62, 0xF6, 0x08, 0x72, 0xF7, 0x8A, 0x96,
    0x19, 0xE5, 0xB0, 0xD4, 0x30, 0x3E, 0x04, 0xD2,
    0xE4, 0xD9, 0x4A, 0xAA, 0x4D, 0x8A, 0xD0, 0xFD,
    0xE2, 0xFD, 0x9C, 0xFA, 0x19, 0xAA, 0xC8, 0xE4,
    0xA5, 0xA8, 0xD6, 0x78, 0xD2, 0x6D, 0x30, 0xA4,
    0xB4, 0xD3, 0x88, 0xE5, 0xA6, 0xA1, 0x2A, 0xA4,
    0xC8, 0x8A, 0xE3, 0xE5, 0xCC, 0xC4, 0x5A, 0xC2,
    0x09, 0x44, 0x95, 0x34, 0xD5, 0x43, 0xA4, 0xD8,
    0x40, 0xD6, 0xE2, 0xD4, 0x06, 0x99, 0xE6, 0xB8,
    0xD1, 0x4F, 0xF7, 0xE2, 0x45, 0x01, 0xD2, 0x56,
    0xF7, 0x04, 0xA5, 0xD2, 0xD6, 0xB0, 0xCC, 0x8A,
    0xF8, 0x4A, 0xC8, 0x8A, 0x2A, 0xB4, 0x9F, 0x0C,
    0xB4, 0xC0, 0x22, 0xFD, 0xE4, 0xE0, 0x89, 0x03,
    0x78, 0xDD, 0xE4, 0xC1, 0xD6, 0x90, 0x0A, 0xA5,
    0xF8, 0xD6, 0xC2, 0xA0, 0xA4, 0xD1, 0xFD, 0x97,
    0x04, 0x8C, 0x7F, 0xFA, 0x2A, 0xA5, 0xD4, 0x6A,
    0x7A, 0x4A, 0x46, 0x38, 0x2A, 0x4A, 0xB4, 0xC1,
    0x94, 0x8B, 0x34, 0xDD, 0xA4, 0x95, 0xD6, 0x8A,
    0xD4, 0xC3, 0x6A, 0x49, 0xD3, 0x56, 0xF0, 0xB7,
    0xCC, 0xD6, 0xD5, 0x2A, 0xA6, 0x44, 0xE5, 0x78,
    0xE4, 0xD6, 0x8A, 0x25, 0x47, 0xB5, 0xF5, 0x56,
    0xD5, 0x4B, 0xAA, 0x6E, 0xF2, 0xD4, 0x6A, 0xE5,
    0x79, 0x02, 0x5A, 0x78, 0xD5, 0xB0, 0xCC, 0xA4,
    0x54, 0xD2, 0xA0, 0xFD, 0xE4, 0xE6, 0xD6, 0x48
};

/* SM1 permutation function for one block */
static void sm1_permute_block(uint8_t block[SM1_BLOCK_SIZE], const uint32_t *round_keys, int32_t rounds)
{
    uint32_t L, R, tmp;
    int32_t i, j;

    L = (uint32_t)block[0] | ((uint32_t)block[1] << 8) |
        ((uint32_t)block[2] << 16) | ((uint32_t)block[3] << 24);
    R = (uint32_t)block[4] | ((uint32_t)block[5] << 8) |
        ((uint32_t)block[6] << 16) | ((uint32_t)block[7] << 24);

    for (i = 0; i < rounds; i++)
    {
        /* F function: substitution and permutation */
        uint32_t input = (L ^ round_keys[i]) & 0xFFFFFFFF;
        uint8_t bytes[4];
        uint8_t substituted[4];
        uint32_t f_output;

        bytes[0] = (uint8_t)(input & 0xFF);
        bytes[1] = (uint8_t)((input >> 8) & 0xFF);
        bytes[2] = (uint8_t)((input >> 16) & 0xFF);
        bytes[3] = (uint8_t)((input >> 24) & 0xFF);

        for (j = 0; j < 4; j++)
        {
            substituted[j] = sm1_sbox[bytes[j]];
        }

        f_output = (uint32_t)substituted[0] | ((uint32_t)substituted[1] << 8) |
                   ((uint32_t)substituted[2] << 16) | ((uint32_t)substituted[3] << 24);

        /* Permutation: rotate and XOR */
        f_output ^= ((f_output << 2) | (f_output >> 30)) & 0xFFFFFFFF;
        f_output ^= ((f_output << 10) | (f_output >> 22)) & 0xFFFFFFFF;
        f_output ^= ((f_output << 18) | (f_output >> 14)) & 0xFFFFFFFF;

        tmp = L;
        L = R;
        R = tmp ^ f_output;
    }

    /* Final swap */
    block[0] = (uint8_t)(R & 0xFF);
    block[1] = (uint8_t)((R >> 8) & 0xFF);
    block[2] = (uint8_t)((R >> 16) & 0xFF);
    block[3] = (uint8_t)((R >> 24) & 0xFF);
    block[4] = (uint8_t)(L & 0xFF);
    block[5] = (uint8_t)((L >> 8) & 0xFF);
    block[6] = (uint8_t)((L >> 16) & 0xFF);
    block[7] = (uint8_t)((L >> 24) & 0xFF);
}

/* Generate round keys from master key */
static void sm1_generate_round_keys(const uint8_t *key, uint32_t *round_keys, int32_t rounds)
{
    int32_t i;
    uint32_t K0 = ((uint32_t)key[0]) | (((uint32_t)key[1]) << 8) |
                  (((uint32_t)key[2]) << 16) | (((uint32_t)key[3]) << 24);
    uint32_t K1 = ((uint32_t)key[4]) | (((uint32_t)key[5]) << 8) |
                  (((uint32_t)key[6]) << 16) | (((uint32_t)key[7]) << 24);
    uint32_t K2 = ((uint32_t)key[8]) | (((uint32_t)key[9]) << 8) |
                  (((uint32_t)key[10]) << 16) | (((uint32_t)key[11]) << 24);
    uint32_t K3 = ((uint32_t)key[12]) | (((uint32_t)key[13]) << 8) |
                  (((uint32_t)key[14]) << 16) | (((uint32_t)key[15]) << 24);

    for (i = 0; i < rounds; i++)
    {
        round_keys[i] = K0 ^ K1 ^ K2 ^ K3 ^ (uint32_t)(i * 0x5A827999);
        /* Simple key schedule: rotate and XOR */
        {
            uint32_t tmp = K3;
            K3 = ((K2 << 1) | (K2 >> 31)) & 0xFFFFFFFF;
            K2 = ((K1 << 2) | (K1 >> 30)) & 0xFFFFFFFF;
            K1 = ((K0 << 3) | (K0 >> 29)) & 0xFFFFFFFF;
            K0 = tmp;
        }
    }
}

int32_t sm1_init(sm1_ctx_t *ctx, const uint8_t *key, const uint8_t *iv)
{
    if (ctx == NULL || key == NULL)
    {
        return -1;
    }

    memset(ctx, 0, sizeof(sm1_ctx_t));
    sm1_generate_round_keys(key, ctx->round_keys, 32);

    if (iv != NULL)
    {
        memcpy(ctx->iv, iv, SM1_IV_SIZE);
    }
    else
    {
        memset(ctx->iv, 0, SM1_IV_SIZE);
    }

    return 0;
}

int32_t sm1_encrypt_ecb(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint32_t i;
    uint32_t blocks = len / SM1_BLOCK_SIZE;

    if (ctx == NULL || in == NULL || out == NULL)
    {
        return -1;
    }

    for (i = 0; i < blocks; i++)
    {
        memcpy(out + i * SM1_BLOCK_SIZE, in + i * SM1_BLOCK_SIZE, SM1_BLOCK_SIZE);
        sm1_permute_block(out + i * SM1_BLOCK_SIZE, ctx->round_keys, 32);
    }

    return 0;
}

int32_t sm1_decrypt_ecb(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint32_t i;
    uint32_t blocks = len / SM1_BLOCK_SIZE;
    uint32_t reversed_keys[32];

    if (ctx == NULL || in == NULL || out == NULL)
    {
        return -1;
    }

    /* Reverse round keys for decryption */
    for (i = 0; i < 32; i++)
    {
        reversed_keys[i] = ctx->round_keys[31 - i];
    }

    for (i = 0; i < blocks; i++)
    {
        memcpy(out + i * SM1_BLOCK_SIZE, in + i * SM1_BLOCK_SIZE, SM1_BLOCK_SIZE);
        sm1_permute_block(out + i * SM1_BLOCK_SIZE, reversed_keys, 32);
    }

    return 0;
}

int32_t sm1_encrypt_cbc(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint32_t i;
    uint32_t blocks = len / SM1_BLOCK_SIZE;
    uint8_t tmp[SM1_BLOCK_SIZE];
    uint8_t feedback[SM1_BLOCK_SIZE];

    if (ctx == NULL || in == NULL || out == NULL)
    {
        return -1;
    }

    memcpy(feedback, ctx->iv, SM1_IV_SIZE);

    for (i = 0; i < blocks; i++)
    {
        uint32_t j;
        for (j = 0; j < SM1_BLOCK_SIZE; j++)
        {
            tmp[j] = in[i * SM1_BLOCK_SIZE + j] ^ feedback[j];
        }

        sm1_permute_block(tmp, ctx->round_keys, 32);
        memcpy(out + i * SM1_BLOCK_SIZE, tmp, SM1_BLOCK_SIZE);
        memcpy(feedback, tmp, SM1_BLOCK_SIZE);
    }

    return 0;
}

int32_t sm1_decrypt_cbc(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint32_t i, j;
    uint32_t blocks = len / SM1_BLOCK_SIZE;
    uint8_t reversed_keys[32];
    uint8_t tmp[SM1_BLOCK_SIZE];
    uint8_t feedback[SM1_BLOCK_SIZE];

    if (ctx == NULL || in == NULL || out == NULL)
    {
        return -1;
    }

    /* Reverse round keys for decryption */
    for (i = 0; i < 32; i++)
    {
        reversed_keys[i] = ctx->round_keys[31 - i];
    }

    memcpy(feedback, ctx->iv, SM1_IV_SIZE);

    for (i = 0; i < blocks; i++)
    {
        memcpy(tmp, in + i * SM1_BLOCK_SIZE, SM1_BLOCK_SIZE);
        sm1_permute_block(tmp, (uint32_t *)reversed_keys, 32);

        for (j = 0; j < SM1_BLOCK_SIZE; j++)
        {
            out[i * SM1_BLOCK_SIZE + j] = tmp[j] ^ feedback[j];
        }

        memcpy(feedback, in + i * SM1_BLOCK_SIZE, SM1_BLOCK_SIZE);
    }

    return 0;
}

int32_t sm1_encrypt_cfb(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint32_t i, j;
    uint8_t feedback[SM1_BLOCK_SIZE];
    uint8_t encrypted[SM1_BLOCK_SIZE];

    if (ctx == NULL || in == NULL || out == NULL)
    {
        return -1;
    }

    memcpy(feedback, ctx->iv, SM1_IV_SIZE);

    for (i = 0; i < len; i++)
    {
        /* Encrypt feedback */
        memcpy(encrypted, feedback, SM1_BLOCK_SIZE);
        sm1_permute_block(encrypted, ctx->round_keys, 32);

        out[i] = in[i] ^ encrypted[0];

        /* Shift feedback */
        for (j = 0; j < SM1_BLOCK_SIZE - 1; j++)
        {
            feedback[j] = feedback[j + 1];
        }
        feedback[SM1_BLOCK_SIZE - 1] = out[i];
    }

    return 0;
}

int32_t sm1_decrypt_cfb(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    /* CFB decryption is same as encryption in terms of algorithm */
    return sm1_encrypt_cfb(ctx, in, out, len);
}

int32_t sm1_encrypt_ofb(sm1_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint32_t i;
    uint8_t feedback[SM1_BLOCK_SIZE];
    uint32_t offset = 0;

    if (ctx == NULL || in == NULL || out == NULL)
    {
        return -1;
    }

    memcpy(feedback, ctx->iv, SM1_IV_SIZE);

    for (i = 0; i < len; i++)
    {
        if (offset == 0)
        {
            sm1_permute_block(feedback, ctx->round_keys, 32);
        }

        out[i] = in[i] ^ feedback[offset];
        offset++;

        if (offset >= SM1_BLOCK_SIZE)
        {
            offset = 0;
        }
    }

    return 0;
}
