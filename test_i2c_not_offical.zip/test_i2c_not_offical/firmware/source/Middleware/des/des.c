/*
 * Phil Karn KA9Q DES386 (Public Domain)
 * Source base: desport.c + deskey.c from skissane/des386
 * Merge + add ECB/CBC/3DES wrapper for performance test
 * Adapted for 7680 Bytes throughput benchmark
 */
#include "des.h"
#include <string.h>

/* 原始des386 置换表 S盒，完全保留原版常量 */
static const uint8_t pc1[56] = {
    57,49,41,33,25,17,9,1,58,50,42,34,26,18,
    10,2,59,51,43,35,27,19,11,3,60,52,44,36,
    63,55,47,39,31,23,15,7,62,54,46,38,30,22,
    14,6,61,53,45,37,29,21,13,5,28,20,12,4
};

static const uint8_t pc2[48] = {
    14,17,11,24,1,5,3,28,15,6,21,10,
    23,19,12,4,26,8,16,7,27,20,13,2,
    41,52,31,37,47,55,30,40,51,45,33,48,
    44,49,39,56,34,53,46,42,50,36,29,32
};

static const uint8_t shift_tab[16] = {1,1,2,2,2,2,2,2,1,2,2,2,2,2,2,1};

static const uint8_t ip[64] = {
    58,50,42,34,26,18,10,2,60,52,44,36,28,20,12,4,
    62,54,46,38,30,22,14,6,64,56,48,40,32,24,16,8,
    57,49,41,33,25,17,9,1,59,51,43,35,27,19,11,3,
    61,53,45,37,29,21,13,5,63,55,47,39,31,23,15,7
};

static const uint8_t ipinv[64] = {
    40,8,48,16,56,24,64,32,39,7,47,15,55,23,63,31,
    38,6,46,14,54,22,62,30,37,5,45,13,53,21,61,29,
    36,4,44,12,52,20,60,28,35,3,43,11,51,19,59,27,
    34,2,42,10,50,18,58,26,33,1,41,9,49,17,57,25
};

static const uint8_t e[48] = {
    32,1,2,3,4,5,4,5,6,7,8,9,
    8,9,10,11,12,13,12,13,14,15,16,17,
    16,17,18,19,20,21,20,21,22,23,24,25,
    24,25,26,27,28,29,28,29,30,31,32,1
};

static const uint8_t p[32] = {
    16,7,20,21,29,12,28,17,1,15,23,26,5,18,31,10,
    2,8,24,14,32,27,3,9,19,13,30,6,22,11,4,25
};

static const uint8_t s[8][64] = {
    {14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7,
     0,15,7,4,14,2,13,1,10,6,12,11,9,5,3,8,
     4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0,
     15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13},
    {15,1,8,14,6,11,3,4,9,7,2,13,12,0,5,10,
     3,13,4,7,15,2,8,14,12,0,1,10,6,9,11,5,
     0,14,7,11,10,4,13,1,5,8,12,6,9,3,2,15,
     13,8,10,1,3,15,4,2,11,6,7,12,0,5,14,9},
    {10,0,9,14,6,3,15,5,1,13,12,7,11,4,2,8,
     13,7,0,9,3,4,6,10,2,8,5,14,12,11,15,1,
     13,6,4,9,8,15,3,0,11,1,2,12,5,10,14,7,
     1,10,13,0,6,9,8,7,4,15,14,3,11,5,2,12},
    {7,13,14,3,0,6,9,10,1,2,8,5,11,12,4,15,
     13,8,11,5,6,15,0,3,4,7,2,12,1,10,14,9,
     10,6,9,0,12,11,7,13,15,1,3,14,5,2,8,4,
     3,15,0,6,10,1,13,8,9,4,5,11,12,7,2,14},
    {2,12,4,1,7,10,11,6,8,5,3,15,13,0,14,9,
     14,11,2,12,4,7,13,1,5,0,15,10,3,9,8,6,
     4,2,1,11,10,13,7,8,15,9,12,5,6,3,0,14,
     11,8,12,7,1,14,2,13,6,15,0,9,10,4,5,3},
    {12,1,10,15,9,2,6,8,0,13,3,4,14,7,5,11,
     10,15,4,2,7,12,9,5,6,1,13,14,0,11,3,8,
     9,14,15,5,2,8,12,3,7,0,4,10,1,13,11,6,
     4,3,2,12,9,5,15,10,11,14,1,7,6,0,8,13},
    {4,11,2,14,15,0,8,13,3,12,9,7,5,10,6,1,
     13,0,11,7,4,9,1,10,14,3,5,12,2,15,8,6,
     1,4,11,13,12,3,7,14,10,15,6,8,0,5,9,2,
     6,11,13,8,1,4,10,7,9,5,0,15,14,2,3,12},
    {13,2,8,4,6,15,11,1,10,9,3,14,5,0,12,7,
     1,15,13,8,10,3,7,4,12,5,6,11,0,14,9,2,
     7,11,4,1,9,12,14,2,0,6,10,13,15,3,5,8,
     2,1,14,7,4,10,8,13,15,12,9,0,3,5,6,11}
};

static uint32_t getbits(const uint8_t *buf, int start, int count)
{
    uint32_t val = 0;
    int i;
    for (i = start; i < start + count; i++) {
        int bit = i - 1;
        int byte = bit / 8;
        int bitinbyte = 7 - (bit % 8);
        val = (val << 1) | ((buf[byte] >> bitinbyte) & 1);
    }
    return val;
}

static void putbits(uint8_t *buf, int start, int count, uint32_t val)
{
    int i;
    for (i = start + count - 1; i >= start; i--) {
        int bit = i - 1;
        int byte = bit / 8;
        int bitinbyte = 7 - (bit % 8);
        if (val & 1)
            buf[byte] |= (1U << bitinbyte);
        else
            buf[byte] &= ~(1U << bitinbyte);
        val >>= 1;
    }
}

static void permute(const uint8_t *in, uint8_t *out, const uint8_t *table, int nbits)
{
    memset(out, 0, 8);
    for (int i = 0; i < nbits; i++) {
        uint32_t b = getbits(in, table[i], 1);
        putbits(out, i+1, 1, b);
    }
}

/* ====== 原版deskey.c 密钥扩展 ====== */
void des_key(const uint8_t *key, des_key_schedule *ks)
{
    uint8_t buf[8];
    uint32_t cc, dd;
    int round;

    permute(key, buf, pc1, 56);
    /* PC1 输出 56bit: C = bit1..28, D = bit29..56 */
    cc = getbits(buf, 1, 28);
    dd = getbits(buf, 29, 28);

    for (round = 0; round < 16; round++) {
        int shift = shift_tab[round];
        uint8_t cd[8] = {0};
        uint8_t subkey[8] = {0};

        cc = ((cc << shift) | (cc >> (28 - shift))) & 0x0FFFFFFFU;
        dd = ((dd << shift) | (dd >> (28 - shift))) & 0x0FFFFFFFU;

        putbits(cd, 1, 28, cc);
        putbits(cd, 29, 28, dd);

        permute(cd, subkey, pc2, 48);
        ks->subkeys[round*2]   = getbits(subkey, 1, 24);
        ks->subkeys[round*2+1] = getbits(subkey, 25, 24);
    }
}

/* ====== 原版desport.c 单分组加解密 ====== */
void des_encrypt(const uint8_t *plain, uint8_t *cipher, const des_key_schedule *ks)
{
    uint8_t buf[8];
    permute(plain, buf, ip, 64);
    uint32_t L = getbits(buf, 1, 32);
    uint32_t R = getbits(buf, 33, 32);

    for (int i = 0; i < 16; i++) {
        uint64_t E = 0;
        for (int j = 0; j < 48; j++) {
            int bitpos = e[j];
            int srcbit;
            if (bitpos <= 32)
                srcbit = (R >> (32 - bitpos)) & 1;
            else
                srcbit = (R >> (32 - (bitpos - 32))) & 1;
            E = (E << 1) | (uint64_t)srcbit;
        }
        E ^= (((uint64_t)ks->subkeys[i*2] << 24) | (uint64_t)ks->subkeys[i*2+1]);

        uint8_t s_out[8] = {0};
        for (int sidx = 0; sidx < 8; sidx++) {
            uint8_t six = (uint8_t)((E >> (42 - sidx*6)) & 0x3F);
            /* S 盒行号 = b1b6 = 2*b1 + b6 (b1 为最高位) */
            uint8_t row = (((six >> 4) & 0x2) | (six & 0x1));
            uint8_t col = (six >> 1) & 0x0F;
            uint8_t sval = s[sidx][row*16 + col];
            putbits(s_out, sidx*4+1, 4, sval);
        }
        uint32_t f = 0;
        for(int j=0;j<32;j++){
            uint32_t b = getbits(s_out, p[j],1);
            f = (f << 1) | b;
        }
        uint32_t tmp = R;
        R = L ^ f;
        L = tmp;
    }
    uint8_t pre[8] = {0};
    putbits(pre,1,32,R);
    putbits(pre,33,32,L);
    permute(pre, cipher, ipinv, 64);
}

void des_decrypt(const uint8_t *cipher, uint8_t *plain, const des_key_schedule *ks)
{
    uint8_t buf[8];
    permute(cipher, buf, ip, 64);
    uint32_t L = getbits(buf, 1, 32);
    uint32_t R = getbits(buf, 33, 32);

    for (int i = 15; i >= 0; i--) {
        uint64_t E = 0;
        for (int j = 0; j < 48; j++) {
            int bitpos = e[j];
            int srcbit;
            if (bitpos <= 32)
                srcbit = (R >> (32 - bitpos)) & 1;
            else
                srcbit = (R >> (32 - (bitpos - 32))) & 1;
            E = (E << 1) | (uint64_t)srcbit;
        }
        E ^= (((uint64_t)ks->subkeys[i*2] << 24) | (uint64_t)ks->subkeys[i*2+1]);

        uint8_t s_out[8] = {0};
        for (int sidx = 0; sidx < 8; sidx++) {
            uint8_t six = (uint8_t)((E >> (42 - sidx*6)) & 0x3F);
            /* S 盒行号 = b1b6 = 2*b1 + b6 (b1 为最高位) */
            uint8_t row = (((six >> 4) & 0x2) | (six & 0x1));
            uint8_t col = (six >> 1) & 0x0F;
            uint8_t sval = s[sidx][row*16 + col];
            putbits(s_out, sidx*4+1, 4, sval);
        }
        uint32_t f = 0;
        for(int j=0;j<32;j++){
            uint32_t b = getbits(s_out, p[j],1);
            f = (f << 1) | b;
        }
        uint32_t tmp = R;
        R = L ^ f;
        L = tmp;
    }
    uint8_t pre[8] = {0};
    putbits(pre,1,32,R);
    putbits(pre,33,32,L);
    permute(pre, plain, ipinv, 64);
}

/* ====================== ECB批量封装 ====================== */
int des_ecb_encrypt(const uint8_t *in, uint8_t *out, size_t len, const des_key_schedule *ks)
{
    if(len % DES_BLOCK_SIZE != 0) return -1;
    for(size_t offset=0; offset < len; offset += DES_BLOCK_SIZE){
        des_encrypt(in + offset, out + offset, ks);
    }
    return 0;
}
int des_ecb_decrypt(const uint8_t *in, uint8_t *out, size_t len, const des_key_schedule *ks)
{
    if(len % DES_BLOCK_SIZE != 0) return -1;
    for(size_t offset=0; offset < len; offset += DES_BLOCK_SIZE){
        des_decrypt(in + offset, out + offset, ks);
    }
    return 0;
}

/* ====================== CBC批量封装 ====================== */
int des_cbc_encrypt(const uint8_t *in, uint8_t *out, size_t len,
                    const uint8_t *iv, const des_key_schedule *ks)
{
    if(len % DES_BLOCK_SIZE != 0) return -1;
    uint8_t prev[8];
    memcpy(prev, iv, 8);
    for(size_t offset=0; offset < len; offset += 8){
        uint8_t tmp[8];
        for(int i=0;i<8;i++) tmp[i] = in[offset+i] ^ prev[i];
        des_encrypt(tmp, out + offset, ks);
        memcpy(prev, out + offset, 8);
    }
    return 0;
}

int des_cbc_decrypt(const uint8_t *in, uint8_t *out, size_t len,
                    const uint8_t *iv, const des_key_schedule *ks)
{
    if(len % DES_BLOCK_SIZE != 0) return -1;
    uint8_t prev[8];
    memcpy(prev, iv, 8);
    for(size_t offset=0; offset < len; offset += 8){
        uint8_t tmp[8];
        des_decrypt(in + offset, tmp, ks);
        for(int i=0;i<8;i++) tmp[i] ^= prev[i];
        memcpy(out + offset, tmp, 8);
        memcpy(prev, in + offset, 8);
    }
    return 0;
}

/* ====================== 3DES-EDE 封装 ====================== */
void tdes_key(const uint8_t *key, size_t key_len,
              des_key_schedule *ks1, des_key_schedule *ks2, des_key_schedule *ks3)
{
    des_key(key, ks1);
    des_key(key + 8, ks2);
    if(key_len == TRIPLE_DES_KEY_192){
        des_key(key + 16, ks3);
    } else {
        memcpy(ks3, ks1, sizeof(des_key_schedule));
    }
}

void tdes_encrypt_block(const uint8_t *in, uint8_t *out,
                        const des_key_schedule *ks1, const des_key_schedule *ks2, const des_key_schedule *ks3)
{
    uint8_t tmp[8];
    des_encrypt(in, tmp, ks1);
    des_decrypt(tmp, tmp, ks2);
    des_encrypt(tmp, out, ks3);
}

void tdes_decrypt_block(const uint8_t *in, uint8_t *out,
                        const des_key_schedule *ks1, const des_key_schedule *ks2, const des_key_schedule *ks3)
{
    uint8_t tmp[8];
    des_decrypt(in, tmp, ks3);
    des_encrypt(tmp, tmp, ks2);
    des_decrypt(tmp, out, ks1);
}

int tdes_ecb_encrypt(const uint8_t *in, uint8_t *out, size_t len,
                     const des_key_schedule *ks1, const des_key_schedule *ks2, const des_key_schedule *ks3)
{
    if(len % DES_BLOCK_SIZE != 0) return -1;
    for(size_t offset=0; offset < len; offset +=8){
        tdes_encrypt_block(in+offset, out+offset, ks1, ks2, ks3);
    }
    return 0;
}

int tdes_cbc_encrypt(const uint8_t *in, uint8_t *out, size_t len, const uint8_t *iv,
                     const des_key_schedule *ks1, const des_key_schedule *ks2, const des_key_schedule *ks3)
{
    if(len % DES_BLOCK_SIZE !=0) return -1;
    uint8_t prev[8];
    memcpy(prev, iv,8);
    for(size_t offset=0; offset < len; offset +=8){
        uint8_t tmp[8];
        for(int i=0;i<8;i++) tmp[i] = in[offset+i] ^ prev[i];
        tdes_encrypt_block(tmp, out+offset, ks1,ks2,ks3);
        memcpy(prev, out+offset,8);
    }
    return 0;
}