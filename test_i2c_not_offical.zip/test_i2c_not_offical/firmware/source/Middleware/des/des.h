/*
 * Phil Karn's DES386 public domain DES implementation
 * Integrated: DES ECB / CBC, 3DES-EDE
 * Adapted for performance test: 7680 bytes block test
 * Public Domain
 */
#ifndef __DES_H__
#define __DES_H__

#include <stdint.h>
#include <stddef.h>

#define DES_BLOCK_SIZE      8
#define DES_KEY_SIZE        8
#define TRIPLE_DES_KEY_128  16
#define TRIPLE_DES_KEY_192  24

/* 原始des386密钥调度结构体 */
typedef struct {
    uint32_t subkeys[32];
} des_key_schedule;

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief DES 密钥扩展
 * @param key 8字节密钥
 * @param ks 输出密钥调度表
 */
void des_key(const uint8_t *key, des_key_schedule *ks);

/**
 * @brief DES 单个8字节分组加密
 * @param plain 输入8字节明文
 * @param cipher 输出8字节密文
 * @param ks 预计算密钥调度
 */
void des_encrypt(const uint8_t *plain, uint8_t *cipher, const des_key_schedule *ks);

/**
 * @brief DES 单个8字节分组解密
 */
void des_decrypt(const uint8_t *cipher, uint8_t *plain, const des_key_schedule *ks);

/* ====================== DES ECB 批量 ====================== */
/**
 * @brief DES ECB 批量加密
 * @param len 输入长度，必须是8的整数倍
 */
int des_ecb_encrypt(const uint8_t *in, uint8_t *out, size_t len, const des_key_schedule *ks);
int des_ecb_decrypt(const uint8_t *in, uint8_t *out, size_t len, const des_key_schedule *ks);

/* ====================== DES CBC 批量 ====================== */
/**
 * @brief DES CBC 批量加密
 * @param iv 8字节初始向量
 * @param len 输入长度，必须是8整数倍
 */
int des_cbc_encrypt(const uint8_t *in, uint8_t *out, size_t len,
                    const uint8_t *iv, const des_key_schedule *ks);
int des_cbc_decrypt(const uint8_t *in, uint8_t *out, size_t len,
                    const uint8_t *iv, const des_key_schedule *ks);

/* ====================== 3DES-EDE 封装 ====================== */
/**
 * @brief 3DES 密钥扩展
 * key_len = 16(2key) / 24(3key)
 */
void tdes_key(const uint8_t *key, size_t key_len,
              des_key_schedule *ks1, des_key_schedule *ks2, des_key_schedule *ks3);

/**
 * 3DES 单分组 EDE
 */
void tdes_encrypt_block(const uint8_t *in, uint8_t *out,
                        const des_key_schedule *ks1, const des_key_schedule *ks2, const des_key_schedule *ks3);
void tdes_decrypt_block(const uint8_t *in, uint8_t *out,
                        const des_key_schedule *ks1, const des_key_schedule *ks2, const des_key_schedule *ks3);

/* 3DES ECB / CBC批量 */
int tdes_ecb_encrypt(const uint8_t *in, uint8_t *out, size_t len,
                     const des_key_schedule *ks1, const des_key_schedule *ks2, const des_key_schedule *ks3);
int tdes_cbc_encrypt(const uint8_t *in, uint8_t *out, size_t len, const uint8_t *iv,
                     const des_key_schedule *ks1, const des_key_schedule *ks2, const des_key_schedule *ks3);

#ifdef __cplusplus
}
#endif

#endif