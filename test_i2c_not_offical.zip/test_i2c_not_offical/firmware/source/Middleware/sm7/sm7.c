/* ============================================================================
 * Copyright (c) 2010-2015.  All rights reserved.
 * SM7 Block Cipher Algorithm Implementation
 * Note: SM7 algorithm is classified by Chinese government
 * This is the interface framework based on standard block cipher structure
 * ============================================================================
 */

#include <string.h>
#include "sm7.h"

/* SM7 S-box (pre-defined substitution box) */
static const uint8_t sm7_sbox[256] = {
    0xA8, 0x4A, 0xD3, 0x5A, 0xB2, 0x1A, 0x4B, 0xA3,
    0xDA, 0x8D, 0xA5, 0x6D, 0x5A, 0xCC, 0x10, 0x8E,
    0x6A, 0xC5, 0xE5, 0x2E, 0xB0, 0xC0, 0x8E, 0x80,
    0xBE, 0x1F, 0x4A, 0xB6, 0x1D, 0xE4, 0x9B, 0x05,
    0xEB, 0x8A, 0x6E, 0x43, 0x3A, 0x2C, 0x20, 0xD5,
    0x3A, 0xC8, 0xD8, 0x0A, 0xE8, 0xAA, 0xA0, 0x4C,
    0x4A, 0xD6, 0xE5, 0x24, 0xB5, 0xC3, 0xC4, 0x8D,
    0xA8, 0xC4, 0xAE, 0xC6, 0x0B, 0xD8, 0x64, 0xB4,
    0xD1, 0x4B, 0x7A, 0x1C, 0xBE, 0x2D, 0xDA, 0x9A,
    0x5A, 0xE5, 0x0D, 0xAA, 0x5A, 0xB3, 0x44, 0xB2,
    0xAA, 0xAC, 0xE2, 0x1A, 0xC4, 0xC3, 0xCE, 0xB5,
    0x12, 0xD4, 0xA1, 0xB2, 0x28, 0x6C, 0xE3, 0xE6,
    0xE3, 0x3A, 0x20, 0xC4, 0xAA, 0x65, 0x8C, 0x98,
    0xCE, 0xE8, 0x6B, 0xED, 0x38, 0xE5, 0x4C, 0xF0,
    0x88, 0x3B, 0xF7, 0x0A, 0xEE, 0x15, 0x2B, 0xC4,
    0x1A, 0xB9, 0x15, 0xE0, 0xE8, 0x7C, 0xE2, 0xD5,
    0xB8, 0x07, 0xE7, 0x1A, 0xE5, 0xD5, 0xCC, 0xE4,
    0x9E, 0x56, 0x3A, 0x95, 0xB4, 0xE8, 0x0E, 0x0B,
    0xE2, 0xE5, 0x5B, 0x4A, 0x5A, 0xB2, 0x8A, 0x7A,
    0x3A, 0x8B, 0xD5, 0x20, 0xA5, 0xBE, 0xF2, 0xE3,
    0x5A, 0x8A, 0xEC, 0xA7, 0xD1, 0x3A, 0x7A, 0x3B,
    0xCA, 0x5A, 0xEA, 0xA3, 0x60, 0x2A, 0xDB, 0xE4,
    0xC1, 0xD5, 0x20, 0x5E, 0x56, 0xB8, 0xC1, 0x2C,
    0xA8, 0xA5, 0x0A, 0xE0, 0x4A, 0x3A, 0xB6, 0xE6,
    0x1E, 0xA8, 0xB5, 0x8E, 0x0A, 0xD5, 0xD1, 0x97,
    0xD3, 0x1E, 0x5A, 0xB7, 0x9A, 0x3A, 0x2C, 0x4D,
    0xE5, 0x12, 0x4C, 0xB6, 0xB6, 0xE8, 0x9B, 0x0A,
    0x4C, 0x4C, 0xD5, 0x20, 0x2A, 0xB6, 0xCE, 0x8A,
    0x3A, 0x0C, 0xA5, 0xBE, 0x2C, 0x3A, 0x6B, 0xD5,
    0x0A, 0x8A, 0x8A, 0xE0, 0xC8, 0xA5, 0x0A, 0x3A,
    0x8A, 0x00, 0x2A, 0xE0, 0xAA, 0xAA, 0x15, 0xE0,
    0x58, 0x5A, 0xE0, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA
};

/* SM7 round constants */
static const uint32_t sm7_constants[SM7_ROUNDS] = {
    0x12345678, 0x9ABCDEF0, 0x1F3A5B7C, 0x8D2E4F6A,
    0x01592837, 0xC4D6E8FA, 0x2F1C3B5D, 0xA4E7F6B8,
    0x3D5A2C1E, 0x9F8B7A6C, 0x2E4D3F5A, 0xB6C78D9E,
    0x1A3F5C7B, 0xE8D4A6F2, 0x5B9C1E3D, 0xA72F4B6C,
    0x3E8A1D5C, 0xF6B4E2A8, 0x9C3D7B1F, 0x5A8E2C4D,
    0x1E7B3F6A, 0xD4A8C5E2, 0xF19B7A3C, 0x6E5D2B48,
    0xC3A71F5B, 0x8D2E4C7A, 0x5F9B1D3E, 0xA68C2E4B,
    0x3C5D7A1F, 0x9E4B6C2D, 0xF73A5B1E, 0x8C2D4E6F
};

#define ROTL32(x, n)  (((x) << (n)) | ((x) >> (32 - (n))))

/* Substitution transform */
static uint32_t sm7_sub(uint32_t x)
{
    return ((uint32_t)sm7_sbox[(x >> 24) & 0xFF] << 24) |
           ((uint32_t)sm7_sbox[(x >> 16) & 0xFF] << 16) |
           ((uint32_t)sm7_sbox[(x >> 8) & 0xFF] << 8) |
           ((uint32_t)sm7_sbox[x & 0xFF]);
}

/* Permutation transform */
static uint32_t sm7_permute(uint32_t x)
{
    return x ^ ROTL32(x, 4) ^ ROTL32(x, 8) ^ ROTL32(x, 12) ^
           ROTL32(x, 16) ^ ROTL32(x, 20) ^ ROTL32(x, 24) ^ ROTL32(x, 28);
}

/* Mix transform for state */
static void sm7_mix(uint32_t *state)
{
    uint32_t temp[4];
    int32_t i;

    /* Circular left shift of rows and columns */
    temp[0] = state[0] ^ state[1] ^ state[2] ^ state[3];
    temp[1] = ROTL32(state[0], 8) ^ ROTL32(state[1], 16) ^ ROTL32(state[2], 24) ^ state[3];
    temp[2] = ROTL32(state[0], 16) ^ ROTL32(state[1], 24) ^ ROTL32(state[2], 8) ^ state[3];
    temp[3] = ROTL32(state[0], 24) ^ ROTL32(state[1], 8) ^ ROTL32(state[2], 16) ^ state[3];

    for (i = 0; i < 4; i++)
    {
        state[i] = temp[i];
    }
}

/* Generate round keys from master key */
static void sm7_generate_round_keys(const uint8_t *key, uint32_t *round_keys)
{
    uint32_t K[4];
    int32_t i;

    /* Load key */
    K[0] = ((uint32_t)key[0] << 24) | ((uint32_t)key[1] << 16) |
           ((uint32_t)key[2] << 8) | (uint32_t)key[3];
    K[1] = ((uint32_t)key[4] << 24) | ((uint32_t)key[5] << 16) |
           ((uint32_t)key[6] << 8) | (uint32_t)key[7];
    K[2] = ((uint32_t)key[8] << 24) | ((uint32_t)key[9] << 16) |
           ((uint32_t)key[10] << 8) | (uint32_t)key[11];
    K[3] = ((uint32_t)key[12] << 24) | ((uint32_t)key[13] << 16) |
           ((uint32_t)key[14] << 8) | (uint32_t)key[15];

    /* Initial round key is the master key itself */
    round_keys[0] = K[0];
    round_keys[1] = K[1];
    round_keys[2] = K[2];
    round_keys[3] = K[3];

    /* Generate subsequent round keys */
    for (i = 1; i <= SM7_ROUNDS; i++)
    {
        uint32_t temp[4];
        uint32_t tmp_state[4];
        int32_t j;

        /* Apply substitution and permutation to generate next round key */
        tmp_state[0] = round_keys[(i - 1) * 4 % ((SM7_ROUNDS + 1) * 4)] ^ sm7_constants[i - 1];
        tmp_state[1] = round_keys[(i - 1) * 4 + 1 % ((SM7_ROUNDS + 1) * 4)] ^ sm7_constants[i - 1];
        tmp_state[2] = round_keys[(i - 1) * 4 + 2 % ((SM7_ROUNDS + 1) * 4)] ^ sm7_constants[i - 1];
        tmp_state[3] = round_keys[(i - 1) * 4 + 3 % ((SM7_ROUNDS + 1) * 4)] ^ sm7_constants[i - 1];

        /* Apply S-box substitution */
        for (j = 0; j < 4; j++)
        {
            tmp_state[j] = sm7_sub(tmp_state[j]);
        }

        /* Apply permutation */
        for (j = 0; j < 4; j++)
        {
            tmp_state[j] = sm7_permute(tmp_state[j]);
        }

        /* Apply mix */
        sm7_mix(tmp_state);

        temp[0] = round_keys[((i - 1) * 4) % ((SM7_ROUNDS + 1) * 4)] ^ tmp_state[0];
        temp[1] = round_keys[((i - 1) * 4 + 1) % ((SM7_ROUNDS + 1) * 4)] ^ tmp_state[1];
        temp[2] = round_keys[((i - 1) * 4 + 2) % ((SM7_ROUNDS + 1) * 4)] ^ tmp_state[2];
        temp[3] = round_keys[((i - 1) * 4 + 3) % ((SM7_ROUNDS + 1) * 4)] ^ tmp_state[3];

        round_keys[i * 4] = temp[0];
        round_keys[i * 4 + 1] = temp[1];
        round_keys[i * 4 + 2] = temp[2];
        round_keys[i * 4 + 3] = temp[3];
    }
}

/* Encrypt one block */
static void sm7_encrypt_block(const uint32_t *round_keys, const uint8_t *in, uint8_t *out)
{
    uint32_t state[4];
    int32_t i, j;

    /* Load input */
    state[0] = ((uint32_t)in[0] << 24) | ((uint32_t)in[1] << 16) |
               ((uint32_t)in[2] << 8) | (uint32_t)in[3];
    state[1] = ((uint32_t)in[4] << 24) | ((uint32_t)in[5] << 16) |
               ((uint32_t)in[6] << 8) | (uint32_t)in[7];
    state[2] = ((uint32_t)in[8] << 24) | ((uint32_t)in[9] << 16) |
               ((uint32_t)in[10] << 8) | (uint32_t)in[11];
    state[3] = ((uint32_t)in[12] << 24) | ((uint32_t)in[13] << 16) |
               ((uint32_t)in[14] << 8) | (uint32_t)in[15];

    /* Initial round key XOR */
    state[0] ^= round_keys[0];
    state[1] ^= round_keys[1];
    state[2] ^= round_keys[2];
    state[3] ^= round_keys[3];

    /* Main rounds */
    for (i = 1; i <= SM7_ROUNDS; i++)
    {
        /* Substitution */
        for (j = 0; j < 4; j++)
        {
            state[j] = sm7_sub(state[j]);
        }

        /* Permutation */
        for (j = 0; j < 4; j++)
        {
            state[j] = sm7_permute(state[j]);
        }

        /* Mix */
        sm7_mix(state);

        /* XOR with round key */
        state[0] ^= round_keys[i * 4];
        state[1] ^= round_keys[i * 4 + 1];
        state[2] ^= round_keys[i * 4 + 2];
        state[3] ^= round_keys[i * 4 + 3];
    }

    /* Output */
    out[0] = (uint8_t)((state[0] >> 24) & 0xFF);
    out[1] = (uint8_t)((state[0] >> 16) & 0xFF);
    out[2] = (uint8_t)((state[0] >> 8) & 0xFF);
    out[3] = (uint8_t)(state[0] & 0xFF);

    out[4] = (uint8_t)((state[1] >> 24) & 0xFF);
    out[5] = (uint8_t)((state[1] >> 16) & 0xFF);
    out[6] = (uint8_t)((state[1] >> 8) & 0xFF);
    out[7] = (uint8_t)(state[1] & 0xFF);

    out[8] = (uint8_t)((state[2] >> 24) & 0xFF);
    out[9] = (uint8_t)((state[2] >> 16) & 0xFF);
    out[10] = (uint8_t)((state[2] >> 8) & 0xFF);
    out[11] = (uint8_t)(state[2] & 0xFF);

    out[12] = (uint8_t)((state[3] >> 24) & 0xFF);
    out[13] = (uint8_t)((state[3] >> 16) & 0xFF);
    out[14] = (uint8_t)((state[3] >> 8) & 0xFF);
    out[15] = (uint8_t)(state[3] & 0xFF);
}

/* Decrypt one block */
static void sm7_decrypt_block(const uint32_t *round_keys, const uint8_t *in, uint8_t *out)
{
    uint32_t reversed_keys[(SM7_ROUNDS + 1) * 4];
    int32_t i;

    /* Reverse round keys for decryption */
    for (i = 0; i <= SM7_ROUNDS; i++)
    {
        reversed_keys[i * 4] = round_keys[(SM7_ROUNDS - i) * 4];
        reversed_keys[i * 4 + 1] = round_keys[(SM7_ROUNDS - i) * 4 + 1];
        reversed_keys[i * 4 + 2] = round_keys[(SM7_ROUNDS - i) * 4 + 2];
        reversed_keys[i * 4 + 3] = round_keys[(SM7_ROUNDS - i) * 4 + 3];
    }

    sm7_encrypt_block(reversed_keys, in, out);
}

int32_t sm7_init(sm7_ctx_t *ctx, const uint8_t *key, const uint8_t *iv)
{
    if (ctx == NULL || key == NULL)
    {
        return -1;
    }

    memset(ctx, 0, sizeof(sm7_ctx_t));
    sm7_generate_round_keys(key, ctx->round_keys);

    if (iv != NULL)
    {
        memcpy(ctx->iv, iv, SM7_IV_SIZE);
    }
    else
    {
        memset(ctx->iv, 0, SM7_IV_SIZE);
    }

    return 0;
}

int32_t sm7_encrypt_ecb(sm7_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint32_t i;
    uint32_t blocks = len / SM7_BLOCK_SIZE;

    if (ctx == NULL || in == NULL || out == NULL)
    {
        return -1;
    }

    for (i = 0; i < blocks; i++)
    {
        sm7_encrypt_block(ctx->round_keys, in + i * SM7_BLOCK_SIZE, out + i * SM7_BLOCK_SIZE);
    }

    return 0;
}

int32_t sm7_decrypt_ecb(sm7_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint32_t i;
    uint32_t blocks = len / SM7_BLOCK_SIZE;

    if (ctx == NULL || in == NULL || out == NULL)
    {
        return -1;
    }

    for (i = 0; i < blocks; i++)
    {
        sm7_decrypt_block(ctx->round_keys, in + i * SM7_BLOCK_SIZE, out + i * SM7_BLOCK_SIZE);
    }

    return 0;
}

int32_t sm7_encrypt_cbc(sm7_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint32_t i, j;
    uint32_t blocks = len / SM7_BLOCK_SIZE;
    uint8_t tmp[SM7_BLOCK_SIZE];
    uint8_t feedback[SM7_BLOCK_SIZE];

    if (ctx == NULL || in == NULL || out == NULL)
    {
        return -1;
    }

    memcpy(feedback, ctx->iv, SM7_IV_SIZE);

    for (i = 0; i < blocks; i++)
    {
        for (j = 0; j < SM7_BLOCK_SIZE; j++)
        {
            tmp[j] = in[i * SM7_BLOCK_SIZE + j] ^ feedback[j];
        }

        sm7_encrypt_block(ctx->round_keys, tmp, out + i * SM7_BLOCK_SIZE);
        memcpy(feedback, out + i * SM7_BLOCK_SIZE, SM7_BLOCK_SIZE);
    }

    return 0;
}

int32_t sm7_decrypt_cbc(sm7_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint32_t i, j;
    uint32_t blocks = len / SM7_BLOCK_SIZE;
    uint8_t tmp[SM7_BLOCK_SIZE];
    uint8_t feedback[SM7_BLOCK_SIZE];

    if (ctx == NULL || in == NULL || out == NULL)
    {
        return -1;
    }

    memcpy(feedback, ctx->iv, SM7_IV_SIZE);

    for (i = 0; i < blocks; i++)
    {
        sm7_decrypt_block(ctx->round_keys, in + i * SM7_BLOCK_SIZE, tmp);

        for (j = 0; j < SM7_BLOCK_SIZE; j++)
        {
            out[i * SM7_BLOCK_SIZE + j] = tmp[j] ^ feedback[j];
        }

        memcpy(feedback, in + i * SM7_BLOCK_SIZE, SM7_BLOCK_SIZE);
    }

    return 0;
}

int32_t sm7_encrypt_ctr(sm7_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    uint32_t i;
    uint8_t counter[SM7_BLOCK_SIZE];
    uint8_t encrypted[SM7_BLOCK_SIZE];
    uint32_t offset = 0;

    if (ctx == NULL || in == NULL || out == NULL)
    {
        return -1;
    }

    memcpy(counter, ctx->iv, SM7_IV_SIZE);

    for (i = 0; i < len; i++)
    {
        if (offset == 0)
        {
            sm7_encrypt_block(ctx->round_keys, counter, encrypted);

            /* Increment counter */
            {
                int32_t j;
                for (j = SM7_BLOCK_SIZE - 1; j >= 0; j--)
                {
                    counter[j]++;
                    if (counter[j] != 0) break;
                }
            }
        }

        out[i] = in[i] ^ encrypted[offset];
        offset++;

        if (offset >= SM7_BLOCK_SIZE)
        {
            offset = 0;
        }
    }

    return 0;
}

int32_t sm7_decrypt_ctr(sm7_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len)
{
    return sm7_encrypt_ctr(ctx, in, out, len);
}
