/* ============================================================================
 * Copyright (c) 2010-2015.  All rights reserved.
 * SM7 Block Cipher Algorithm: Block size is 128-bit, Key size is 128-bit
 * Note: SM7 algorithm is classified, this is the interface framework
 * ============================================================================
 */

#ifndef __SM7_HEADER__
#define __SM7_HEADER__

#ifdef  __cplusplus
extern "C" {
#endif

#include <stdint.h>

#define SM7_BLOCK_SIZE  16
#define SM7_KEY_SIZE    16
#define SM7_IV_SIZE     16
#define SM7_ROUNDS      32

typedef struct sm7_ctx
{
    uint32_t round_keys[SM7_ROUNDS + 1];
    uint8_t iv[SM7_IV_SIZE];
} sm7_ctx_t;

int32_t sm7_init(sm7_ctx_t *ctx, const uint8_t *key, const uint8_t *iv);
int32_t sm7_encrypt_ecb(sm7_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);
int32_t sm7_decrypt_ecb(sm7_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);
int32_t sm7_encrypt_cbc(sm7_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);
int32_t sm7_decrypt_cbc(sm7_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);
int32_t sm7_encrypt_ctr(sm7_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);
int32_t sm7_decrypt_ctr(sm7_ctx_t *ctx, const uint8_t *in, uint8_t *out, uint32_t len);

#ifdef  __cplusplus
}
#endif

#endif
