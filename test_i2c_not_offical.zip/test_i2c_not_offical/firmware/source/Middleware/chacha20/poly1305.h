#ifndef POLY1305_H
#define POLY1305_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define POLY1305_KEY_SIZE 32U
#define POLY1305_TAG_SIZE 16U

typedef struct {
    uint32_t h[5];
    uint32_t r[5];
    uint32_t r5[5];

    uint32_t pad[4];

    uint8_t buffer[16];
    size_t buffer_len;

    int finalized;
} poly1305_ctx;

int poly1305_init(poly1305_ctx *ctx,
                  const uint8_t key[POLY1305_KEY_SIZE]);

int poly1305_update(poly1305_ctx *ctx,
                    const uint8_t *data,
                    size_t len);

int poly1305_finish(poly1305_ctx *ctx,
                    uint8_t tag[POLY1305_TAG_SIZE]);

int poly1305_auth(uint8_t tag[POLY1305_TAG_SIZE],
                  const uint8_t *msg,
                  size_t msg_len,
                  const uint8_t key[POLY1305_KEY_SIZE]);

int poly1305_verify(const uint8_t tag1[POLY1305_TAG_SIZE],
                    const uint8_t tag2[POLY1305_TAG_SIZE]);

#ifdef __cplusplus
}
#endif

#endif