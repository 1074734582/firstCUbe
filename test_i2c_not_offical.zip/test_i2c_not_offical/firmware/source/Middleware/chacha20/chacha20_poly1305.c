#include "chacha20_poly1305.h"

#include <string.h>

/*
 * RFC 8439:
 *
 * Poly1305 input:
 *
 *     AAD
 *     pad16(AAD)
 *     ciphertext
 *     pad16(ciphertext)
 *     len(AAD)       -- little endian uint64
 *     len(ciphertext)-- little endian uint64
 */

static void store64_le(uint8_t *p, uint64_t x)
{
    p[0] = (uint8_t)x;
    p[1] = (uint8_t)(x >> 8);
    p[2] = (uint8_t)(x >> 16);
    p[3] = (uint8_t)(x >> 24);
    p[4] = (uint8_t)(x >> 32);
    p[5] = (uint8_t)(x >> 40);
    p[6] = (uint8_t)(x >> 48);
    p[7] = (uint8_t)(x >> 56);
}

static int poly1305_update_pad16(poly1305_ctx *ctx,
                                 const uint8_t *data,
                                 size_t len)
{
    static const uint8_t zero[16] = {0};
    size_t pad;

    if (len != 0U) {
        if (poly1305_update(ctx, data, len) != 0)
            return -1;
    }

    pad = (16U - (len & 15U)) & 15U;

    if (pad != 0U) {
        if (poly1305_update(ctx, zero, pad) != 0)
            return -1;
    }

    return 0;
}

/*
 * Derive the one-time Poly1305 key:
 *
 *     Poly1305Key = ChaCha20(key, counter=0, nonce)[0..31]
 */
static void derive_poly1305_key(
    const uint8_t key[CHACHA20_POLY1305_KEY_SIZE],
    const uint8_t nonce[CHACHA20_POLY1305_NONCE_SIZE],
    uint8_t poly_key[POLY1305_KEY_SIZE])
{
    uint8_t block[64];

    chacha20_block(key, 0U, nonce, block);

    memcpy(poly_key, block, 32U);

    memset(block, 0, sizeof(block));
}

static int build_poly1305_tag(
    const uint8_t poly_key[POLY1305_KEY_SIZE],
    const uint8_t *aad,
    size_t aad_len,
    const uint8_t *ciphertext,
    size_t ciphertext_len,
    uint8_t tag[POLY1305_TAG_SIZE])
{
    poly1305_ctx ctx;
    uint8_t lengths[16];

    if (poly1305_init(&ctx, poly_key) != 0)
        return -1;

    /*
     * AAD.
     */
    if (poly1305_update_pad16(&ctx, aad, aad_len) != 0)
        goto fail;

    /*
     * Ciphertext.
     */
    if (poly1305_update_pad16(&ctx,
                              ciphertext,
                              ciphertext_len) != 0)
        goto fail;

    /*
     * Length block.
     *
     * Both lengths are encoded as unsigned 64-bit little-endian.
     */
    store64_le(lengths + 0, (uint64_t)aad_len);
    store64_le(lengths + 8, (uint64_t)ciphertext_len);

    if (poly1305_update(&ctx, lengths, sizeof(lengths)) != 0)
        goto fail;

    if (poly1305_finish(&ctx, tag) != 0)
        goto fail;

    memset(lengths, 0, sizeof(lengths));
    return 0;

fail:
    memset(&ctx, 0, sizeof(ctx));
    memset(lengths, 0, sizeof(lengths));
    return -1;
}

int chacha20_poly1305_encrypt(
    const uint8_t key[CHACHA20_POLY1305_KEY_SIZE],
    const uint8_t nonce[CHACHA20_POLY1305_NONCE_SIZE],
    const uint8_t *aad,
    size_t aad_len,
    const uint8_t *plaintext,
    size_t plaintext_len,
    uint8_t *ciphertext,
    uint8_t tag[CHACHA20_POLY1305_TAG_SIZE])
{
    uint8_t poly_key[POLY1305_KEY_SIZE];
    int ret;

    if (key == NULL || nonce == NULL || tag == NULL)
        return -1;

    if (aad_len != 0U && aad == NULL)
        return -1;

    if (plaintext_len != 0U &&
        (plaintext == NULL || ciphertext == NULL))
        return -1;

    /*
     * Derive Poly1305 one-time key using ChaCha20 block 0.
     */
    derive_poly1305_key(key, nonce, poly_key);

    /*
     * Encrypt using ChaCha20 starting at counter 1.
     */
    if (plaintext_len != 0U) {
        ret = chacha20_encrypt(key,
                               1U,
                               nonce,
                               plaintext,
                               ciphertext,
                               plaintext_len);

        if (ret != 0) {
            memset(poly_key, 0, sizeof(poly_key));
            return ret;
        }
    }

    /*
     * Authenticate AAD + ciphertext + lengths.
     */
    ret = build_poly1305_tag(poly_key,
                             aad,
                             aad_len,
                             ciphertext,
                             plaintext_len,
                             tag);

    memset(poly_key, 0, sizeof(poly_key));

    return ret;
}

int chacha20_poly1305_decrypt(
    const uint8_t key[CHACHA20_POLY1305_KEY_SIZE],
    const uint8_t nonce[CHACHA20_POLY1305_NONCE_SIZE],
    const uint8_t *aad,
    size_t aad_len,
    const uint8_t *ciphertext,
    size_t ciphertext_len,
    const uint8_t tag[CHACHA20_POLY1305_TAG_SIZE],
    uint8_t *plaintext)
{
    uint8_t poly_key[POLY1305_KEY_SIZE];
    uint8_t expected_tag[POLY1305_TAG_SIZE];
    int ret;

    if (key == NULL || nonce == NULL || tag == NULL)
        return -1;

    if (aad_len != 0U && aad == NULL)
        return -1;

    if (ciphertext_len != 0U &&
        (ciphertext == NULL || plaintext == NULL))
        return -1;

    /*
     * Derive Poly1305 key.
     */
    derive_poly1305_key(key, nonce, poly_key);

    /*
     * Authenticate ciphertext BEFORE decrypting it.
     */
    ret = build_poly1305_tag(poly_key,
                             aad,
                             aad_len,
                             ciphertext,
                             ciphertext_len,
                             expected_tag);

    if (ret != 0) {
        memset(poly_key, 0, sizeof(poly_key));
        memset(expected_tag, 0, sizeof(expected_tag));
        return -1;
    }

    /*
     * Constant-time tag comparison.
     */
    if (!poly1305_verify(expected_tag, tag)) {
        /*
         * Authentication failure:
         *
         * Do not produce plaintext.
         */
        if (plaintext != NULL && ciphertext_len != 0U)
            memset(plaintext, 0, ciphertext_len);

        memset(poly_key, 0, sizeof(poly_key));
        memset(expected_tag, 0, sizeof(expected_tag));

        return -2;
    }

    /*
     * Authentication succeeded.
     *
     * Now decrypt using ChaCha20 counter 1.
     */
    if (ciphertext_len != 0U) {
        ret = chacha20_decrypt(key,
                               1U,
                               nonce,
                               ciphertext,
                               plaintext,
                               ciphertext_len);

        if (ret != 0) {
            memset(poly_key, 0, sizeof(poly_key));
            memset(expected_tag, 0, sizeof(expected_tag));
            return ret;
        }
    }

    memset(poly_key, 0, sizeof(poly_key));
    memset(expected_tag, 0, sizeof(expected_tag));

    return 0;
}