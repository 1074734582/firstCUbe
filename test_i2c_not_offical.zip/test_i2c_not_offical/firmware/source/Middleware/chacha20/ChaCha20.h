#ifndef CHACHA20_H
#define CHACHA20_H

#include <stddef.h>
#include <stdint.h>

#define CHACHA20_KEY_SIZE    32U
#define CHACHA20_NONCE_SIZE  12U
#define CHACHA20_BLOCK_SIZE  64U
#define CHACHA20_ROUNDS      20U

typedef struct {
    uint32_t state[16];
    uint8_t  keystream[CHACHA20_BLOCK_SIZE];
    size_t   keystream_used;
    int      exhausted;
    int      initialized;
} chacha20_ctx;

void chacha20_block(const uint8_t key[CHACHA20_KEY_SIZE],
                    uint32_t counter,
                    const uint8_t nonce[CHACHA20_NONCE_SIZE],
                    uint8_t out[CHACHA20_BLOCK_SIZE]);

int chacha20_init(chacha20_ctx *ctx,
                  const uint8_t key[CHACHA20_KEY_SIZE],
                  const uint8_t nonce[CHACHA20_NONCE_SIZE],
                  uint32_t counter);

int chacha20_crypt(chacha20_ctx *ctx,
                   const uint8_t *input,
                   uint8_t *output,
                   size_t len);

int chacha20_encrypt(const uint8_t key[CHACHA20_KEY_SIZE],
                     uint32_t counter,
                     const uint8_t nonce[CHACHA20_NONCE_SIZE],
                     const uint8_t *input,
                     uint8_t *output,
                     size_t len);

int chacha20_decrypt(const uint8_t key[CHACHA20_KEY_SIZE],
                     uint32_t counter,
                     const uint8_t nonce[CHACHA20_NONCE_SIZE],
                     const uint8_t *input,
                     uint8_t *output,
                     size_t len);

#endif /* CHACHA20_H */