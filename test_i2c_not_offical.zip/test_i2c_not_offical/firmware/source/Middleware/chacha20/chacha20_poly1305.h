#ifndef CHACHA20_POLY1305_H
#define CHACHA20_POLY1305_H

#include <stddef.h>
#include <stdint.h>

#include "ChaCha20.h"
#include "poly1305.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CHACHA20_POLY1305_KEY_SIZE   32U
#define CHACHA20_POLY1305_NONCE_SIZE 12U
#define CHACHA20_POLY1305_TAG_SIZE   16U

/*
 * RFC 8439 ChaCha20-Poly1305 AEAD encryption.
 *
 * key:
 *     32-byte key.
 *
 * nonce:
 *     12-byte IETF nonce.
 *
 * aad:
 *     Additional Authenticated Data.
 *
 * plaintext:
 *     Input plaintext.
 *
 * ciphertext:
 *     Output ciphertext. Must have plaintext_len bytes.
 *
 * tag:
 *     Output 16-byte authentication tag.
 *
 * Return:
 *     0  success
 *    -1  invalid parameters
 */
int chacha20_poly1305_encrypt(
    const uint8_t key[CHACHA20_POLY1305_KEY_SIZE],
    const uint8_t nonce[CHACHA20_POLY1305_NONCE_SIZE],
    const uint8_t *aad,
    size_t aad_len,
    const uint8_t *plaintext,
    size_t plaintext_len,
    uint8_t *ciphertext,
    uint8_t tag[CHACHA20_POLY1305_TAG_SIZE]);

/*
 * RFC 8439 ChaCha20-Poly1305 AEAD decryption.
 *
 * The plaintext is only released when authentication succeeds.
 *
 * Return:
 *     0  success
 *    -1  invalid parameters
 *    -2  authentication failure
 */
int chacha20_poly1305_decrypt(
    const uint8_t key[CHACHA20_POLY1305_KEY_SIZE],
    const uint8_t nonce[CHACHA20_POLY1305_NONCE_SIZE],
    const uint8_t *aad,
    size_t aad_len,
    const uint8_t *ciphertext,
    size_t ciphertext_len,
    const uint8_t tag[CHACHA20_POLY1305_TAG_SIZE],
    uint8_t *plaintext);

#ifdef __cplusplus
}
#endif

#endif /* CHACHA20_POLY1305_H */