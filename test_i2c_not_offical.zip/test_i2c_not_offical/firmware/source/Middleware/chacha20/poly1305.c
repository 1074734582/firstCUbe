#include "poly1305.h"

#include <string.h>

static uint32_t load32_le(const uint8_t *p)
{
    return ((uint32_t)p[0]) |
           ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

static void store32_le(uint8_t *p, uint32_t x)
{
    p[0] = (uint8_t)x;
    p[1] = (uint8_t)(x >> 8);
    p[2] = (uint8_t)(x >> 16);
    p[3] = (uint8_t)(x >> 24);
}

static void poly1305_blocks(poly1305_ctx *ctx,
                            const uint8_t *m,
                            size_t bytes,
                            uint32_t hibit)
{
    uint32_t r0 = ctx->r[0];
    uint32_t r1 = ctx->r[1];
    uint32_t r2 = ctx->r[2];
    uint32_t r3 = ctx->r[3];
    uint32_t r4 = ctx->r[4];

    uint32_t s1 = ctx->r5[1];
    uint32_t s2 = ctx->r5[2];
    uint32_t s3 = ctx->r5[3];
    uint32_t s4 = ctx->r5[4];

    uint32_t h0 = ctx->h[0];
    uint32_t h1 = ctx->h[1];
    uint32_t h2 = ctx->h[2];
    uint32_t h3 = ctx->h[3];
    uint32_t h4 = ctx->h[4];

    while (bytes >= 16U) {
        uint64_t d0;
        uint64_t d1;
        uint64_t d2;
        uint64_t d3;
        uint64_t d4;

        uint32_t c;

        h0 += load32_le(m + 0) & 0x3ffffffU;
        h1 += (load32_le(m + 3) >> 2) & 0x3ffffffU;
        h2 += (load32_le(m + 6) >> 4) & 0x3ffffffU;
        h3 += (load32_le(m + 9) >> 6) & 0x3ffffffU;
        h4 += (load32_le(m + 12) >> 8) | hibit;

        d0 = ((uint64_t)h0 * r0) +
             ((uint64_t)h1 * s4) +
             ((uint64_t)h2 * s3) +
             ((uint64_t)h3 * s2) +
             ((uint64_t)h4 * s1);

        d1 = ((uint64_t)h0 * r1) +
             ((uint64_t)h1 * r0) +
             ((uint64_t)h2 * s4) +
             ((uint64_t)h3 * s3) +
             ((uint64_t)h4 * s2);

        d2 = ((uint64_t)h0 * r2) +
             ((uint64_t)h1 * r1) +
             ((uint64_t)h2 * r0) +
             ((uint64_t)h3 * s4) +
             ((uint64_t)h4 * s3);

        d3 = ((uint64_t)h0 * r3) +
             ((uint64_t)h1 * r2) +
             ((uint64_t)h2 * r1) +
             ((uint64_t)h3 * r0) +
             ((uint64_t)h4 * s4);

        d4 = ((uint64_t)h0 * r4) +
             ((uint64_t)h1 * r3) +
             ((uint64_t)h2 * r2) +
             ((uint64_t)h3 * r1) +
             ((uint64_t)h4 * r0);

        c = (uint32_t)(d0 >> 26);
        h0 = (uint32_t)d0 & 0x3ffffffU;
        d1 += c;

        c = (uint32_t)(d1 >> 26);
        h1 = (uint32_t)d1 & 0x3ffffffU;
        d2 += c;

        c = (uint32_t)(d2 >> 26);
        h2 = (uint32_t)d2 & 0x3ffffffU;
        d3 += c;

        c = (uint32_t)(d3 >> 26);
        h3 = (uint32_t)d3 & 0x3ffffffU;
        d4 += c;

        c = (uint32_t)(d4 >> 26);
        h4 = (uint32_t)d4 & 0x3ffffffU;

        h0 += c * 5U;

        c = h0 >> 26;
        h0 &= 0x3ffffffU;
        h1 += c;

        m += 16U;
        bytes -= 16U;
    }

    ctx->h[0] = h0;
    ctx->h[1] = h1;
    ctx->h[2] = h2;
    ctx->h[3] = h3;
    ctx->h[4] = h4;
}
int poly1305_init(poly1305_ctx *ctx,
                  const uint8_t key[POLY1305_KEY_SIZE])
{
    uint32_t t0;
    uint32_t t1;
    uint32_t t2;
    uint32_t t3;

    if (ctx == NULL || key == NULL)
        return -1;

    memset(ctx, 0, sizeof(*ctx));

    /*
     * r = key[0..15]
     *
     * Poly1305 uses:
     *
     *     p = 2^130 - 5
     *
     * The 128-bit r value must be clamped before use.
     *
     * 26-bit limb representation:
     *
     *     r0 = 26 bits
     *     r1 = 26 bits
     *     r2 = 26 bits
     *     r3 = 26 bits
     *     r4 = 22 bits
     */

    t0 = load32_le(key + 0);
    t1 = load32_le(key + 4);
    t2 = load32_le(key + 8);
    t3 = load32_le(key + 12);

    /*
     * Correct Poly1305 clamp:
     *
     * clear:
     *   r[3], r[7], r[11], r[15] low 2 bits
     *   r[4], r[8], r[12] high 4 bits
     *
     * In the 26-bit limb representation this becomes:
     */
    ctx->r[0] = t0 & 0x3ffffffU;

    ctx->r[1] = ((t0 >> 26) |
                 (t1 << 6)) & 0x3ffff03U;

    ctx->r[2] = ((t1 >> 20) |
                 (t2 << 12)) & 0x3ffc0ffU;

    ctx->r[3] = ((t2 >> 14) |
                 (t3 << 18)) & 0x3f03fffU;

    ctx->r[4] = (t3 >> 8) & 0x00fffffU;

    /*
     * Precompute 5*r because:
     *
     *     2^130 = 5 (mod 2^130 - 5)
     *
     * Multiplication therefore folds the high limb back
     * multiplied by 5.
     */
    ctx->r5[0] = ctx->r[0] * 5U;
    ctx->r5[1] = ctx->r[1] * 5U;
    ctx->r5[2] = ctx->r[2] * 5U;
    ctx->r5[3] = ctx->r[3] * 5U;
    ctx->r5[4] = ctx->r[4] * 5U;

    /*
     * s = key[16..31]
     */
    ctx->pad[0] = load32_le(key + 16);
    ctx->pad[1] = load32_le(key + 20);
    ctx->pad[2] = load32_le(key + 24);
    ctx->pad[3] = load32_le(key + 28);

    ctx->buffer_len = 0;
    ctx->finalized = 0;

    return 0;
}

int poly1305_update(poly1305_ctx *ctx,
                    const uint8_t *data,
                    size_t len)
{
    size_t n;

    if (ctx == NULL)
        return -1;

    if (ctx->finalized)
        return -1;

    if (len == 0U)
        return 0;

    if (data == NULL)
        return -1;

    if (ctx->buffer_len != 0U) {
        n = 16U - ctx->buffer_len;

        if (n > len)
            n = len;

        memcpy(ctx->buffer + ctx->buffer_len, data, n);

        ctx->buffer_len += n;
        data += n;
        len -= n;

        if (ctx->buffer_len == 16U) {
            poly1305_blocks(ctx, ctx->buffer, 16U, 1U << 24);
            ctx->buffer_len = 0U;
        }
    }

    if (len >= 16U) {
        size_t full = len & ~(size_t)15U;

        poly1305_blocks(ctx, data, full, 1U << 24);

        data += full;
        len -= full;
    }

    if (len != 0U) {
        memcpy(ctx->buffer, data, len);
        ctx->buffer_len = len;
    }

    return 0;
}

int poly1305_finish(poly1305_ctx *ctx,
                    uint8_t tag[POLY1305_TAG_SIZE])
{
    uint32_t h0;
    uint32_t h1;
    uint32_t h2;
    uint32_t h3;
    uint32_t h4;

    uint32_t g0;
    uint32_t g1;
    uint32_t g2;
    uint32_t g3;
    uint32_t g4;

    uint32_t c;
    uint32_t mask;

    uint32_t f0;
    uint32_t f1;
    uint32_t f2;
    uint32_t f3;

    uint64_t f;

    if (ctx == NULL || tag == NULL)
        return -1;

    if (ctx->finalized)
        return -1;

    /*
     * Final partial block.
     */
    if (ctx->buffer_len != 0U) {
        size_t i = ctx->buffer_len;

        ctx->buffer[i++] = 1U;

        while (i < 16U)
            ctx->buffer[i++] = 0U;

        poly1305_blocks(ctx, ctx->buffer, 16U, 0U);

        ctx->buffer_len = 0U;
    }

    h0 = ctx->h[0];
    h1 = ctx->h[1];
    h2 = ctx->h[2];
    h3 = ctx->h[3];
    h4 = ctx->h[4];

    /*
     * Final carry.
     */
    c = h1 >> 26;
    h1 &= 0x3ffffffU;
    h2 += c;

    c = h2 >> 26;
    h2 &= 0x3ffffffU;
    h3 += c;

    c = h3 >> 26;
    h3 &= 0x3ffffffU;
    h4 += c;

    c = h4 >> 26;
    h4 &= 0x3ffffffU;
    h0 += c * 5U;

    c = h0 >> 26;
    h0 &= 0x3ffffffU;
    h1 += c;

    /*
     * g = h + 5 - p
     *
     * If h >= p, select g.
     */
    g0 = h0 + 5U;
    c = g0 >> 26;
    g0 &= 0x3ffffffU;

    g1 = h1 + c;
    c = g1 >> 26;
    g1 &= 0x3ffffffU;

    g2 = h2 + c;
    c = g2 >> 26;
    g2 &= 0x3ffffffU;

    g3 = h3 + c;
    c = g3 >> 26;
    g3 &= 0x3ffffffU;

    g4 = h4 + c;

    /*
     * If g4 overflowed 26 bits, h >= p.
     */
    mask = (uint32_t)0U - (g4 >> 26);

    g4 &= 0x3ffffffU;

    h0 = (h0 & ~mask) | (g0 & mask);
    h1 = (h1 & ~mask) | (g1 & mask);
    h2 = (h2 & ~mask) | (g2 & mask);
    h3 = (h3 & ~mask) | (g3 & mask);
    h4 = (h4 & ~mask) | (g4 & mask);

    /*
     * Serialize.
     */
    f0 = h0 | (h1 << 26);
    f1 = (h1 >> 6) | (h2 << 20);
    f2 = (h2 >> 12) | (h3 << 14);
    f3 = (h3 >> 18) | (h4 << 8);

    /*
     * Add s.
     */
    f = (uint64_t)f0 + ctx->pad[0];
    f0 = (uint32_t)f;

    f = (uint64_t)f1 + ctx->pad[1] + (f >> 32);
    f1 = (uint32_t)f;

    f = (uint64_t)f2 + ctx->pad[2] + (f >> 32);
    f2 = (uint32_t)f;

    f = (uint64_t)f3 + ctx->pad[3] + (f >> 32);
    f3 = (uint32_t)f;

    store32_le(tag + 0, f0);
    store32_le(tag + 4, f1);
    store32_le(tag + 8, f2);
    store32_le(tag + 12, f3);

    memset(ctx, 0, sizeof(*ctx));

    return 0;
}

int poly1305_auth(uint8_t tag[POLY1305_TAG_SIZE],
                  const uint8_t *msg,
                  size_t msg_len,
                  const uint8_t key[POLY1305_KEY_SIZE])
{
    poly1305_ctx ctx;
    int ret;

    if (tag == NULL || key == NULL)
        return -1;

    if (msg_len != 0U && msg == NULL)
        return -1;

    ret = poly1305_init(&ctx, key);
    if (ret != 0)
        return ret;

    ret = poly1305_update(&ctx, msg, msg_len);
    if (ret != 0) {
        memset(&ctx, 0, sizeof(ctx));
        return ret;
    }

    return poly1305_finish(&ctx, tag);
}

int poly1305_verify(const uint8_t tag1[POLY1305_TAG_SIZE],
                    const uint8_t tag2[POLY1305_TAG_SIZE])
{
    uint32_t diff = 0;
    size_t i;

    if (tag1 == NULL || tag2 == NULL)
        return 0;

    for (i = 0; i < POLY1305_TAG_SIZE; ++i)
        diff |= (uint32_t)(tag1[i] ^ tag2[i]);

    diff = (diff | (0U - diff)) >> 31;

    return (int)(diff ^ 1U);
}