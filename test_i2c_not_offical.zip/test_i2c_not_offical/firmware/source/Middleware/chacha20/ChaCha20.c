/*
 * ChaCha20.c
 *
 * RFC 8439 / IETF ChaCha20 implementation.
 *
 * IMPORTANT:
 *   The URL supplied by the user points to RFC 7841, which is about
 *   RFC document formatting/boilerplate, not ChaCha20.
 *   The ChaCha20 specification and test vectors are in RFC 8439.
 *
 * Reference:
 *   RFC 8439, Section 2.1  - ChaCha quarter round
 *   RFC 8439, Section 2.2  - ChaCha state
 *   RFC 8439, Section 2.3  - ChaCha20 block function
 *   RFC 8439, Section 2.4  - ChaCha20 encryption
 *   RFC 8439, Section 2.4.2- encryption example/test vector
 *   RFC 8439, Appendix A  - additional test vectors
 *
 * Parameters of IETF ChaCha20:
 *   key     : 32 bytes / 256 bits
 *   nonce   : 12 bytes / 96 bits
 *   counter : 32 bits
 *   block   : 64 bytes
 *   rounds  : 20
 *
 * No OpenSSL/GmSSL dependency.
 */

#include "ChaCha20.h"

#include <string.h>

static uint32_t load32_le(const uint8_t *p)
{
    return ((uint32_t)p[0]) |
           ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

static void store32_le(uint8_t *p, uint32_t x)
{
    p[0] = (uint8_t)(x);
    p[1] = (uint8_t)(x >> 8);
    p[2] = (uint8_t)(x >> 16);
    p[3] = (uint8_t)(x >> 24);
}

static uint32_t rotl32(uint32_t x, unsigned int n)
{
    /* n is always 7, 8, 12, or 16 in ChaCha20. */
    return (x << n) | (x >> (32U - n));
}

/* RFC 8439 Section 2.1 */
static void quarter_round(uint32_t *a, uint32_t *b,
                          uint32_t *c, uint32_t *d)
{
    *a += *b;
    *d ^= *a;
    *d = rotl32(*d, 16);

    *c += *d;
    *b ^= *c;
    *b = rotl32(*b, 12);

    *a += *b;
    *d ^= *a;
    *d = rotl32(*d, 8);

    *c += *d;
    *b ^= *c;
    *b = rotl32(*b, 7);
}

/*
 * RFC 8439 Section 2.3
 *
 * ChaCha state layout:
 *
 *   0   1   2   3       constants
 *   4   5   6   7       key
 *   8   9  10  11       key
 *  12  13  14  15       counter + nonce
 *
 * The function produces one 64-byte keystream block.
 */
void chacha20_block(const uint8_t key[CHACHA20_KEY_SIZE],
                    uint32_t counter,
                    const uint8_t nonce[CHACHA20_NONCE_SIZE],
                    uint8_t out[CHACHA20_BLOCK_SIZE])
{
    static const uint8_t sigma[16] = "expand 32-byte k";
    uint32_t x[16];
    uint32_t w[16];
    unsigned int i;

    x[0] = load32_le(sigma + 0);
    x[1] = load32_le(sigma + 4);
    x[2] = load32_le(sigma + 8);
    x[3] = load32_le(sigma + 12);

    for (i = 0; i < 8U; ++i)
        x[4U + i] = load32_le(key + 4U * i);

    x[12] = counter;
    x[13] = load32_le(nonce + 0);
    x[14] = load32_le(nonce + 4);
    x[15] = load32_le(nonce + 8);

    memcpy(w, x, sizeof(w));

    /* 10 column+diagonal pairs = 20 rounds. */
    for (i = 0; i < CHACHA20_ROUNDS; i += 2U) {
        /* Column round */
        quarter_round(&w[0], &w[4], &w[8],  &w[12]);
        quarter_round(&w[1], &w[5], &w[9],  &w[13]);
        quarter_round(&w[2], &w[6], &w[10], &w[14]);
        quarter_round(&w[3], &w[7], &w[11], &w[15]);

        /* Diagonal round */
        quarter_round(&w[0], &w[5], &w[10], &w[15]);
        quarter_round(&w[1], &w[6], &w[11], &w[12]);
        quarter_round(&w[2], &w[7], &w[8],  &w[13]);
        quarter_round(&w[3], &w[4], &w[9],  &w[14]);
    }

    /* Add the original state, then serialize little-endian. */
    for (i = 0; i < 16U; ++i)
        store32_le(out + 4U * i, w[i] + x[i]);

    /* Avoid retaining the temporary state longer than necessary. */
    memset(x, 0, sizeof(x));
    memset(w, 0, sizeof(w));
}

/*
 * Initialize a streaming ChaCha20 context.
 *
 * counter may be 0 or 1, and may be any other 32-bit value as permitted
 * by the protocol using ChaCha20.
 *
 * Return: 0 on success, -1 on invalid parameters.
 */
int chacha20_init(chacha20_ctx *ctx,
                  const uint8_t key[CHACHA20_KEY_SIZE],
                  const uint8_t nonce[CHACHA20_NONCE_SIZE],
                  uint32_t counter)
{
    static const uint8_t sigma[16] = "expand 32-byte k";
    unsigned int i;

    if (ctx == NULL || key == NULL || nonce == NULL)
        return -1;

    ctx->state[0] = load32_le(sigma + 0);
    ctx->state[1] = load32_le(sigma + 4);
    ctx->state[2] = load32_le(sigma + 8);
    ctx->state[3] = load32_le(sigma + 12);

    for (i = 0; i < 8U; ++i)
        ctx->state[4U + i] = load32_le(key + 4U * i);

    ctx->state[12] = counter;
    ctx->state[13] = load32_le(nonce + 0);
    ctx->state[14] = load32_le(nonce + 4);
    ctx->state[15] = load32_le(nonce + 8);

    memset(ctx->keystream, 0, sizeof(ctx->keystream));
    ctx->keystream_used = CHACHA20_BLOCK_SIZE;
    ctx->exhausted = 0;
    ctx->initialized = 1;

    return 0;
}

/*
 * Process arbitrary-length input.
 *
 * ChaCha20 encryption and decryption are identical:
 *     output = input XOR keystream
 *
 * input and output may point to the same buffer.
 *
 * Return:
 *   0  success
 *  -1  invalid parameters / uninitialized context
 *  -2  32-bit block-counter space exhausted
 */
int chacha20_crypt(chacha20_ctx *ctx,
                   const uint8_t *input,
                   uint8_t *output,
                   size_t len)
{
    while (len != 0U) {
        size_t n;
        size_t i;

        if (ctx == NULL || !ctx->initialized)
            return -1;

        if (input == NULL || output == NULL)
            return -1;

        if (ctx->keystream_used == CHACHA20_BLOCK_SIZE) {
            uint8_t key[CHACHA20_KEY_SIZE];
            uint8_t nonce[CHACHA20_NONCE_SIZE];
            uint32_t counter;

            if (ctx->exhausted)
                return -2;

            counter = ctx->state[12];

            for (i = 0; i < 8U; ++i)
                store32_le(key + 4U * i, ctx->state[4U + i]);

            store32_le(nonce + 0, ctx->state[13]);
            store32_le(nonce + 4, ctx->state[14]);
            store32_le(nonce + 8, ctx->state[15]);

            chacha20_block(key, counter, nonce, ctx->keystream);

            memset(key, 0, sizeof(key));
            memset(nonce, 0, sizeof(nonce));

            ctx->keystream_used = 0U;

            if (counter == UINT32_MAX) {
                /* This block is valid; no block may follow it. */
                ctx->exhausted = 1;
            } else {
                ctx->state[12] = counter + 1U;
            }
        }

        n = CHACHA20_BLOCK_SIZE - ctx->keystream_used;
        if (n > len)
            n = len;

        for (i = 0; i < n; ++i) {
            output[i] = input[i] ^
                        ctx->keystream[ctx->keystream_used + i];
        }

        input += n;
        output += n;
        len -= n;
        ctx->keystream_used += n;
    }

    return 0;
}

/*
 * One-shot ChaCha20 encryption.
 *
 * Decryption uses exactly the same function because ChaCha20 is a stream
 * cipher.
 *
 * Return:
 *   0  success
 *  -1  invalid parameters
 *  -2  input length exceeds the remaining 32-bit counter space
 */
int chacha20_encrypt(const uint8_t key[CHACHA20_KEY_SIZE],
                     uint32_t counter,
                     const uint8_t nonce[CHACHA20_NONCE_SIZE],
                     const uint8_t *input,
                     uint8_t *output,
                     size_t len)
{
    chacha20_ctx ctx;
    uint64_t blocks_needed;
    uint64_t blocks_available;
    int ret;

    if (key == NULL || nonce == NULL)
        return -1;

    if (len != 0U && (input == NULL || output == NULL))
        return -1;

    /* ceil(len / 64), written without a possible uint64_t overflow. */
    blocks_needed = ((uint64_t)len / CHACHA20_BLOCK_SIZE) +
                    (((uint64_t)len % CHACHA20_BLOCK_SIZE) != 0U);

    blocks_available = (uint64_t)UINT32_MAX -
                       (uint64_t)counter + 1ULL;

    if (blocks_needed > blocks_available)
        return -2;

    ret = chacha20_init(&ctx, key, nonce, counter);
    if (ret != 0)
        return ret;

    ret = chacha20_crypt(&ctx, input, output, len);

    memset(&ctx, 0, sizeof(ctx));
    return ret;
}

/* Alias for readability at call sites. */
int chacha20_decrypt(const uint8_t key[CHACHA20_KEY_SIZE],
                     uint32_t counter,
                     const uint8_t nonce[CHACHA20_NONCE_SIZE],
                     const uint8_t *input,
                     uint8_t *output,
                     size_t len)
{
    return chacha20_encrypt(key, counter, nonce, input, output, len);
}

#ifdef CHACHA20_TEST

#include <stdio.h>

static void print_hex(const char *name, const uint8_t *p, size_t len)
{
    size_t i;

    printf("%s", name);
    for (i = 0; i < len; ++i)
        printf("%02x", p[i]);
    putchar('\n');
}

/* RFC 8439 Section 2.4.2 test vector. */
static int test_rfc8439_vector(void)
{
    static const uint8_t key[32] = {
        0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
        0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,
        0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,
        0x18,0x19,0x1a,0x1b,0x1c,0x1d,0x1e,0x1f
    };

    /* RFC 8439 Section 2.4.2 encryption vector nonce. */
    static const uint8_t nonce[12] = {
        0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x4a,
        0x00,0x00,0x00,0x00
    };

    static const uint8_t plaintext[] =
        "Ladies and Gentlemen of the class of '99: If I could offer you "
        "only one tip for the future, sunscreen would be it.";

    static const uint8_t expected[114] = {
        0x6e,0x2e,0x35,0x9a,0x25,0x68,0xf9,0x80,
        0x41,0xba,0x07,0x28,0xdd,0x0d,0x69,0x81,
        0xe9,0x7e,0x7a,0xec,0x1d,0x43,0x60,0xc2,
        0x0a,0x27,0xaf,0xcc,0xfd,0x9f,0xae,0x0b,
        0xf9,0x1b,0x65,0xc5,0x52,0x47,0x33,0xab,
        0x8f,0x59,0x3d,0xab,0xcd,0x62,0xb3,0x57,
        0x16,0x39,0xd6,0x24,0xe6,0x51,0x52,0xab,
        0x8f,0x53,0x0c,0x35,0x9f,0x08,0x61,0xd8,
        0x07,0xca,0x0d,0xbf,0x50,0x0d,0x6a,0x61,
        0x56,0xa3,0x8e,0x08,0x8a,0x22,0xb6,0x5e,
        0x52,0xbc,0x51,0x4d,0x16,0xcc,0xf8,0x06,
        0x81,0x8c,0xe9,0x1a,0xb7,0x79,0x37,0x36,
        0x5a,0xf9,0x0b,0xbf,0x74,0xa3,0x5b,0xe6,
        0xb4,0x0b,0x8e,0xed,0xf2,0x78,0x5e,0x42,
        0x87,0x4d
    };

    uint8_t ciphertext[sizeof(plaintext) - 1U];
    uint8_t recovered[sizeof(plaintext) - 1U];

    if (sizeof(ciphertext) != sizeof(expected)) {
        printf("[FAIL] RFC 8439 vector length mismatch\n");
        return -1;
    }

    if (chacha20_encrypt(key, 1U, nonce,
                         plaintext, ciphertext, sizeof(ciphertext)) != 0) {
        printf("[FAIL] RFC 8439 encryption returned error\n");
        return -1;
    }

    if (memcmp(ciphertext, expected, sizeof(expected)) != 0) {
        printf("[FAIL] RFC 8439 ciphertext mismatch\n");
        print_hex("actual  : ", ciphertext, sizeof(ciphertext));
        print_hex("expected: ", expected, sizeof(expected));
        return -1;
    }

    if (chacha20_decrypt(key, 1U, nonce,
                         ciphertext, recovered, sizeof(recovered)) != 0) {
        printf("[FAIL] RFC 8439 decryption returned error\n");
        return -1;
    }

    if (memcmp(recovered, plaintext, sizeof(recovered)) != 0) {
        printf("[FAIL] RFC 8439 plaintext recovery mismatch\n");
        return -1;
    }

    printf("[PASS] RFC 8439 ChaCha20 encryption/decryption vector\n");
    return 0;
}

static int test_block_vector(void)
{
    static const uint8_t key[32] = {
        0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
        0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,
        0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,
        0x18,0x19,0x1a,0x1b,0x1c,0x1d,0x1e,0x1f
    };

    static const uint8_t nonce[12] = {
        0x00,0x00,0x00,0x09,
        0x00,0x00,0x00,0x4a,
        0x00,0x00,0x00,0x00
    };

    static const uint8_t expected[64] = {
        0x10,0xf1,0xe7,0xe4,0xd1,0x3b,0x59,0x15,
        0x50,0x0f,0xdd,0x1f,0xa3,0x20,0x71,0xc4,
        0xc7,0xd1,0xf4,0xc7,0x33,0xc0,0x68,0x03,
        0x04,0x22,0xaa,0x9a,0xc3,0xd4,0x6c,0x4e,
        0xd2,0x82,0x64,0x46,0x07,0x9f,0xaa,0x09,
        0x14,0xc2,0xd7,0x05,0xd9,0x8b,0x02,0xa2,
        0xb5,0x12,0x9c,0xd1,0xde,0x16,0x4e,0xb9,
        0xcb,0xd0,0x83,0xe8,0xa2,0x50,0x3c,0x4e
    };

    uint8_t block[64];

    chacha20_block(key, 1U, nonce, block);

    if (memcmp(block, expected, sizeof(expected)) != 0) {
        printf("[FAIL] RFC 8439 block test vector\n");
        print_hex("actual  : ", block, sizeof(block));
        print_hex("expected: ", expected, sizeof(expected));
        return -1;
    }

    printf("[PASS] RFC 8439 ChaCha20 block vector\n");
    return 0;
}

static int test_streaming_equivalence(void)
{
    uint8_t key[32];
    uint8_t nonce[12];
    uint8_t input[257];
    uint8_t one_shot[257];
    uint8_t streaming[257];
    chacha20_ctx ctx;
    size_t i;
    size_t pos;
    int ret;

    for (i = 0; i < sizeof(key); ++i)
        key[i] = (uint8_t)i;

    for (i = 0; i < sizeof(nonce); ++i)
        nonce[i] = (uint8_t)(0xa0U + i);

    for (i = 0; i < sizeof(input); ++i)
        input[i] = (uint8_t)(i * 13U + 7U);

    ret = chacha20_encrypt(key, 7U, nonce,
                           input, one_shot, sizeof(input));
    if (ret != 0)
        return -1;

    ret = chacha20_init(&ctx, key, nonce, 7U);
    if (ret != 0)
        return -1;

    /* Deliberately split at non-block-aligned boundaries. */
    pos = 0;
    while (pos < sizeof(input)) {
        size_t n = 1U + ((pos * 17U) % 71U);
        if (n > sizeof(input) - pos)
            n = sizeof(input) - pos;

        ret = chacha20_crypt(&ctx, input + pos,
                             streaming + pos, n);
        if (ret != 0)
            return -1;

        pos += n;
    }

    if (memcmp(one_shot, streaming, sizeof(input)) != 0) {
        printf("[FAIL] streaming/one-shot mismatch\n");
        return -1;
    }

    printf("[PASS] streaming/one-shot equivalence\n");
    return 0;
}

int main(void)
{
    printf("============================================================\n");
    printf("                 ChaCha20 RFC 8439 TEST\n");
    printf("============================================================\n");

    if (test_block_vector() != 0)
        return 1;

    if (test_rfc8439_vector() != 0)
        return 1;

    if (test_streaming_equivalence() != 0)
        return 1;

    printf("============================================================\n");
    printf("ALL TESTS PASSED\n");
    printf("============================================================\n");

    return 0;
}

#endif /* CHACHA20_TEST */
