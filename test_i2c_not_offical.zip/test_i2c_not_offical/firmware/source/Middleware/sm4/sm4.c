#include <stdint.h>
#include <stddef.h>
#include <string.h>

#include "sm4.h"

#define SM4_BLOCK_SIZE 16

/* ---------- BE load/store ---------- */
static inline uint32_t GET_ULONG_BE(const uint8_t *b)
{
    return ((uint32_t)b[0] << 24) | ((uint32_t)b[1] << 16)
         | ((uint32_t)b[2] <<  8) | ((uint32_t)b[3]);
}
static inline void PUT_ULONG_BE(uint32_t n, uint8_t *b)
{
    b[0] = (uint8_t)(n >> 24); b[1] = (uint8_t)(n >> 16);
    b[2] = (uint8_t)(n >>  8); b[3] = (uint8_t)(n);
}
#define ROTL32(x, n) ((uint32_t)(((uint32_t)(x) << (n)) | \
                                 ((uint32_t)(x) >> (32U - (n)))))

/* ---------- SBOX ---------- */
static const uint8_t SboxTable[16][16] = {
    {0xd6,0x90,0xe9,0xfe,0xcc,0xe1,0x3d,0xb7,0x16,0xb6,0x14,0xc2,0x28,0xfb,0x2c,0x05},
    {0x2b,0x67,0x9a,0x76,0x2a,0xbe,0x04,0xc3,0xaa,0x44,0x13,0x26,0x49,0x86,0x06,0x99},
    {0x9c,0x42,0x50,0xf4,0x91,0xef,0x98,0x7a,0x33,0x54,0x0b,0x43,0xed,0xcf,0xac,0x62},
    {0xe4,0xb3,0x1c,0xa9,0xc9,0x08,0xe8,0x95,0x80,0xdf,0x94,0xfa,0x75,0x8f,0x3f,0xa6},
    {0x47,0x07,0xa7,0xfc,0xf3,0x73,0x17,0xba,0x83,0x59,0x3c,0x19,0xe6,0x85,0x4f,0xa8},
    {0x68,0x6b,0x81,0xb2,0x71,0x64,0xda,0x8b,0xf8,0xeb,0x0f,0x4b,0x70,0x56,0x9d,0x35},
    {0x1e,0x24,0x0e,0x5e,0x63,0x58,0xd1,0xa2,0x25,0x22,0x7c,0x3b,0x01,0x21,0x78,0x87},
    {0xd4,0x00,0x46,0x57,0x9f,0xd3,0x27,0x52,0x4c,0x36,0x02,0xe7,0xa0,0xc4,0xc8,0x9e},
    {0xea,0xbf,0x8a,0xd2,0x40,0xc7,0x38,0xb5,0xa3,0xf7,0xf2,0xce,0xf9,0x61,0x15,0xa1},
    {0xe0,0xae,0x5d,0xa4,0x9b,0x34,0x1a,0x55,0xad,0x93,0x32,0x30,0xf5,0x8c,0xb1,0xe3},
    {0x1d,0xf6,0xe2,0x2e,0x82,0x66,0xca,0x60,0xc0,0x29,0x23,0xab,0x0d,0x53,0x4e,0x6f},
    {0xd5,0xdb,0x37,0x45,0xde,0xfd,0x8e,0x2f,0x03,0xff,0x6a,0x72,0x6d,0x6c,0x5b,0x51},
    {0x8d,0x1b,0xaf,0x92,0xbb,0xdd,0xbc,0x7f,0x11,0xd9,0x5c,0x41,0x1f,0x10,0x5a,0xd8},
    {0x0a,0xc1,0x31,0x88,0xa5,0xcd,0x7b,0xbd,0x2d,0x74,0xd0,0x12,0xb8,0xe5,0xb4,0xb0},
    {0x89,0x69,0x97,0x4a,0x0c,0x96,0x77,0x7e,0x65,0xb9,0xf1,0x09,0xc5,0x6e,0xc6,0x84},
    {0x18,0xf0,0x7d,0xec,0x3a,0xdc,0x4d,0x20,0x79,0xee,0x5f,0x3e,0xd7,0xcb,0x39,0x48}
};
static const uint32_t FK[4] = {0xa3b1bac6,0x56aa3350,0x677d9197,0xb27022dc};
static const uint32_t CK[32] = {
    0x00070e15,0x1c232a31,0x383f464d,0x545b6269,
    0x70777e85,0x8c939aa1,0xa8afb6bd,0xc4cbd2d9,
    0xe0e7eef5,0xfc030a11,0x181f262d,0x343b4249,
    0x50575e65,0x6c737a81,0x888f969d,0xa4abb2b9,
    0xc0c7ced5,0xdce3eaf1,0xf8ff060d,0x141b2229,
    0x30373e45,0x4c535a61,0x686f767d,0x848b9299,
    0xa0a7aeb5,0xbcc3cad1,0xd8dfe6ed,0xf4fb0209,
    0x10171e25,0x2c333a41,0x484f565d,0x646b7279
};

/* ---------- T ---------- */
static inline uint32_t sm4_tau(uint32_t x)
{
    uint8_t b0 = (uint8_t)(x >> 24), b1 = (uint8_t)(x >> 16);
    uint8_t b2 = (uint8_t)(x >>  8), b3 = (uint8_t)(x      );
    b0 = SboxTable[b0 >> 4][b0 & 0x0F];
    b1 = SboxTable[b1 >> 4][b1 & 0x0F];
    b2 = SboxTable[b2 >> 4][b2 & 0x0F];
    b3 = SboxTable[b3 >> 4][b3 & 0x0F];
    return ((uint32_t)b0 << 24) | ((uint32_t)b1 << 16)
         | ((uint32_t)b2 <<  8) | ((uint32_t)b3);
}
static inline uint32_t sm4_T(uint32_t x)
{
    uint32_t b = sm4_tau(x);
    return b ^ ROTL32(b,2) ^ ROTL32(b,10) ^ ROTL32(b,18) ^ ROTL32(b,24);
}
static inline uint32_t sm4_T_key(uint32_t x)
{
    uint32_t b = sm4_tau(x);
    return b ^ ROTL32(b,13) ^ ROTL32(b,23);
}
static inline uint32_t sm4_F(uint32_t x0, uint32_t x1, uint32_t x2,
                             uint32_t x3, uint32_t rk)
{
    return x0 ^ sm4_T(x1 ^ x2 ^ x3 ^ rk);
}

static void sm4_setkey(uint32_t SK[32], const uint8_t key[16])
{
    uint32_t K[36];
    K[0] = GET_ULONG_BE(key + 0) ^ FK[0];
    K[1] = GET_ULONG_BE(key + 4) ^ FK[1];
    K[2] = GET_ULONG_BE(key + 8) ^ FK[2];
    K[3] = GET_ULONG_BE(key +12) ^ FK[3];
    for (int i = 0; i < 32; i++) {
        K[i+4] = K[i] ^ sm4_T_key(K[i+1] ^ K[i+2] ^ K[i+3] ^ CK[i]);
        SK[i]  = K[i+4];
    }
}

void sm4_encrypt_block(const uint32_t sk[32], const uint8_t in[16], uint8_t out[16])
{
    uint32_t X[36];
    X[0] = GET_ULONG_BE(in + 0);
    X[1] = GET_ULONG_BE(in + 4);
    X[2] = GET_ULONG_BE(in + 8);
    X[3] = GET_ULONG_BE(in +12);
    for (int i = 0; i < 32; i++)
        X[i+4] = sm4_F(X[i], X[i+1], X[i+2], X[i+3], sk[i]);
    PUT_ULONG_BE(X[35], out + 0);
    PUT_ULONG_BE(X[34], out + 4);
    PUT_ULONG_BE(X[33], out + 8);
    PUT_ULONG_BE(X[32], out +12);
}

void sm4_setkey_enc(sm4_ctx *ctx, const uint8_t key[16])
{
    if (!ctx || !key) return;
    memset(ctx, 0, sizeof(*ctx));
    ctx->mode = SM4_ENCRYPT;
    sm4_setkey(ctx->sk, key);
}
void sm4_setkey_dec(sm4_ctx *ctx, const uint8_t key[16])
{
    if (!ctx || !key) return;
    memset(ctx, 0, sizeof(*ctx));
    ctx->mode = SM4_DECRYPT;
    sm4_setkey(ctx->sk, key);
    for (int i = 0; i < 16; i++) {
        uint32_t t = ctx->sk[i];
        ctx->sk[i] = ctx->sk[31-i];
        ctx->sk[31-i] = t;
    }
}

/* ---------- ECB ---------- */
int sm4_ecb(sm4_ctx *ctx, int32_t mode,
            const uint8_t *in, size_t inlen, uint8_t *out)
{
    (void)mode;
    if (!ctx || !in || !out) return SM4_ERR_PARAM;
    if (inlen % SM4_BLOCK_SIZE) return SM4_ERR_LEN;
    while (inlen >= SM4_BLOCK_SIZE) {
        sm4_encrypt_block(ctx->sk, in, out);
        in += 16; out += 16; inlen -= 16;
    }
    return SM4_OK;
}

/* ---------- CBC ---------- */
int sm4_cbc(sm4_ctx *ctx, int32_t mode, uint8_t iv[16],
            const uint8_t *in, size_t inlen, uint8_t *out)
{
    (void)mode;
    if (!ctx || !iv || !in || !out) return SM4_ERR_PARAM;
    if (inlen % SM4_BLOCK_SIZE) return SM4_ERR_LEN;
    if (ctx->mode == SM4_ENCRYPT) {
        while (inlen >= 16) {
            for (int i = 0; i < 16; i++) out[i] = in[i] ^ iv[i];
            sm4_encrypt_block(ctx->sk, out, out);
            memcpy(iv, out, 16);
            in += 16; out += 16; inlen -= 16;
        }
    } else if (ctx->mode == SM4_DECRYPT) {
        uint8_t temp[16];
        while (inlen >= 16) {
            memcpy(temp, in, 16);
            sm4_encrypt_block(ctx->sk, in, out);
            for (int i = 0; i < 16; i++) out[i] ^= iv[i];
            memcpy(iv, temp, 16);
            in += 16; out += 16; inlen -= 16;
        }
    } else return SM4_ERR_STATE;
    return SM4_OK;
}

/* ---------- CTR ---------- */
static void sm4_ctr_increment(uint8_t c[16])
{
    for (int i = 15; i >= 0; i--) if (++c[i] != 0) break;
}
int sm4_ctr_init(sm4_ctx *ctx, const uint8_t key[16], const uint8_t iv[16])
{
    if (!ctx || !key || !iv) return SM4_ERR_PARAM;
    memset(ctx, 0, sizeof(*ctx));
    sm4_setkey_enc(ctx, key);
    memcpy(ctx->counter, iv, 16);
    return SM4_OK;
}
int sm4_ctr_update(sm4_ctx *ctx, const uint8_t *in, size_t inlen, uint8_t *out)
{
    if (!ctx) return SM4_ERR_PARAM;
    if (inlen == 0) return SM4_OK;
    if (!in || !out) return SM4_ERR_PARAM;
    uint32_t n = ctx->unprocessed_len;
    if (n > 15) return SM4_ERR_STATE;
    while (inlen > 0) {
        if (n == 0) {
            sm4_encrypt_block(ctx->sk, ctx->counter, ctx->unprocessed_data);
            sm4_ctr_increment(ctx->counter);
        }
        size_t avail = 16U - n;
        size_t todo = inlen < avail ? inlen : avail;
        for (size_t i = 0; i < todo; i++)
            out[i] = in[i] ^ ctx->unprocessed_data[n + i];
        in += todo; out += todo; inlen -= todo;
        n += (uint32_t)todo;
        if (n == 16) n = 0;
    }
    ctx->unprocessed_len = n;
    return SM4_OK;
}
int sm4_ctr_final(sm4_ctx *ctx) { (void)ctx; return SM4_OK; }

void cap_sm4_ctr_enc(uint8_t key[16], uint8_t iv[16],
                     uint8_t *in, uint32_t len, uint8_t *out)
{
    sm4_ctx c;
    if (!key||!iv||!in||!out) return;
    if (sm4_ctr_init(&c,key,iv)!=SM4_OK) return;
    (void)sm4_ctr_update(&c,in,(size_t)len,out);
}
void cap_sm4_ctr_dec(uint8_t key[16], uint8_t iv[16],
                     uint8_t *in, uint32_t len, uint8_t *out)
{ cap_sm4_ctr_enc(key,iv,in,len,out); }
void cap_sm4_ctr_enc_local(uint8_t key[16], uint8_t iv[16],
                           uint8_t *in, uint32_t len, uint8_t *out)
{ cap_sm4_ctr_enc(key,iv,in,len,out); }
void cap_sm4_ctr_dec_local(uint8_t key[16], uint8_t iv[16],
                           uint8_t *in, uint32_t len, uint8_t *out)
{ cap_sm4_ctr_enc(key,iv,in,len,out); }

/* ---------- CFB128 ---------- */
int sm4_cfb128_encrypt(sm4_ctx *ctx, uint8_t iv[16],
                       const uint8_t *in, size_t inlen, uint8_t *out)
{
    if (!ctx||!iv||!in||!out) return SM4_ERR_PARAM;
    uint8_t ks[16];
    while (inlen > 0) {
        sm4_encrypt_block(ctx->sk, iv, ks);
        size_t todo = inlen < 16 ? inlen : 16;
        for (size_t i = 0; i < todo; i++) out[i] = in[i] ^ ks[i];
        memcpy(iv, out, todo);
        in += todo; out += todo; inlen -= todo;
    }
    return SM4_OK;
}
int sm4_cfb128_decrypt(sm4_ctx *ctx, uint8_t iv[16],
                       const uint8_t *in, size_t inlen, uint8_t *out)
{
    if (!ctx||!iv||!in||!out) return SM4_ERR_PARAM;
    uint8_t ks[16], c[16];
    while (inlen > 0) {
        sm4_encrypt_block(ctx->sk, iv, ks);
        size_t todo = inlen < 16 ? inlen : 16;
        memcpy(c, in, todo);
        for (size_t i = 0; i < todo; i++) out[i] = in[i] ^ ks[i];
        memcpy(iv, c, todo);
        in += todo; out += todo; inlen -= todo;
    }
    return SM4_OK;
}

/* ---------- OFB ---------- */
int sm4_ofb_xor(sm4_ctx *ctx, uint8_t iv[16],
                const uint8_t *in, size_t inlen, uint8_t *out)
{
    if (!ctx||!iv||!in||!out) return SM4_ERR_PARAM;
    while (inlen > 0) {
        sm4_encrypt_block(ctx->sk, iv, iv);
        size_t todo = inlen < 16 ? inlen : 16;
        for (size_t i = 0; i < todo; i++) out[i] = in[i] ^ iv[i];
        in += todo; out += todo; inlen -= todo;
    }
    return SM4_OK;
}

/* ---------- GCM ---------- */
static void gf128_mul(uint8_t Z[16], const uint8_t X[16], const uint8_t Y[16])
{
    uint8_t V[16], Zt[16];
    memset(Zt, 0, 16);
    memcpy(V, Y, 16);
    for (int i = 0; i < 128; i++) {
        int bit = (X[i >> 3] >> (7 - (i & 7))) & 1;
        if (bit) for (int j = 0; j < 16; j++) Zt[j] ^= V[j];
        int lsb = V[15] & 1;
        for (int j = 15; j > 0; j--)
            V[j] = (uint8_t)((V[j] >> 1) | (V[j-1] << 7));
        V[0] >>= 1;
        if (lsb) V[0] ^= 0xE1;
    }
    memcpy(Z, Zt, 16);
}
static void ghash_block(uint8_t S[16], const uint8_t H[16], const uint8_t b[16])
{
    for (int i = 0; i < 16; i++) S[i] ^= b[i];
    uint8_t Z[16];
    gf128_mul(Z, S, H);
    memcpy(S, Z, 16);
}
static void ghash_bytes(uint8_t S[16], const uint8_t H[16],
                        const uint8_t *d, size_t n)
{
    while (n >= 16) { ghash_block(S, H, d); d += 16; n -= 16; }
    if (n) { uint8_t b[16] = {0}; memcpy(b, d, n); ghash_block(S, H, b); }
}
static void gcm_inc32(uint8_t c[16])
{
    for (int i = 15; i >= 12; i--) if (++c[i] != 0) break;
}
static void gcm_lenblk(uint8_t out[16], uint64_t a, uint64_t m)
{
    for (int i = 0; i < 8; i++) {
        out[i]   = (uint8_t)(a >> (56 - 8*i));
        out[8+i] = (uint8_t)(m >> (56 - 8*i));
    }
}

int sm4_gcm_init(sm4_gcm_ctx *g, const uint8_t key[16],
                 const uint8_t *iv, size_t ivlen)
{
    if (!g || !key || (!iv && ivlen)) return SM4_ERR_PARAM;
    memset(g, 0, sizeof(*g));
    sm4_setkey_enc(&g->sm4, key);
    uint8_t zero[16] = {0};
    sm4_encrypt_block(g->sm4.sk, zero, g->H);
    if (ivlen == 12) {
        memcpy(g->J0, iv, 12);
        g->J0[12]=0; g->J0[13]=0; g->J0[14]=0; g->J0[15]=1;
    } else {
        memset(g->S, 0, 16);
        ghash_bytes(g->S, g->H, iv, ivlen);
        uint8_t lb[16];
        gcm_lenblk(lb, 0, (uint64_t)ivlen * 8);
        ghash_block(g->S, g->H, lb);
        memcpy(g->J0, g->S, 16);
        memset(g->S, 0, 16);
    }
    g->state = 1;
    return SM4_OK;
}

int sm4_gcm_aad(sm4_gcm_ctx *g, const uint8_t *aad, size_t aadlen)
{
    if (!g) return SM4_ERR_PARAM;
    if (g->state != 1) return SM4_ERR_STATE;
    if (aadlen == 0) return SM4_OK;
    if (!aad) return SM4_ERR_PARAM;
    ghash_bytes(g->S, g->H, aad, aadlen);
    g->aad_len += aadlen;
    return SM4_OK;
}

int sm4_gcm_update(sm4_gcm_ctx *g, const uint8_t *in, size_t inlen, uint8_t *out)
{
    if (!g) return SM4_ERR_PARAM;
    if (g->state == 1) {
        g->state = 2;
        memcpy(g->E, g->J0, 16);
        gcm_inc32(g->E);
        g->keystream_pos = 0;
        g->ghash_pos = 0;
    }
    if (g->state != 2) return SM4_ERR_STATE;
    if (inlen == 0) return SM4_OK;
    if (!in || !out) return SM4_ERR_PARAM;

    while (inlen > 0) {
        if (g->keystream_pos == 0) {
            /* 修复: 原实现 sm4_encrypt_block(..., g->E, g->E) 原地覆盖后
             * gcm_inc32 递增的是密钥流而非计数器, 计数器链丢失,
             * 第2块起 keystream = Enc(Enc(J0+1)+1) 非标准 GCM。
             * 现在 E 只做计数器, 密钥流放独立 ks 缓冲 */
            sm4_encrypt_block(g->sm4.sk, g->E, g->ks);
            gcm_inc32(g->E);
        }
        size_t avail = 16 - g->keystream_pos;
        size_t todo = inlen < avail ? inlen : avail;
        for (size_t i = 0; i < todo; i++)
            out[i] = in[i] ^ g->ks[g->keystream_pos + i];

        /* GHASH 密文 */
        const uint8_t *ct = g->enc ? out : in;
        for (size_t i = 0; i < todo; i++) {
            g->ghash_buf[g->ghash_pos++] = ct[i];
            if (g->ghash_pos == 16) {
                ghash_block(g->S, g->H, g->ghash_buf);
                g->ghash_pos = 0;
            }
        }

        in += todo; out += todo; inlen -= todo;
        g->keystream_pos += (uint32_t)todo;
        if (g->keystream_pos == 16) g->keystream_pos = 0;
        g->msg_len += todo;
    }
    return SM4_OK;
}

int sm4_gcm_final(sm4_gcm_ctx *g, uint8_t tag[16])
{
    if (!g || !tag) return SM4_ERR_PARAM;
    if (g->state == 1) {
        /* 没有任何 update，直接给 J0 加密 */
        g->state = 2;
    }
    if (g->state != 2) return SM4_ERR_STATE;

    /* 残余 GHASH 块 */
    if (g->ghash_pos > 0) {
        uint8_t b[16] = {0};
        memcpy(b, g->ghash_buf, g->ghash_pos);
        ghash_block(g->S, g->H, b);
        g->ghash_pos = 0;
    }
    /* 长度块 */
    uint8_t lb[16];
    gcm_lenblk(lb, (uint64_t)g->aad_len * 8, (uint64_t)g->msg_len * 8);
    ghash_block(g->S, g->H, lb);

    uint8_t Ek[16];
    sm4_encrypt_block(g->sm4.sk, g->J0, Ek);
    for (int i = 0; i < 16; i++) tag[i] = Ek[i] ^ g->S[i];
    g->state = 3;
    return SM4_OK;
}

int sm4_gcm_encrypt(const uint8_t key[16], const uint8_t *iv, size_t ivlen,
                    const uint8_t *aad, size_t aadlen,
                    const uint8_t *in, size_t inlen,
                    uint8_t *out, uint8_t tag[16])
{
    sm4_gcm_ctx g;
    if (sm4_gcm_init(&g, key, iv, ivlen) != SM4_OK) return SM4_ERR_PARAM;
    g.enc = 1;
    if (aadlen && sm4_gcm_aad(&g, aad, aadlen) != SM4_OK) return SM4_ERR_PARAM;
    if (inlen && sm4_gcm_update(&g, in, inlen, out) != SM4_OK) return SM4_ERR_PARAM;
    return sm4_gcm_final(&g, tag);
}

int sm4_gcm_decrypt(const uint8_t key[16], const uint8_t *iv, size_t ivlen,
                    const uint8_t *aad, size_t aadlen,
                    const uint8_t *in, size_t inlen,
                    uint8_t *out, const uint8_t tag[16])
{
    sm4_gcm_ctx g;
    uint8_t t[16];
    if (sm4_gcm_init(&g, key, iv, ivlen) != SM4_OK) return SM4_ERR_PARAM;
    g.enc = 0;
    if (aadlen && sm4_gcm_aad(&g, aad, aadlen) != SM4_OK) return SM4_ERR_PARAM;
    if (inlen && sm4_gcm_update(&g, in, inlen, out) != SM4_OK) return SM4_ERR_PARAM;
    if (sm4_gcm_final(&g, t) != SM4_OK) return SM4_ERR_PARAM;
    if (memcmp(t, tag, 16) != 0) return SM4_ERR_AUTH;
    return SM4_OK;
}

/* ---------- CMAC ---------- */
static void cmac_dbl(uint8_t out[16], const uint8_t in[16])
{
    int msb = in[0] >> 7;
    for (int i = 0; i < 15; i++)
        out[i] = (uint8_t)((in[i] << 1) | (in[i+1] >> 7));
    out[15] = (uint8_t)(in[15] << 1);
    if (msb) out[15] ^= 0x87;
}

int sm4_cmac_init(sm4_cmac_ctx *c, const uint8_t key[16])
{
    if (!c || !key) return SM4_ERR_PARAM;
    memset(c, 0, sizeof(*c));
    sm4_setkey_enc(&c->sm4, key);
    uint8_t L[16], zero[16] = {0};
    sm4_encrypt_block(c->sm4.sk, zero, L);
    cmac_dbl(c->K1, L);
    cmac_dbl(c->K2, c->K1);
    return SM4_OK;
}

int sm4_cmac_update(sm4_cmac_ctx *c, const uint8_t *in, size_t inlen)
{
    if (!c) return SM4_ERR_PARAM;
    if (inlen == 0) return SM4_OK;
    if (!in) return SM4_ERR_PARAM;

    c->total += inlen;
    while (inlen > 0) {
        if (c->buflen == 16) {
            for (int i = 0; i < 16; i++) c->X[i] ^= c->buf[i];
            sm4_encrypt_block(c->sm4.sk, c->X, c->X);
            c->buflen = 0;
        }
        size_t take = 16 - c->buflen;
        if (take > inlen) take = inlen;
        memcpy(c->buf + c->buflen, in, take);
        c->buflen += take;
        in += take; inlen -= take;
    }
    return SM4_OK;
}

int sm4_cmac_final(sm4_cmac_ctx *c, uint8_t mac[16])
{
    if (!c || !mac) return SM4_ERR_PARAM;
    uint8_t last[16];
    if (c->buflen == 16) {
        /* 满块，用 K1 */
        for (int i = 0; i < 16; i++) last[i] = c->buf[i] ^ c->K1[i];
    } else {
        /* 不足块：补 0x80 0x00...，用 K2 */
        memset(last, 0, 16);
        memcpy(last, c->buf, c->buflen);
        last[c->buflen] = 0x80;
        for (int i = 0; i < 16; i++) last[i] ^= c->K2[i];
    }
    for (int i = 0; i < 16; i++) c->X[i] ^= last[i];
    sm4_encrypt_block(c->sm4.sk, c->X, mac);
    return SM4_OK;
}

/* ---------- PKCS#7 ---------- */
size_t sm4_pkcs7_pad(const uint8_t *in, size_t inlen, uint8_t *out)
{
    size_t pad = 16 - (inlen % 16);
    if (in) memcpy(out, in, inlen);
    memset(out + inlen, (int)pad, pad);
    return inlen + pad;
}
size_t sm4_pkcs7_unpad(const uint8_t *in, size_t inlen)
{
    if (inlen == 0 || inlen % 16) return (size_t)-1;
    uint8_t pad = in[inlen - 1];
    if (pad == 0 || pad > 16) return (size_t)-1;
    for (size_t i = 0; i < pad; i++)
        if (in[inlen - 1 - i] != pad) return (size_t)-1;
    return inlen - pad;
}