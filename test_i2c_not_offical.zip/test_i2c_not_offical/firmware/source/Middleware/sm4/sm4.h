/*
 * sm4.h — SM4 + ECB / CBC / CTR / CFB128 / OFB / GCM / CMAC
 * 依赖：仅标准 C 库。GCM 的 GHASH 为 GF(2^128) 乘法，与 SM3 无关。
 */
#ifndef SM4_H
#define SM4_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SM4_OK          0
#define SM4_ERR_PARAM  (-1)
#define SM4_ERR_LEN    (-2)
#define SM4_ERR_AUTH   (-3)
#define SM4_ERR_STATE  (-4)

#define SM4_ENCRYPT   0
#define SM4_DECRYPT   1

typedef struct {
    int32_t  mode;
    uint32_t sk[32];
    uint8_t  unprocessed_data[16];
    uint32_t unprocessed_len;
    uint8_t  counter[16];
} sm4_ctx;

/* 基础 */
void sm4_setkey_enc(sm4_ctx *ctx, const uint8_t key[16]);
void sm4_setkey_dec(sm4_ctx *ctx, const uint8_t key[16]);
void sm4_encrypt_block(const uint32_t sk[32], const uint8_t in[16], uint8_t out[16]);

/* ECB */
int sm4_ecb(sm4_ctx *ctx, int32_t mode,
            const uint8_t *in, size_t inlen, uint8_t *out);

/* CBC */
int sm4_cbc(sm4_ctx *ctx, int32_t mode, uint8_t iv[16],
            const uint8_t *in, size_t inlen, uint8_t *out);

/* CTR */
int  sm4_ctr_init  (sm4_ctx *ctx, const uint8_t key[16], const uint8_t iv[16]);
int  sm4_ctr_update(sm4_ctx *ctx, const uint8_t *in, size_t inlen, uint8_t *out);
int  sm4_ctr_final (sm4_ctx *ctx);
void cap_sm4_ctr_enc(uint8_t key[16], uint8_t iv[16], uint8_t *in, uint32_t len, uint8_t *out);
void cap_sm4_ctr_dec(uint8_t key[16], uint8_t iv[16], uint8_t *in, uint32_t len, uint8_t *out);
void cap_sm4_ctr_enc_local(uint8_t key[16], uint8_t iv[16], uint8_t *in, uint32_t len, uint8_t *out);
void cap_sm4_ctr_dec_local(uint8_t key[16], uint8_t iv[16], uint8_t *in, uint32_t len, uint8_t *out);

/* CFB128 */
int sm4_cfb128_encrypt(sm4_ctx *ctx, uint8_t iv[16],
                       const uint8_t *in, size_t inlen, uint8_t *out);
int sm4_cfb128_decrypt(sm4_ctx *ctx, uint8_t iv[16],
                       const uint8_t *in, size_t inlen, uint8_t *out);

/* OFB */
int sm4_ofb_xor(sm4_ctx *ctx, uint8_t iv[16],
                const uint8_t *in, size_t inlen, uint8_t *out);

/* GCM */
typedef struct {
    sm4_ctx  sm4;
    uint8_t  H[16];
    uint8_t  J0[16];
    uint8_t  S[16];
    uint8_t  E[16];        /* CTR 计数器 (每块后 inc32) */
    uint8_t  ks[16];       /* 当前密钥流块 = Enc(E), 与计数器分离 */
    uint8_t  ghash_buf[16];
    size_t   aad_len;
    size_t   msg_len;
    uint32_t keystream_pos;
    uint32_t ghash_pos;
    int      enc;      /* 1=加密 0=解密 */
    int      state;    /* 1=aad 2=msg 3=final */
} sm4_gcm_ctx;

int sm4_gcm_init  (sm4_gcm_ctx *g, const uint8_t key[16],
                   const uint8_t *iv, size_t ivlen);
int sm4_gcm_aad   (sm4_gcm_ctx *g, const uint8_t *aad, size_t aadlen);
int sm4_gcm_update(sm4_gcm_ctx *g, const uint8_t *in, size_t inlen, uint8_t *out);
int sm4_gcm_final (sm4_gcm_ctx *g, uint8_t tag[16]);

int sm4_gcm_encrypt(const uint8_t key[16], const uint8_t *iv, size_t ivlen,
                    const uint8_t *aad, size_t aadlen,
                    const uint8_t *in, size_t inlen,
                    uint8_t *out, uint8_t tag[16]);
int sm4_gcm_decrypt(const uint8_t key[16], const uint8_t *iv, size_t ivlen,
                    const uint8_t *aad, size_t aadlen,
                    const uint8_t *in, size_t inlen,
                    uint8_t *out, const uint8_t tag[16]);

/* CMAC */
typedef struct {
    sm4_ctx  sm4;
    uint8_t  K1[16];
    uint8_t  K2[16];
    uint8_t  X[16];
    uint8_t  buf[16];
    size_t   buflen;
    size_t   total;
} sm4_cmac_ctx;

int sm4_cmac_init  (sm4_cmac_ctx *c, const uint8_t key[16]);
int sm4_cmac_update(sm4_cmac_ctx *c, const uint8_t *in, size_t inlen);
int sm4_cmac_final (sm4_cmac_ctx *c, uint8_t mac[16]);

/* PKCS#7 */
size_t sm4_pkcs7_pad  (const uint8_t *in, size_t inlen, uint8_t *out);
size_t sm4_pkcs7_unpad(const uint8_t *in, size_t inlen);

#ifdef __cplusplus
}
#endif
#endif /* SM4_H */