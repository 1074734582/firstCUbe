#ifndef ECDSA_H
#define ECDSA_H
#include <stdint.h>
#include <stddef.h>

#define BN_WORDS 12

typedef struct { uint64_t w[BN_WORDS]; } bn_t;
typedef struct { bn_t x, y, z; } ec_point;
typedef struct {
    bn_t p, a, b, n, gx, gy;
    int bits;
    int nbytes;
} ec_curve;
typedef struct { bn_t r, s; } ecdsa_sig;
typedef struct { bn_t d, Qx, Qy; } ecdsa_key;

/* ===== BN =====
 * 契约：
 *  - bn_mod_add / bn_mod_sub 要求 a, b 均已归约到 [0, m)；未归约时结果未定义。
 *  - bn_to_bytes / bn_from_bytes 对 len 做了范围保护：
 *      * len > BN_WORDS*8 时，bn_to_bytes 高位补零，bn_from_bytes 忽略高位。
 *      * 越界 limb 不会被访问。
 *  - 所有 _mod_* 函数要求 m != 0。
 */
void bn_zero(bn_t *r);
void bn_set_u64(bn_t *r, uint64_t v);
int  bn_is_zero(const bn_t *a);
int  bn_cmp(const bn_t *a, const bn_t *b);
void bn_add(bn_t *r, const bn_t *a, const bn_t *b);
void bn_sub(bn_t *r, const bn_t *a, const bn_t *b);
int  bn_bit(const bn_t *a, int i);
void bn_mod_add(bn_t *r, const bn_t *a, const bn_t *b, const bn_t *m);
void bn_mod_sub(bn_t *r, const bn_t *a, const bn_t *b, const bn_t *m);
void bn_mod_mul(bn_t *r, const bn_t *a, const bn_t *b, const bn_t *m);
void bn_mod_inv(bn_t *r, const bn_t *a, const bn_t *m);
void bn_from_bytes(bn_t *r, const uint8_t *src, size_t len);
void bn_to_bytes(uint8_t *dst, const bn_t *a, size_t len);

/* ===== EC =====
 * 契约：
 *  - ec_scalar_mul / ec_scalar_mul_ct 不验证输入点 P 在曲线上；调用方负责。
 */
const ec_curve *ec_p256(void);
const ec_curve *ec_p384(void);
void ec_point_set_infinity(ec_point *P);
int  ec_point_is_infinity(const ec_point *P);
void ec_point_double(ec_point *R, const ec_point *P, const ec_curve *c);
void ec_point_add(ec_point *R, const ec_point *P, const ec_point *Q, const ec_curve *c);
void ec_point_to_affine(bn_t *x, bn_t *y, const ec_point *P, const ec_curve *c);
void ec_scalar_mul(ec_point *R, const bn_t *k, const ec_point *P, const ec_curve *c);
void ec_scalar_mul_ct(ec_point *R, const bn_t *k, const ec_point *P, const ec_curve *c);

/* ===== ECDSA =====
 *  - ecdsa_keygen 从 /dev/urandom 读 nbytes 字节并做子群自检。
 *  - ecdsa_sign 的 fixed_k：
 *      * NULL    → 走 RFC 6979（HMAC-DRBG），需要 sha.h 提供 SHA-256/384
 *      * 非 NULL → 使用固定 k（测试/确定性场景）
 *  - ecdsa_verify 会校验 Q 在曲线上、0 < r,s < n。
 */
int ecdsa_keygen(ecdsa_key *key, const ec_curve *c);
int ecdsa_sign(ecdsa_sig *sig, const uint8_t *hash, size_t hash_len,
               const ecdsa_key *key, const ec_curve *c, const bn_t *fixed_k);
int ecdsa_verify(const ecdsa_sig *sig, const uint8_t *hash, size_t hash_len,
                 const ecdsa_key *key, const ec_curve *c);

/* ===== SEC1 point encoding ===== */
int ecdsa_pubkey_encode(uint8_t *out, const ecdsa_key *key, const ec_curve *c);
int ecdsa_pubkey_decode(ecdsa_key *key, const uint8_t *in, size_t in_len, const ec_curve *c);
int ecdsa_pubkey_encode_compressed(uint8_t *out, const ecdsa_key *key, const ec_curve *c);
int ecdsa_pubkey_decode_compressed(ecdsa_key *key, const uint8_t *in, size_t in_len, const ec_curve *c);

/* ===== DER signature encoding ===== */
int ecdsa_sig_encode_der(uint8_t *out, const ecdsa_sig *sig, const ec_curve *c);
int ecdsa_sig_decode_der(ecdsa_sig *sig, const uint8_t *in, size_t in_len, const ec_curve *c);

#endif
