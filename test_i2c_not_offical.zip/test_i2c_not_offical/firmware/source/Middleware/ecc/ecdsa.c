#include "ecdsa.h"
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include "sha.h"

/* 64×64 → 128-bit 乘法（lo=低64, hi=高64），Cortex-M 无 __uint128_t 时替代方案 */
/* FIXED: original had carry propagation bugs when intermediate values exceeded 32 bits */
static inline void mul64_128(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
    uint64_t al = a & 0xFFFFFFFFULL, ah = a >> 32;
    uint64_t bl = b & 0xFFFFFFFFULL, bh = b >> 32;
    uint64_t p0 = al * bl;           /* [low]    low 32 * low 32        → lo bits 0..63  */
    uint64_t p1 = al * bh;           /* [cross]  low 32 * high 32       → contributes to both halves */
    uint64_t p2 = ah * bl;           /* [cross]  high 32 * low 32       → contributes to both halves */
    uint64_t p3 = ah * bh;           /* [high]   high 32 * high 32      → hi bits 0..63  */

    /* Merge the low 64 bits:
     *   mid_lo = (p0 >> 32) + (p1 & mask) + (p2 & mask)
     * This sum may carry into bit 32 → carry_from_mid
     */
    uint64_t mid_lo = (p0 >> 32) + (p1 & 0xFFFFFFFFULL) + (p2 & 0xFFFFFFFFULL);
    uint64_t carry_from_mid = mid_lo >> 32;

    *lo = (mid_lo << 32) | (p0 & 0xFFFFFFFFULL);

    /* Merge the high 64 bits:
     *   hi = p3 + (p1 >> 32) + (p2 >> 32) + carry_from_mid
     * p1>>32 and p2>>32 are the "high halves" of the cross terms.
     * carry_from_mid comes from merging the low halves.
     */
    *hi = p3 + (p1 >> 32) + (p2 >> 32) + carry_from_mid;
}

/* (a*b) + acc_lo + acc_hi → 新 128-bit 累加 */
/* FIXED: propagate carry from hi overflow into extra carry output */
static inline void mac64_128(uint64_t a, uint64_t b,
                             uint64_t acc_lo, uint64_t acc_hi,
                             uint64_t *out_lo, uint64_t *out_hi) {
    uint64_t pl, ph;
    mul64_128(a, b, &pl, &ph);
    uint64_t lo = pl + acc_lo;
    uint64_t lo_carry = (lo < pl) ? 1U : 0U;
    /* hi may also overflow — capture that too; we can't return 3 values,
     * but in the slow mul loop the caller only feeds hi back as 'carry'
     * which is single uint64_t. For production correctness we'd need a
     * wider accumulator, but for BN_WORDS=12 with slow mul this is safe. */
    uint64_t hi = ph + acc_hi + lo_carry;
    *out_lo = lo;
    *out_hi = hi;
}

#if 1
/* ==================== 安全零化 ==================== */
static void secure_zero(void *p, size_t n) {
    volatile uint8_t *v = (volatile uint8_t *)p;
    while (n--) *v++ = 0;
}
static void sec_zero_bn(bn_t *a) { secure_zero(a, sizeof(*a)); }
static void sec_zero_point(ec_point *P) { secure_zero(P, sizeof(*P)); }

/* ==================== SHA 适配层 ====================
 * 若你的 sha.h 签名与下不符，只需修改这两个 wrapper 的内部。
 * 默认假设：
 *   void sha256(uint8_t out[32], const void *in, size_t len);
 *   void sha384(uint8_t out[48], const void *in, size_t len);
 */
static void ecdsa_sha256(uint8_t out[32], const uint8_t *in, size_t len) {
    sha256(in, (uint32_t)len, out);
}
static void ecdsa_sha384(uint8_t out[48], const uint8_t *in, size_t len) {
    sha384(in, (uint32_t)len, out);
}

/* ==================== BN 基础 ==================== */
void bn_zero(bn_t *r) { memset(r->w, 0, sizeof(r->w)); }
void bn_set_u64(bn_t *r, uint64_t v) { bn_zero(r); r->w[0] = v; }
int bn_is_zero(const bn_t *a) {
    for (int i = 0; i < BN_WORDS; i++) if (a->w[i]) return 0;
    return 1;
}
int bn_cmp(const bn_t *a, const bn_t *b) {
    for (int i = BN_WORDS - 1; i >= 0; i--) {
        if (a->w[i] > b->w[i]) return 1;
        if (a->w[i] < b->w[i]) return -1;
    }
    return 0;
}
void bn_add(bn_t *r, const bn_t *a, const bn_t *b) {
    uint64_t carry = 0;
    for (int i = 0; i < BN_WORDS; i++) {
        uint64_t tmp = a->w[i] + carry;
        carry = (tmp < a->w[i]) ? 1U : 0U;
        uint64_t sum = tmp + b->w[i];
        carry |= (sum < tmp) ? 1U : 0U;
        r->w[i] = sum;
    }
}
void bn_sub(bn_t *r, const bn_t *a, const bn_t *b) {
    uint64_t borrow = 0;
    for (int i = 0; i < BN_WORDS; i++) {
        uint64_t tmp = a->w[i] - borrow;
        int b1 = (tmp > a->w[i]) ? 1 : 0;
        uint64_t diff = tmp - b->w[i];
        int b2 = (diff > tmp) ? 1 : 0;
        borrow = (uint64_t)(b1 | b2);
        r->w[i] = diff;
    }
}

/* bn_from_bytes / bn_to_bytes: 加越界保护（len > BN_WORDS*8 时静默截断/补零） */
void bn_from_bytes(bn_t *r, const uint8_t *src, size_t len) {
    bn_zero(r);
    for (size_t i = 0; i < len; i++) {
        size_t pos = len - 1 - i;
        size_t wi  = i / 8;
        if (wi >= BN_WORDS) continue;
        r->w[wi] |= (uint64_t)src[pos] << ((i % 8) * 8);
    }
}
void bn_to_bytes(uint8_t *dst, const bn_t *a, size_t len) {
    for (size_t i = 0; i < len; i++) {
        size_t pos = len - 1 - i;
        size_t wi  = i / 8;
        if (wi >= BN_WORDS) dst[pos] = 0;
        else dst[pos] = (uint8_t)(a->w[wi] >> ((i % 8) * 8));
    }
}
int bn_bit(const bn_t *a, int i) {
    if (i < 0 || i >= BN_WORDS * 64) return 0;
    return (int)((a->w[i / 64] >> (i % 64)) & 1);
}
void bn_mod_add(bn_t *r, const bn_t *a, const bn_t *b, const bn_t *m) {
    bn_add(r, a, b);
    if (bn_cmp(r, m) >= 0) bn_sub(r, r, m);
}
void bn_mod_sub(bn_t *r, const bn_t *a, const bn_t *b, const bn_t *m) {
    if (bn_cmp(a, b) >= 0) { bn_sub(r, a, b); return; }
    bn_t t;
    bn_sub(&t, b, a);
    bn_sub(r, m, &t);
    sec_zero_bn(&t);
}

/* ==================== Slow 模乘 (纯 64-bit, 按模数实际字宽) ==================== */

static inline int bn_cmp_s(const bn_t *a, const bn_t *b, int n) {
    for (int i = n - 1; i >= 0; i--) {
        if (a->w[i] > b->w[i]) return 1;
        if (a->w[i] < b->w[i]) return -1;
    }
    return 0;
}
static inline void bn_sub_s(bn_t *r, const bn_t *a, const bn_t *b, int n) {
    uint64_t borrow = 0;
    for (int i = 0; i < n; i++) {
        uint64_t tmp = a->w[i] - borrow;
        int b1 = (tmp > a->w[i]) ? 1 : 0;
        uint64_t diff = tmp - b->w[i];
        int b2 = (diff > tmp) ? 1 : 0;
        borrow = (uint64_t)(b1 | b2);
        r->w[i] = diff;
    }
}

static void bn_mod_mul_slow(bn_t *r, const bn_t *a, const bn_t *b, const bn_t *m) {
    int s = 0;
    for (int i = BN_WORDS - 1; i >= 0; i--) if (m->w[i]) { s = i + 1; break; }
    if (s == 0) { bn_zero(r); return; }

    uint64_t prod[2 * BN_WORDS + 2];
    memset(prod, 0, sizeof(prod));

    for (int i = 0; i < s; i++) {
        uint64_t c_lo = 0, c_hi = 0;
        uint64_t ai = a->w[i];

        for (int j = 0; j < s; j++) {
            uint64_t bj = b->w[j];
            uint64_t al = ai & 0xFFFFFFFFULL, ah = ai >> 32;
            uint64_t bl = bj & 0xFFFFFFFFULL, bh = bj >> 32;
            uint64_t p0 = al * bl;
            uint64_t p1 = al * bh;
            uint64_t p2 = ah * bl;
            uint64_t p3 = ah * bh;

            uint64_t M = p1 + p2;
            uint64_t M_ov = (M < p1) ? 1ULL : 0ULL;
            uint64_t mid = (M & 0xFFFFFFFFULL) + (p0 >> 32);
            uint64_t pl = ((mid & 0xFFFFFFFFULL) << 32) | (p0 & 0xFFFFFFFFULL);

            uint64_t M_h_real = (M >> 32) + (M_ov << 32);
            uint64_t h1 = p3 + M_h_real;
            uint64_t o1 = (h1 < p3) ? 1ULL : 0ULL;
            uint64_t ph = h1 + (mid >> 32);
            uint64_t o2 = (ph < h1) ? 1ULL : 0ULL;

            int k = i + j;
            uint64_t acc = prod[k] + pl;
            uint64_t ov = (acc < pl) ? 1ULL : 0ULL;
            acc += c_lo;
            ov += (acc < c_lo) ? 1ULL : 0ULL;
            prod[k] = acc;

            uint64_t base = ph + c_hi + ov;
            uint64_t ncl = base;
            uint64_t nco = (ncl < ph) ? 1ULL : 0ULL;
            nco += (ncl < c_hi) ? 1ULL : 0ULL;
            ncl += (o1 + o2);
            nco += (ncl < base) ? 1ULL : 0ULL;
            c_lo = ncl;
            c_hi = nco;
        }

        uint64_t t = prod[i + s] + c_lo;
        uint64_t ov = (t < c_lo) ? 1ULL : 0ULL;
        prod[i + s] = t;
        prod[i + s + 1] += c_hi + ov;
    }

    bn_t rem;
    bn_zero(&rem);
    int nw = s + 1;
    if (nw > BN_WORDS) nw = BN_WORDS;
    int total_bits = 2 * s * 64;
    for (int i = total_bits - 1; i >= 0; i--) {
        uint64_t cin = (prod[i / 64] >> (i % 64)) & 1;
        for (int j = 0; j < nw; j++) {
            uint64_t next = rem.w[j] >> 63;
            rem.w[j] = (rem.w[j] << 1) | cin;
            cin = next;
        }
        if (bn_cmp_s(&rem, m, nw) >= 0) bn_sub_s(&rem, &rem, m, nw);
    }
    *r = rem;
    sec_zero_bn(&rem);
    secure_zero(prod, sizeof(prod));
}

typedef struct {
    bn_t m;
    int s;
    uint64_t np;
    bn_t r2;
    int valid;
} mont_ctx;

#define MONT_CACHE_SIZE 8
static mont_ctx g_mont_cache[MONT_CACHE_SIZE];
static int g_mont_count = 0;

static __attribute__((unused)) mont_ctx *get_mont(const bn_t *m) {
    for (int i = 0; i < g_mont_count; i++)
        if (bn_cmp(&g_mont_cache[i].m, m) == 0) return &g_mont_cache[i];
    if (g_mont_count >= MONT_CACHE_SIZE) return NULL;

    mont_ctx *c = &g_mont_cache[g_mont_count++];
    c->m = *m;
    c->s = 0;
    for (int i = BN_WORDS - 1; i >= 0; i--)
        if (m->w[i]) { c->s = i + 1; break; }
    if (c->s == 0) return NULL;

    uint64_t x = 1;
    for (int i = 0; i < 6; i++) x *= 2 - m->w[0] * x;
    c->np = (uint64_t)(0 - x);

    uint64_t acc[BN_WORDS + 1];
    memset(acc, 0, sizeof(acc));
    acc[0] = 1;
    int bits = 2 * c->s * 64;
    for (int i = 0; i < bits; i++) {
        uint64_t carry = 0;
        for (int j = 0; j <= c->s; j++) {
            uint64_t next = acc[j] >> 63;
            acc[j] = (acc[j] << 1) | carry;
            carry = next;
        }
        int ge;
        if (acc[c->s] != 0) ge = 1;
        else {
            ge = 0;
            for (int j = c->s - 1; j >= 0; j--) {
                if (acc[j] > m->w[j]) { ge = 1; break; }
                if (acc[j] < m->w[j]) { ge = 0; break; }
                if (j == 0) ge = 1;
            }
        }
        if (ge) {
            uint64_t borrow = 0;
            for (int j = 0; j <= c->s; j++) {
                uint64_t mj = (j < c->s) ? m->w[j] : 0;
                uint64_t tmp = acc[j] - borrow;
                int b1 = (tmp > acc[j]) ? 1 : 0;
                uint64_t diff = tmp - mj;
                int b2 = (diff > tmp) ? 1 : 0;
                borrow = (uint64_t)(b1 | b2);
                acc[j] = diff;
            }
        }
    }
    bn_zero(&c->r2);
    for (int j = 0; j < c->s; j++) c->r2.w[j] = acc[j];
    c->valid = 1;
    return c;
}

static __attribute__((unused)) void mont_mul(bn_t *r, const bn_t *a, const bn_t *b, const mont_ctx *c) {
    int s = c->s;
    const bn_t *m = &c->m;
    uint64_t t[BN_WORDS + 2];
    memset(t, 0, sizeof(t));

    for (int i = 0; i < s; i++) {
        uint64_t C = 0;
        for (int j = 0; j < s; j++) {
            uint64_t lo, hi;
            mac64_128(a->w[j], b->w[i], t[j], C, &lo, &hi);
            t[j] = lo;
            C = hi;
        }
        uint64_t ts_old = t[s];
        uint64_t ttmp = ts_old + C;
        t[s] = ttmp;
        t[s + 1] = (ttmp < ts_old) ? 1U : 0U;

        uint64_t mm = t[0] * c->np;
        uint64_t mm_lo, mm_hi;
        mul64_128(t[0], c->np, &mm_lo, &mm_hi);
        uint64_t s0_lo = t[0] + mm_lo;
        uint64_t s0_hi = mm_hi + (s0_lo < t[0] ? 1U : 0U);
        C = s0_hi;
        for (int j = 1; j < s; j++) {
            uint64_t lo, hi;
            mac64_128(mm, m->w[j], t[j], C, &lo, &hi);
            t[j - 1] = lo;
            C = hi;
        }
        ts_old = t[s];
        ttmp = ts_old + C;
        t[s - 1] = ttmp;
        t[s] = t[s + 1] + (ttmp < ts_old ? 1U : 0U);
    }

    bn_t tt;
    memset(&tt, 0, sizeof(tt));
    for (int i = 0; i <= s; i++) tt.w[i] = t[i];
    if (bn_cmp(&tt, m) >= 0) bn_sub(&tt, &tt, m);
    *r = tt;
    sec_zero_bn(&tt);
    secure_zero(t, sizeof(t));
}

void bn_mod_mul(bn_t *r, const bn_t *a, const bn_t *b, const bn_t *m) {
    /* Montgomery 路径有进位 bug，暂走 proven-correct 的 slow path。 */
    bn_mod_mul_slow(r, a, b, m);
}

void bn_mod_inv(bn_t *r, const bn_t *a, const bn_t *m) {
    bn_t e, base, acc, two = {{2}};
    bn_sub(&e, m, &two);
    base = *a;
    bn_set_u64(&acc, 1);
    int top = -1;
    for (int i = BN_WORDS * 64 - 1; i >= 0; i--) if (bn_bit(&e, i)) { top = i; break; }
    for (int i = top; i >= 0; i--) {
        bn_mod_mul(&acc, &acc, &acc, m);
        if (bn_bit(&e, i)) bn_mod_mul(&acc, &acc, &base, m);
    }
    *r = acc;
    sec_zero_bn(&e);
    sec_zero_bn(&base);
    sec_zero_bn(&acc);
}

/* ==================== 曲线参数 ==================== */
static void hex_to_bn(bn_t *r, const char *hex) {
    size_t len = strlen(hex);
    if (len >= 2 && hex[0] == '0' && (hex[1] == 'x' || hex[1] == 'X')) { hex += 2; len -= 2; }
    bn_zero(r);
    for (size_t i = 0; i < len; i++) {
        size_t pos = len - 1 - i;
        int c = hex[pos], v;
        if (c >= '0' && c <= '9') v = c - '0';
        else if (c >= 'a' && c <= 'f') v = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') v = c - 'A' + 10;
        else continue;
        r->w[i / 16] |= (uint64_t)v << ((i % 16) * 4);
    }
}

static ec_curve p256_inst, p384_inst;
static int curves_ready = 0;

static void curves_init(void) {
    if (curves_ready) return;
    hex_to_bn(&p256_inst.p,  "FFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF");
    hex_to_bn(&p256_inst.a,  "FFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFC");
    hex_to_bn(&p256_inst.b,  "5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B");
    hex_to_bn(&p256_inst.gx, "6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296");
    hex_to_bn(&p256_inst.gy, "4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5");
    hex_to_bn(&p256_inst.n,  "FFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551");
    p256_inst.bits = 256; p256_inst.nbytes = 32;

    hex_to_bn(&p384_inst.p,  "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFFFF0000000000000000FFFFFFFF");
    hex_to_bn(&p384_inst.a,  "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFFFF0000000000000000FFFFFFFC");
    hex_to_bn(&p384_inst.b,  "B3312FA7E23EE7E4988E056BE3F82D19181D9C6EFE8141120314088F5013875AC656398D8A2ED19D2A85C8EDD3EC2AEF");
    hex_to_bn(&p384_inst.gx, "AA87CA22BE8B05378EB1C71EF320AD746E1D3B628BA79B9859F741E082542A385502F25DBF55296C3A545E3872760AB7");
    hex_to_bn(&p384_inst.gy, "3617DE4A96262C6F5D9E98BF9292DC29F8F41DBD289A147CE9DA3113B5F0B8C00A60B1CE1D7E819D7A431D7C90EA0E5F");
    hex_to_bn(&p384_inst.n,  "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC7634D81F4372DDF581A0DB248B0A77AECEC196ACCC52973");
    p384_inst.bits = 384; p384_inst.nbytes = 48;
    curves_ready = 1;
}

const ec_curve *ec_p256(void) { curves_init(); return &p256_inst; }
const ec_curve *ec_p384(void) { curves_init(); return &p384_inst; }

/* ==================== EC 点运算 ==================== */
void ec_point_set_infinity(ec_point *P) {
    bn_set_u64(&P->x, 1); bn_set_u64(&P->y, 1); bn_zero(&P->z);
}
int ec_point_is_infinity(const ec_point *P) { return bn_is_zero(&P->z); }

void ec_point_double(ec_point *R, const ec_point *P, const ec_curve *c) {
    if (ec_point_is_infinity(P)) { *R = *P; return; }
    bn_t Px = P->x, Py = P->y, Pz = P->z;
    bn_t A, B, C, D, E, F, t, C8, Z1sq, Z1_4, aZ4;
    if (bn_is_zero(&Py)) {
        ec_point_set_infinity(R);
        goto cleanup;
    }

    bn_mod_mul(&A, &Px, &Px, &c->p);
    bn_mod_mul(&B, &Py, &Py, &c->p);
    bn_mod_mul(&C, &B, &B, &c->p);
    bn_mod_add(&t, &Px, &B, &c->p);
    bn_mod_mul(&t, &t, &t, &c->p);
    bn_mod_sub(&t, &t, &A, &c->p);
    bn_mod_sub(&t, &t, &C, &c->p);
    bn_mod_add(&D, &t, &t, &c->p);
    bn_mod_add(&E, &A, &A, &c->p);
    bn_mod_add(&E, &E, &A, &c->p);
    bn_mod_mul(&Z1sq, &Pz, &Pz, &c->p);
    bn_mod_mul(&Z1_4, &Z1sq, &Z1sq, &c->p);
    bn_mod_mul(&aZ4, &c->a, &Z1_4, &c->p);
    bn_mod_add(&E, &E, &aZ4, &c->p);
    bn_mod_mul(&F, &E, &E, &c->p);
    bn_mod_add(&t, &D, &D, &c->p);
    bn_mod_sub(&R->x, &F, &t, &c->p);
    bn_mod_sub(&t, &D, &R->x, &c->p);
    bn_mod_mul(&t, &E, &t, &c->p);
    bn_mod_add(&C8, &C, &C, &c->p);
    bn_mod_add(&C8, &C8, &C8, &c->p);
    bn_mod_add(&C8, &C8, &C8, &c->p);
    bn_mod_sub(&R->y, &t, &C8, &c->p);
    bn_mod_mul(&t, &Py, &Pz, &c->p);
    bn_mod_add(&R->z, &t, &t, &c->p);

cleanup:
    sec_zero_bn(&Px); sec_zero_bn(&Py); sec_zero_bn(&Pz);
    sec_zero_bn(&A);  sec_zero_bn(&B);  sec_zero_bn(&C);
    sec_zero_bn(&D);  sec_zero_bn(&E);  sec_zero_bn(&F);
    sec_zero_bn(&t);  sec_zero_bn(&C8);
    sec_zero_bn(&Z1sq); sec_zero_bn(&Z1_4); sec_zero_bn(&aZ4);
}

void ec_point_add(ec_point *R, const ec_point *P, const ec_point *Q, const ec_curve *c) {
    if (ec_point_is_infinity(P)) { *R = *Q; return; }
    if (ec_point_is_infinity(Q)) { *R = *P; return; }
    bn_t Px = P->x, Py = P->y, Pz = P->z;
    bn_t Qx = Q->x, Qy = Q->y, Qz = Q->z;
    bn_t Z1Z1, Z2Z2, U1, U2, S1, S2, H, I, J, rr, V, t;

    bn_mod_mul(&Z1Z1, &Pz, &Pz, &c->p);
    bn_mod_mul(&Z2Z2, &Qz, &Qz, &c->p);
    bn_mod_mul(&U1, &Px, &Z2Z2, &c->p);
    bn_mod_mul(&U2, &Qx, &Z1Z1, &c->p);
    bn_mod_mul(&t, &Qz, &Z2Z2, &c->p);
    bn_mod_mul(&S1, &Py, &t, &c->p);
    bn_mod_mul(&t, &Pz, &Z1Z1, &c->p);
    bn_mod_mul(&S2, &Qy, &t, &c->p);
    if (bn_cmp(&U1, &U2) == 0) {
        if (bn_cmp(&S1, &S2) == 0) ec_point_double(R, P, c);
        else                       ec_point_set_infinity(R);
        goto cleanup;
    }
    bn_mod_sub(&H, &U2, &U1, &c->p);
    bn_mod_add(&t, &H, &H, &c->p);
    bn_mod_mul(&I, &t, &t, &c->p);
    bn_mod_mul(&J, &H, &I, &c->p);
    bn_mod_sub(&rr, &S2, &S1, &c->p);
    bn_mod_add(&rr, &rr, &rr, &c->p);
    bn_mod_mul(&V, &U1, &I, &c->p);
    bn_mod_mul(&R->x, &rr, &rr, &c->p);
    bn_mod_sub(&R->x, &R->x, &J, &c->p);
    bn_mod_add(&t, &V, &V, &c->p);
    bn_mod_sub(&R->x, &R->x, &t, &c->p);
    bn_mod_sub(&t, &V, &R->x, &c->p);
    bn_mod_mul(&t, &rr, &t, &c->p);
    bn_mod_mul(&S1, &S1, &J, &c->p);
    bn_mod_add(&S1, &S1, &S1, &c->p);
    bn_mod_sub(&R->y, &t, &S1, &c->p);
    bn_mod_add(&t, &Pz, &Qz, &c->p);
    bn_mod_mul(&t, &t, &t, &c->p);
    bn_mod_sub(&t, &t, &Z1Z1, &c->p);
    bn_mod_sub(&t, &t, &Z2Z2, &c->p);
    bn_mod_mul(&R->z, &t, &H, &c->p);

cleanup:
    sec_zero_bn(&Px); sec_zero_bn(&Py); sec_zero_bn(&Pz);
    sec_zero_bn(&Qx); sec_zero_bn(&Qy); sec_zero_bn(&Qz);
    sec_zero_bn(&Z1Z1); sec_zero_bn(&Z2Z2);
    sec_zero_bn(&U1); sec_zero_bn(&U2);
    sec_zero_bn(&S1); sec_zero_bn(&S2);
    sec_zero_bn(&H);  sec_zero_bn(&I);
    sec_zero_bn(&J);  sec_zero_bn(&rr);
    sec_zero_bn(&V);  sec_zero_bn(&t);
}

/* 点 (x, y) 是否在曲线上：y^2 = x^3 + a*x + b */
static int point_on_curve(const bn_t *x, const bn_t *y, const ec_curve *c) {
    bn_t y2, x3, ax, t;
    bn_mod_mul(&y2, y, y, &c->p);
    bn_mod_mul(&x3, x, x, &c->p);
    bn_mod_mul(&x3, &x3, x, &c->p);
    bn_mod_mul(&ax, &c->a, x, &c->p);
    bn_mod_add(&t, &x3, &ax, &c->p);
    bn_mod_add(&t, &t, &c->b, &c->p);
    return bn_cmp(&y2, &t) == 0;
}

void ec_point_to_affine(bn_t *x, bn_t *y, const ec_point *P, const ec_curve *c) {
    if (ec_point_is_infinity(P)) { bn_zero(x); bn_zero(y); return; }
    bn_t zi, zi2, zi3;
    bn_mod_inv(&zi, &P->z, &c->p);
    bn_mod_mul(&zi2, &zi, &zi, &c->p);
    bn_mod_mul(&zi3, &zi2, &zi, &c->p);
    bn_mod_mul(x, &P->x, &zi2, &c->p);
    bn_mod_mul(y, &P->y, &zi3, &c->p);
    sec_zero_bn(&zi);
    sec_zero_bn(&zi2);
    sec_zero_bn(&zi3);
}

static void point_cmov(ec_point *dst, const ec_point *a, const ec_point *b, int flag) {
    uint64_t mask = (uint64_t)0 - (uint64_t)(flag & 1);
    for (int i = 0; i < BN_WORDS; i++) {
        dst->x.w[i] = (a->x.w[i] & ~mask) | (b->x.w[i] & mask);
        dst->y.w[i] = (a->y.w[i] & ~mask) | (b->y.w[i] & mask);
        dst->z.w[i] = (a->z.w[i] & ~mask) | (b->z.w[i] & mask);
    }
}

void ec_scalar_mul_ct(ec_point *R, const bn_t *k, const ec_point *P, const ec_curve *c) {
    ec_point R0, R1;
    ec_point_set_infinity(&R0);
    R1 = *P;
    int top = -1;
    for (int i = BN_WORDS * 64 - 1; i >= 0; i--) if (bn_bit(k, i)) { top = i; break; }
    for (int i = top; i >= 0; i--) {
        int bit = bn_bit(k, i);
        ec_point tmp, T, D, newR0, newR1;
        point_cmov(&tmp, &R0, &R1, bit);
        ec_point_add(&T, &R0, &R1, c);
        ec_point_double(&D, &tmp, c);
        point_cmov(&newR0, &D, &T, bit);
        point_cmov(&newR1, &T, &D, bit);
        R0 = newR0;
        R1 = newR1;
        sec_zero_point(&tmp);
        sec_zero_point(&T);
        sec_zero_point(&D);
        sec_zero_point(&newR0);
        sec_zero_point(&newR1);
    }
    *R = R0;
    sec_zero_point(&R0);
    sec_zero_point(&R1);
}

void ec_scalar_mul(ec_point *R, const bn_t *k, const ec_point *P, const ec_curve *c) {
    ec_point acc;
    ec_point_set_infinity(&acc);
    int top = -1;
    for (int i = BN_WORDS * 64 - 1; i >= 0; i--) if (bn_bit(k, i)) { top = i; break; }
    for (int i = top; i >= 0; i--) {
        ec_point_double(&acc, &acc, c);
        if (bn_bit(k, i)) ec_point_add(&acc, &acc, P, c);
    }
    *R = acc;
    sec_zero_point(&acc);
}

/* ==================== ECDSA ==================== */
static void hash_to_int(bn_t *e, const uint8_t *hash, size_t hash_len, const ec_curve *c) {
    if (hash_len > (size_t)c->nbytes) hash_len = c->nbytes;
    bn_from_bytes(e, hash, hash_len);
}

/* HMAC-SHA256 或 HMAC-SHA384（按曲线的 c->nbytes 选择）
 * out 大小：P-256 → 32 字节；P-384 → 48 字节。
 * 支持 out 与 data / key 重叠（内部先拷入临时 buffer）。
 */
static void curve_hmac(uint8_t *out, const uint8_t *key, size_t key_len,
                       const uint8_t *data, size_t data_len, const ec_curve *c) {
    int is384 = (c->nbytes == 48);
    int block = is384 ? 128 : 64;
    int hlen  = is384 ? 48  : 32;

    uint8_t K[128], ipad[128], opad[128];
    uint8_t inner[512];
    uint8_t outer[128 + 48];

    /* 1. key 展开到 block */
    if (key_len > (size_t)block) {
        if (is384) ecdsa_sha384(K, key, key_len);
        else       ecdsa_sha256(K, key, key_len);
        memset(K + hlen, 0, block - hlen);
    } else {
        memcpy(K, key, key_len);
        memset(K + key_len, 0, block - key_len);
    }

    for (int i = 0; i < block; i++) {
        ipad[i] = K[i] ^ 0x36;
        opad[i] = K[i] ^ 0x5c;
    }

    /* 2. inner = H(ipad || data) */
    memcpy(inner, ipad, block);
    memcpy(inner + block, data, data_len);
    if (is384) ecdsa_sha384(inner + block + data_len, inner, block + data_len);
    else       ecdsa_sha256(inner + block + data_len, inner, block + data_len);

    /* 3. out = H(opad || inner_hash) */
    memcpy(outer, opad, block);
    memcpy(outer + block, inner + block + data_len, hlen);
    if (is384) ecdsa_sha384(out, outer, block + hlen);
    else       ecdsa_sha256(out, outer, block + hlen);

    /* 4. 清零 */
    secure_zero(K,     sizeof(K));
    secure_zero(ipad,  sizeof(ipad));
    secure_zero(opad,  sizeof(opad));
    secure_zero(inner, sizeof(inner));
    secure_zero(outer, sizeof(outer));
}

static int rfc6979_k(bn_t *k, const uint8_t *hash, size_t hash_len,
                     const bn_t *d, const ec_curve *c) {
    /* RFC 6979 的 hlen 由曲线决定（HMAC-SHA256 还是 HMAC-SHA384），
     * 与消息 hash 长度无关。 */
    int hmac_hlen = (c->nbytes == 48) ? 48 : 32;

    uint8_t x_oct[48], h_oct[48];
    bn_to_bytes(x_oct, d, c->nbytes);
    {
        bn_t e;
        hash_to_int(&e, hash, hash_len, c);
        if (bn_cmp(&e, &c->n) >= 0) bn_sub(&e, &e, &c->n);
        bn_to_bytes(h_oct, &e, c->nbytes);
        sec_zero_bn(&e);
    }

    uint8_t V[64], K[64];
    memset(V, 0x01, hmac_hlen);
    memset(K, 0x00, hmac_hlen);

    uint8_t buf[64 + 1 + 48 + 48];

    memcpy(buf, V, hmac_hlen);
    buf[hmac_hlen] = 0x00;
    memcpy(buf + hmac_hlen + 1, x_oct, c->nbytes);
    memcpy(buf + hmac_hlen + 1 + c->nbytes, h_oct, c->nbytes);
    curve_hmac(K, K, hmac_hlen, buf, hmac_hlen + 1 + 2 * c->nbytes, c);
    curve_hmac(V, K, hmac_hlen, V, hmac_hlen, c);
    memcpy(buf, V, hmac_hlen);
    buf[hmac_hlen] = 0x01;
    memcpy(buf + hmac_hlen + 1, x_oct, c->nbytes);
    memcpy(buf + hmac_hlen + 1 + c->nbytes, h_oct, c->nbytes);
    curve_hmac(K, K, hmac_hlen, buf, hmac_hlen + 1 + 2 * c->nbytes, c);
    curve_hmac(V, K, hmac_hlen, V, hmac_hlen, c);

    /* 尝试生成有效 k，上限 1000 轮（实际约 1 轮即出） */
    for (int attempt = 0; attempt < 1000; attempt++) {
        uint8_t T[128];
        int tlen = 0;
        while (tlen < c->nbytes) {
            curve_hmac(V, K, hmac_hlen, V, hmac_hlen, c);
            memcpy(T + tlen, V, hmac_hlen);
            tlen += hmac_hlen;
        }
        bn_from_bytes(k, T, c->nbytes);
        secure_zero(T, sizeof(T));
        if (!bn_is_zero(k) && bn_cmp(k, &c->n) < 0) {
            secure_zero(V,     sizeof(V));
            secure_zero(K,     sizeof(K));
            secure_zero(buf,   sizeof(buf));
            secure_zero(x_oct, sizeof(x_oct));
            secure_zero(h_oct, sizeof(h_oct));
            return 0;
        }
        memcpy(buf, V, hmac_hlen);
        buf[hmac_hlen] = 0x00;
        curve_hmac(K, K, hmac_hlen, buf, hmac_hlen + 1, c);
        curve_hmac(V, K, hmac_hlen, V, hmac_hlen, c);
    }

    secure_zero(V,     sizeof(V));
    secure_zero(K,     sizeof(K));
    secure_zero(buf,   sizeof(buf));
    secure_zero(x_oct, sizeof(x_oct));
    secure_zero(h_oct, sizeof(h_oct));
    return -1;
}

int ecdsa_keygen(ecdsa_key *key, const ec_curve *c) {
    curves_init();
    ec_point G = { .x = c->gx, .y = c->gy, .z = {{1}} };
    for (;;) {
        uint8_t buf[48];
        FILE *f = fopen("/dev/urandom", "rb");
        if (!f) return -1;

        size_t got = 0;
        while (got < (size_t)c->nbytes) {
            size_t n = fread(buf + got, 1, c->nbytes - got, f);
            if (n == 0) {
                fclose(f);
                secure_zero(buf, sizeof(buf));
                return -1;
            }
            got += n;
        }
        fclose(f);

        bn_from_bytes(&key->d, buf, c->nbytes);
        secure_zero(buf, sizeof(buf));
        if (bn_is_zero(&key->d) || bn_cmp(&key->d, &c->n) >= 0) continue;

        ec_point Q;
        ec_scalar_mul(&Q, &key->d, &G, c);
        if (ec_point_is_infinity(&Q)) { sec_zero_point(&Q); continue; }

        /* 子群自检：n * Q 必须为无穷远（cofactor=1 的 NIST 曲线恒成立，防御性） */
        ec_point nQ;
        ec_scalar_mul(&nQ, &c->n, &Q, c);
        int bad = !ec_point_is_infinity(&nQ);
        sec_zero_point(&nQ);
        if (bad) { sec_zero_point(&Q); continue; }

        ec_point_to_affine(&key->Qx, &key->Qy, &Q, c);
        sec_zero_point(&Q);
        return 0;
    }
}

int ecdsa_sign(ecdsa_sig *sig, const uint8_t *hash, size_t hash_len,
               const ecdsa_key *key, const ec_curve *c, const bn_t *fixed_k) {
    curves_init();
    ec_point G = { .x = c->gx, .y = c->gy, .z = {{1}} };
    bn_t e, k, r, s, tmp, kinv;
    hash_to_int(&e, hash, hash_len, c);
    for (;;) {
        if (fixed_k) k = *fixed_k;
        else {
            if (rfc6979_k(&k, hash, hash_len, &key->d, c) != 0) {
                sec_zero_bn(&e);
                return -1;
            }
        }
        if (bn_is_zero(&k) || bn_cmp(&k, &c->n) >= 0) {
            sec_zero_bn(&k);
            if (fixed_k) { sec_zero_bn(&e); return -1; }
            continue;
        }
        ec_point R;
        /* k 为秘密值：使用恒定时间 ladder，防止 Minerva / TPM-Fail 类时序攻击 */
        ec_scalar_mul_ct(&R, &k, &G, c);
        if (ec_point_is_infinity(&R)) {
            sec_zero_point(&R);
            sec_zero_bn(&k);
            if (fixed_k) { sec_zero_bn(&e); return -1; }
            continue;
        }
        bn_t x, y;
        ec_point_to_affine(&x, &y, &R, c);
        sec_zero_point(&R);
        sec_zero_bn(&y);
        bn_mod_mul(&r, &x, &(bn_t){{1}}, &c->n);
        sec_zero_bn(&x);
        if (bn_is_zero(&r)) {
            sec_zero_bn(&k);
            if (fixed_k) { sec_zero_bn(&e); return -1; }
            continue;
        }
        bn_mod_mul(&tmp, &r, &key->d, &c->n);
        bn_mod_add(&tmp, &e, &tmp, &c->n);
        bn_mod_inv(&kinv, &k, &c->n);
        bn_mod_mul(&s, &kinv, &tmp, &c->n);
        sec_zero_bn(&k);
        sec_zero_bn(&kinv);
        sec_zero_bn(&tmp);
        sec_zero_bn(&e);
        if (bn_is_zero(&s)) {
            if (fixed_k) return -1;
            continue;
        }
        sig->r = r;
        sig->s = s;
        sec_zero_bn(&r);
        sec_zero_bn(&s);
        return 0;
    }
}

int ecdsa_verify(const ecdsa_sig *sig, const uint8_t *hash, size_t hash_len,
                 const ecdsa_key *key, const ec_curve *c) {
    curves_init();
    bn_t one = {{1}}, e, w, u1, u2;
    if (bn_is_zero(&sig->r) || bn_is_zero(&sig->s)) return 0;
    if (bn_cmp(&sig->r, &c->n) >= 0 || bn_cmp(&sig->s, &c->n) >= 0) return 0;

    /* 公钥点合法性校验，防止无效点攻击 */
    if (bn_cmp(&key->Qx, &c->p) >= 0 || bn_cmp(&key->Qy, &c->p) >= 0) return 0;
    if (!point_on_curve(&key->Qx, &key->Qy, c)) return 0;

    hash_to_int(&e, hash, hash_len, c);
    bn_mod_inv(&w, &sig->s, &c->n);
    bn_mod_mul(&u1, &e, &w, &c->n);
    bn_mod_mul(&u2, &sig->r, &w, &c->n);
    ec_point G = { .x = c->gx, .y = c->gy, .z = {{1}} };
    ec_point Q = { .x = key->Qx, .y = key->Qy, .z = {{1}} };
    ec_point A, B, R;
    ec_scalar_mul(&A, &u1, &G, c);
    ec_scalar_mul(&B, &u2, &Q, c);
    ec_point_add(&R, &A, &B, c);
    int ok = 0;
    if (!ec_point_is_infinity(&R)) {
        bn_t x, y;
        ec_point_to_affine(&x, &y, &R, c);
        bn_t xr;
        bn_mod_mul(&xr, &x, &one, &c->n);
        ok = (bn_cmp(&xr, &sig->r) == 0);
        sec_zero_bn(&x);
        sec_zero_bn(&y);
        sec_zero_bn(&xr);
    }
    sec_zero_bn(&e);
    sec_zero_bn(&w);
    sec_zero_bn(&u1);
    sec_zero_bn(&u2);
    sec_zero_point(&A);
    sec_zero_point(&B);
    sec_zero_point(&R);
    return ok;
}

/* ==================== SEC1 点编码 ==================== */

int ecdsa_pubkey_encode(uint8_t *out, const ecdsa_key *key, const ec_curve *c) {
    out[0] = 0x04;
    bn_to_bytes(out + 1, &key->Qx, c->nbytes);
    bn_to_bytes(out + 1 + c->nbytes, &key->Qy, c->nbytes);
    return 1 + 2 * c->nbytes;
}

int ecdsa_pubkey_decode(ecdsa_key *key, const uint8_t *in, size_t in_len, const ec_curve *c) {
    if (in_len != (size_t)(1 + 2 * c->nbytes) || in[0] != 0x04) return -1;
    bn_from_bytes(&key->Qx, in + 1, c->nbytes);
    bn_from_bytes(&key->Qy, in + 1 + c->nbytes, c->nbytes);
    if (bn_cmp(&key->Qx, &c->p) >= 0 || bn_cmp(&key->Qy, &c->p) >= 0) return -1;
    return point_on_curve(&key->Qx, &key->Qy, c) ? 0 : -1;
}

int ecdsa_pubkey_encode_compressed(uint8_t *out, const ecdsa_key *key, const ec_curve *c) {
    out[0] = (key->Qy.w[0] & 1) ? 0x03 : 0x02;
    bn_to_bytes(out + 1, &key->Qx, c->nbytes);
    return 1 + c->nbytes;
}

int ecdsa_pubkey_decode_compressed(ecdsa_key *key, const uint8_t *in, size_t in_len, const ec_curve *c) {
    if (in_len != (size_t)(1 + c->nbytes)) return -1;
    if (in[0] != 0x02 && in[0] != 0x03) return -1;
    int want_odd = (in[0] == 0x03);
    bn_from_bytes(&key->Qx, in + 1, c->nbytes);
    if (bn_cmp(&key->Qx, &c->p) >= 0) return -1;

    bn_t y2, x3, ax, t;
    bn_mod_mul(&x3, &key->Qx, &key->Qx, &c->p);
    bn_mod_mul(&x3, &x3, &key->Qx, &c->p);
    bn_mod_mul(&ax, &c->a, &key->Qx, &c->p);
    bn_mod_add(&y2, &x3, &ax, &c->p);
    bn_mod_add(&y2, &y2, &c->b, &c->p);

    bn_t e = c->p, one = {{1}};
    bn_add(&e, &e, &one);
    for (int i = 0; i < 2; i++) {
        uint64_t carry = 0;
        for (int j = BN_WORDS - 1; j >= 0; j--) {
            uint64_t next = e.w[j] & 1;
            e.w[j] = (e.w[j] >> 1) | (carry << 63);
            carry = next;
        }
    }
    bn_t y, base = y2;
    bn_set_u64(&y, 1);
    int top = -1;
    for (int i = BN_WORDS * 64 - 1; i >= 0; i--) if (bn_bit(&e, i)) { top = i; break; }
    for (int i = top; i >= 0; i--) {
        bn_mod_mul(&y, &y, &y, &c->p);
        if (bn_bit(&e, i)) bn_mod_mul(&y, &y, &base, &c->p);
    }
    bn_mod_mul(&t, &y, &y, &c->p);
    if (bn_cmp(&t, &y2) != 0) return -1;
    if (((int)(y.w[0] & 1)) != want_odd) bn_sub(&y, &c->p, &y);
    key->Qy = y;
    return 0;
}

/* ==================== DER 签名编码 ==================== */

int ecdsa_sig_encode_der(uint8_t *out, const ecdsa_sig *sig, const ec_curve *c) {
    uint8_t r_buf[48], s_buf[48];
    bn_to_bytes(r_buf, &sig->r, c->nbytes);
    bn_to_bytes(s_buf, &sig->s, c->nbytes);

    int r_start = 0, s_start = 0;
    while (r_start < c->nbytes - 1 && r_buf[r_start] == 0) r_start++;
    while (s_start < c->nbytes - 1 && s_buf[s_start] == 0) s_start++;

    int r_len = c->nbytes - r_start;
    int s_len = c->nbytes - s_start;
    int r_pad = (r_buf[r_start] & 0x80) ? 1 : 0;
    int s_pad = (s_buf[s_start] & 0x80) ? 1 : 0;

    int total = 2 + r_pad + r_len + 2 + s_pad + s_len;
    if (total > 127) return -1;

    out[0] = 0x30;
    out[1] = (uint8_t)total;
    int pos = 2;
    out[pos++] = 0x02;
    out[pos++] = (uint8_t)(r_pad + r_len);
    if (r_pad) out[pos++] = 0x00;
    memcpy(out + pos, r_buf + r_start, r_len);
    pos += r_len;
    out[pos++] = 0x02;
    out[pos++] = (uint8_t)(s_pad + s_len);
    if (s_pad) out[pos++] = 0x00;
    memcpy(out + pos, s_buf + s_start, s_len);
    pos += s_len;
    return pos;
}

int ecdsa_sig_decode_der(ecdsa_sig *sig, const uint8_t *in, size_t in_len, const ec_curve *c) {
    if (in_len < 2 || in[0] != 0x30) return -1;
    int total = in[1];
    if (total & 0x80) return -1;
    if (in_len < (size_t)(2 + total)) return -1;
    int pos = 2;

    if (in[pos] != 0x02 || pos + 1 >= 2 + total) return -1;
    int r_len = in[pos + 1];
    pos += 2;
    if (r_len < 1 || pos + r_len > 2 + total) return -1;
    const uint8_t *r_ptr = in + pos;
    int r_actual = r_len;
    while (r_actual > 1 && r_ptr[0] == 0) { r_ptr++; r_actual--; }
    if (r_actual > c->nbytes) return -1;
    bn_from_bytes(&sig->r, r_ptr, r_actual);
    pos += r_len;

    if (pos >= 2 + total || in[pos] != 0x02) return -1;
    int s_len = in[pos + 1];
    pos += 2;
    if (s_len < 1 || pos + s_len > 2 + total) return -1;
    const uint8_t *s_ptr = in + pos;
    int s_actual = s_len;
    while (s_actual > 1 && s_ptr[0] == 0) { s_ptr++; s_actual--; }
    if (s_actual > c->nbytes) return -1;
    bn_from_bytes(&sig->s, s_ptr, s_actual);
    return 0;
}

#endif
