#ifndef RSA2048_H
#define RSA2048_H

#include <stdint.h>
#include <stddef.h>

#define RSA2048_BYTES 256
#define RSA2048_WORDS 64

typedef struct {
    uint32_t n[RSA2048_WORDS];
    uint32_t e[RSA2048_WORDS];
    uint32_t d[RSA2048_WORDS];
    uint32_t p[32];
    uint32_t q[32];
    uint32_t dp[32];
    uint32_t dq[32];
    uint32_t qinv[32];
    int has_crt;
} RSA2048_KEY;

/* BN 辅助：加 rsa2048_ 前缀避免与 ecdsa.c 的 bn_* 冲突 */
void rsa2048_bn_from_bytes(uint32_t *dst, const uint8_t *src, size_t len);
void rsa2048_bn_from_bytes_n(uint32_t *dst, const uint8_t *src, size_t len, int words);
void rsa2048_bn_to_bytes(uint8_t *dst, const uint32_t *src, size_t len);
void rsa2048_bn_mod_exp(uint32_t *r, const uint32_t *base, const uint32_t *exp, const uint32_t *mod);

int rsa2048_encrypt(const RSA2048_KEY *key, const uint8_t *msg, size_t msg_len, uint8_t *out);
int rsa2048_decrypt(const RSA2048_KEY *key, const uint8_t *cipher, uint8_t *out);
int rsa2048_sign(const RSA2048_KEY *key, const uint8_t *digest_info, size_t di_len, uint8_t *sig);
int rsa2048_verify(const RSA2048_KEY *key, const uint8_t *digest_info, size_t di_len, const uint8_t *sig);

int rsa2048_keygen(RSA2048_KEY *key);

void mgf1_sha256(const uint8_t *seed, size_t seed_len, uint8_t *out, size_t mask_len);
int rsa2048_pss_sign(const RSA2048_KEY *key, const uint8_t *msg, size_t msg_len,
                     uint8_t *sig, const uint8_t *fixed_salt);
int rsa2048_pss_verify(const RSA2048_KEY *key, const uint8_t *msg, size_t msg_len,
                       const uint8_t *sig);

#endif