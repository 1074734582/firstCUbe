#include "rsa2048.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ==================== 安全零化 ==================== */
static void secure_zero(void *p, size_t n) {
    volatile uint8_t *v = (volatile uint8_t *)p;
    while (n--) *v++ = 0;
}

/* ==================== BN 基础（公开符号加 rsa2048_ 前缀） ==================== */
void rsa2048_bn_zero(uint32_t *a) { memset(a, 0, RSA2048_WORDS * sizeof(uint32_t)); }
void rsa2048_bn_set_u64(uint32_t *a, uint64_t v) { rsa2048_bn_zero(a); a[0] = (uint32_t)v; }

static int bn_is_zero_n(const uint32_t *a, int s) {
    for (int i = 0; i < s; i++) if (a[i]) return 0;
    return 1;
}
int rsa2048_bn_is_zero(const uint32_t *a) { return bn_is_zero_n(a, RSA2048_WORDS); }

static int bn_cmp_n(const uint32_t *a, const uint32_t *b, int s) {
    for (int i = s - 1; i >= 0; i--) {
        if (a[i] > b[i]) return 1;
        if (a[i] < b[i]) return -1;
    }
    return 0;
}
int rsa2048_bn_cmp(const uint32_t *a, const uint32_t *b) { return bn_cmp_n(a, b, RSA2048_WORDS); }

static void bn_add_n(uint32_t *r, const uint32_t *a, const uint32_t *b, int s) {
    uint64_t carry = 0;
    for (int i = 0; i < s; i++) {
        uint64_t t = (uint64_t)a[i] + b[i] + carry;
        r[i] = (uint32_t)t;
        carry = t >> 32;
    }
}
void rsa2048_bn_add(uint32_t *r, const uint32_t *a, const uint32_t *b) {
    bn_add_n(r, a, b, RSA2048_WORDS);
}

static void bn_sub_n(uint32_t *r, const uint32_t *a, const uint32_t *b, int s) {
    uint64_t borrow = 0;
    for (int i = 0; i < s; i++) {
        uint64_t t = (uint64_t)a[i] - b[i] - borrow;
        r[i] = (uint32_t)t;
        borrow = (t >> 32) & 1;
    }
}
void rsa2048_bn_sub(uint32_t *r, const uint32_t *a, const uint32_t *b) {
    bn_sub_n(r, a, b, RSA2048_WORDS);
}

void rsa2048_bn_from_bytes_n(uint32_t *dst, const uint8_t *src, size_t len, int words) {
    rsa2048_bn_zero(dst);
    for (size_t i = 0; i < len; i++) {
        size_t pos = len - 1 - i;
        int w = (int)(i / 4);
        if (w >= words) break;
        dst[w] |= (uint32_t)src[pos] << ((i % 4) * 8);
    }
}
void rsa2048_bn_from_bytes(uint32_t *dst, const uint8_t *src, size_t len) {
    rsa2048_bn_from_bytes_n(dst, src, len, RSA2048_WORDS);
}
void rsa2048_bn_to_bytes(uint8_t *dst, const uint32_t *src, size_t len) {
    for (size_t i = 0; i < len; i++) {
        size_t pos = len - 1 - i;
        dst[pos] = (uint8_t)(src[i / 4] >> ((i % 4) * 8));
    }
}

/* ==================== 乘法（static） ==================== */
static void bn_mul_full_n(uint32_t *prod, const uint32_t *a, const uint32_t *b, int s) {
    memset(prod, 0, 2 * s * sizeof(uint32_t));
    for (int i = 0; i < s; i++) {
        uint64_t carry = 0;
        for (int j = 0; j < s; j++) {
            uint64_t t = (uint64_t)a[i] * b[j] + prod[i + j] + carry;
            prod[i + j] = (uint32_t)t;
            carry = t >> 32;
        }
        prod[i + s] += (uint32_t)carry;
    }
}

/* ==================== Montgomery（static） ==================== */
static uint32_t compute_n_prime(uint32_t n0) {
    uint32_t x = 1;
    for (int i = 0; i < 5; i++) x = x * (2u - n0 * x);
    return (uint32_t)(0u - x);
}

static void mont_mul_n(uint32_t *r, const uint32_t *a, const uint32_t *b,
                       const uint32_t *n, uint32_t np, int s) {
    uint32_t t[RSA2048_WORDS + 2];
    memset(t, 0, sizeof(uint32_t) * (s + 2));

    for (int i = 0; i < s; i++) {
        uint64_t C = 0;
        for (int j = 0; j < s; j++) {
            uint64_t sum = (uint64_t)a[j] * b[i] + t[j] + C;
            t[j] = (uint32_t)sum;
            C = sum >> 32;
        }
        uint64_t sum = (uint64_t)t[s] + C;
        t[s] = (uint32_t)sum;
        t[s + 1] = (uint32_t)(sum >> 32);

        uint32_t m = t[0] * np;
        sum = (uint64_t)t[0] + (uint64_t)m * n[0];
        C = sum >> 32;
        for (int j = 1; j < s; j++) {
            sum = (uint64_t)m * n[j] + t[j] + C;
            t[j - 1] = (uint32_t)sum;
            C = sum >> 32;
        }
        sum = (uint64_t)t[s] + C;
        t[s - 1] = (uint32_t)sum;
        t[s] = t[s + 1] + (uint32_t)(sum >> 32);
    }

    int ge;
    if (t[s] != 0) ge = 1;
    else {
        ge = 0;
        for (int j = s - 1; j >= 0; j--) {
            if (t[j] > n[j]) { ge = 1; break; }
            if (t[j] < n[j]) { ge = 0; break; }
            if (j == 0) ge = 1;
        }
    }
    if (ge) {
        uint32_t borrow = 0;
        for (int j = 0; j < s; j++) {
            uint64_t sub = (uint64_t)t[j] - n[j] - borrow;
            t[j] = (uint32_t)sub;
            borrow = (uint32_t)(sub >> 32) & 1u;
        }
    }
    memcpy(r, t, s * sizeof(uint32_t));
}

static void bn_mod_pow2_n(uint32_t *r, const uint32_t *n, int s, int exp) {
    uint32_t rem[RSA2048_WORDS + 1];
    memset(rem, 0, sizeof(uint32_t) * (s + 1));
    rem[0] = 1;

    for (int i = 0; i < exp; i++) {
        uint32_t carry = 0;
        for (int j = 0; j <= s; j++) {
            uint32_t next = rem[j] >> 31;
            rem[j] = (rem[j] << 1) | carry;
            carry = next;
        }
        int ge;
        if (rem[s] != 0) ge = 1;
        else {
            ge = 0;
            for (int j = s - 1; j >= 0; j--) {
                if (rem[j] > n[j]) { ge = 1; break; }
                if (rem[j] < n[j]) { ge = 0; break; }
                if (j == 0) ge = 1;
            }
        }
        if (ge) {
            uint32_t borrow = 0;
            for (int j = 0; j <= s; j++) {
                uint32_t nj = (j < s) ? n[j] : 0;
                uint64_t sub = (uint64_t)rem[j] - nj - borrow;
                rem[j] = (uint32_t)sub;
                borrow = (uint32_t)(sub >> 32) & 1u;
            }
        }
    }
    memcpy(r, rem, s * sizeof(uint32_t));
}

static void bn_mod_exp_n(uint32_t *r, const uint32_t *base, const uint32_t *exp,
                         const uint32_t *mod, int s) {
    uint32_t np = compute_n_prime(mod[0]);
    uint32_t r2[RSA2048_WORDS];
    bn_mod_pow2_n(r2, mod, s, 2 * s * 32);

    uint32_t one[RSA2048_WORDS];
    memset(one, 0, s * sizeof(uint32_t));
    one[0] = 1;

    uint32_t base_m[RSA2048_WORDS];
    mont_mul_n(base_m, base, r2, mod, np, s);

    uint32_t result_m[RSA2048_WORDS];
    mont_mul_n(result_m, one, r2, mod, np, s);

    int top = -1;
    for (int i = s - 1; i >= 0; i--) {
        if (exp[i] != 0) {
            for (int b = 31; b >= 0; b--) {
                if ((exp[i] >> b) & 1u) { top = i * 32 + b; break; }
            }
            break;
        }
    }
    if (top < 0) { memcpy(r, one, s * sizeof(uint32_t)); return; }

    for (int i = top; i >= 0; i--) {
        mont_mul_n(result_m, result_m, result_m, mod, np, s);
        if ((exp[i / 32] >> (i % 32)) & 1u)
            mont_mul_n(result_m, result_m, base_m, mod, np, s);
    }
    mont_mul_n(r, result_m, one, mod, np, s);
}
void rsa2048_bn_mod_exp(uint32_t *r, const uint32_t *base, const uint32_t *exp, const uint32_t *mod) {
    bn_mod_exp_n(r, base, exp, mod, RSA2048_WORDS);
}

/* ==================== 对短模约减（static） ==================== */
static void bn_mod_reduce(uint32_t *r, const uint32_t *a, int a_words,
                          const uint32_t *n, int n_words) {
    uint32_t rem[RSA2048_WORDS + 1];
    memset(rem, 0, sizeof(uint32_t) * (n_words + 1));
    for (int i = a_words * 32 - 1; i >= 0; i--) {
        uint32_t in_bit = (a[i / 32] >> (i % 32)) & 1u;
        uint32_t carry = in_bit;
        for (int j = 0; j <= n_words; j++) {
            uint32_t next = rem[j] >> 31;
            rem[j] = (rem[j] << 1) | carry;
            carry = next;
        }
        int ge;
        if (rem[n_words] != 0) ge = 1;
        else {
            ge = 0;
            for (int j = n_words - 1; j >= 0; j--) {
                if (rem[j] > n[j]) { ge = 1; break; }
                if (rem[j] < n[j]) { ge = 0; break; }
                if (j == 0) ge = 1;
            }
        }
        if (ge) {
            uint32_t borrow = 0;
            for (int j = 0; j <= n_words; j++) {
                uint32_t nj = (j < n_words) ? n[j] : 0;
                uint64_t sub = (uint64_t)rem[j] - nj - borrow;
                rem[j] = (uint32_t)sub;
                borrow = (uint32_t)(sub >> 32) & 1u;
            }
        }
    }
    memcpy(r, rem, n_words * sizeof(uint32_t));
}

/* ==================== CRT 私钥运算（static） ==================== */
static void rsa_private_op_crt(uint32_t *out, const uint32_t *c, const RSA2048_KEY *key) {
    uint32_t c1[32], c2[32];
    bn_mod_reduce(c1, c, RSA2048_WORDS, key->p, 32);
    bn_mod_reduce(c2, c, RSA2048_WORDS, key->q, 32);

    uint32_t m1[32], m2[32];
    bn_mod_exp_n(m1, c1, key->dp, key->p, 32);
    bn_mod_exp_n(m2, c2, key->dq, key->q, 32);

    uint32_t diff[32];
    if (bn_cmp_n(m1, m2, 32) >= 0) {
        uint32_t borrow = 0;
        for (int j = 0; j < 32; j++) {
            uint64_t sub = (uint64_t)m1[j] - m2[j] - borrow;
            diff[j] = (uint32_t)sub;
            borrow = (uint32_t)(sub >> 32) & 1u;
        }
    } else {
        uint32_t tmp[32];
        uint32_t borrow = 0;
        for (int j = 0; j < 32; j++) {
            uint64_t sub = (uint64_t)m2[j] - m1[j] - borrow;
            tmp[j] = (uint32_t)sub;
            borrow = (uint32_t)(sub >> 32) & 1u;
        }
        borrow = 0;
        for (int j = 0; j < 32; j++) {
            uint64_t sub = (uint64_t)key->p[j] - tmp[j] - borrow;
            diff[j] = (uint32_t)sub;
            borrow = (uint32_t)(sub >> 32) & 1u;
        }
    }

    uint32_t prod[64];
    bn_mul_full_n(prod, key->qinv, diff, 32);
    uint32_t h[32];
    bn_mod_reduce(h, prod, 64, key->p, 32);

    uint32_t hq[64];
    bn_mul_full_n(hq, h, key->q, 32);

    uint64_t carry = 0;
    for (int j = 0; j < 64; j++) {
        uint32_t m2j = (j < 32) ? m2[j] : 0;
        uint64_t sum = (uint64_t)hq[j] + m2j + carry;
        out[j] = (uint32_t)sum;
        carry = sum >> 32;
    }
    if (bn_cmp_n(out, key->n, 64) >= 0) {
        uint32_t borrow = 0;
        for (int j = 0; j < 64; j++) {
            uint64_t sub = (uint64_t)out[j] - key->n[j] - borrow;
            out[j] = (uint32_t)sub;
            borrow = (uint32_t)(sub >> 32) & 1u;
        }
    }
    secure_zero(m1, sizeof(m1));
    secure_zero(m2, sizeof(m2));
    secure_zero(diff, sizeof(diff));
    secure_zero(h, sizeof(h));
}

static void rsa_private_op(uint32_t *out, const uint32_t *c, const RSA2048_KEY *key) {
    if (key->has_crt) rsa_private_op_crt(out, c, key);
    else              bn_mod_exp_n(out, c, key->d, key->n, RSA2048_WORDS);
}

/* ==================== PKCS#1 v1.5 ==================== */
int rsa2048_encrypt(const RSA2048_KEY *key, const uint8_t *msg, size_t msg_len, uint8_t *out) {
    if (msg_len > RSA2048_BYTES - 11) return -1;
    uint8_t em[RSA2048_BYTES];
    memset(em, 0, sizeof(em));
    em[0] = 0x00;
    em[1] = 0x02;
    size_t ps_len = RSA2048_BYTES - msg_len - 3;
    for (size_t i = 0; i < ps_len; i++) em[2 + i] = 0xFF;
    em[2 + ps_len] = 0x00;
    if (msg_len > 0) memcpy(em + 3 + ps_len, msg, msg_len);

    uint32_t m[RSA2048_WORDS], c[RSA2048_WORDS];
    rsa2048_bn_from_bytes(m, em, RSA2048_BYTES);
    bn_mod_exp_n(c, m, key->e, key->n, RSA2048_WORDS);
    rsa2048_bn_to_bytes(out, c, RSA2048_BYTES);
    secure_zero(em, sizeof(em));
    return 0;
}

int rsa2048_decrypt(const RSA2048_KEY *key, const uint8_t *cipher, uint8_t *out) {
    uint32_t c[RSA2048_WORDS], m[RSA2048_WORDS];
    rsa2048_bn_from_bytes(c, cipher, RSA2048_BYTES);
    if (rsa2048_bn_cmp(c, key->n) >= 0) return -1;

    rsa_private_op(m, c, key);

    uint8_t em[RSA2048_BYTES];
    rsa2048_bn_to_bytes(em, m, RSA2048_BYTES);

    if (em[0] != 0x00 || em[1] != 0x02) return -1;
    size_t idx = 2;
    while (idx < RSA2048_BYTES && em[idx] != 0x00) idx++;
    if (idx >= RSA2048_BYTES || idx == 2) return -1;
    size_t msg_len = RSA2048_BYTES - idx - 1;
    if (msg_len > 0) memcpy(out, em + idx + 1, msg_len);
    secure_zero(em, sizeof(em));
    return (int)msg_len;
}

int rsa2048_sign(const RSA2048_KEY *key, const uint8_t *digest_info, size_t di_len, uint8_t *sig) {
    if (di_len > RSA2048_BYTES - 11) return -1;
    uint8_t em[RSA2048_BYTES];
    memset(em, 0, sizeof(em));
    em[0] = 0x00;
    em[1] = 0x01;
    size_t ps_len = RSA2048_BYTES - di_len - 3;
    for (size_t i = 0; i < ps_len; i++) em[2 + i] = 0xFF;
    em[2 + ps_len] = 0x00;
    memcpy(em + 3 + ps_len, digest_info, di_len);

    uint32_t m[RSA2048_WORDS], s[RSA2048_WORDS];
    rsa2048_bn_from_bytes(m, em, RSA2048_BYTES);
    rsa_private_op(s, m, key);
    rsa2048_bn_to_bytes(sig, s, RSA2048_BYTES);
    secure_zero(em, sizeof(em));
    return 0;
}

int rsa2048_verify(const RSA2048_KEY *key, const uint8_t *digest_info, size_t di_len, const uint8_t *sig) {
    uint32_t s[RSA2048_WORDS], m[RSA2048_WORDS];
    rsa2048_bn_from_bytes(s, sig, RSA2048_BYTES);
    if (rsa2048_bn_cmp(s, key->n) >= 0) return 0;

    bn_mod_exp_n(m, s, key->e, key->n, RSA2048_WORDS);

    uint8_t em[RSA2048_BYTES];
    rsa2048_bn_to_bytes(em, m, RSA2048_BYTES);

    if (em[0] != 0x00 || em[1] != 0x01) return 0;
    size_t idx = 2;
    while (idx < RSA2048_BYTES && em[idx] == 0xFF) idx++;
    if (idx >= RSA2048_BYTES || em[idx] != 0x00) return 0;
    idx++;
    if (RSA2048_BYTES - idx != di_len) return 0;
    return memcmp(em + idx, digest_info, di_len) == 0;
}

/* ==================== 密钥生成 ==================== */
static int get_random_bytes(uint8_t *buf, size_t len) {
    FILE *f = fopen("/dev/urandom", "rb");
    if (!f) return -1;
    size_t n = fread(buf, 1, len, f);
    fclose(f);
    return n == len ? 0 : -1;
}
static uint32_t bn_mod_small(const uint32_t *a, int words, uint32_t m) {
    uint64_t r = 0;
    for (int i = words - 1; i >= 0; i--)
        r = ((r << 32) | a[i]) % m;
    return (uint32_t)r;
}

static int is_one_n(const uint32_t *x, int s) {
    if (x[0] != 1) return 0;
    for (int i = 1; i < s; i++) if (x[i]) return 0;
    return 1;
}

static void mont_sqr_mod(uint32_t *r, const uint32_t *x, const uint32_t *n,
                         uint32_t np, const uint32_t *r2, int s) {
    uint32_t one[RSA2048_WORDS] = {0};
    one[0] = 1;
    uint32_t xR[RSA2048_WORDS], x2R[RSA2048_WORDS];
    mont_mul_n(xR,  x,  r2, n, np, s);
    mont_mul_n(x2R, xR, xR, n, np, s);
    mont_mul_n(r,   x2R, one, n, np, s);
}

static int is_probable_prime(const uint32_t *n) {
    static const uint32_t sp[] = {
        3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,
        79,83,89,97,101,103,107,109,113,127,131,137,139,149,151,157,
        163,167,173,179,181,191,193,197,199,211,223,227,229,233,239,
        241,251,257,263,269,271,277,281,283,293,307,311,313,317,331,
        337,347,349,353,359,367,373,379,383,389,397,401,409,419,421,
        431,433,439,443,449,457,461,463,467,479,487,491,499,503,509,
        521,523,541
    };
    int np_small = (int)(sizeof(sp) / sizeof(sp[0]));
    for (int i = 0; i < np_small; i++)
        if (bn_mod_small(n, 32, sp[i]) == 0) return 0;

    uint32_t nm1[32];
    memcpy(nm1, n, sizeof(nm1));
    { uint32_t borrow = 1; for (int i = 0; i < 32 && borrow; i++) {
        uint64_t v = (uint64_t)nm1[i] - borrow;
        nm1[i] = (uint32_t)v;
        borrow = (uint32_t)(v >> 32) & 1u; } }

    uint32_t d[32];
    memcpy(d, nm1, sizeof(d));
    int s = 0;
    while ((d[0] & 1u) == 0) {
        uint32_t carry = 0;
        for (int i = 31; i >= 0; i--) {
            uint32_t next = d[i] & 1u;
            d[i] = (d[i] >> 1) | (carry << 31);
            carry = next;
        }
        s++;
    }

    uint32_t np = compute_n_prime(n[0]);
    uint32_t r2[32];
    bn_mod_pow2_n(r2, n, 32, 2048);

    static const uint32_t bases[] = {
        2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71
    };
    int nb = (int)(sizeof(bases) / sizeof(bases[0]));

    for (int b = 0; b < nb; b++) {
        uint32_t a[32] = {0};
        a[0] = bases[b];
        uint32_t x[32];
        bn_mod_exp_n(x, a, d, n, 32);
        if (is_one_n(x, 32)) continue;
        if (bn_cmp_n(x, nm1, 32) == 0) continue;
        int passed = 0;
        for (int r = 1; r < s; r++) {
            mont_sqr_mod(x, x, n, np, r2, 32);
            if (bn_cmp_n(x, nm1, 32) == 0) { passed = 1; break; }
            if (is_one_n(x, 32)) break;
        }
        if (!passed) return 0;
    }
    return 1;
}

static int generate_prime(uint32_t *out) {
    uint8_t bytes[128];
    for (;;) {
        if (get_random_bytes(bytes, 128) != 0) return -1;
        bytes[0]  |= 0xC0;
        bytes[127] |= 1;
        rsa2048_bn_from_bytes_n(out, bytes, 128, 32);
        if (is_probable_prime(out)) return 0;
    }
}

static void bn_dec(uint32_t *a, int words) {
    uint32_t borrow = 1;
    for (int i = 0; i < words && borrow; i++) {
        uint64_t v = (uint64_t)a[i] - borrow;
        a[i] = (uint32_t)v;
        borrow = (uint32_t)(v >> 32) & 1u;
    }
}

int rsa2048_keygen(RSA2048_KEY *key) {
    const uint32_t e = 65537;

    for (int attempt = 0; attempt < 100; attempt++) {
        uint32_t p[32], q[32];
        if (generate_prime(p) != 0) return -1;
        if (generate_prime(q) != 0) return -1;

        while (bn_cmp_n(p, q, 32) == 0) {
            if (generate_prime(q) != 0) return -1;
        }
        if (bn_cmp_n(p, q, 32) < 0) {
            uint32_t t[32];
            memcpy(t, p, sizeof(p));
            memcpy(p, q, sizeof(q));
            memcpy(q, t, sizeof(t));
        }

        uint32_t prod[64];
        bn_mul_full_n(prod, p, q, 32);
        if (prod[63] == 0) continue;

        uint32_t pm1[32], qm1[32];
        memcpy(pm1, p, sizeof(pm1));
        memcpy(qm1, q, sizeof(qm1));
        bn_dec(pm1, 32);
        bn_dec(qm1, 32);
        uint32_t phi[64];
        bn_mul_full_n(phi, pm1, qm1, 32);

        uint32_t r = bn_mod_small(phi, 64, e);
        if (r == 0) continue;

        int64_t t0 = 0, t1 = 1;
        int64_t a0 = (int64_t)e, b0 = (int64_t)r;
        while (b0) {
            int64_t qq = a0 / b0;
            int64_t tmp = a0 - qq * b0; a0 = b0; b0 = tmp;
            tmp = t0 - qq * t1; t0 = t1; t1 = tmp;
        }
        t0 %= (int64_t)e;
        if (t0 < 0) t0 += (int64_t)e;
        uint32_t rinv = (uint32_t)t0;
        uint32_t k = e - rinv;

        uint32_t tmp[65];
        memset(tmp, 0, sizeof(tmp));
        uint64_t carry = 0;
        for (int i = 0; i < 64; i++) {
            uint64_t v = (uint64_t)phi[i] * k + carry;
            tmp[i] = (uint32_t)v;
            carry = v >> 32;
        }
        tmp[64] = (uint32_t)carry;
        for (int i = 0; i < 65; i++) if (++tmp[i] != 0) break;

        uint64_t rem = 0;
        for (int i = 64; i >= 0; i--) {
            uint64_t cur = (rem << 32) | tmp[i];
            tmp[i] = (uint32_t)(cur / e);
            rem = cur % e;
        }
        if (rem != 0) continue;

        uint32_t de[65];
        memset(de, 0, sizeof(de));
        carry = 0;
        for (int i = 0; i < 64; i++) {
            uint64_t v = (uint64_t)tmp[i] * e + carry;
            de[i] = (uint32_t)v;
            carry = v >> 32;
        }
        de[64] = (uint32_t)carry;
        uint32_t check[64];
        bn_mod_reduce(check, de, 65, phi, 64);
        int ok = (check[0] == 1);
        for (int i = 1; i < 64; i++) if (check[i]) { ok = 0; break; }
        if (!ok) continue;

        memcpy(key->n, prod, sizeof(key->n));
        memcpy(key->d, tmp, sizeof(key->d));
        memcpy(key->p, p, sizeof(key->p));
        memcpy(key->q, q, sizeof(key->q));

        bn_mod_reduce(key->dp, key->d, 64, pm1, 32);
        bn_mod_reduce(key->dq, key->d, 64, qm1, 32);

        uint32_t pm2[32];
        memcpy(pm2, p, sizeof(pm2));
        {
            uint32_t borrow = 2;
            for (int i = 0; i < 32 && borrow; i++) {
                uint64_t v = (uint64_t)pm2[i] - borrow;
                pm2[i] = (uint32_t)v;
                borrow = (uint32_t)(v >> 32) & 1u;
            }
        }
        bn_mod_exp_n(key->qinv, q, pm2, p, 32);

        memset(key->e, 0, sizeof(key->e));
        key->e[0] = e;
        key->has_crt = 1;
        return 0;
    }
    return -2;
}

/* ==================== SHA-256 ==================== */
static const uint32_t K256[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};
#define ROR32(x,n) (((x)>>(n))|((x)<<(32-(n))))
static void sha256_compress(uint32_t st[8], const uint8_t blk[64]) {
    uint32_t w[64];
    for (int i = 0; i < 16; i++)
        w[i] = ((uint32_t)blk[4*i]<<24)|((uint32_t)blk[4*i+1]<<16)|((uint32_t)blk[4*i+2]<<8)|blk[4*i+3];
    for (int i = 16; i < 64; i++) {
        uint32_t s0 = ROR32(w[i-15],7)^ROR32(w[i-15],18)^(w[i-15]>>3);
        uint32_t s1 = ROR32(w[i-2],17)^ROR32(w[i-2],19)^(w[i-2]>>10);
        w[i] = w[i-16]+s0+w[i-7]+s1;
    }
    uint32_t a=st[0],b=st[1],c=st[2],d=st[3],e=st[4],f=st[5],g=st[6],h=st[7];
    for (int i = 0; i < 64; i++) {
        uint32_t S1 = ROR32(e,6)^ROR32(e,11)^ROR32(e,25);
        uint32_t ch = (e&f)^(~e&g);
        uint32_t t1 = h+S1+ch+K256[i]+w[i];
        uint32_t S0 = ROR32(a,2)^ROR32(a,13)^ROR32(a,22);
        uint32_t mj = (a&b)^(a&c)^(b&c);
        uint32_t t2 = S0+mj;
        h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
    }
    st[0]+=a; st[1]+=b; st[2]+=c; st[3]+=d; st[4]+=e; st[5]+=f; st[6]+=g; st[7]+=h;
}
static void sha256(const uint8_t *data, size_t len, uint8_t out[32]) {
    uint32_t st[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
                      0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    size_t i = 0;
    for (; i + 64 <= len; i += 64) sha256_compress(st, data + i);
    uint8_t tail[128] = {0};
    size_t rem = len - i;
    if (rem) memcpy(tail, data + i, rem);
    tail[rem] = 0x80;
    size_t tl = (rem < 56) ? 64 : 128;
    uint64_t bits = (uint64_t)len * 8;
    for (int k = 0; k < 8; k++) tail[tl-1-k] = (uint8_t)(bits >> (8*k));
    for (size_t p = 0; p < tl; p += 64) sha256_compress(st, tail + p);
    for (int k = 0; k < 8; k++) {
        out[4*k]   = (uint8_t)(st[k] >> 24);
        out[4*k+1] = (uint8_t)(st[k] >> 16);
        out[4*k+2] = (uint8_t)(st[k] >> 8);
        out[4*k+3] = (uint8_t)st[k];
    }
}

/* ==================== MGF1-SHA256 ==================== */
void mgf1_sha256(const uint8_t *seed, size_t seed_len, uint8_t *out, size_t mask_len) {
    uint8_t buf[128 + 4];
    if (seed_len > 128) return;
    memcpy(buf, seed, seed_len);
    size_t pos = 0;
    uint32_t counter = 0;
    while (pos < mask_len) {
        buf[seed_len]     = (uint8_t)(counter >> 24);
        buf[seed_len + 1] = (uint8_t)(counter >> 16);
        buf[seed_len + 2] = (uint8_t)(counter >> 8);
        buf[seed_len + 3] = (uint8_t)counter;
        uint8_t digest[32];
        sha256(buf, seed_len + 4, digest);
        size_t take = (mask_len - pos < 32) ? (mask_len - pos) : 32;
        memcpy(out + pos, digest, take);
        pos += take;
        counter++;
    }
}

/* ==================== RSA-PSS ==================== */
#define PSS_HLEN  32
#define PSS_SLEN  32

int rsa2048_pss_sign(const RSA2048_KEY *key, const uint8_t *msg, size_t msg_len,
                     uint8_t *sig, const uint8_t *fixed_salt) {
    const size_t emLen = RSA2048_BYTES;
    if (emLen < PSS_HLEN + PSS_SLEN + 2) return -1;

    uint8_t mHash[PSS_HLEN];
    sha256(msg, msg_len, mHash);

    uint8_t salt[PSS_SLEN];
    if (fixed_salt) {
        memcpy(salt, fixed_salt, PSS_SLEN);
    } else {
        if (get_random_bytes(salt, PSS_SLEN) != 0) return -1;
    }

    uint8_t Mprime[8 + PSS_HLEN + PSS_SLEN];
    memset(Mprime, 0, 8);
    memcpy(Mprime + 8, mHash, PSS_HLEN);
    memcpy(Mprime + 8 + PSS_HLEN, salt, PSS_SLEN);

    uint8_t H[PSS_HLEN];
    sha256(Mprime, sizeof(Mprime), H);

    const size_t dbLen = emLen - PSS_HLEN - 1;
    const size_t psLen = dbLen - PSS_SLEN - 1;
    uint8_t DB[RSA2048_BYTES];
    memset(DB, 0, psLen);
    DB[psLen] = 0x01;
    memcpy(DB + psLen + 1, salt, PSS_SLEN);

    uint8_t dbMask[RSA2048_BYTES];
    mgf1_sha256(H, PSS_HLEN, dbMask, dbLen);

    uint8_t maskedDB[RSA2048_BYTES];
    for (size_t i = 0; i < dbLen; i++) maskedDB[i] = DB[i] ^ dbMask[i];
    maskedDB[0] &= 0x7F;

    uint8_t EM[RSA2048_BYTES];
    memcpy(EM, maskedDB, dbLen);
    memcpy(EM + dbLen, H, PSS_HLEN);
    EM[emLen - 1] = 0xBC;

    uint32_t m[RSA2048_WORDS], s[RSA2048_WORDS];
    rsa2048_bn_from_bytes(m, EM, emLen);
    rsa_private_op(s, m, key);
    rsa2048_bn_to_bytes(sig, s, emLen);

    secure_zero(mHash, sizeof(mHash));
    secure_zero(salt, sizeof(salt));
    secure_zero(Mprime, sizeof(Mprime));
    secure_zero(H, sizeof(H));
    secure_zero(DB, sizeof(DB));
    secure_zero(dbMask, sizeof(dbMask));
    secure_zero(maskedDB, sizeof(maskedDB));
    secure_zero(EM, sizeof(EM));
    secure_zero(m, sizeof(m));
    secure_zero(s, sizeof(s));
    return 0;
}

int rsa2048_pss_verify(const RSA2048_KEY *key, const uint8_t *msg, size_t msg_len,
                       const uint8_t *sig) {
    const size_t emLen = RSA2048_BYTES;
    if (emLen < PSS_HLEN + PSS_SLEN + 2) return 0;

    uint32_t s[RSA2048_WORDS], m[RSA2048_WORDS];
    rsa2048_bn_from_bytes(s, sig, emLen);
    if (rsa2048_bn_cmp(s, key->n) >= 0) return 0;
    bn_mod_exp_n(m, s, key->e, key->n, RSA2048_WORDS);

    uint8_t EM[RSA2048_BYTES];
    rsa2048_bn_to_bytes(EM, m, emLen);

    if (EM[emLen - 1] != 0xBC) return 0;

    const size_t dbLen = emLen - PSS_HLEN - 1;
    const uint8_t *maskedDB = EM;
    const uint8_t *H = EM + dbLen;

    if (maskedDB[0] & 0x80) return 0;

    uint8_t dbMask[RSA2048_BYTES];
    mgf1_sha256(H, PSS_HLEN, dbMask, dbLen);

    uint8_t DB[RSA2048_BYTES];
    for (size_t i = 0; i < dbLen; i++) DB[i] = maskedDB[i] ^ dbMask[i];
    DB[0] &= 0x7F;

    const size_t psLen = dbLen - PSS_SLEN - 1;
    for (size_t i = 0; i < psLen; i++) if (DB[i] != 0x00) return 0;
    if (DB[psLen] != 0x01) return 0;
    const uint8_t *salt = DB + psLen + 1;

    uint8_t mHash[PSS_HLEN];
    sha256(msg, msg_len, mHash);

    uint8_t Mprime[8 + PSS_HLEN + PSS_SLEN];
    memset(Mprime, 0, 8);
    memcpy(Mprime + 8, mHash, PSS_HLEN);
    memcpy(Mprime + 8 + PSS_HLEN, salt, PSS_SLEN);

    uint8_t H2[PSS_HLEN];
    sha256(Mprime, sizeof(Mprime), H2);

    int ok = (memcmp(H, H2, PSS_HLEN) == 0);

    secure_zero(mHash, sizeof(mHash));
    secure_zero(Mprime, sizeof(Mprime));
    secure_zero(H2, sizeof(H2));
    secure_zero(DB, sizeof(DB));
    secure_zero(dbMask, sizeof(dbMask));
    return ok;
}