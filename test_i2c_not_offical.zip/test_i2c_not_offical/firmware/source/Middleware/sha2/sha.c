/* ============================================================================
 * Copyright (c) 2010-2015.  All rights reserved.
 * SHA Hash Algorithms Implementation
 * SHA-1, SHA-256, SHA-512
 * ============================================================================
 */

#include <string.h>
#include "sha.h"

#define ROTL32(x, n)  (((x) << (n)) | ((x) >> (32 - (n))))
#define ROTR32(x, n)  (((x) >> (n)) | ((x) << (32 - (n))))
#define ROTL64(x, n)  (((x) << (n)) | ((x) >> (64 - (n))))
#define ROTR64(x, n)  (((x) >> (n)) | ((x) << (64 - (n))))

/* ============= SHA-1 Implementation ============= */

static void sha1_transform(uint32_t state[5], const uint8_t block[64])
{
    uint32_t w[80];
    uint32_t a, b, c, d, e, temp;
    int32_t i;

    /* Break block into sixteen 32-bit words */
    for (i = 0; i < 16; i++)
    {
        w[i] = ((uint32_t)block[i * 4] << 24) | ((uint32_t)block[i * 4 + 1] << 16) |
               ((uint32_t)block[i * 4 + 2] << 8) | (uint32_t)block[i * 4 + 3];
    }

    /* Extend to eighty 32-bit words */
    for (i = 16; i < 80; i++)
    {
        w[i] = ROTL32(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1);
    }

    a = state[0];
    b = state[1];
    c = state[2];
    d = state[3];
    e = state[4];

    /* 80 rounds */
    for (i = 0; i < 80; i++)
    {
        if (i < 20)
        {
            temp = ROTL32(a, 5) + ((b & c) | ((~b) & d)) + e + 0x5A827999 + w[i];
        }
        else if (i < 40)
        {
            temp = ROTL32(a, 5) + (b ^ c ^ d) + e + 0x6ED9EBA1 + w[i];
        }
        else if (i < 60)
        {
            temp = ROTL32(a, 5) + ((b & c) | (b & d) | (c & d)) + e + 0x8F1BBCDC + w[i];
        }
        else
        {
            temp = ROTL32(a, 5) + (b ^ c ^ d) + e + 0xCA62C1D6 + w[i];
        }

        e = d;
        d = c;
        c = ROTL32(b, 30);
        b = a;
        a = temp;
    }

    state[0] += a;
    state[1] += b;
    state[2] += c;
    state[3] += d;
    state[4] += e;
}

int32_t sha1_init(sha1_ctx_t *ctx)
{
    if (ctx == NULL)
    {
        return -1;
    }

    ctx->state[0] = 0x67452301;
    ctx->state[1] = 0xEFCDAB89;
    ctx->state[2] = 0x98BADCFE;
    ctx->state[3] = 0x10325476;
    ctx->state[4] = 0xC3D2E1F0;
    ctx->total_len = 0;

    return 0;
}

int32_t sha1_update(sha1_ctx_t *ctx, const uint8_t *in, uint32_t len)
{
    uint32_t i, index, part_len;

    if (ctx == NULL || in == NULL)
    {
        return -1;
    }

    index = (uint32_t)(ctx->total_len % SHA1_BLOCK_SIZE);
    ctx->total_len += len;
    part_len = SHA1_BLOCK_SIZE - index;

    if (len >= part_len)
    {
        memcpy(&ctx->buffer[index], in, part_len);
        sha1_transform(ctx->state, ctx->buffer);

        for (i = part_len; i + SHA1_BLOCK_SIZE <= len; i += SHA1_BLOCK_SIZE)
        {
            sha1_transform(ctx->state, &in[i]);
        }
        index = 0;
    }
    else
    {
        i = 0;
    }

    memcpy(&ctx->buffer[index], &in[i], len - i);

    return 0;
}

int32_t sha1_final(sha1_ctx_t *ctx, uint8_t *hash)
{
    uint32_t i;
    uint64_t bits_len;
    uint32_t index, pad_len;

    if (ctx == NULL || hash == NULL)
    {
        return -1;
    }

    bits_len = ctx->total_len * 8;
    index = (uint32_t)(ctx->total_len % SHA1_BLOCK_SIZE);
    pad_len = (index < 56) ? (56 - index) : (120 - index);

    /* Pad with 0x80 followed by zeros */
    ctx->buffer[index++] = 0x80;
    if (index > 56)
    {
        /* 需要跨两个块：当前块填 0 到尾，transform 后清前 56 字节 */
        memset(&ctx->buffer[index], 0, SHA1_BLOCK_SIZE - index);
        sha1_transform(ctx->state, ctx->buffer);
        memset(ctx->buffer, 0, 56);
    }
    else
    {
        memset(&ctx->buffer[index], 0, 56 - index);
    }

    /* Append length (big-endian) */
    ctx->buffer[56] = (uint8_t)(bits_len >> 56);
    ctx->buffer[57] = (uint8_t)(bits_len >> 48);
    ctx->buffer[58] = (uint8_t)(bits_len >> 40);
    ctx->buffer[59] = (uint8_t)(bits_len >> 32);
    ctx->buffer[60] = (uint8_t)(bits_len >> 24);
    ctx->buffer[61] = (uint8_t)(bits_len >> 16);
    ctx->buffer[62] = (uint8_t)(bits_len >> 8);
    ctx->buffer[63] = (uint8_t)(bits_len);

    sha1_transform(ctx->state, ctx->buffer);
    (void)pad_len;

    /* Output hash in big-endian */
    for (i = 0; i < 5; i++)
    {
        hash[i * 4] = (uint8_t)(ctx->state[i] >> 24);
        hash[i * 4 + 1] = (uint8_t)(ctx->state[i] >> 16);
        hash[i * 4 + 2] = (uint8_t)(ctx->state[i] >> 8);
        hash[i * 4 + 3] = (uint8_t)(ctx->state[i]);
    }

    memset(ctx, 0, sizeof(sha1_ctx_t));

    return 0;
}

int32_t sha1(const uint8_t *in, uint32_t len, uint8_t *hash)
{
    sha1_ctx_t ctx;

    if (sha1_init(&ctx) != 0)
    {
        return -1;
    }

    if (sha1_update(&ctx, in, len) != 0)
    {
        return -1;
    }

    return sha1_final(&ctx, hash);
}

/* ============= SHA-256 Implementation ============= */

static const uint32_t sha256_k[64] = {
    0x428A2F98, 0x71374491, 0xB5C0FBCF, 0xE9B5DBA5,
    0x3956C25B, 0x59F111F1, 0x923F82A4, 0xAB1C5ED5,
    0xD807AA98, 0x12835B01, 0x243185BE, 0x550C7DC3,
    0x72BE5D74, 0x80DEB1FE, 0x9BDC06A7, 0xC19BF174,
    0xE49B69C1, 0xEFBE4786, 0x0FC19DC6, 0x240CA1CC,
    0x2DE92C6F, 0x4A7484AA, 0x5CB0A9DC, 0x76F988DA,
    0x983E5152, 0xA831C66D, 0xB00327C8, 0xBF597FC7,
    0xC6E00BF3, 0xD5A79147, 0x06CA6351, 0x14292967,
    0x27B70A85, 0x2E1B2138, 0x4D2C6DFC, 0x53380D13,
    0x650A7354, 0x766A0ABB, 0x81C2C92E, 0x92722C85,
    0xA2BFE8A1, 0xA81A664B, 0xC24B8B70, 0xC76C51A3,
    0xD192E819, 0xD6990624, 0xF40E3585, 0x106AA070,
    0x19A4C116, 0x1E376C08, 0x2748774C, 0x34B0BCB5,
    0x391C0CB3, 0x4ED8AA4A, 0x5B9CCA4F, 0x682E6FF3,
    0x748F82EE, 0x78A5636F, 0x84C87814, 0x8CC70208,
    0x90BEFFFA, 0xA4506CEB, 0xBEF9A3F7, 0xC67178F2
};

static void sha256_transform(uint32_t state[8], const uint8_t block[64])
{
    uint32_t w[64];
    uint32_t a, b, c, d, e, f, g, h, t1, t2;
    int32_t i;

    /* Break block into sixteen 32-bit words */
    for (i = 0; i < 16; i++)
    {
        w[i] = ((uint32_t)block[i * 4] << 24) | ((uint32_t)block[i * 4 + 1] << 16) |
               ((uint32_t)block[i * 4 + 2] << 8) | (uint32_t)block[i * 4 + 3];
    }

    /* Extend to sixty-four 32-bit words */
    for (i = 16; i < 64; i++)
    {
        uint32_t s0 = ROTR32(w[i - 15], 7) ^ ROTR32(w[i - 15], 18) ^ (w[i - 15] >> 3);
        uint32_t s1 = ROTR32(w[i - 2], 17) ^ ROTR32(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }

    a = state[0];
    b = state[1];
    c = state[2];
    d = state[3];
    e = state[4];
    f = state[5];
    g = state[6];
    h = state[7];

    /* 64 rounds */
    for (i = 0; i < 64; i++)
    {
        t1 = h + (ROTR32(e, 6) ^ ROTR32(e, 11) ^ ROTR32(e, 25)) +
             ((e & f) ^ ((~e) & g)) + sha256_k[i] + w[i];
        t2 = (ROTR32(a, 2) ^ ROTR32(a, 13) ^ ROTR32(a, 22)) +
             ((a & b) ^ (a & c) ^ (b & c));

        h = g;
        g = f;
        f = e;
        e = d + t1;
        d = c;
        c = b;
        b = a;
        a = t1 + t2;
    }

    state[0] += a;
    state[1] += b;
    state[2] += c;
    state[3] += d;
    state[4] += e;
    state[5] += f;
    state[6] += g;
    state[7] += h;
}

int32_t sha256_init(sha256_ctx_t *ctx)
{
    if (ctx == NULL)
    {
        return -1;
    }

    ctx->state[0] = 0x6A09E667;
    ctx->state[1] = 0xBB67AE85;
    ctx->state[2] = 0x3C6EF372;
    ctx->state[3] = 0xA54FF53A;
    ctx->state[4] = 0x510E527F;
    ctx->state[5] = 0x9B05688C;
    ctx->state[6] = 0x1F83D9AB;
    ctx->state[7] = 0x5BE0CD19;
    ctx->total_len = 0;

    return 0;
}

int32_t sha256_update(sha256_ctx_t *ctx, const uint8_t *in, uint32_t len)
{
    uint32_t i, index, part_len;

    if (ctx == NULL || in == NULL)
    {
        return -1;
    }

    index = (uint32_t)(ctx->total_len % SHA256_BLOCK_SIZE);
    ctx->total_len += len;
    part_len = SHA256_BLOCK_SIZE - index;

    if (len >= part_len)
    {
        memcpy(&ctx->buffer[index], in, part_len);
        sha256_transform(ctx->state, ctx->buffer);

        for (i = part_len; i + SHA256_BLOCK_SIZE <= len; i += SHA256_BLOCK_SIZE)
        {
            sha256_transform(ctx->state, &in[i]);
        }
        index = 0;
    }
    else
    {
        i = 0;
    }

    memcpy(&ctx->buffer[index], &in[i], len - i);

    return 0;
}

int32_t sha256_final(sha256_ctx_t *ctx, uint8_t *hash)
{
    uint32_t i;
    uint64_t bits_len;
    uint32_t index, pad_len;

    if (ctx == NULL || hash == NULL)
    {
        return -1;
    }

    bits_len = ctx->total_len * 8;
    index = (uint32_t)(ctx->total_len % SHA256_BLOCK_SIZE);
    pad_len = (index < 56) ? (56 - index) : (120 - index);

    /* Pad with 0x80 followed by zeros */
    ctx->buffer[index++] = 0x80;
    if (index > 56)
    {
        /* 需要跨两个块：当前块填 0 到尾，transform 后清前 56 字节 */
        memset(&ctx->buffer[index], 0, SHA256_BLOCK_SIZE - index);
        sha256_transform(ctx->state, ctx->buffer);
        memset(ctx->buffer, 0, 56);
    }
    else
    {
        memset(&ctx->buffer[index], 0, 56 - index);
    }

    /* Append length (big-endian 64-bit) */
    ctx->buffer[56] = (uint8_t)(bits_len >> 56);
    ctx->buffer[57] = (uint8_t)(bits_len >> 48);
    ctx->buffer[58] = (uint8_t)(bits_len >> 40);
    ctx->buffer[59] = (uint8_t)(bits_len >> 32);
    ctx->buffer[60] = (uint8_t)(bits_len >> 24);
    ctx->buffer[61] = (uint8_t)(bits_len >> 16);
    ctx->buffer[62] = (uint8_t)(bits_len >> 8);
    ctx->buffer[63] = (uint8_t)(bits_len);

    sha256_transform(ctx->state, ctx->buffer);
    (void)pad_len;

    /* Output hash in big-endian */
    for (i = 0; i < 8; i++)
    {
        hash[i * 4] = (uint8_t)(ctx->state[i] >> 24);
        hash[i * 4 + 1] = (uint8_t)(ctx->state[i] >> 16);
        hash[i * 4 + 2] = (uint8_t)(ctx->state[i] >> 8);
        hash[i * 4 + 3] = (uint8_t)(ctx->state[i]);
    }

    memset(ctx, 0, sizeof(sha256_ctx_t));

    return 0;
}

int32_t sha256(const uint8_t *in, uint32_t len, uint8_t *hash)
{
    sha256_ctx_t ctx;

    if (sha256_init(&ctx) != 0)
    {
        return -1;
    }

    if (sha256_update(&ctx, in, len) != 0)
    {
        return -1;
    }

    return sha256_final(&ctx, hash);
}

/* ============= SHA-512 Implementation ============= */

static const uint64_t sha512_k[80] = {
    0x428A2F98D728AE22ULL, 0x7137449123EF65CDULL, 0xB5C0FBCFEC4D3B2FULL, 0xE9B5DBA58189DBBCULL,
    0x3956C25BF348B538ULL, 0x59F111F1B605D019ULL, 0x923F82A4AF194F9BULL, 0xAB1C5ED5DA6D8118ULL,
    0xD807AA98A3030242ULL, 0x12835B0145706FBEULL, 0x243185BE4EE4B28CULL, 0x550C7DC3D5FFB4E2ULL,
    0x72BE5D74F27B896FULL, 0x80DEB1FE3B1696B1ULL, 0x9BDC06A725C71235ULL, 0xC19BF174CF692694ULL,
    0xE49B69C19EF14AD2ULL, 0xEFBE4786384F25E3ULL, 0x0FC19DC68B8CD5B5ULL, 0x240CA1CC77AC9C65ULL,
    0x2DE92C6F592B0275ULL, 0x4A7484AA6EA6E483ULL, 0x5CB0A9DCBD41FBD4ULL, 0x76F988DA831153B5ULL,
    0x983E5152EE66DFABULL, 0xA831C66D2DB43210ULL, 0xB00327C898FB213FULL, 0xBF597FC7BEEF0EE4ULL,
    0xC6E00BF33DA88FC2ULL, 0xD5A79147930AA725ULL, 0x06CA6351E003826FULL, 0x142929670A0E6E70ULL,
    0x27B70A8546D22FFCULL, 0x2E1B21385C26C926ULL, 0x4D2C6DFC5AC42AEDULL, 0x53380D139D95B3DFULL,
    0x650A73548BAF63DEULL, 0x766A0ABB3C77B2A8ULL, 0x81C2C92E47EDAEE6ULL, 0x92722C851482353BULL,
    0xA2BFE8A14CF10364ULL, 0xA81A664BBC423001ULL, 0xC24B8B70D0F89791ULL, 0xC76C51A30654BE30ULL,
    0xD192E819D6EF5218ULL, 0xD69906245565A910ULL, 0xF40E35855771202AULL, 0x106AA07032BBD1B8ULL,
    0x19A4C116B8D2D0C8ULL, 0x1E376C085141AB53ULL, 0x2748774CDF8EEB99ULL, 0x34B0BCB5E19B48A8ULL,
    0x391C0CB3C5C95A63ULL, 0x4ED8AA4AE3418ACBULL, 0x5B9CCA4F7763E373ULL, 0x682E6FF3D6B2B8A3ULL,
    0x748F82EE5DEFB2FCULL, 0x78A5636F43172F60ULL, 0x84C87814A1F0AB72ULL, 0x8CC702081A6439ECULL,
    0x90BEFFFA23631E28ULL, 0xA4506CEBDE82BDE9ULL, 0xBEF9A3F7B2C67915ULL, 0xC67178F2E372532BULL,
    0xCA273ECEEA26619CULL, 0xD186B8C721C0C207ULL, 0xEADA7DD6CDE0EB1EULL, 0xF57D4F7FEE6ED178ULL,
    0x06F067AA72176FBAULL, 0x0A637DC5A2C898A6ULL, 0x113F9804BEF90DAEULL, 0x1B710B35131C471BULL,
    0x28DB77F523047D84ULL, 0x32CAAB7B40C72493ULL, 0x3C9EBE0A15C9BEBCULL, 0x431D67C49C100D4CULL,
    0x4CC5D4BECB3E42B6ULL, 0x597F299CFC657E2AULL, 0x5FCB6FAB3AD6FAECULL, 0x6C44198C4A475817ULL
};

static void sha512_transform(uint64_t state[8], const uint8_t block[128])
{
    uint64_t w[80];
    uint64_t a, b, c, d, e, f, g, h, t1, t2;
    int32_t i;

    /* Break block into sixteen 64-bit words */
    for (i = 0; i < 16; i++)
    {
        w[i] = ((uint64_t)block[i * 8] << 56) | ((uint64_t)block[i * 8 + 1] << 48) |
               ((uint64_t)block[i * 8 + 2] << 40) | ((uint64_t)block[i * 8 + 3] << 32) |
               ((uint64_t)block[i * 8 + 4] << 24) | ((uint64_t)block[i * 8 + 5] << 16) |
               ((uint64_t)block[i * 8 + 6] << 8) | (uint64_t)block[i * 8 + 7];
    }

    /* Extend to eighty 64-bit words */
    for (i = 16; i < 80; i++)
    {
        uint64_t s0 = ROTR64(w[i - 15], 1) ^ ROTR64(w[i - 15], 8) ^ (w[i - 15] >> 7);
        uint64_t s1 = ROTR64(w[i - 2], 19) ^ ROTR64(w[i - 2], 61) ^ (w[i - 2] >> 6);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }

    a = state[0];
    b = state[1];
    c = state[2];
    d = state[3];
    e = state[4];
    f = state[5];
    g = state[6];
    h = state[7];

    /* 80 rounds */
    for (i = 0; i < 80; i++)
    {
        t1 = h + (ROTR64(e, 14) ^ ROTR64(e, 18) ^ ROTR64(e, 41)) +
             ((e & f) ^ ((~e) & g)) + sha512_k[i] + w[i];
        t2 = (ROTR64(a, 28) ^ ROTR64(a, 34) ^ ROTR64(a, 39)) +
             ((a & b) ^ (a & c) ^ (b & c));

        h = g;
        g = f;
        f = e;
        e = d + t1;
        d = c;
        c = b;
        b = a;
        a = t1 + t2;
    }

    state[0] += a;
    state[1] += b;
    state[2] += c;
    state[3] += d;
    state[4] += e;
    state[5] += f;
    state[6] += g;
    state[7] += h;
}

int32_t sha512_init(sha512_ctx_t *ctx)
{
    if (ctx == NULL)
    {
        return -1;
    }

    ctx->state[0] = 0x6A09E667F3BCC908ULL;
    ctx->state[1] = 0xBB67AE8584CAA73BULL;
    ctx->state[2] = 0x3C6EF372FE94F82BULL;
    ctx->state[3] = 0xA54FF53A5F1D36F1ULL;
    ctx->state[4] = 0x510E527FADE682D1ULL;
    ctx->state[5] = 0x9B05688C2B3E6C1FULL;
    ctx->state[6] = 0x1F83D9ABFB41BD6BULL;
    ctx->state[7] = 0x5BE0CD19137E2179ULL;
    ctx->total_len = 0;
    ctx->total_len_high = 0;

    return 0;
}

int32_t sha512_update(sha512_ctx_t *ctx, const uint8_t *in, uint32_t len)
{
    uint32_t i, index, part_len;

    if (ctx == NULL || in == NULL)
    {
        return -1;
    }

    index = (uint32_t)(ctx->total_len % SHA512_BLOCK_SIZE);
    ctx->total_len += len;
    if (ctx->total_len < len)
    {
        ctx->total_len_high++;
    }
    part_len = SHA512_BLOCK_SIZE - index;

    if (len >= part_len)
    {
        memcpy(&ctx->buffer[index], in, part_len);
        sha512_transform(ctx->state, ctx->buffer);

        for (i = part_len; i + SHA512_BLOCK_SIZE <= len; i += SHA512_BLOCK_SIZE)
        {
            sha512_transform(ctx->state, &in[i]);
        }
        index = 0;
    }
    else
    {
        i = 0;
    }

    memcpy(&ctx->buffer[index], &in[i], len - i);

    return 0;
}

int32_t sha512_final(sha512_ctx_t *ctx, uint8_t *hash)
{
    uint32_t i;
    uint64_t bits_len, bits_len_high;
    uint32_t index, pad_len;

    if (ctx == NULL || hash == NULL)
    {
        return -1;
    }

    bits_len = ctx->total_len << 3;
    bits_len_high = (ctx->total_len_high << 3) | (ctx->total_len >> 61);
    index = (uint32_t)(ctx->total_len % SHA512_BLOCK_SIZE);
    pad_len = (index < 112) ? (112 - index) : (240 - index);

    /* Pad with 0x80 followed by zeros */
    ctx->buffer[index++] = 0x80;
    if (index > 112)
    {
        /* 需要跨两个块：当前块填 0 到尾，transform 后清前 112 字节 */
        memset(&ctx->buffer[index], 0, SHA512_BLOCK_SIZE - index);
        sha512_transform(ctx->state, ctx->buffer);
        memset(ctx->buffer, 0, 112);
    }
    else
    {
        memset(&ctx->buffer[index], 0, 112 - index);
    }

    /* Append length (big-endian 128-bit) */
    ctx->buffer[112] = (uint8_t)(bits_len_high >> 56);
    ctx->buffer[113] = (uint8_t)(bits_len_high >> 48);
    ctx->buffer[114] = (uint8_t)(bits_len_high >> 40);
    ctx->buffer[115] = (uint8_t)(bits_len_high >> 32);
    ctx->buffer[116] = (uint8_t)(bits_len_high >> 24);
    ctx->buffer[117] = (uint8_t)(bits_len_high >> 16);
    ctx->buffer[118] = (uint8_t)(bits_len_high >> 8);
    ctx->buffer[119] = (uint8_t)(bits_len_high);

    ctx->buffer[120] = (uint8_t)(bits_len >> 56);
    ctx->buffer[121] = (uint8_t)(bits_len >> 48);
    ctx->buffer[122] = (uint8_t)(bits_len >> 40);
    ctx->buffer[123] = (uint8_t)(bits_len >> 32);
    ctx->buffer[124] = (uint8_t)(bits_len >> 24);
    ctx->buffer[125] = (uint8_t)(bits_len >> 16);
    ctx->buffer[126] = (uint8_t)(bits_len >> 8);
    ctx->buffer[127] = (uint8_t)(bits_len);

    sha512_transform(ctx->state, ctx->buffer);
    (void)pad_len;

    /* Output hash in big-endian */
    for (i = 0; i < 8; i++)
    {
        hash[i * 8] = (uint8_t)(ctx->state[i] >> 56);
        hash[i * 8 + 1] = (uint8_t)(ctx->state[i] >> 48);
        hash[i * 8 + 2] = (uint8_t)(ctx->state[i] >> 40);
        hash[i * 8 + 3] = (uint8_t)(ctx->state[i] >> 32);
        hash[i * 8 + 4] = (uint8_t)(ctx->state[i] >> 24);
        hash[i * 8 + 5] = (uint8_t)(ctx->state[i] >> 16);
        hash[i * 8 + 6] = (uint8_t)(ctx->state[i] >> 8);
        hash[i * 8 + 7] = (uint8_t)(ctx->state[i]);
    }

    memset(ctx, 0, sizeof(sha512_ctx_t));

    return 0;
}

int32_t sha512(const uint8_t *in, uint32_t len, uint8_t *hash)
{
    sha512_ctx_t ctx;

    if (sha512_init(&ctx) != 0)
    {
        return -1;
    }

    if (sha512_update(&ctx, in, len) != 0)
    {
        return -1;
    }

    return sha512_final(&ctx, hash);
}

/* ============= SHA-384 Implementation ============= */

/* SHA-384 uses SHA-512 transform with different initial values.
 * Initial hash values (FIPS 180-4): first 64 bits of fractional parts of
 * square roots of 9th-16th primes. */
int32_t sha384_init(sha384_ctx_t *ctx)
{
    if (ctx == NULL)
    {
        return -1;
    }

    ctx->state[0] = 0xCBBB9D5DC1059ED8ULL;
    ctx->state[1] = 0x629A292A367CD507ULL;
    ctx->state[2] = 0x9159015A3070DD17ULL;
    ctx->state[3] = 0x152FECD8F70E5939ULL;
    ctx->state[4] = 0x67332667FFC00B31ULL;
    ctx->state[5] = 0x8EB44A8768581511ULL;
    ctx->state[6] = 0xDB0C2E0D64F98FA7ULL;
    ctx->state[7] = 0x47B5481DBEFA4FA4ULL;
    ctx->total_len = 0;
    ctx->total_len_high = 0;

    return 0;
}

int32_t sha384_update(sha384_ctx_t *ctx, const uint8_t *in, uint32_t len)
{
    uint32_t i, index, part_len;

    if (ctx == NULL || in == NULL)
    {
        return -1;
    }

    index = (uint32_t)(ctx->total_len % SHA384_BLOCK_SIZE);
    ctx->total_len += len;
    if (ctx->total_len < len)
    {
        ctx->total_len_high++;
    }
    part_len = SHA384_BLOCK_SIZE - index;

    if (len >= part_len)
    {
        memcpy(&ctx->buffer[index], in, part_len);
        sha512_transform(ctx->state, ctx->buffer);

        for (i = part_len; i + SHA384_BLOCK_SIZE <= len; i += SHA384_BLOCK_SIZE)
        {
            sha512_transform(ctx->state, &in[i]);
        }
        index = 0;
    }
    else
    {
        i = 0;
    }

    memcpy(&ctx->buffer[index], &in[i], len - i);

    return 0;
}

int32_t sha384_final(sha384_ctx_t *ctx, uint8_t *hash)
{
    uint32_t i;
    uint64_t bits_len, bits_len_high;
    uint32_t index, pad_len;

    if (ctx == NULL || hash == NULL)
    {
        return -1;
    }

    bits_len = ctx->total_len << 3;
    bits_len_high = (ctx->total_len_high << 3) | (ctx->total_len >> 61);
    index = (uint32_t)(ctx->total_len % SHA384_BLOCK_SIZE);
    pad_len = (index < 112) ? (112 - index) : (240 - index);

    /* Pad with 0x80 followed by zeros */
    ctx->buffer[index++] = 0x80;
    if (index > 112)
    {
        /* 需要跨两个块：当前块填 0 到尾，transform 后清前 112 字节 */
        memset(&ctx->buffer[index], 0, SHA384_BLOCK_SIZE - index);
        sha512_transform(ctx->state, ctx->buffer);
        memset(ctx->buffer, 0, 112);
    }
    else
    {
        memset(&ctx->buffer[index], 0, 112 - index);
    }

    /* Append length (big-endian 128-bit) */
    ctx->buffer[112] = (uint8_t)(bits_len_high >> 56);
    ctx->buffer[113] = (uint8_t)(bits_len_high >> 48);
    ctx->buffer[114] = (uint8_t)(bits_len_high >> 40);
    ctx->buffer[115] = (uint8_t)(bits_len_high >> 32);
    ctx->buffer[116] = (uint8_t)(bits_len_high >> 24);
    ctx->buffer[117] = (uint8_t)(bits_len_high >> 16);
    ctx->buffer[118] = (uint8_t)(bits_len_high >> 8);
    ctx->buffer[119] = (uint8_t)(bits_len_high);

    ctx->buffer[120] = (uint8_t)(bits_len >> 56);
    ctx->buffer[121] = (uint8_t)(bits_len >> 48);
    ctx->buffer[122] = (uint8_t)(bits_len >> 40);
    ctx->buffer[123] = (uint8_t)(bits_len >> 32);
    ctx->buffer[124] = (uint8_t)(bits_len >> 24);
    ctx->buffer[125] = (uint8_t)(bits_len >> 16);
    ctx->buffer[126] = (uint8_t)(bits_len >> 8);
    ctx->buffer[127] = (uint8_t)(bits_len);

    sha512_transform(ctx->state, ctx->buffer);
    (void)pad_len;

    /* Output first 48 bytes of hash in big-endian */
    for (i = 0; i < 6; i++)
    {
        hash[i * 8] = (uint8_t)(ctx->state[i] >> 56);
        hash[i * 8 + 1] = (uint8_t)(ctx->state[i] >> 48);
        hash[i * 8 + 2] = (uint8_t)(ctx->state[i] >> 40);
        hash[i * 8 + 3] = (uint8_t)(ctx->state[i] >> 32);
        hash[i * 8 + 4] = (uint8_t)(ctx->state[i] >> 24);
        hash[i * 8 + 5] = (uint8_t)(ctx->state[i] >> 16);
        hash[i * 8 + 6] = (uint8_t)(ctx->state[i] >> 8);
        hash[i * 8 + 7] = (uint8_t)(ctx->state[i]);
    }

    memset(ctx, 0, sizeof(sha384_ctx_t));

    return 0;
}

int32_t sha384(const uint8_t *in, uint32_t len, uint8_t *hash)
{
    sha384_ctx_t ctx;

    if (sha384_init(&ctx) != 0)
    {
        return -1;
    }

    if (sha384_update(&ctx, in, len) != 0)
    {
        return -1;
    }

    return sha384_final(&ctx, hash);
}
