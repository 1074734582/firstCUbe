/* ============================================================================
 * Copyright (c) 2010-2015.  All rights reserved.
 * SHA Hash Algorithms: SHA-1, SHA-256, SHA-512
 * ============================================================================
 */

#ifndef __SHA_HEADER__
#define __SHA_HEADER__

#ifdef  __cplusplus
extern "C" {
#endif

#include <stdint.h>

/* SHA-1 */
#define SHA1_HASH_SIZE      20
#define SHA1_BLOCK_SIZE     64

typedef struct sha1_ctx
{
    uint32_t state[5];
    uint8_t buffer[SHA1_BLOCK_SIZE];
    uint64_t total_len;
} sha1_ctx_t;

int32_t sha1_init(sha1_ctx_t *ctx);
int32_t sha1_update(sha1_ctx_t *ctx, const uint8_t *in, uint32_t len);
int32_t sha1_final(sha1_ctx_t *ctx, uint8_t *hash);
int32_t sha1(const uint8_t *in, uint32_t len, uint8_t *hash);

/* SHA-256 */
#define SHA256_HASH_SIZE    32
#define SHA256_BLOCK_SIZE   64

typedef struct sha256_ctx
{
    uint32_t state[8];
    uint8_t buffer[SHA256_BLOCK_SIZE];
    uint64_t total_len;
} sha256_ctx_t;

int32_t sha256_init(sha256_ctx_t *ctx);
int32_t sha256_update(sha256_ctx_t *ctx, const uint8_t *in, uint32_t len);
int32_t sha256_final(sha256_ctx_t *ctx, uint8_t *hash);
int32_t sha256(const uint8_t *in, uint32_t len, uint8_t *hash);

/* SHA-384 (uses SHA-512 transform with different IV, 64-byte block) */
#define SHA384_HASH_SIZE    48
#define SHA384_BLOCK_SIZE   128

typedef struct sha384_ctx
{
    uint64_t state[8];
    uint8_t buffer[SHA384_BLOCK_SIZE];
    uint64_t total_len;
    uint64_t total_len_high;
} sha384_ctx_t;

int32_t sha384_init(sha384_ctx_t *ctx);
int32_t sha384_update(sha384_ctx_t *ctx, const uint8_t *in, uint32_t len);
int32_t sha384_final(sha384_ctx_t *ctx, uint8_t *hash);
int32_t sha384(const uint8_t *in, uint32_t len, uint8_t *hash);

/* SHA-512 */
#define SHA512_HASH_SIZE    64
#define SHA512_BLOCK_SIZE   128

typedef struct sha512_ctx
{
    uint64_t state[8];
    uint8_t buffer[SHA512_BLOCK_SIZE];
    uint64_t total_len;
    uint64_t total_len_high;
} sha512_ctx_t;

int32_t sha512_init(sha512_ctx_t *ctx);
int32_t sha512_update(sha512_ctx_t *ctx, const uint8_t *in, uint32_t len);
int32_t sha512_final(sha512_ctx_t *ctx, uint8_t *hash);
int32_t sha512(const uint8_t *in, uint32_t len, uint8_t *hash);

#ifdef  __cplusplus
}
#endif

#endif
