/*
 * Advanced Encryption Standard
 * @author Dani Huertas
 * @email huertas.dani@gmail.com
 *
 * Based on the document FIPS PUB 197
 */

#include <stdint.h>

/*
 * Multiplication in GF(2^8)
 * http://en.wikipedia.org/wiki/Finite_field_arithmetic
 * Irreducible polynomial m(x) = x8 + x4 + x3 + x + 1
 * 
 * NOTE: we are using the look up table instead of the (slower) gmult function
 */

int aes_cipher_ecb_enc(uint8_t *key, uint32_t keylen, uint8_t *in, uint32_t inlen, uint8_t *out);
int aes_cipher_ecb_dec(uint8_t *key, uint32_t keylen, uint8_t *in, uint32_t inlen, uint8_t *out);

/*
 * AES-GCM 软件参考（FIPS PUB 197 + NIST SP 800-38D）
 * iv 固定 12 字节 nonce（内部补 0x00000001 作为 J0）
 * tag 固定 16 字节
 * aes_gcm_decrypt 返回 0=TAG 通过, -1=TAG 校验失败（明文不可信）
 */
void aes_gcm_encrypt(const uint8_t *key, uint32_t keylen,
                     const uint8_t *iv,
                     const uint8_t *aad, uint32_t aad_len,
                     const uint8_t *in, uint32_t in_len,
                     uint8_t *out, uint8_t *tag);
int  aes_gcm_decrypt(const uint8_t *key, uint32_t keylen,
                     const uint8_t *iv,
                     const uint8_t *aad, uint32_t aad_len,
                     const uint8_t *in, uint32_t in_len,
                     uint8_t *out, const uint8_t *tag);