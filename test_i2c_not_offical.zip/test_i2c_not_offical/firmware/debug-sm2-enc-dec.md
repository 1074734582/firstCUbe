# Debug Session: sm2-enc-dec
- **Status**: [OPEN]
- **progress_status**: collecting
- **Issue**: SM2 ENC 无 OFIFO 输出，DEC 返回固定错误明文；用户确认同一硬件此前测试通过。
- **Evidence Source**: 现有 UART printf，由用户烧录运行后回传
- **Evidence Directory**: C:\Users\2304026\AppData\Local\Temp\trae-debug\sm2-enc-dec（仅备用；当前不使用 HTTP Debug Server）

## Reproduction Steps
1. 编译并烧录当前 firmware。
2. 运行 SM2 测试套件。
3. 观察 TEST 4/5 的 enc/dec dbg、KP 对比和明文输出。

## Hypotheses & Verification
| ID | Hypothesis | Likelihood | Effort | Evidence |
|----|------------|------------|--------|----------|
| A | ENC/DEC 的 ENABLE 触发方式与已验证 SOC 流程不一致 | Med | Low | Pending |
| B | 当前边写边读时序与 SOC 的 wait_sm2_fifo/wait_sm2_done 分段时序不一致 | High | Low | Pending |
| C | DEC 输入字段顺序或输出读取时机错误 | Med | Low | Pending |
| D | 前次失败留下 OFIFO 残留，本次先读到旧数据 | High | Low | CONFIRMED：TEST5 DEC 输出的前 14B 正好是前一次 KP(d,C1) 的 golden x 坐标 |

## Log Evidence
- TEST 4 ENC: stage=2, STATE=0x000000AA, CFG=0x00000500, IFIFO_CNT=0, OFIFO_CNT=0, 预期 8 条但读到 0 条。
- TEST 4 DEC: stage=10, STATE=0x0006000A, CFG=0x00000600, 读取 32B 后 OFIFO_CNT=6，得到固定错误明文。
- TEST 5 DEC: stage=10, STATE=0x0001000A, 读取 16B 后 OFIFO_CNT=1，得到固定错误明文。
- TEST 1/2/3/8 已通过；这些路径不得修改。
- 新增 KP 诊断后：KP 返回 -3；紧接着 TEST5 DEC 得到 `33 5E 18 D7 51 E5 1F 04 0E 27 D4 68 13 8B`，与 KP(d,C1) golden x 坐标前缀完全相同，证明读到了前次操作的输出。
- 代码核对：`sm2_ip_reset()` 原先每条目只读 `OFIFO[0]`；同系列 ECC/DES 已验证实现均连续读 `OFIFO[0..3]` 才弹出一条 16B 记录。

## Minimal Fix
- 第一处：`sm2_ip_reset()` 的 OFIFO 排空循环每次连续读取 4 个 32-bit 字。19:36 复现结果完全不变，因此该修正不是当前主因。
- 第二处：移除 ENC/DEC 在 IFIFO/OFIFO 等待期间的重复 ENABLE，仅保留启动时一次触发；复现仍完全不变，排除该单项为根因。
- 项目历史记录给出明确回归窗口：17:49 TEST1~5/8 曾全部通过；18:26 引入两步 CFG 启动和 C1→C2→C3 输出映射后 TEST4/5 开始失败。
- 第三处：`sm2_start` 恢复历史已通过的 `PKG_LEN → CFG|ENABLE` 一次写入。
- 用户提供 msg=32 实测通过的旧 `rsp_ip_sm2.c` 后，第四处直接恢复其 ENC/DEC 主流程：连续写完所有输入，不在静态输入与变长数据之间等待，不按 entry 边写边读；ENC 依次读取 C1/C2/C3，DEC 写完后读取明文。复位排空也恢复旧版实现。
- 旧源码明确输出为 C1→C2→C3，因此不再采用 C2 先出的推测。
- 20:09 烧录仍失败，继续恢复遗漏的公共路径差异：删除 `sm2_start` 的 10000 次调试延时/STATE 读取；非 sign/verify 的 `sm2_pull_entry` 恢复旧版“首次读取前且 IFIFO 未空时低频补触发 ENABLE”；删除 ENC 启动后的额外调试写。
- 未改 sign/verify 专用路径。
- 每次修改后均运行 `gcc -fsyntax-only -std=gnu99 -Wall -Wextra -Werror` 检查。

## Verification Conclusion
等待 KP(d,C1) 对比和严格 SOC 时序实验证据。

## Final Evidence Gate
- **Evidence Sources**: 用户回传的 UART 输出；source/core/sm2_enc_test_soc.txt；source/core/sm2_dec_soc.txt
- **progress_status**: collecting
- **Hypothesis Conclusions**: A/B/C/D 均 INCONCLUSIVE
