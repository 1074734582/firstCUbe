import re, hashlib

with open(r'z:\ccrc\test_i2c_not_offical\firmware\source\app\rsa_test_vectors.h', 'r', encoding='utf-8-sig') as f:
    src = f.read()

def extract_array(name):
    m = re.search(rf'static const uint8_t {name}\[\d+\] = \{{([^}}]+)\}};', src)
    vals = re.findall(r'0x([0-9A-Fa-f]+)', m.group(1))
    return bytes(int(v,16) for v in vals)

N = extract_array('TEST_N_256')
D = extract_array('TEST_D_256')
E_int = 65537
SHA256_TLV = bytes.fromhex('3031300D060960864801650304020105000420')
msg = bytes(range(256))
msg_rev = msg[::-1]
zero = b'\x00' * 256
N_rev = N[::-1]
D_rev = D[::-1]

def pkcs1v15_pad(digest_bytes):
    em = bytearray(256)
    em[0]=0x00; em[1]=0x01
    for i in range(2, 2+202): em[i]=0xFF
    em[2+202]=0x00
    em[2+203:2+203+19] = SHA256_TLV
    em[2+203+19:2+203+19+32] = digest_bytes
    return bytes(em)

def swap32(b):
    out = bytearray()
    for i in range(0, len(b), 4):
        out += b[i:i+4][::-1]
    return bytes(out)

hw_ramp_hex = (
    '60ACE48DB52B45D3A645EA374B1218D9BDCA70F15E51FA69AB2683C295FD0376'
    'DDB492F57C107C8E8337AE9688B21B6BBB885E876C125C7FB702CAF6871B5E84'
    '983CBDE7DB62167DA7DC8F6481299276BF4FE4A4ABFC7FA24E4AEA638E37CF96'
    '64BF9C3D72213CE6166C22B3E41C0B93C13045D7F0CB12E2DCA7BB6269107CBA'
    '73BA2E3EECBD5F8AD8CE711D1D2E3EE3F32590A520B1AB4C44344F448B41761D'
    'BB5E9D39C380597A58349FA371B67428E8873D8734869541EDD6F97B0B9E0FCF'
    'A2E4D03AED719C0FD4D78D3D9A8F33E5673F6142FB156E517D839C836B17A421'
    '86700D983BFFA97DD9BD7544E39622D6D6273FD5D255AA2FD748889350EDFE49'
)
hw_zero_hex = (
    'BF92E42B528B726F9DB3A43119C9A334B5D5FB6B7FEEB514F2A680E93ADD6297'
    'DABC0046D0FFEAD85C63D73ADE6A99A64BF8DA63F65BF1BD6D02E3CE2B378F40'
    'F0645070A77BFB14E1BA3B097B703252A4CB57E77EB318714620CAC69BBA700C'
    '9519DE882C8E432A7B2DAB59CB0A90E4F01D5E9463025E37232A0360A6641681'
    '1E4F3946DAD8B0D50D10E4E7CA786062A6FAFE08562D2E9DB5FA2B8AE392E101'
    'CBAFC28EBC6BA256716207EEE2343023F6BCCDF8C4A14A57208FE1BCB098DBAD'
    'FFECCCD2586D56BAA806D0B91ACF1045677799D58BE4C01C2E9BF22C6C397C12'
    '853AFA4BAA5E3E69BD88BA2B180B86C30CFAABFF7D546098CE9E6962DF288640'
)
sig_ramp = bytes.fromhex(hw_ramp_hex)
sig_zero = bytes.fromhex(hw_zero_hex)

N_int = int.from_bytes(N, 'big')
D_int = int.from_bytes(D, 'big')
EM_ramp = pow(int.from_bytes(sig_ramp,'big'), E_int, N_int).to_bytes(256,'big')
EM_zero = pow(int.from_bytes(sig_zero,'big'), E_int, N_int).to_bytes(256,'big')

print("===== Comprehensive brute force =====")
print(f"HW ramp sig head  = {sig_ramp[:8].hex().upper()}")
print(f"HW zero sig head  = {sig_zero[:8].hex().upper()}")
print()
print(f"EM_ramp[0..1]  = {EM_ramp[0]:02X} {EM_ramp[1]:02X}")
print(f"EM_ramp[203]   = {EM_ramp[203]:02X}")
print(f"EM_ramp[204:223] = {EM_ramp[204:223].hex().upper()}")
print(f"EM_ramp[224:256] = {EM_ramp[224:256].hex().upper()}")
print()
print(f"EM_zero[0..1]  = {EM_zero[0]:02X} {EM_zero[1]:02X}")
print(f"EM_zero[203]   = {EM_zero[203]:02X}")
print(f"EM_zero[204:223] = {EM_zero[204:223].hex().upper()}")
print(f"EM_zero[224:256] = {EM_zero[224:256].hex().upper()}")

# 让我看 HW EM 的完整 hex dump
print("\n===== EM_ramp full dump =====")
for i in range(0, 256, 16):
    print(f"  {i:03X}: {EM_ramp[i:i+16].hex().upper()}")

print("\n===== EM_zero full dump =====")
for i in range(0, 256, 16):
    print(f"  {i:03X}: {EM_zero[i:i+16].hex().upper()}")

# ====== 关键测试: EM 是不是 raw SHA-256 digest? ======
# 如果 padding 块完全坏了, 也许它直接把 SHA-256 块输出的 digest 放在 EM 某个位置
# 让我穷举每个 EM offset 和每个可能的 SHA-256 输入
print("\n===== Find SHA-256 digest in HW EM =====")

candidates = {
    'msg': msg, 'msg_rev': msg_rev,
    'msg_swap32': swap32(msg), 'msg_rev_swap32': swap32(msg_rev),
    'msg_rev_swap32_rev': swap32(msg_rev)[::-1],
    'msg_doublerev32': swap32(msg)[::-1],  # 先 swap32 再整体 rev = rev 再 swap32
    'N': N, 'N_rev': N_rev, 'N_swap32': swap32(N),
    'D': D, 'D_rev': D_rev, 'D_swap32': swap32(D),
}

# 先只测 ramp, 看看 HW EM 里有没有任何 SHA-256 digest
for name, data in candidates.items():
    d = hashlib.sha256(data).digest()
    for offset in range(0, 225, 1):
        if EM_ramp[offset:offset+32] == d:
            print(f'  RAMP: SHA256({name}) found at EM offset {offset}')
        if EM_zero[offset:offset+32] == d:
            print(f'  ZERO: SHA256({name}) found at EM offset {offset}')

# 也看 EM 反转后的窗口
EM_ramp_rev = EM_ramp[::-1]
EM_zero_rev = EM_zero[::-1]
for name, data in candidates.items():
    d = hashlib.sha256(data).digest()
    for offset in range(0, 225, 1):
        if EM_ramp_rev[offset:offset+32] == d:
            print(f'  RAMP_REV: SHA256({name}) found at offset {offset}')
        if EM_zero_rev[offset:offset+32] == d:
            print(f'  ZERO_REV: SHA256({name}) found at offset {offset}')

print("===== Done =====")
