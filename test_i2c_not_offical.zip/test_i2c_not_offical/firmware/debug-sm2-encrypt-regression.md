# Debug Session: sm2-encrypt-regression
- **Status**: [OPEN]
- **progress_status**: collecting
- **Issue**: SM2 TEST6 的 128B 此前通过，当前 128B 加密返回 -3；输入已写完，但只收到 10/14 个输出条目。
- **Evidence Source**: 固件现有串口 printf（关键路径仅记录快照，返回后打印）；HTTP Debug Server 主机探针成功
- **Evidence Directory**: C:\Users\2304026\AppData\Local\Temp\trae-debug\sm2-encrypt-regression
- **Log File**: C:\Users\2304026\AppData\Local\Temp\trae-debug\sm2-encrypt-regression\trae-debug-log-sm2-encrypt-regression.ndjson

## Reproduction Steps
1. 编译并烧录当前固件，复位运行 `sm2_test()`。
2. 执行 TEST6 的 128B 加密。
3. 观察到 `ret=-3 stage=2 STATE=0xAA IF_CNT=0 OF_CNT=0 in_ofs=128 out_cnt=10`。

## Hypotheses & Verification
| ID | Hypothesis | Likelihood | Effort | Evidence |
|----|------------|------------|--------|----------|
| A | 最新超时 guard/进度打印导致回归 | Low | Low | REJECTED：失败 stage=2，非新增 stage=7 |
| B | 驱动期望 14 条输出但硬件只给出 10 条 | High | Low | CONFIRMED：`total_out=14`，`out_cnt=10`，之后 OFIFO 恒空 |
| C | 启动前 FIFO/算核残留 | Medium | Low | REJECTED：冷启动 `pre_reset/start=0xAA`，FIFO 全空 |
| D | 整块写入导致 OFIFO 灌满后丢输出 | High | Low | CONFIRMED：`post_write=0x00080450`，OF_CNT=8 且 OFIFO_FULL |

## Log Evidence
- pre-fix 串口：`len=128: encrypt ret=-3 ... stage=2 IF_CNT=0 OF_CNT=0 in_ofs=128 out_cnt=10`。
- 128B 理论输出条目数：`C1(4)+C2(8)+C3(2)=14`，实际只有 10 条。
- 冷启动 trace：`pre_reset=0x000000AA start=0x000000AA static_in=0x000000AA pre_write=0x0004000A post_write=0x00080450 post_read=0x0002000A total_out=14 c2_ent=8`
  - `0x000000AA`：IFIFO/OFIFO 全空 → 无复位残留
  - `0x0004000A`：OF_CNT=4（C1 已产出）、IFIFO 空
  - `0x00080450`：OF_CNT=8 且 OFIFO_FULL 置位 → 输出 FIFO 被灌满
  - `0x0002000A`：读走 8 条后仅剩 2 条，其后永久为空

## Instrumentation
- `rsp_ip_sm2.c`：记录复位前、启动后、固定输入后、块写前、块写后、块读后的 STATE，以及 total_out/c2_ent。
- `test_sm2.c`：仅在加密返回后输出结构化 `[DEBUG]` 快照，不在 FIFO 读写关键路径打印。
- 语法检查：`gcc -std=gnu99 -Wall -Wextra -Werror -fsyntax-only` 通过。
- 下一次复现要求：完全断电重启 FPGA 后烧录当前固件，仅采集首轮 128B 日志，runId=`pre-fix`。

## Verification Conclusion
- 根因：整块 8 条灌入后算核一次性产出超过 OFIFO 剩余空间的条目，FIFO 满后剩余 C2/C3 丢失。
- 修复：加密/解密改为逐条写入并在每次写入后立即非阻塞排空 OFIFO，使 FIFO 占用始终很低。
- 待 post-fix：重新烧录后确认 128/512/1024B 串口出现 `round-trip OK`。

## Final Evidence Gate
- **Evidence Sources**: 用户串口日志；待添加的本地结构化 printf  instrumentation
- **progress_status**: collecting
- **Hypothesis Conclusions**: A 初步 REJECTED；B/C/D INCONCLUSIVE
