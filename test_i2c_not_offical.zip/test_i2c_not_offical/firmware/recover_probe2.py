import re, hashlib

with open(r'z:\ccrc\test_i2c_not_offical\firmware\source\app\rsa_test_vectors.h', 'r', encoding='utf-8-sig') as f:
    src = f.read()

def extract_array(name):
    m = re.search(rf'static const uint8_t {name}\[\d+\] = \{{([^}}]+)\}};', src)
    vals = re.findall(r'0x([0-9A-Fa-f]+)', m.group(1))
    return bytes(int(v,16) for v in vals)

N = extract_array('TEST_N_256')
N_int = int.from_bytes(N, 'big')
E_int = 65537
SHA256_TLV = bytes.fromhex('3031300D060960864801650304020105000420')

def recover_em(sig_hex):
    sig = bytes.fromhex(sig_hex.replace(' ',''))
    em = pow(int.from_bytes(sig,'big'), E_int, N_int).to_bytes(256,'big')
    return em

# 0xAA sig
aa_sig = (
    'FFFFFFFFFFFFFFFF0100FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    'FFFFFFFFFFFFFFFF30313000FFFFFFFF650148866009060D2004000501020403'
    'A16F7B9A3DF3AFF6D871AC12FD9BC1DE80ADA7B718145960ACD88F4E34276CCD'
)
em_aa = recover_em(aa_sig)
em_aa_rev = em_aa[::-1]

print("===== 0xAA EM vs EM reversed =====")
print(f"EM[0:2]     = {em_aa[0]:02X} {em_aa[1]:02X}")
print(f"EM_rev[254:256] = {em_aa_rev[254]:02X} {em_aa_rev[255]:02X} (should be 00 01 if padding was LE)")
print(f"EM[203]     = {em_aa[203]:02X}")
print(f"EM_rev[52]  = {em_aa_rev[52]:02X} (255-203=52, should be 0x00 separator)")
print(f"EM[204:223] = {em_aa[204:223].hex().upper()}")
print(f"EM_rev[32:52] = {em_aa_rev[32:52].hex().upper()} (255-223=32)")
print(f"Expected TLV = {SHA256_TLV.hex().upper()}")
print()

# 检查整个 EM reversed 有没有 pkcs1v15 结构
# pkcs1v15: [00] [01] [0xFF*202] [00] [TLV 19B] [digest 32B]
# 如果 HW 输出的是 LE 版本，那 reversed 应该是:
# [digest 32B] [TLV 19B rev?] [00] [0xFF*202] [01] [00]
# 不对... 整个 EM 反转的话, digest 会在头部
print("===== Test: padding block outputs pkcs1v15 but LE byte order =====")
# 正确 pkcs1v15 big-endian EM:
# offset 0:   00
# offset 1:   01
# offset 2-202: 0xFF
# offset 203: 00
# offset 204-222: SHA256 TLV (19B)
# offset 224-255: SHA256 digest (32B)

# 如果整个 EM 被小端存储, 那 modpow 块收到的是:
# digest(rev) + TLV(rev) + 00 + FF + FF + ... + FF + 01 + 00
# 即 EM_reversed

# 那 HW EM 应该等于 pkcs1v15_big_endian[::-1]
# 让我生成正确的 pkcs1v15 EM (big-endian), 反转后对比

# 先算 SHA256(256*0xAA)
msg_aa = bytes([0xAA] * 256)
digest_aa = hashlib.sha256(msg_aa).digest()
print(f"Golden SHA256(256*0xAA) = {digest_aa.hex().upper()}")

# 正确 pkcs1v15 EM (big-endian)
correct_em = bytearray(256)
correct_em[0] = 0x00; correct_em[1] = 0x01
for i in range(2, 203): correct_em[i] = 0xFF
correct_em[203] = 0x00
correct_em[204:223] = SHA256_TLV
correct_em[224:256] = digest_aa

# 反转整个 EM -> 小端版本
le_em = bytes(correct_em[::-1])
print(f"Correct BE EM head: {bytes(correct_em)[:8].hex().upper()}")
print(f"Correct LE EM head (rev): {le_em[:8].hex().upper()}")
print(f"HW EM head: {em_aa[:8].hex().upper()}")
print(f"Match HW == pkcs1v15_LE? {bytes(correct_em[::-1]) == em_aa}")

# 也试 padding 内部元素分别反转
# 比如: 每个 32-bit word 反转
def wordswap32(b):
    out = bytearray()
    for i in range(0, len(b), 4):
        out += b[i:i+4][::-1]
    return bytes(out)

print(f"\nCorrect EM word-swapped: {wordswap32(bytes(correct_em))[:8].hex().upper()}")
print(f"HW EM:                  {em_aa[:8].hex().upper()}")
print(f"Match? {wordswap32(bytes(correct_em)) == em_aa}")

# 试 digest 单独反转
correct_em_digest_rev = bytearray(correct_em)
correct_em_digest_rev[224:256] = digest_aa[::-1]
# 试 TLV 单独反转
correct_em_tlv_rev = bytearray(correct_em)
correct_em_tlv_rev[204:223] = SHA256_TLV[::-1]
# 试 padding 部分反转
correct_em_pad_rev = bytearray(256)
correct_em_pad_rev[255] = 0x00
correct_em_pad_rev[254] = 0x01
for i in range(0, 252-2): correct_em_pad_rev[253-i] = 0xFF  # 202 bytes of FF from right
correct_em_pad_rev[253-202] = 0x00
correct_em_pad_rev[32:51] = SHA256_TLV  # reversed offset
correct_em_pad_rev[0:32] = digest_aa

print(f"\n===== 详细字节级对比 =====")
print(f"HW EM[0:16]   = {em_aa[0:16].hex().upper()}")
print(f"Correct EM[0:16] = {bytes(correct_em)[0:16].hex().upper()}")

# 让我看 HW EM 是不是 correct EM 做了 word swap
for bitpos in range(0, 16):
    if em_aa[bitpos] != correct_em[bitpos]:
        print(f"  diff at offset {bitpos}: HW=0x{em_aa[bitpos]:02X} expected=0x{correct_em[bitpos]:02X}")

print(f"\n===== 关键发现: 0xAA sig 原始 hex 里的 TLV =====")
# 原始 sig hex dump 里 offset 0x60 开始:
# 30313000FFFFFFFF650148866009060D2004000501020403
# 正确: 3031300D 060960864801650304 0201 0500 0420
# HW:   30313000 FFFFFFFF 650148866009060D 20040005 0102 0403
# 对比:
# correct: 30 31 30 0D 06 09 60 86 48 01 65 03 04 02 01 05 00 04 20
# HW:      30 31 30 00 FF FF FF FF 65 01 48 86 60 09 06 0D 20 04 00 05 01 02 04 03
# 哇! 看 HW[0:4] = 30 31 30 00 vs correct[0:4] = 30 31 30 0D
# HW[4:8] = FF FF FF FF vs correct[4:8] = 06 09 60 86
# HW[8:12] = 65 01 48 86 vs correct[8:12] = 48 01 65 03
# HW[12:16] = 60 09 06 0D vs correct[12:16] = 04 02 01 05
# HW[16:20] = 20 04 00 05 vs correct[16:20] = 00 04 20 ...
# 这完全像 32-bit words 被 rev 了!
print(f"\nTLV word comparison (32-bit BE words):")
import struct
tlv_words = struct.unpack('>5I', SHA256_TLV)
print(f"Correct TLV as 5x32-bit BE words: {[hex(w) for w in tlv_words]}")
hw_tlv = bytes.fromhex('30313000FFFFFFFF650148866009060D2004000501020403')  # 25 bytes
# 不对, HW TLV 区域应该只看 padding 块输出的, 不是 sig 里的
# 让我从 EM 恢复 TLV 区域
# EM 的 TLV 区域应该在 offset 204 附近

# 等一下! 我应该先搞清楚 sig = EM^D mod N, 所以 EM = sig^E mod N
# EM 是 padding 块输出给 modpow 的
# 现在 EM 完全乱的...

# 但 sig 的原始 hex 里能看出 pkcs1v15 结构的碎片
# 这说明 modpow 块是对的 (它只是算 EM^D)
# 问题在 padding 块输出的 EM

# 让我直接对比: padding 块到底输出了什么?
# 就是 EM = sig^E = padding 输出

# 0xAA padding 输出 EM 的 hex:
# 29D40E79F815093D1BC8FABE3EF65546
# 9249FEBD88259F1AB693E2FA56866DDF
# EB5CFF7BBA5DF7DBCB45772F7B8A8798
# 7DDD02E64F88AE29DCC421B78401D8D5
# ...
# 完全不像是任何 pkcs1v15 变体

# 等等! 让我看看 0xAA sig 的原始 hex 更仔细
# sig head = FF FF FF FF FF FF 01 00
# 正确 pkcs1v15 head = 00 01 FF FF FF ...
# 哦 my god! 0xAA sig head "FFFFFFFFFF0100" 完全就是 pkcs1v15 head "00 01 FF FF FF FF" 小端格式!
# 因为 modpow 输出是小端的 (驱动里 put_rev 了)
# 所以 OFIFO 里的 sig raw = 00 01 FF FF FF FF ... (小端 word 先出)
# 反转后 (驱动 rev_bytes) = FF FF FF FF FF FF 01 00 (大端)
# 对! 这就是 Layer1 0xAA sig 的头部!!

# 那 modpow 块接收的 EM 应该是正确 pkcs1v15 格式
# modpow 块输出 sig = EM^D (大端整数), 但被硬件按小端 OFIFO 输出
# 等等... 让我重新理清楚

# 实际上:
# - padding 块输出 EM (大端整数)
# - modpow 块计算 sig = EM^D mod N (大端整数结果)
# - OFIFO 输出 sig 的字节序: 硬件小端 (LSB first)
# - 我们读 OFIFO 后做 rev_bytes 得到大端 sig

# 所以 0xAA 的 sig head = FF FF FF FF FF FF 01 00 (大端 after rev)
# = 00 01 FF FF FF FF ... (OFIFO raw, before rev)
# 这就是 pkcs1v15 head 的小端存储!

# 那 padding 块输出的 EM 是什么呢?
# EM = sig^E mod N = padding 块送给 modpow 的原始数据
# 但我们 recovered EM 完全不对...

# 等等! 让我重新看 sig 和 EM 的关系
# 如果 HW sig (大端) 是 "FFFFFFFFFFFF0100..."
# EM = sig^E mod N
# 但 recovered EM head 是 29 D4...
# 这不可能... 除非我 recover 方法错了?

# 但之前对 TEST_SIG_256 做了同样的 recover, 得到了 TEST_EM_256, 是对的
# 数学验证 OK

# 那 recovered EM 就是 padding 块输出的... 完全乱的东西

# 但是 sig 头部有 pkcs1v15 的碎片!
# 让我算: 如果 EM 是正确的 pkcs1v15, sig = EM^D 会不会也有类似头部?

from cryptography.hazmat.primitives.asymmetric.padding import PKCS1v15
# 没装 cryptography, 直接算
N_int = int.from_bytes(N, 'big')
D = extract_array('TEST_D_256')
D_int = int.from_bytes(D, 'big')

# 正确的 pkcs1v15 EM for 0xAA
correct_em_int = int.from_bytes(bytes(correct_em), 'big')
correct_sig = pow(correct_em_int, D_int, N_int).to_bytes(256, 'big')
print(f"\nCorrect pkcs1v15 sig for 0xAA head: {correct_sig[:16].hex().upper()}")
print(f"HW 0xAA sig head:                   {aa_sig[:16].hex().upper()}")
print(f"BIG DIFFERENCE! Correct sig head != FFFF...0100")

# 那 HW sig 头部 FFFF...0100 到底是什么意思?
# 让我看看 HW sig^E 恢复的 EM
print(f"\nHW 0xAA sig: {aa_sig[:32].hex().upper()}")
print(f"Recovered EM[0:16]: {em_aa[0:16].hex().upper()}")
print(f"Recovered EM[0x60:0x74]: {em_aa[0x60:0x74].hex().upper()}")  # 100~116
# 之前 raw sig dump 里 offset 0x60 开始的 TLV-like 东西
# 但那是 sig, 不是 EM!

# 让我看 recovered EM 里有没有 SHA256 TLV 的碎片
for offset in range(256-20):
    if em_aa[offset:offset+4] == b'\x30\x31\x30\x00':  # 正确是 3031300D
        print(f"  Found 30313000-like TLV at EM offset {offset}")
    if em_aa[offset:offset+4] == b'\x30\x31\x30\x0D':
        print(f"  Found correct TLV start 3031300D at EM offset {offset}")
