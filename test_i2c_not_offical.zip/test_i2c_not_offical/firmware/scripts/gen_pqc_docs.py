﻿# -*- coding: utf-8 -*-
"""生成 PQC E203 (Kyber-512) 两份交付文档：
1) PQC软件合格性测试用例.docx
2) PQC软件合格性测试报告.docx（对齐 PLD 模板）
自包含样式助手（与 ECC 文档一致的版式）。
"""
import os
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml

ROOT = r"z:\ccrc\test_i2c_not_offical\firmware"
CN = "宋体"
EN = "Times New Roman"
MONO = "Consolas"


def setrun(run, size=10.5, bold=False, color=None, latin=EN):
    run.font.name = latin
    rpr = run._element.get_or_add_rPr()
    rfont = rpr.find(qn("w:rFonts"))
    if rfont is None:
        rfont = parse_xml(r'<w:rFonts %s w:ascii="%s" w:hAnsi="%s"/>' % (nsdecls("w"), latin, latin))
        rpr.append(rfont)
    rfont.set(qn("w:eastAsia"), CN)
    run.font.size = Pt(size)
    run.font.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)


def new_doc(margins=(3.0, 2.5, 2.5, 2.0), line=1.4):
    d = Document()
    s = d.sections[0]
    s.page_width = Cm(21)
    s.page_height = Cm(29.7)
    s.left_margin = Cm(margins[0])
    s.right_margin = Cm(margins[1])
    s.top_margin = Cm(margins[2])
    s.bottom_margin = Cm(margins[3])
    st = d.styles["Normal"]
    st.font.name = EN
    st.font.size = Pt(10.5)
    rpr = st.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = parse_xml(r'<w:rFonts %s w:ascii="%s" w:hAnsi="%s"/>' % (nsdecls("w"), EN, EN))
        rpr.append(rfonts)
    rfonts.set(qn("w:eastAsia"), CN)
    st.paragraph_format.line_spacing = line
    st.paragraph_format.space_after = Pt(3)
    return d


def h(doc, level, text):
    p = doc.add_paragraph(style="Heading %d" % level)
    run = p.add_run(text)
    sizes = {1: 15, 2: 12.5, 3: 11.5}
    setrun(run, sizes.get(level, 11), True, color=(0, 0, 0))
    p.paragraph_format.space_before = Pt(10 if level == 1 else 7)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.2
    return p


def body(doc, text, indent=0.74, size=10.5, bold=False, align=None, space_after=3):
    p = doc.add_paragraph()
    run = p.add_run(text)
    setrun(run, size, bold)
    if indent:
        p.paragraph_format.first_line_indent = Cm(indent)
    if align is not None:
        p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    return p


def code(doc, text, size=9):
    p = doc.add_paragraph()
    run = p.add_run(text)
    setrun(run, size, latin=MONO)
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.left_indent = Cm(0.5)
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.space_after = Pt(2)
    p._p.get_or_add_pPr().append(parse_xml('<w:shd %s w:fill="F2F2F2"/>' % nsdecls("w")))
    return p


def cell_text(cell, text, size=9.5, bold=False, align=WD_ALIGN_PARAGRAPH.CENTER, bg=None):
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_after = Pt(0)
    lines = str(text).split("\n")
    for i, line in enumerate(lines):
        if i:
            p = cell.add_paragraph()
            p.paragraph_format.line_spacing = 1.15
            p.paragraph_format.space_after = Pt(0)
        run = p.add_run(line)
        setrun(run, size, bold)
        p.alignment = align
    if bg:
        cell._tc.get_or_add_tcPr().append(parse_xml('<w:shd %s w:fill="%s"/>' % (nsdecls("w"), bg)))
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def _row_opts(row, header=False):
    trPr = row._tr.get_or_add_trPr()
    trPr.append(parse_xml('<w:cantSplit %s/>' % nsdecls("w")))
    if header:
        trPr.append(parse_xml('<w:tblHeader %s/>' % nsdecls("w")))


def make_table(doc, headers, rows, widths=None, size=9.5, head_bg="D9E1F2",
               first_center=True, align_left=True):
    t = doc.add_table(rows=1 + len(rows), cols=len(headers))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.style = "Table Grid"
    t.autofit = False
    for i, hd in enumerate(headers):
        cell_text(t.rows[0].cells[i], hd, size, True, bg=head_bg)
    _row_opts(t.rows[0], header=True)
    for r, row in enumerate(rows):
        _row_opts(t.rows[r + 1])
        for c, val in enumerate(row):
            al = WD_ALIGN_PARAGRAPH.CENTER
            if not (first_center and c == 0):
                al = WD_ALIGN_PARAGRAPH.LEFT if align_left else WD_ALIGN_PARAGRAPH.CENTER
            cell_text(t.rows[r + 1].cells[c], val, size, False, align=al)
    if widths:
        for i, w in enumerate(widths):
            t.columns[i].width = Cm(w)
            for row in t.rows:
                row.cells[i].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def cover(doc, title, subtitle, info, history=None, signature=True):
    for _ in range(3):
        doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    setrun(p.add_run(title), 25, True)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    setrun(p.add_run(subtitle), 19, True)
    for _ in range(3):
        doc.add_paragraph()
    t = doc.add_table(rows=len(info), cols=2)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.style = "Table Grid"
    t.autofit = False
    for i, (k, v) in enumerate(info):
        cell_text(t.rows[i].cells[0], k, 10.5, True, bg="E2EFDA")
        cell_text(t.rows[i].cells[1], v, 10.5, False, align=WD_ALIGN_PARAGRAPH.LEFT)
        t.rows[i].cells[0].width = Cm(3.6)
        t.rows[i].cells[1].width = Cm(11.0)
    if signature:
        doc.add_paragraph()
        t = doc.add_table(rows=3, cols=4)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.style = "Table Grid"
        t.autofit = False
        pairs = [("编  制", "", "工  艺", ""), ("校  核", "", "标准化", ""), ("审  核", "", "批  准", "")]
        for r, (a, b, c, dd) in enumerate(pairs):
            cell_text(t.rows[r].cells[0], a, 10.5, True, bg="F2F2F2")
            cell_text(t.rows[r].cells[1], b, 10.5)
            cell_text(t.rows[r].cells[2], c, 10.5, True, bg="F2F2F2")
            cell_text(t.rows[r].cells[3], dd, 10.5)
            for i, w in enumerate([3.0, 4.8, 3.0, 4.8]):
                t.rows[r].cells[i].width = Cm(w)
    if history:
        p = doc.add_paragraph()
        setrun(p.add_run("版 本 历 史"), 10.5, True)
        make_table(doc, ["版本号", "更改人", "更改日期", "更改说明", "变更编号"],
                   history, [2.0, 3.0, 2.8, 5.2, 2.5], size=9.5)
    doc.add_page_break()


# ------------------------------------------------------------------
# 文档一：软件合格性测试用例
# ------------------------------------------------------------------
def gen_cases():
    d = new_doc()
    cover(d,
          "PQC E203（Kyber-512）KEM 单元",
          "软件合格性测试用例",
          [("项目名称", "可信密码算法固件 — PQC E203 单元"),
           ("文档编号", "PQC-SW-TC-2026-001"),
           ("版本", "A"),
           ("编制日期", "2026-11-05"),
           ("密级", "内部")],
          signature=False)

    h(d, 1, "1  引言")
    body(d, "本文档给出 PQC E203（Kyber-512）后量子密钥封装（KEM）算法单元的软件合格性测试用例，共 3 条，"
            "分别覆盖密钥生成（keygen）、封装/加密（enc）、解封装/解密（dec）三个测试函数。"
            "三个函数按 keygen → enc → dec 顺序构成完整 KEM 闭环，判定依据为与 e203_512_data.h 中的 "
            "golden data 参考向量逐 32bit 字比对，且 dec 恢复的共享密钥 ss 必须与 enc 产出的 golden ss 一致。"
            "配套文档：《PQC单元集成合格性测试设计说明书-软件》（被测对象、环境与策略）、"
            "《PQC软件合格性测试报告》（编号 PQC-SW-TR-2026-001，执行记录与结论）。")

    h(d, 1, "2  用例总览")
    make_table(d,
               ["用例编号", "测试函数", "被测对象", "输入数据", "任务描述块", "循环次数"],
               [["TC-PQC-KG", "pkpu_e203_keygen_512_test", "PQC0 IP 密钥生成", "seed 32B + 常量 40B", "416 字", "1"],
                ["TC-PQC-EN", "pkpu_e203_enc_512_test", "PQC0 IP 封装", "seed 32B + pk 800B + 常量 32B", "768 字", "1"],
                ["TC-PQC-DE", "pkpu_e203_dec_512_test", "PQC0 IP 解封装", "sk 1632B + ct 768B + 常量 32B", "1756 字", "1"],
                ["汇总", "—", "—", "—", "—", "3"]],
               [2.4, 3.9, 3.0, 3.9, 1.6, 1.4])

    d.add_page_break()
    h(d, 1, "3  测试用例详情")

    h(d, 2, "3.1  TC-PQC-KG  Kyber-512 密钥生成（keygen）")
    body(d, "被测接口: pkpu_e203_keygen_512_test(void)  —— source/app/e203/512/e203_512_test.c L6")
    make_table(d,
               ["项", "内容"],
               [["用例编号", "TC-PQC-KG"],
                ["用例名称", "Kyber-512 密钥生成 golden data 比对"],
                ["被测接口", "pkpu_e203_keygen_512_test(void)"],
                ["用例描述", "向 PQC0 IP 写入 32B 随机种子与密钥生成常量、416 字任务描述块后启动算核，"
                             "从数据内存读回公钥 pk（200 字 / 800B）与私钥 sk（前 392 字 / 1568B），"
                             "与 e203_512_pk[] / e203_512_sk[] golden 数组逐 32bit 字比对，验证密钥生成功能正确性。"],
                ["测试步骤", "1) 写 keygen_const[10] 到 MEM+0x9400（4736×8）；\n"
                             "2) 写 keygen_task[416] 到 TASK（0x60200000）；\n"
                             "3) 写 keygen_seed[8] 到 MEM+0x0；\n"
                             "4) 写 PQC0_BASE（0x60000000）= 0 启动，轮询 BASE+4 直到等于 1；\n"
                             "5) 从 MEM+0xC300（6240×8）读 pk 200 字与 golden 逐字比对；\n"
                             "6) 从 MEM+0xC000（6144×8）读 sk 前 392 字与 golden 逐字比对；\n"
                             "7) 打印耗时 us、perf（times/s）与 done 标志。"],
                ["预期结果", "pk 200 字、sk 前 392 字全部与 golden 一致；串口无任何 “compare failed” 行；"
                             "末尾打印 “pkpu_e203_keygen_512_test ALGO_FUN done”"],
                ["执行次数", "1"],
                ["实际结果", "通过 1/1 次（读回数据与 golden 数组逐字一致）"],
                ["执行结论", "通过"]],
               [3.0, 12.0], size=9.5)
    body(d, "")

    h(d, 2, "3.2  TC-PQC-EN  Kyber-512 封装（enc）")
    body(d, "被测接口: pkpu_e203_enc_512_test(void)  —— source/app/e203/512/e203_512_test.c L66")
    make_table(d,
               ["项", "内容"],
               [["用例编号", "TC-PQC-EN"],
                ["用例名称", "Kyber-512 封装 golden data 比对"],
                ["被测接口", "pkpu_e203_enc_512_test(void)"],
                ["用例描述", "向 PQC0 IP 写入封装常量、768 字任务描述块、32B 随机种子与公钥 pk（200 字 / 800B）后启动算核，"
                             "读回密文 ct（192 字 / 768B）与共享密钥 ss（7 字），与 e203_512_enc_ct[] / e203_512_enc_ss[] "
                             "golden 数组逐字比对，验证封装功能正确性。"],
                ["测试步骤", "1) 写 enc_task[768] 到 TASK（0x60200000）；\n"
                             "2) 写 enc_const[8] 到 MEM+0x6200（3136×8）；\n"
                             "3) 写 enc_seed[8] 到 MEM+0x0；\n"
                             "4) 写 e203_512_pk[200] 到 MEM+0x6400（3200×8）；\n"
                             "5) 写 PQC0_BASE = 0 启动，轮询 BASE+4 直到等于 1；\n"
                             "6) 从 MEM+0xC000（6144×8）读 ct 192 字、从 MEM+0x6400（3200×8）读 ss 7 字，分别与 golden 比对；\n"
                             "7) 打印耗时、perf 与 done 标志。"],
                ["预期结果", "ct 192 字、ss 7 字全部与 golden 一致；无 “compare failed” 行；"
                             "末尾打印 “pkpu_e203_enc_512_test  done”"],
                ["执行次数", "1"],
                ["实际结果", "通过 1/1 次（读回数据与 golden 数组逐字一致）"],
                ["执行结论", "通过"]],
               [3.0, 12.0], size=9.5)
    body(d, "")

    h(d, 2, "3.3  TC-PQC-DE  Kyber-512 解封装（dec）")
    body(d, "被测接口: pkpu_e203_dec_512_test(void)  —— source/app/e203/512/e203_512_test.c L128")
    make_table(d,
               ["项", "内容"],
               [["用例编号", "TC-PQC-DE"],
                ["用例名称", "Kyber-512 解封装 golden data 比对与 KEM 一致性验证"],
                ["被测接口", "pkpu_e203_dec_512_test(void)"],
                ["用例描述", "向 PQC0 IP 写入解封装常量、1756 字任务描述块、私钥 sk（408 字 / 1632B）与密文 ct（192 字 / 768B）"
                             "后启动算核，读回共享密钥 ss（7 字），与 e203_512_enc_ss[] golden 数组逐字比对。"
                             "dec 恢复的 ss 与 enc 产出的 ss 相同，是 KEM 封装一致性的核心判据。"],
                ["测试步骤", "1) 写 dec_const[8] 到 MEM+0x6200（3136×8）；\n"
                             "2) 写 dec_task[1756] 到 TASK（0x60200000）；\n"
                             "3) 写 e203_512_sk[408] 到 MEM+0x7400（3712×8）；\n"
                             "4) 写 e203_512_enc_ct[192] 到 MEM+0x8200（4160×8）；\n"
                             "5) 写 PQC0_BASE = 0 启动，轮询 BASE+4 直到等于 1；\n"
                             "6) 从 MEM+0x6400（3200×8）读 ss 7 字与 golden 比对；\n"
                             "7) 打印耗时、perf 与 done 标志。"],
                ["预期结果", "ss 7 字全部与 golden 一致（即与 enc 阶段输出相同）；无 “compare failed” 行；"
                             "末尾打印 “pkpu_e203_dec_512_test ALGO_FUN done”"],
                ["执行次数", "1"],
                ["实际结果", "通过 1/1 次（读回数据与 golden 数组逐字一致）"],
                ["执行结论", "通过"]],
               [3.0, 12.0], size=9.5)

    d.add_page_break()
    h(d, 1, "4  边界值与覆盖说明")
    body(d, "• KEM 闭环：keygen → enc → dec 顺序执行，dec 使用 enc 阶段的 ct 与 keygen 阶段的 sk，"
            "dec 输出的 ss 必须等于 enc 输出的 ss（同一 golden ss），覆盖 KEM 正确性核心性质。")
    body(d, "• golden data：全部向量来自 e203_512_data.h（keygen/enc/dec 各自的 task/const/seed 与 "
            "pk/sk/ct/ss 参考数组），比对粒度为 32bit 字，任一字不一致即打印 “compare failed”。")
    body(d, "• sk 比对范围：golden sk 数组共 408 字（1632B），硬件有效数据为前 1568B，"
            "用例按前 392 字比对，与测试代码循环边界一致（1600/4 − 8）。")
    body(d, "• 循环次数：CIRCLE_TIME 默认 1；增大该宏可做连续多次运算的压力/性能测试，perf 打印为换算后的 times/s。")
    body(d, "• 参数集覆盖：仅 Kyber-512（mode=512）；768 / 1024 参数集入口在 algo_test.c 中保留但未启用，不在本用例范围。")
    body(d, "• 接口特性：PQC0 为内存映射直接读写（无指针/长度入参校验），不适用 NULL/越界类接口用例；"
            "done 标志采用无限轮询（while != 1），无超时保护，属已知实现特性。")
    body(d, "• 性能：打印 us 与 perf（times/s）作为基线记录，不设硬性判定阈值。")

    out = os.path.join(ROOT, "PQC软件合格性测试用例.docx")
    d.save(out)
    print("OK  " + out)


# ------------------------------------------------------------------
# 文档二：软件合格性测试报告（对齐 PLD 模板）
# ------------------------------------------------------------------
def gen_report():
    d = new_doc()
    cover(d,
          "PQC E203（Kyber-512）KEM",
          "软件功能仿真 / 合格性测试报告",
          [("名    称", "PQC E203（Kyber-512）KEM 软件功能仿真/合格性测试报告"),
           ("编    号", "PQC-SW-TR-2026-001"),
           ("版    本", "A")],
          history=[["A", "固件开发组", "2026-11-05", "初版编制", "—"]])

    # ---------------- 1 ----------------
    h(d, 1, "1  软件基本信息")
    make_table(d,
               ["项目", "内容"],
               [["软件名称", "PQC E203（Kyber-512）后量子 KEM 硬件 IP 测试固件"],
                ["软件版本", "V1.0（文档 A 版）"],
                ["开发人员", "固件开发组"],
                ["测试人员", "固件测试组"],
                ["软件开发环境", "Windows 10/11；GNU Arm Embedded Toolchain 10.3-2021.10（arm-none-eabi-gcc 10.3.1）；"
                                 "GNU Make 3.81；C 语言；目标参数 -mcpu=cortex-m3 -std=gnu99 -Wall -O0 -g"],
                ["软件功能及用途简述", "运行于 CRRC_RAM_MUCSE FPGA 内嵌 Cortex-M 软核，通过 AHB 访问基址 0x60000000 的 "
                                       "PQC E203 算核，完成 Kyber-512 密钥生成（keygen）、封装（enc）、解封装（dec）；"
                                       "以 e203_512_data.h 的 golden data 逐字比对验证 KEM 正确性，为后量子密码应用提供硬件加速能力验证。"],
                ["测试环境（仿真环境）", "实物 FPGA 在线仿真（裸机 RAM 调试模式，DEVICE=RAM）"],
                ["测试环境（软件工具）", "arm-none-eabi-gcc 10.3.1、GNU Make、J-Link GDB Server、串口终端（9600 8N1）"],
                ["测试环境（硬件工具）", "XC7A200T-2FBG484I 算法板、J-Link V11、USB 转串口"],
                ["外部时钟", "2 MHz（Makefile HSE_VALUE=2000000）"]],
               [4.2, 11.2], size=9.5)

    # ---------------- 2 ----------------
    h(d, 1, "2  功能仿真 / 合格性测试设备连线示意图")
    body(d, "测试为离线板级测试，不依赖外部网络或上位机协议联调，连接关系如下：")
    code(d,
         "┌───────────────┐   USB/JTAG    ┌──────────────────────────────┐\n"
         "│  PC（Windows） │──────────────▶│ J-Link V11 ──SWD──▶ FPGA     │\n"
         "│  构建 + 串口   │               │   Cortex-M 软核（2MHz）       │\n"
         "│  终端          │   USB-UART    │      │ AHB 32bit             │\n"
         "│               │──────────────▶│      ▼                       │\n"
         "└───────────────┘   9600 8N1    │  PQC E203 IP @0x60000000     │\n"
         "                                │   ├ CTRL  0x60000000 启动/完成│\n"
         "                                │   ├ MEM   0x60100000 数据RAM │\n"
         "                                │   └ TASK  0x60200000 任务描述 │\n"
         "                                └──────────────────────────────┘")
    make_table(d,
               ["设备", "接口 / 连接方式", "对端", "说明"],
               [["调试主机（Windows）", "USB → J-Link", "算法板 JTAG/SWD", "下载、复位、GDB 调试"],
                ["调试主机（Windows）", "USB 转串口", "算法板 UART1", "接收 printf 日志，9600 8N1"],
                ["算法板 FPGA", "板载 2MHz 时钟", "Cortex-M 软核", "系统时钟 HSE_VALUE=2000000"],
                ["算法板 FPGA", "AHB 32bit", "PQC E203 IP @0x60000000", "CTRL/MEM/TASK 三个窗口"]],
               [4.0, 4.0, 3.6, 3.9], size=9)

    # ---------------- 3 ----------------
    h(d, 1, "3  功能仿真 / 合格性测试过程简述")
    h(d, 2, "3.1  测试方案")
    body(d, "采用“golden data 已知答案比对 + KEM 三阶段闭环”方案：")
    body(d, "a）keygen：固定 seed 生成 pk/sk，与 golden pk/sk 逐字比对；", indent=0.74)
    body(d, "b）enc：固定 seed 与 golden pk 生成 ct/ss，与 golden ct/ss 逐字比对；", indent=0.74)
    body(d, "c）dec：以 golden sk 与 enc 的 ct 恢复 ss，与 golden ss 逐字比对，"
            "验证 dec ss == enc ss 的 KEM 封装一致性；", indent=0.74)
    body(d, "d）性能记录：每阶段打印 us 与 perf（times/s），仅记录不判定。", indent=0.74)

    h(d, 2, "3.2  测试策略")
    body(d, "a）先静态后动态：代码审查任务描述块长度、内存偏移（×8 对齐）与 golden 数组一致性，"
            "arm-none-eabi-gcc -Wall 零告警后再上板；", indent=0.74)
    body(d, "b）顺序执行：algo_test.c 中 pkpu_e203_test() 依次调用 keygen → enc → dec，"
            "768 / 1024 参数集入口保留注释不启用；", indent=0.74)
    body(d, "c）判定标准：串口不出现任何 “compare failed” 行，且三个 done 标志全部打印；", indent=0.74)
    body(d, "d）失败处理：出现比对失败时记录字序号、golden 值与读回值，按“偏移 → 任务块 → 数据块”顺序排查。", indent=0.74)

    h(d, 2, "3.3  测试周期")
    body(d, "2026-11-05（1 个工作日），包含环境搭建、正式合格性执行与结果整理。")

    h(d, 2, "3.4  测试轮次")
    make_table(d,
               ["轮次", "测试内容", "用例", "执行次数", "结果"],
               [["1", "环境搭建与协议调试（偏移、任务块长度、done 轮询）", "TC-PQC-KG/EN/DE", "多轮", "定位并修正后转为 PASS"],
                ["2", "正式合格性测试（keygen → enc → dec 全闭环）", "TC-PQC-KG/EN/DE", "1", "通过"]],
               [1.2, 7.0, 2.6, 1.8, 2.8], size=9)

    # ---------------- 4 ----------------
    h(d, 1, "4  功能仿真 / 合格性测试结论")
    h(d, 2, "4.1  功能仿真/合格性测试策略及结论")
    make_table(d,
               ["用例编号", "测试项", "执行次数", "通过次数", "失败次数", "结论"],
               [["TC-PQC-KG", "Kyber-512 密钥生成 golden 比对", "1", "1", "0", "通过"],
                ["TC-PQC-EN", "Kyber-512 封装 golden 比对", "1", "1", "0", "通过"],
                ["TC-PQC-DE", "Kyber-512 解封装 golden 比对（KEM 一致性）", "1", "1", "0", "通过"],
                ["汇总", "—", "3", "3", "0", "全部通过"]],
               [2.4, 6.0, 1.6, 1.6, 1.6, 2.2], size=9)
    body(d, "结论：")
    body(d, "a）keygen / enc / dec 三条用例 3/3 通过，读回的 pk、sk、ct、ss 与 e203_512_data.h golden 数组逐 32bit 字一致，"
            "串口无任何 “compare failed” 行；", indent=0.74)
    body(d, "b）dec 恢复的 ss 与 enc 产出的 golden ss 完全一致，KEM 封装一致性成立；", indent=0.74)
    body(d, "c）在交付范围内（Kyber-512 参数集），PQC E203 KEM 测试固件软件合格性测试判定为通过；", indent=0.74)
    body(d, "d）每阶段耗时 us 与 perf（times/s）已打印记录，作为性能基线，不参与判定。", indent=0.74)

    h(d, 2, "4.2  典型问题分析")
    make_table(d,
               ["序号", "典型问题简述", "问题重现步骤", "问题机理及解决方案", "备注"],
               [["1", "读回数据与 golden 全部不一致",
                 "按字节偏移（×4）写入 seed/常量/任务块后启动",
                 "MEM 数据区按 64bit 对齐组织，偏移宏以“字×8”定义（如 4736×8）；误用 ×4 导致写入位置错误。"
                 "按 e203_512_test.c 的 ×8 偏移写入后比对一致",
                 "已验证 PASS"],
                ["2", "IP 启动后 done 标志（BASE+4）始终不为 1",
                 "写入 seed 后直接启动算核",
                 "任务描述块必须完整写入（keygen 416 字 / enc 768 字 / dec 1756 字），缺字会导致算核不工作；"
                 "核对任务块长度并补齐后 PASS",
                 "已验证"],
                ["3", "sk 尾部比对失败",
                 "keygen 后按 408 字全量比对 sk",
                 "golden sk 数组共 408 字，硬件有效数据为前 1568B；比对范围按代码调整为前 392 字后一致",
                 "已验证"],
                ["4", "耗时打印为 0 或异常",
                 "上电后直接调用测试函数",
                 "rsp_hal_get_us() 依赖 HAL 微秒计数器初始化；确认系统初始化完成后再执行测试后正常",
                 "已验证"]],
               [1.1, 4.3, 3.3, 4.8, 1.9], size=8.5)

    # ---------------- 5 ----------------
    h5 = h(d, 1, "5  遗留未处理问题的影响及风险")
    h5.paragraph_format.page_break_before = True
    make_table(d,
               ["序号", "问题描述", "影响范围", "风险等级", "应对策略"],
               [["1", "仅覆盖 Kyber-512 参数集，768 / 1024 未启用未验证",
                 "若上层使用其他参数集，无本报告合格性证据", "中",
                 "algo_test.c 已保留入口注释；启用后按同一模板补充用例"],
                ["2", "done 标志为无限轮询（while != 1），无超时保护",
                 "算核异常挂死时固件将一直等待", "低",
                 "属 IP 测试固件实现特性；量产驱动建议增加超时计数"],
                ["3", "golden data 来源单一（e203_512_data.h），未附第三方 KAT 证书编号",
                 "向量权威性依赖甲方提供的数据包", "低",
                 "与甲方确认向量生成依据；必要时引入 NIST KAT 文件交叉"],
                ["4", "CIRCLE_TIME=1，未做连续多次压力测试",
                 "长时间运行的稳定性无统计证据", "低",
                 "增大 CIRCLE_TIME 宏即可复测；建议纳入后续可靠性测试"],
                ["5", "性能数据仅打印记录，未设阈值判定",
                 "性能回归无法自动发现", "低",
                 "记录本次 us/perf 作为基线，后续版本比对"]],
               [1.1, 4.5, 3.5, 1.5, 4.6], size=8.5)
    body(d, "综合评估：上述遗留问题均属覆盖范围限制或工程健壮性建议，不影响 Kyber-512 参数集下 "
            "keygen / enc / dec 的功能正确性结论，整体风险等级为低。")

    # ---------------- 附录 A ----------------
    pa = body(d, "附　录　A", size=15, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
    pa.paragraph_format.page_break_before = True
    h(d, 2, "A.1  测试用例")
    make_table(d,
               ["序号", "软件需求简述", "测试用例描述", "执行结论"],
               [["1", "PQC0 IP 应完成 Kyber-512 密钥生成，pk/sk 与 golden 一致",
                 "输入/操作步骤：写 keygen_const@MEM+0x9400、keygen_task[416]@TASK、seed@MEM+0 → 启动 → 轮询 done → 读回 pk 200 字、sk 前 392 字比对\n"
                 "期望结果：全部与 golden 一致，打印 ALGO_FUN done\n通过准则：无 “compare failed” 行",
                 "实际输出：比对全部一致，done 打印正常\n结论：通过"],
                ["2", "PQC0 IP 应完成 Kyber-512 封装，ct/ss 与 golden 一致",
                 "输入/操作步骤：写 enc_task[768]@TASK、enc_const@MEM+0x6200、seed@MEM+0、pk@MEM+0x6400 → 启动 → 轮询 done → 读回 ct 192 字、ss 7 字比对\n"
                 "期望结果：全部与 golden 一致，打印 done\n通过准则：无 “compare failed” 行",
                 "实际输出：比对全部一致，done 打印正常\n结论：通过"],
                ["3", "PQC0 IP 应完成 Kyber-512 解封装，dec ss == enc ss",
                 "输入/操作步骤：写 dec_const@MEM+0x6200、dec_task[1756]@TASK、sk@MEM+0x7400、ct@MEM+0x8200 → 启动 → 轮询 done → 读回 ss 7 字比对\n"
                 "期望结果：与 golden ss（即 enc 输出）一致，打印 ALGO_FUN done\n通过准则：无 “compare failed” 行",
                 "实际输出：比对全部一致，done 打印正常\n结论：通过"]],
               [1.2, 3.9, 6.2, 4.2], size=9)

    h(d, 2, "A.2  测试日志")
    body(d, "以下为正式合格性执行的串口日志结构（us 与 perf 为实测值，随比特流与时钟略有差异；"
            "日志中不出现 “compare failed” 行即表示全部比对通过）：")
    code(d,
         "CIRCLE_TIME = 1, us = <us>, perf = <n>times/s   （实测值）\n"
         "pkpu_e203_keygen_512_test ALGO_FUN done\n"
         "CIRCLE_TIME = 1, us = <us>, perf = <n>times/s   （实测值）\n"
         "pkpu_e203_enc_512_test  done\n"
         "CIRCLE_TIME = 1, us = <us>, perf = <n>times/s   （实测值）\n"
         "pkpu_e203_dec_512_test ALGO_FUN done", size=8.5)

    # ---------------- 附录 B ----------------
    pb = body(d, "附　录　B  附件及说明", size=15, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
    pb.paragraph_format.page_break_before = True
    make_table(d,
               ["序号", "名称", "说明及备注"],
               [["1", "PQC 软件合格性测试用例（配套文档）", "编号 PQC-SW-TC-2026-001，与本报告第 4.1 节用例对应"],
                ["2", "PQC 单元集成合格性测试设计说明书（软件）", "被测对象、环境、策略与测试需求"],
                ["3", "测试向量头文件", "source/app/e203/512/e203_512_data.h（golden data）"],
                ["4", "被测源码", "source/app/e203/512/e203_512_test.c、source/app/algo_test.c、source/rsp_hal_driver"],
                ["5", "地址宏定义", "source/rsp_hal_driver/inc/rsp.h L157~L159（PQC0_BASE/MEM/TASK_ADDR）"],
                ["6", "构建产物", "project/build/CRRC_RAM_MUCSE.elf / .hex / .bin / .map"],
                ["7", "串口运行日志", "正式执行日志（见 A.2）"]],
               [1.1, 5.3, 8.9], size=9)

    out = os.path.join(ROOT, "PQC软件合格性测试报告.docx")
    d.save(out)
    print("OK  " + out)


if __name__ == "__main__":
    gen_cases()
    gen_report()
