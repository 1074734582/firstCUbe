# -*- coding: utf-8 -*-
"""以甲方 003/004 模板生成 ECC、PQC 的用例与报告文档。
- 003 用例模板：保留封面/签署/版本历史/目次样式，改写正文并扩展为 3 条用例
- 004 报告模板：保留封面/目次/连线照片/章节版式，替换表格与正文
"""
import copy
import os
import shutil

from docx import Document
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml
from docx.table import Table
from docx.text.paragraph import Paragraph
from docx.enum.text import WD_BREAK

ROOT = r"z:\ccrc\test_i2c_not_offical\firmware"
TPL_CASES = os.path.join(ROOT, "003 软件合格性测试用例.docx")
TPL_REPORT = os.path.join(ROOT, "004 软件合格性测试报告.docx")
CN = "宋体"
EN = "Times New Roman"


# ------------------------------------------------------------------
# 基础编辑工具
# ------------------------------------------------------------------
def font_of(cell):
    for p in cell.paragraphs:
        for r in p.runs:
            return r.font.name, r.font.size, r.font.bold
    return EN, None, None


def clear_para(p):
    for ch in list(p._p):
        if ch.tag != qn("w:pPr"):
            p._p.remove(ch)


def apply_font(run, name, size, bold):
    run.font.name = name or EN
    run.font.size = size
    run.font.bold = bold
    rpr = run._element.get_or_add_rPr()
    rf = rpr.find(qn("w:rFonts"))
    if rf is None:
        rf = parse_xml("<w:rFonts %s/>" % nsdecls("w"))
        rpr.append(rf)
    rf.set(qn("w:eastAsia"), CN)


def set_cell(cell, text, size=None):
    name, sz, bold = font_of(cell)
    for p in cell.paragraphs[1:]:
        p._p.getparent().remove(p._p)
    p = cell.paragraphs[0]
    clear_para(p)
    for i, line in enumerate(str(text).split("\n")):
        if i:
            p.add_run().add_break(WD_BREAK.LINE)
        r = p.add_run(line)
        apply_font(r, name, size or sz, bold)


def set_par(p, text, size=None):
    name, sz, bold = (EN, None, None)
    for r in p.runs:
        if r.text.strip():
            name, sz, bold = r.font.name, r.font.size, r.font.bold
            break
    clear_para(p)
    for i, line in enumerate(str(text).split("\n")):
        if i:
            p.add_run().add_break(WD_BREAK.LINE)
        r = p.add_run(line)
        apply_font(r, name, size or sz, bold)


def find_par(doc, prefix):
    for p in doc.paragraphs:
        if p.text.strip().startswith(prefix):
            return p
    raise KeyError(prefix)


def set_rows(tbl, data):
    need = len(data)
    cur = len(tbl.rows) - 1
    while cur < need:
        tbl._tbl.append(copy.deepcopy(tbl.rows[-1]._tr))
        cur += 1
    while cur > need:
        tbl._tbl.remove(tbl.rows[-1]._tr)
        cur -= 1
    for i, row in enumerate(data, 1):
        for c, val in enumerate(row):
            set_cell(tbl.rows[i].cells[c], val)


def update_fields(doc):
    settings = doc.settings.element
    if settings.find(qn("w:updateFields")) is None:
        settings.append(parse_xml('<w:updateFields %s w:val="true"/>' % nsdecls("w")))


def fill_cover(doc, name, docno, version, people, date, note):
    t = doc.tables[0]
    set_cell(t.rows[0].cells[1], name)
    set_cell(t.rows[1].cells[1], docno)
    set_cell(t.rows[2].cells[1], version)
    h = doc.tables[2]
    for i, v in enumerate([version, people, date, note, "—"]):
        set_cell(h.rows[1].cells[i], v)


# ------------------------------------------------------------------
# 003 用例：通用生成
# ------------------------------------------------------------------
def gen_cases(out, name, docno, version, date, intro, overview, cases, bullets):
    shutil.copy(TPL_CASES, out)
    d = Document(out)
    fill_cover(d, name, docno, version, "固件开发组", date, "初版编制")
    set_par(find_par(d, "本文档给出"), intro)

    tbl = d.tables[3]
    set_rows(tbl, overview)

    # 找到用例标题段落（ZS_C标题2级 且以 TC- 开头）
    heads = [p for p in d.paragraphs if p.style.name == "ZS_C标题2级" and p.text.strip().startswith("TC-")]

    body = d.element.body
    children = list(body.iterchildren())
    # 页分隔段落（“边界值”章前）
    pb_idx = None
    for i, ch in enumerate(children):
        if ch.tag == qn("w:p") and 'w:type="page"' in ch.xml:
            pb_idx = i
            break
    # 复制第二块用例，按用例数补足到 len(cases) 块，插入到页分隔之前
    if len(heads) == 2 and len(cases) >= 3:
        second = heads[1]._p
        block = []
        el = second
        while el is not None and not (el.tag == qn("w:p") and 'w:type="page"' in el.xml):
            block.append(el)
            el = el.getnext()
            if el is not None and el.tag == qn("w:tbl"):
                block.append(el)
                el = el.getnext()
                break
        for _ in range(len(cases) - 2):
            for e in copy.deepcopy(block):
                children[pb_idx].addprevious(e)
        heads = [p for p in d.paragraphs if p.style.name == "ZS_C标题2级" and p.text.strip().startswith("TC-")]

    for idx, case in enumerate(cases):
        hp = heads[idx]
        set_par(hp, case["title"])
        nxt = hp._p.getnext()
        set_par(Paragraph(nxt, hp._parent), "被测接口: " + case["iface"])
        nxt = nxt.getnext()
        set_par(Paragraph(nxt, hp._parent), case["iface"])
        tbl_el = nxt.getnext()
        t = Table(tbl_el, hp._parent)
        vals = [case["no"], case["cname"], case["iface"], case["desc"], case["steps"],
                case["expect"], case["times"], case["actual"], case["verdict"]]
        for i, v in enumerate(vals, 1):
            set_cell(t.rows[i].cells[1], v)

    bullets_p = None
    for p in d.paragraphs:
        if p.text.strip().startswith("•"):
            bullets_p = p
            break
    if bullets_p is not None:
        set_par(bullets_p, "\n".join(bullets))

    update_fields(d)
    d.save(out)
    print("OK  " + out)


# ------------------------------------------------------------------
# 004 报告：通用生成
# ------------------------------------------------------------------
def gen_report(out, name, docno, version, date, intro, modules, envs, devices,
               plan, rounds, round_note, results, conclusion, problems, risks,
               risk_summary, annex, compile_log, run_log):
    shutil.copy(TPL_REPORT, out)
    d = Document(out)
    fill_cover(d, name, docno, version, "固件开发组", date, "初版编制")
    set_par(find_par(d, "被测对象由硬件算核驱动"), intro)

    set_rows(d.tables[3], modules)
    set_rows(d.tables[4], envs)
    set_rows(d.tables[5], devices)
    set_rows(d.tables[6], rounds)
    set_cell(d.tables[6].rows[0].cells[0], "用例编号")
    set_rows(d.tables[7], results)
    set_rows(d.tables[8], problems)
    set_rows(d.tables[9], risks)
    set_rows(d.tables[10], annex)

    set_par(find_par(d, "KAT 测试"), plan)
    set_par(find_par(d, "测试数据由 32 位 LCG"), round_note)
    set_par(find_par(d, "DES-ECB KAT 标准向量"), conclusion)
    set_par(find_par(d, "综合评估：DES"), risk_summary)
    set_par(find_par(d, "arm-none-eabi-gcc ... -o des.o"), compile_log)
    set_par(find_par(d, "DES HARDWARE IP TEST SUITE"), run_log)

    update_fields(d)
    d.save(out)
    print("OK  " + out)


# ------------------------------------------------------------------
# ECC 内容
# ------------------------------------------------------------------
ECC_VECT_MSG = "1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
ECC_R = "680e5c73296947ce19a598d6ae0c7a2a257b6fdca429821512b61200bd6779eb"
ECC_S = "4b0642943522de37afd5a4986272d5423b51bb8f92196f062304a140d02442e7"

ecc_overview = [
    ["TC-ECC-K1", "test_ecc [1]", "ecc_hw_sign", "32B message", "d、k 固定 32B", "1"],
    ["TC-ECC-V1", "test_ecc [1b]", "ecc_hw_verify", "32B message + 64B 公钥", "r、s 固定", "1"],
    ["TC-ECC-V2", "test_ecc [1b]", "ecc_hw_verify", "篡改 s 的签名", "r、s 固定", "1"],
    ["TC-ECC-X1", "test_ecc [2]", "ecdsa_sign + 交叉比对", "32B message", "d、k 固定 32B", "1"],
    ["TC-ECC-X2", "test_ecc [3]", "ecdsa_verify", "32B 签名 + 公钥", "r、s、Q 固定", "1"],
    ["汇总", "—", "—", "—", "—", "5"],
]

ecc_cases = [
    dict(no="TC-ECC-K1", title="TC-ECC-K1  P-256 硬件签名 KAT 与标准向量比对",
         iface="ecc_hw_sign", cname="P-256 硬件签名 KAT 与标准向量比对",
         desc="使用固定 32B message、私钥 d、随机数 k 调用硬件签名，将输出 r/s 与 PC 端标准 P-256 预计算值"
              "逐字节比对，并检查返回码。r 只由 k 决定，可单独证明标量乘通路；s 覆盖模逆、模乘、模加通路。",
         steps="1) 系统上电，串口配置 9600 8N1；\n"
               "2) 运行 ecc_test()，进入 [1] HW sign 阶段；\n"
               "3) 驱动复位后写 PKG_LEN=32、CFG=0x3001，按 d→k→message 灌入 IFIFO；\n"
               "4) 从 OFIFO 读回 r→s 共 64B；\n"
               "5) 打印 exp_r/hw_r、exp_s/hw_s 并逐字节比对；\n"
               "6) 汇总 all_pass 并打印 FINAL 结论。",
         expect="ret == RSP_OK；hw_r == FINAL_R；hw_s == FINAL_S；打印 “FINAL: ALL PASS (HW quick verify)”",
         times="1", actual="通过 1/1 次（hw_r/hw_s 与预期向量逐字节一致）", verdict="通过"),
    dict(no="TC-ECC-V1", title="TC-ECC-V1  P-256 硬件验签（合法签名应通过）",
         iface="ecc_hw_verify", cname="P-256 硬件验签 — 合法签名判定通过",
         desc="使用签名阶段输出的 r/s 与私钥 d 对应的公钥 Q 调用硬件验签。驱动写 PKG_LEN=32、CFG=0x3101"
              "（MODE=1 验签模式），按 公钥(64B) → 签名(64B) → 消息(32B) 灌入 IFIFO，读回 1 拍 16B 结果字，"
              "byte[0]==1 判定验签通过。",
         steps="1) 取 [1] 阶段输出 hw_r/hw_s，组装 64B 签名 r||s；\n"
               "2) 组装 64B 公钥 Q = PREFAB_QX||PREFAB_QY；\n"
               "3) 驱动复位后写 PKG_LEN=32、CFG=0x3101；\n"
               "4) 按 公钥→签名→消息 顺序灌入 IFIFO；\n"
               "5) 从 OFIFO 读回 1 拍 16B 结果字；\n"
               "6) byte[0]==1 时返回 RSP_OK 并打印 PASS。",
         expect="ecc_hw_verify 返回 RSP_OK（ret=0），打印 “valid sig : PASS (ret=0, expect RSP_OK)”",
         times="1", actual="通过 1/1 次（ret=0，合法签名被接受）", verdict="通过"),
    dict(no="TC-ECC-V2", title="TC-ECC-V2  P-256 硬件验签（篡改签名应拒绝）",
         iface="ecc_hw_verify", cname="P-256 硬件验签 — 篡改 s 的反向用例",
         desc="把合法签名 s 的最低位取反后再次调用硬件验签，验证硬件能够拒绝被篡改的签名，"
              "避免验签通路恒返回通过而不能发现伪造签名。",
         steps="1) 复制 64B 合法签名到 sig_bad；\n"
               "2) 执行 sig_bad[63] ^= 0x01，翻转 s 最低位；\n"
               "3) 以同一公钥、同一消息调用 ecc_hw_verify；\n"
               "4) 检查返回码不为 RSP_OK（期望 RSP_ERR_DATA_CHECK，ret=-8）。",
         expect="ecc_hw_verify 返回 RSP_ERR_DATA_CHECK（ret=-8），打印 “tampered sig : PASS”",
         times="1", actual="通过 1/1 次（ret=-8，篡改签名被拒绝）", verdict="通过"),
    dict(no="TC-ECC-X1", title="TC-ECC-X1  软件参考签名与硬件交叉比对（可选）",
         iface="ecdsa_sign", cname="软件固定 k 签名 + 与标准向量/硬件输出双向比对",
         desc="开启 ECC_SW_CROSS_VALIDATE 后，用同一组 message/d/k 在 CPU 上执行软件签名，"
              "分别与 PC 标准向量、硬件输出比对，验证硬件与软件两条独立实现结果一致。",
         steps="1) 编译时开启 -DECC_SW_CROSS_VALIDATE；\n"
               "2) 执行 [2] 阶段：bn_from_bytes 装入 d、k、Qx、Qy；\n"
               "3) ecdsa_sign 固定 k=FINAL_K，得到 sw_r、sw_s；\n"
               "4) sw_r/sw_s 与 FINAL_R/FINAL_S 比对；\n"
               "5) sw_r/sw_s 与硬件 hw_r/hw_s 交叉比对。",
         expect="sw_r==FINAL_R、sw_s==FINAL_S、hw_r==sw_r、hw_s==sw_s 全部 PASS",
         times="1", actual="条件执行（默认宏关闭；开启后 2MHz 下约 30 分钟）",
         verdict="可选补充验证，不计入默认合格性判定"),
    dict(no="TC-ECC-X2", title="TC-ECC-X2  软件验签硬件签名（可选）",
         iface="ecdsa_verify", cname="软件使用公钥验签硬件签名",
         desc="把硬件输出的 r/s 组装为 ecdsa_sig，使用 d 对应的公钥 Q 进行标准 ECDSA 验签，"
              "验证硬件签名在数学上有效。",
         steps="1) 取 [1] 阶段硬件输出 hw_r、hw_s；\n"
               "2) bn_from_bytes 组装 hw_sig.r / hw_sig.s；\n"
               "3) 使用 PREFAB_QX/QY 作为公钥；\n"
               "4) 调用 ecdsa_verify 并打印结果。",
         expect="ecdsa_verify 返回成功（verify hw_sig: PASS）",
         times="1", actual="条件执行（默认宏关闭）",
         verdict="可选补充验证，不计入默认合格性判定"),
]

ecc_bullets = [
    "• 曲线参数：固定标准 secp256r1（NIST P-256），a = -3，n 为大素数阶，k、d 取 32B 大值。",
    "• 随机数边界：k 取 32B 大值（FINAL_K）。r=(k·G).x mod n 只与 k 有关，r 匹配即可单独验证标量乘；s 验证 k⁻¹、e+r·d、取模通路。",
    "• 已知 RTL 边界：k=2、3 会触发标量乘极小值缺陷，测试向量主动规避；SOC 与业务侧使用 32B 随机 k，不会触发。",
    "• 长度边界：驱动只接受 msg_len=32，其他长度返回 RSP_ERR_INVALID_PARAM；本用例覆盖唯一合法长度。",
    "• 输出顺序：硬件固定 r→s，用例按前 32B/后 32B 分段比对，可发现顺序颠倒类错误。",
    "• 验签正反覆盖：TC-ECC-V1 验证合法签名被接受，TC-ECC-V2 验证篡改 s 后被拒绝，双向确认验签判定逻辑有效。",
    "• 验签协议：CFG=0x3101（MODE=1）、PKG_LEN=32、IFIFO 顺序 公钥(64B)→签名(64B)→消息(32B)，OFIFO 仅 1 拍 16B 结果字，byte[0]==1 为通过。",
    "• 复位与重复调用：每次调用开头完整复位并排空 OFIFO，重复执行结果应完全一致。",
    "• 可选覆盖：开启宏后额外覆盖软件签名、软件验签两条软件路径，实现硬件/软件双向交叉。",
    "• 未覆盖项：密钥生成、P-384、非 32B 消息、k 随机性质量（属交付范围限制）。",
]

# ------------------------------------------------------------------
# PQC 内容
# ------------------------------------------------------------------
pqc_overview = [
    ["TC-PQC-KG", "pkpu_e203_keygen_512_test", "PQC0 keygen", "pk 800B / sk 1632B", "seed 32B", "1"],
    ["TC-PQC-EN", "pkpu_e203_enc_512_test", "PQC0 enc", "ct 768B / ss 32B", "seed 32B + pk 800B", "1"],
    ["TC-PQC-DE", "pkpu_e203_dec_512_test", "PQC0 dec", "ss 32B", "sk 1632B + ct 768B", "1"],
    ["汇总", "—", "—", "—", "—", "3"],
]

pqc_cases = [
    dict(no="TC-PQC-KG", title="TC-PQC-KG  Kyber-512 密钥生成（keygen）",
         iface="pkpu_e203_keygen_512_test", cname="Kyber-512 密钥生成 golden data 比对",
         desc="向 PQC0 IP 写入 32B 随机种子与密钥生成常量、416 字任务描述块后启动算核，"
              "从数据内存读回公钥 pk（200 字 / 800B）与私钥 sk（前 392 字 / 1568B），"
              "与 e203_512_pk[] / e203_512_sk[] golden 数组逐 32bit 字比对。",
         steps="1) 写 keygen_const[10] 到 MEM+0x9400（4736×8）；\n"
               "2) 写 keygen_task[416] 到 TASK（0x60200000）；\n"
               "3) 写 keygen_seed[8] 到 MEM+0x0；\n"
               "4) 写 PQC0_BASE（0x60000000）= 0 启动，轮询 BASE+4 直到等于 1；\n"
               "5) 读 pk 200 字、sk 前 392 字，与 golden 逐字比对；\n"
               "6) 打印耗时 us、perf（times/s）与 done 标志。",
         expect="pk 200 字、sk 前 392 字全部与 golden 一致；无 “compare failed” 行；"
                "末尾打印 “pkpu_e203_keygen_512_test ALGO_FUN done”",
         times="1", actual="通过 1/1 次（读回数据与 golden 数组逐字一致）", verdict="通过"),
    dict(no="TC-PQC-EN", title="TC-PQC-EN  Kyber-512 封装（enc）",
         iface="pkpu_e203_enc_512_test", cname="Kyber-512 封装 golden data 比对",
         desc="向 PQC0 IP 写入封装常量、768 字任务描述块、32B 随机种子与公钥 pk（200 字 / 800B）后启动算核，"
              "读回密文 ct（192 字 / 768B）与共享密钥 ss（8 字 / 32B），与 golden 数组逐字比对。",
         steps="1) 写 enc_task[768] 到 TASK；\n"
               "2) 写 enc_const[8] 到 MEM+0x6200（3136×8）；\n"
               "3) 写 enc_seed[8] 到 MEM+0x0；\n"
               "4) 写 e203_512_pk[200] 到 MEM+0x6400（3200×8）；\n"
               "5) 写 PQC0_BASE = 0 启动，轮询 BASE+4 直到等于 1；\n"
               "6) 读 ct 192 字、ss 8 字，与 golden 比对；\n"
               "7) 打印耗时、perf 与 done 标志。",
         expect="ct 192 字、ss 8 字全部与 golden 一致；无 “compare failed” 行；"
                "末尾打印 “pkpu_e203_enc_512_test  done”",
         times="1", actual="通过 1/1 次（读回数据与 golden 数组逐字一致）", verdict="通过"),
    dict(no="TC-PQC-DE", title="TC-PQC-DE  Kyber-512 解封装（dec）",
         iface="pkpu_e203_dec_512_test", cname="Kyber-512 解封装 golden data 比对与 KEM 一致性验证",
         desc="向 PQC0 IP 写入解封装常量、1756 字任务描述块、私钥 sk（408 字 / 1632B）与密文 ct（192 字 / 768B）"
              "后启动算核，读回共享密钥 ss（8 字 / 32B）与 golden ss 比对。dec ss 与 enc ss 相同是 KEM 一致性核心判据。",
         steps="1) 写 dec_const[8] 到 MEM+0x6200（3136×8）；\n"
               "2) 写 dec_task[1756] 到 TASK；\n"
               "3) 写 e203_512_sk[408] 到 MEM+0x7400（3712×8）；\n"
               "4) 写 e203_512_enc_ct[192] 到 MEM+0x8200（4160×8）；\n"
               "5) 写 PQC0_BASE = 0 启动，轮询 BASE+4 直到等于 1；\n"
               "6) 从 MEM+0x6400（3200×8）读 ss 8 字与 golden 比对；\n"
               "7) 打印耗时、perf 与 done 标志。",
         expect="ss 8 字全部与 golden 一致（即与 enc 阶段输出相同）；无 “compare failed” 行；"
                "末尾打印 “pkpu_e203_dec_512_test ALGO_FUN done”",
         times="1", actual="通过 1/1 次（读回数据与 golden 数组逐字一致）", verdict="通过"),
]

pqc_bullets = [
    "• KEM 闭环：keygen → enc → dec 顺序执行，dec 使用 enc 阶段的 ct 与 keygen 阶段的 sk，dec 输出 ss 必须等于 enc 输出 ss。",
    "• golden data：全部向量来自 e203_512_data.h，比对粒度为 32bit 字，任一字不一致即打印 “compare failed”。",
    "• sk 比对范围：golden sk 共 408 字（1632B），硬件有效数据前 1568B，按前 392 字比对，与测试代码循环边界一致。",
    "• 循环次数：CIRCLE_TIME 默认 1；增大该宏可做连续多次运算的压力/性能测试。",
    "• 参数集覆盖：仅 Kyber-512；768/1024 入口在 algo_test.c 中保留但未启用，不在本用例范围。",
    "• 接口特性：PQC0 为内存映射直接读写，无指针/长度入参校验；done 标志为无限轮询，无超时保护，属已知实现特性。",
    "• 性能：打印 us 与 perf（times/s）作为基线记录，不设硬性判定阈值。",
]


# ------------------------------------------------------------------
# ECC 报告内容
# ------------------------------------------------------------------
ecc_modules = [
    ["1", "rsp_ip_ecc.c / rsp_ip_ecc.h", "A", "ECC IP 驱动：P-256 签名/验签、CFG/PKG_LEN/IFIFO/OFIFO 协议", "约 260 行", "C"],
    ["2", "test_ecc.c", "A", "签名/验签测试入口：硬件 KAT、篡改反向用例 + 可选软硬交叉验证", "约 240 行", "C"],
    ["3", "ecdsa.c / ecdsa.h", "A", "软件参考 ECDSA 实现（仅用于交叉验证）", "约 860 行", "C"],
    ["4", "Makefile / rsp.gdbinit", "A", "交叉编译、链接与下载调试", "约 130 行", "Make/GDB"],
    ["5", "main.c / algo_test.c", "A", "系统初始化与测试入口调度", "约 60 行", "C"],
]
ecc_envs = [
    ["编译环境", "arm-none-eabi-gcc", "10.3.1", "-mcpu=cortex-m3 -march=armv7-m -std=gnu99 -Wall -O0 -g"],
    ["构建工具", "GNU Make", "3.81 及以上", "project/Makefile；make clean / make all"],
    ["运行环境", "CRRC_RAM_MUCSE FPGA", "Cortex-M3 @2MHz", "HSE_VALUE=2000000，裸机 RAM 调试模式"],
    ["调试工具", "J-Link V11 + GDB Server", "V7.x", "SWD/JTAG，make debug"],
    ["测试工具", "串口终端", "9600 8N1", "接收 printf 日志"],
]
ecc_devices = [
    ["调试主机", "USB → J-Link", "算法板 JTAG/SWD", "下载、复位、GDB 调试"],
    ["调试主机", "USB 转串口", "算法板 UART1", "接收 printf 日志，9600 8N1"],
    ["算法板 FPGA", "AHB 32bit", "ECC IP @0x80090000", "CFG/PKG_LEN/IFIFO/OFIFO 寄存器访问"],
    ["算法板 FPGA", "板载 2MHz 时钟", "Cortex-M3 软核", "系统时钟 HSE_VALUE=2000000"],
]
ecc_rounds = [
    ["TC-ECC-K1", "test_ecc [1]", "ecc_hw_sign", "32B message", "d、k 固定 32B", "1"],
    ["TC-ECC-V1", "test_ecc [1b]", "ecc_hw_verify", "32B message + 64B 公钥", "r、s 固定", "1"],
    ["TC-ECC-V2", "test_ecc [1b]", "ecc_hw_verify", "篡改 s 的签名", "r、s 固定", "1"],
    ["TC-ECC-X1", "test_ecc [2]", "ecdsa_sign + 交叉", "32B message", "d、k 固定 32B", "1"],
    ["TC-ECC-X2", "test_ecc [3]", "ecdsa_verify", "32B 签名 + 公钥", "r、s、Q 固定", "1"],
]
ecc_results = [
    ["TC-ECC-K1", "test_ecc [1]", "ecc_hw_sign", "1", "1", "0", "通过"],
    ["TC-ECC-V1", "test_ecc [1b]", "ecc_hw_verify", "1", "1", "0", "通过"],
    ["TC-ECC-V2", "test_ecc [1b]", "ecc_hw_verify", "1", "1", "0", "通过"],
    ["TC-ECC-X1", "test_ecc [2]", "ecdsa_sign", "条件", "—", "—", "可选"],
    ["TC-ECC-X2", "test_ecc [3]", "ecdsa_verify", "条件", "—", "—", "可选"],
    ["汇总", "—", "—", "3", "3", "0", "默认用例全部通过"],
]
ecc_problems = [
    ["1", "ecc_hw_sign 始终返回 RSP_ERR_FIFO（ret=-3），OFIFO 永远为空",
     "PKG_LEN 误按操作数条目数写 3，算核不消费输入",
     "改为消息字节数 32（与 SOC 参考脚本一致）", "已验证 PASS"],
    ["2", "r 与预期始终不符，r 恒等于 (d·G).x",
     "IFIFO 操作数顺序错误：旧实现按 message→d→k 写入，本 RTL 实际按 d→k→message 取用",
     "改为 d→k→message，r、s 均与标准向量一致", "已验证 PASS"],
    ["3", "读输出超时，返回 RSP_ERR_FIFO",
     "2MHz 下 1,000,000 次轮询不足以覆盖标量乘耗时",
     "提升至 60,000,000 次（约 30s）", "已验证"],
    ["4", "k=2、3 时签名结果错误",
     "RTL 标量乘极小值边界缺陷",
     "测试与业务使用 32B 大值随机 k 规避，不列为固件缺陷", "RTL 已知限制"],
    ["5", "头文件 bit14 注释与实测语义相反",
     "按注释传入 SHA-256 摘要导致二次哈希误判",
     "以 ecc.xlsx/实测为准：0=消息摘要输入、硬件不哈希；文档同步纠正", "文档已纠正"],
    ["6", "验签首次实现时按 message→公钥→签名 顺序灌入，结果不可用",
     "验签 IFIFO 顺序与签名同源规则：密钥类操作数在前、消息在最后",
     "改为 公钥→签名→消息，合法签名通过、篡改签名被拒", "已验证 PASS"],
]
ecc_risks = [
    ["1", "仅验证 msg_len=32，其他长度驱动直接拒绝", "上层只能用于 32B 摘要签名", "低", "接口注释与报告明确；扩展需 RTL 与驱动联合验证"],
    ["2", "仅验证 P-256 签名与验签；密钥生成、P-384 未验证", "其他模式无本报告合格性证据", "中", "交付范围限定为签名/验签模式；其他模式按同模板补充"],
    ["3", "RTL 对 k=2、3 计算错误", "极小 k 会导致签名错误", "低", "使用标准 RNG 产生 32B 随机 k；驱动不校验 k"],
    ["4", "bit14 头文件旧注释与实现相反", "开发人员可能重复做哈希", "低", "以设计说明书表 6-1 为准，后续修正注释"],
    ["5", "2MHz 下完整交叉验证约需 30 分钟", "回归效率", "低", "默认关闭，仅专项验证开启宏"],
]
ecc_annex = [
    ["1", "ECC 软件合格性测试用例（本文档配套）", "docx", "ECC-SW-TC-2026-001.docx"],
    ["2", "ECC 单元集成合格性测试设计说明书（软件）", "docx", "RSP-ECC-DRV-TS-001"],
    ["3", "ECC 寄存器与数据格式手册", "xlsx", "ecc.xlsx、ecc_输入输出数据格式.xlsx"],
    ["4", "SOC 签名/验签参考脚本", "txt", "SOC_ECC_TEST_SIGN.txt、SOC_ECC_TEST_verify.txt"],
    ["5", "被测源码", "C", "rsp_ip_ecc.c/.h、test_ecc.c、ecdsa.c"],
    ["6", "构建产物", "elf/hex/bin", "project/build/CRRC_RAM_MUCSE.*"],
]
ecc_compile_log = (
    "arm-none-eabi-gcc ... -o rsp_ip_ecc.o source/core/rsp_ip_ecc.c\n"
    "arm-none-eabi-gcc ... -o test_ecc.o source/app/test_ecc.c\n"
    "arm-none-eabi-gcc ... -o ecdsa.o source/Middleware/ecc/ecdsa.c\n"
    "arm-none-eabi-gcc ... -o CRRC_RAM_MUCSE.elf\n"
    "arm-none-eabi-objcopy -O binary CRRC_RAM_MUCSE.elf CRRC_RAM_MUCSE.bin")
ecc_run_log = (
    "ECC P-256 SIGN - HW Quick Verify\n"
    "[1] HW sign (ecc_hw_sign)\n"
    "    ecc_hw_sign()   : RSP_OK\n"
    "    exp_r     : " + ECC_R + "\n"
    "    hw_r      : " + ECC_R + "\n"
    "    exp_s     : " + ECC_S + "\n"
    "    hw_s      : " + ECC_S + "\n"
    "    hw_r==exp_r: PASS    hw_s==exp_s: PASS\n"
    "    [1] 1266234 cycles (633 ms)\n"
    "\n"
    "[1b] HW verify (ecc_hw_verify)\n"
    "    valid sig      : PASS (ret=0, expect RSP_OK)\n"
    "    tampered sig   : PASS (ret=-8, expect reject)\n"
    "    [1b] 679120 cycles (339 ms)\n"
    "\n"
    "  FINAL: ALL PASS (HW quick verify)\n"
    "    [TOTAL] 2474090 cycles (1237 ms)")

# ------------------------------------------------------------------
# PQC 报告内容
# ------------------------------------------------------------------
pqc_modules = [
    ["1", "e203_512_test.c", "A", "Kyber-512 keygen / enc / dec 测试", "约 160 行", "C"],
    ["2", "e203_512_data.h", "A", "golden data：任务块、常量、种子、pk/sk/ct/ss", "约 3800 行", "C"],
    ["3", "algo_test.c", "A", "测试入口调度 pkpu_e203_test()", "约 20 行", "C"],
    ["4", "rsp.h / rsp_hal_driver", "A", "PQC0 地址宏、HAL 时钟与串口", "—", "C"],
    ["5", "Makefile", "A", "交叉编译与链接", "约 120 行", "Make"],
]
pqc_envs = ecc_envs
pqc_devices = [
    ["调试主机", "USB → J-Link", "算法板 JTAG/SWD", "下载、复位、GDB 调试"],
    ["调试主机", "USB 转串口", "算法板 UART1", "接收 printf 日志，9600 8N1"],
    ["算法板 FPGA", "AHB 32bit", "PQC E203 IP @0x60000000", "CTRL/MEM/TASK 三个窗口访问"],
    ["算法板 FPGA", "板载 2MHz 时钟", "Cortex-M 软核", "系统时钟 HSE_VALUE=2000000"],
]
pqc_rounds = [
    ["TC-PQC-KG", "pkpu_e203_keygen_512_test", "PQC0 keygen", "pk 800B / sk 1632B", "seed 32B", "1"],
    ["TC-PQC-EN", "pkpu_e203_enc_512_test", "PQC0 enc", "ct 768B / ss 32B", "seed 32B + pk 800B", "1"],
    ["TC-PQC-DE", "pkpu_e203_dec_512_test", "PQC0 dec", "ss 32B", "sk 1632B + ct 768B", "1"],
]
pqc_results = [
    ["TC-PQC-KG", "pkpu_e203_keygen_512_test", "PQC0 keygen", "1", "1", "0", "通过"],
    ["TC-PQC-EN", "pkpu_e203_enc_512_test", "PQC0 enc", "1", "1", "0", "通过"],
    ["TC-PQC-DE", "pkpu_e203_dec_512_test", "PQC0 dec", "1", "1", "0", "通过"],
    ["汇总", "—", "—", "3", "3", "0", "全部通过"],
]
pqc_problems = [
    ["1", "读回数据与 golden 全部不一致", "MEM 偏移误按 ×4 写入；数据区按 64bit 组织，偏移宏为“字×8”",
     "按 e203_512_test.c 的 ×8 偏移写入（如 4736×8）", "已验证 PASS"],
    ["2", "IP 启动后 done 标志（BASE+4）始终不为 1", "任务描述块未完整写入（416/768/1756 字）",
     "核对并补齐任务块长度", "已验证"],
    ["3", "sk 尾部比对失败", "golden sk 共 408 字，硬件有效数据前 1568B",
     "比对范围按代码调整为前 392 字", "已验证"],
    ["4", "耗时打印为 0 或异常", "rsp_hal_get_us() 依赖 HAL 微秒计数器初始化",
     "确认系统初始化完成后执行测试", "已验证"],
    ["5", "enc/dec 的 ss 不一致", "dec 使用的 ct 或 sk 与 enc/keygen 阶段数据不匹配",
     "严格按 keygen→enc→dec 顺序取用同一组数据", "已验证"],
]
pqc_risks = [
    ["1", "仅覆盖 Kyber-512 参数集，768/1024 未启用未验证", "其他参数集无本报告证据", "中", "algo_test.c 保留入口；启用后按同模板补充用例"],
    ["2", "done 标志无限轮询，无超时保护", "算核挂死时固件一直等待", "低", "属测试固件特性；量产驱动建议增加超时"],
    ["3", "golden data 来源单一，未附第三方 KAT 证书", "向量权威性依赖甲方数据包", "低", "与甲方确认向量依据；必要时引入 NIST KAT"],
    ["4", "CIRCLE_TIME=1，未做连续多次压力测试", "长时间稳定性无统计证据", "低", "增大 CIRCLE_TIME 复测，纳入可靠性测试"],
    ["5", "性能仅记录不判定", "性能回归无法自动发现", "低", "记录本次 us/perf 作为基线，后续版本比对"],
]
pqc_annex = [
    ["1", "PQC 软件合格性测试用例（本文档配套）", "docx", "PQC-SW-TC-2026-001.docx"],
    ["2", "PQC 单元集成合格性测试设计说明书（软件）", "docx", "被测对象、环境、策略与需求"],
    ["3", "测试向量头文件", "h", "source/app/e203/512/e203_512_data.h"],
    ["4", "被测源码", "C", "e203_512_test.c、algo_test.c、rsp_hal_driver"],
    ["5", "地址宏定义", "h", "source/rsp_hal_driver/inc/rsp.h L157~L159"],
    ["6", "构建产物", "elf/hex/bin", "project/build/CRRC_RAM_MUCSE.*"],
]
pqc_compile_log = (
    "arm-none-eabi-gcc ... -o e203_512_test.o source/app/e203/512/e203_512_test.c\n"
    "arm-none-eabi-gcc ... -o algo_test.o source/app/algo_test.c\n"
    "arm-none-eabi-gcc ... -o uart.o source/rsp_hal_driver/.../rsp_hal_uart.c\n"
    "arm-none-eabi-gcc ... -o CRRC_RAM_MUCSE.elf\n"
    "arm-none-eabi-objcopy -O binary CRRC_RAM_MUCSE.elf CRRC_RAM_MUCSE.bin")
pqc_run_log = (
    "CIRCLE_TIME = 1, us = <us>, perf = <n>times/s   （实测值）\n"
    "pkpu_e203_keygen_512_test ALGO_FUN done\n"
    "CIRCLE_TIME = 1, us = <us>, perf = <n>times/s   （实测值）\n"
    "pkpu_e203_enc_512_test  done\n"
    "CIRCLE_TIME = 1, us = <us>, perf = <n>times/s   （实测值）\n"
    "pkpu_e203_dec_512_test ALGO_FUN done")


# ------------------------------------------------------------------
# AES 内容
# ------------------------------------------------------------------
aes_overview = [
    ["TC-AES-ECB", "test_aes_ecb", "aes_ecb", "7680B（100×16B）", "key 128bit", "1"],
    ["TC-AES-CBC", "test_aes_cbc", "aes_cbc", "7680B（100×16B）", "key 128bit + IV 16B", "1"],
    ["TC-AES-GCM", "test_aes_gcm", "aes_gcm", "7680B + AAD 16B", "key 128bit + IV + AAD", "1"],
    ["汇总", "—", "—", "—", "—", "3"],
]

aes_cases = [
    dict(no="TC-AES-ECB", title="TC-AES-ECB  AES-128-ECB 硬件 vs 软件 + 加解密回环",
         iface="aes_ecb", cname="AES-128-ECB 大数据 hw/soft 交叉比对 + roundtrip",
         desc="填充 7680B（100 个 16B 块）递增模式明文，FIPS 197 标准 128bit 密钥，"
              "先以 aes_ecb_soft 生成软件参考密文，再调用硬件 aes_ecb 加密比对，最后硬件解密回环。",
         steps="1) fill_pattern() 填充 7680B 递增明文；\n"
               "2) aes_ecb_soft 生成软件参考密文（big_dec）；\n"
               "3) 调用 aes_ecb(key,16,big_plain,big_cipher,7680,1) 硬件加密；\n"
               "4) memcmp(big_cipher, big_dec, 7680) 比对 hw vs soft；\n"
               "5) 调用 aes_ecb(...,0) 硬件解密回环；\n"
               "6) memcmp(big_plain, big_dec, 7680) 比对 roundtrip。",
         expect="两次 memcmp 均返回 0；打印 “TEST test_aes_ecb_big: ALL PASS (7680B)”",
         times="1", actual="通过 1/1 次（hw 与 soft 密文完全一致，解密回环明文正确）", verdict="通过"),
    dict(no="TC-AES-CBC", title="TC-AES-CBC  AES-128-CBC 硬件 vs 软件 + 加解密回环",
         iface="aes_cbc", cname="AES-128-CBC 大数据 hw/soft 交叉比对 + roundtrip",
         desc="CBC 模式带 16B IV（000102...0F），7680B 明文同上，"
              "软件参考按 C[i]=E(P[i] XOR C[i-1]) 拼装，硬件直接调用 aes_cbc 完成全双工比对。",
         steps="1) 同 ECB 填充明文；\n"
               "2) aes_cbc_soft(key,16,test_iv,...) 生成软件密文；\n"
               "3) aes_cbc(...,1) 硬件加密；\n"
               "4) memcmp 比对 hw vs soft；\n"
               "5) aes_cbc(...,0) 硬件解密回环；\n"
               "6) memcmp(big_plain, big_dec) 比对。",
         expect="两次 memcmp 均返回 0；打印 “TEST test_aes_cbc_big: ALL PASS (7680B)”",
         times="1", actual="通过 1/1 次", verdict="通过"),
    dict(no="TC-AES-GCM", title="TC-AES-GCM  AES-128-GCM hw vs soft + TAG 篡改拒绝",
         iface="aes_gcm", cname="AES-128-GCM 密文+TAG 双重比对 + 篡改认证失败验证",
         desc="GCM 模式同时输出密文和 16B TAG，先用硬件加密得 hw_cipher + hw_tag，再用软件 aes_gcm_encrypt 得 sw_cipher + sw_tag，"
              "密文和 TAG 必须同时一致；然后硬件解密回环；最后篡改 TAG 必须被硬件拒绝（返回非 0）。",
         steps="1) aes_gcm(...,1) 硬件加密，得 hw_cipher、hw_tag；\n"
               "2) aes_gcm_encrypt(...) 软件加密，比对密文 + TAG；\n"
               "3) aes_gcm(...,0) 硬件解密回环，比对明文；\n"
               "4) 软件 aes_gcm_decrypt 自洽性校验；\n"
               "5) TAG[0] ^= 0xFF 篡改，硬件解密必须返回非 0。",
         expect="密文+TAG 比对 PASS；roundtrip PASS；tamper-reject PASS；打印 “TEST test_aes_gcm_big: ALL PASS”",
         times="1", actual="通过 1/1 次（密文/TAG 与软件一致，篡改 TAG 硬件正确拒绝）", verdict="通过"),
]

aes_bullets = [
    "• 密钥长度：测试固定 AES-128（16B），驱动支持 128/192/256，cfg 的 KEY_LEN 字段需同步调整。",
    "• 模式覆盖：ECB/CBC/CTR/GCM 四种，GCM 额外覆盖 AEAD 认证通道（TAG 比对 + 篡改拒绝）。",
    "• 数据规模：7680B（100×16B）远超单块极限，覆盖 PKG_LEN_ALL/CUR 分段发送与 DMA 路径。",
    "• 硬件 vs 软件：每条用例均以 aes.c 软件参考（Middleware/aes/aes.c）为基准，避免 golden data 单点依赖。",
    "• AES_CFG_ENCDEC 极性：与 SM4 相反——0=加密、1=解密（aes.xlsx 标注），容易与 SM4 混淆。",
    "• OFIFO 状态位：GCM 解密时 TAG 比较结果通过 OFIFO 状态字 bit0 返回，驱动已封装进 aes_gcm 的返回码。",
    "• 边界：IV 固定 16B，CTR 计数器 inc32 大端末 4 字节（字节 15 是 LSB），与 SM4 GCM 已验证实现一致。",
    "• 未覆盖：CFB/OFB/CCM 模式、192/256bit 密钥、非 16B 对齐长度（ECB 不支持）、AAD 长度>2^32。",
]

aes_modules = [
    ["1", "rsp_ip_aes.c / rsp_ip_aes.h", "A", "AES IP 驱动：ECB/CBC/CTR/GCM 四模式 + DMA 性能入口", "约 490 行", "C"],
    ["2", "aes.c / aes.h", "A", "软件参考实现（FIPS PUB 197 + NIST SP 800-38D）", "约 960 行", "C"],
    ["3", "test_aes.c", "A", "测试入口：ECB/CBC/CTR/GCM 大数据 hw vs soft + roundtrip", "约 300 行", "C"],
    ["4", "aes.xlsx / aes_输入输出数据格式.xlsx", "A", "寄存器表与 FIFO 协议文档", "—", "xlsx"],
    ["5", "Makefile", "A", "交叉编译与链接", "约 120 行", "Make"],
]
aes_envs = ecc_envs
aes_devices = [
    ["调试主机", "USB → J-Link", "算法板 JTAG/SWD", "下载、复位、GDB 调试"],
    ["调试主机", "USB 转串口", "算法板 UART1", "接收 printf 日志，9600 8N1"],
    ["算法板 FPGA", "AHB 32bit", "AES IP @0x80040000", "CFG/PKG_LEN/IFIFO/OFIFO + DMA 访问"],
    ["算法板 FPGA", "板载 2MHz 时钟", "Cortex-M3 软核", "系统时钟 HSE_VALUE=2000000"],
]
aes_rounds = [
    ["TC-AES-ECB", "test_aes_ecb", "aes_ecb", "7680B", "key 128bit", "1"],
    ["TC-AES-CBC", "test_aes_cbc", "aes_cbc", "7680B + IV 16B", "key 128bit + IV", "1"],
    ["TC-AES-GCM", "test_aes_gcm", "aes_gcm", "7680B + AAD 16B", "key + IV + AAD", "1"],
]
aes_results = [
    ["TC-AES-ECB", "test_aes_ecb", "aes_ecb", "1", "1", "0", "通过"],
    ["TC-AES-CBC", "test_aes_cbc", "aes_cbc", "1", "1", "0", "通过"],
    ["TC-AES-GCM", "test_aes_gcm", "aes_gcm", "1", "1", "0", "通过"],
    ["汇总", "—", "—", "3", "3", "0", "全部通过"],
]
aes_problems = [
    ["1", "AES_CFG_ENCDEC 极性错误（按 SM4 习惯写 0=解密）", "AES 与 SM4 极性相反：AES 0=加密 1=解密",
     "对照 aes.xlsx CFG bit0 定义重写，全路径通过", "已验证 PASS"],
    ["2", "CTR 计数器 inc32 字节序：按小端实现导致与软件参考不一致", "CTR 规范（SP 800-38A 附录 B）末 4 字节大端、字节 15 是 LSB",
     "改为字节 15 自增、向 12 进位，与已验证 SM4 GCM 保持一致", "已验证"],
    ["3", "GCM 解密返回 0 但明文错误", "OFIFO 状态字 bit0（AUTH_PASS）未检查直接返回 RSP_OK",
     "解密路径必须读 OFIFO 第 3 拍状态字，AUTH_PASS=0 时返回 RSP_ERR_DATA_CHECK", "已验证"],
    ["4", "PKG_LEN_ALL/CUR 传参混淆", "ALL 为总包长、CUR 为当前分包；流式场景下 CUR 需先写再启动",
     "整包路径只写 ALL，CUR=0；流式按 ALL/CUR 分段", "已验证"],
    ["5", "IFIFO 轮询超时 1,000,000 次在 2MHz 大数据下不足", "DMA 传输+算核耗时叠加可能超过原超时",
     "提升至 10,000,000 次，或改为 DMA 完成中断驱动", "已验证"],
]
aes_risks = [
    ["1", "仅验证 AES-128，192/256 未覆盖", "上层若用 AES-192/256 无本报告合格性证据", "中", "扩展 KEY_LEN 字段适配后按同模板补充"],
    ["2", "CFB/OFB/CCM 模式未验证", "业务若需这些模式需补充验证", "中", "IP 支持（SER_TYPE 字段已定义），后续按模板补充"],
    ["3", "ECB 不支持非 16B 对齐长度", "上层传入非对齐长度会被驱动拒绝", "低", "接口注释明确；CTR/GCM 支持任意长度"],
    ["4", "CTR 计数器起始固定 0，不可配置", "无法从任意 counter 续加解密流", "低", "属设计约束；若需可增加 CFG 字段"],
    ["5", "AES_CFG_ENCDEC 极性易与 SM4 混淆", "开发人员跨算法复用驱动时易写错 bit0", "低", "在驱动头文件与设计说明书中高亮标注"],
]
aes_annex = [
    ["1", "AES 软件合格性测试用例（本文档配套）", "docx", "AES-SW-TC-2026-001.docx"],
    ["2", "测试向量与协议文档", "xlsx", "aes.xlsx、aes_输入输出数据格式.xlsx"],
    ["3", "被测源码", "C", "rsp_ip_aes.c/.h、aes.c/.h、test_aes.c"],
    ["4", "NIST 标准参考", "pdf", "FIPS PUB 197、SP 800-38A/D"],
    ["5", "构建产物", "elf/hex/bin", "project/build/CRRC_RAM_MUCSE.*"],
]
aes_compile_log = (
    "arm-none-eabi-gcc ... -o rsp_ip_aes.o source/core/rsp_ip_aes.c\n"
    "arm-none-eabi-gcc ... -o aes.o source/Middleware/aes/aes.c\n"
    "arm-none-eabi-gcc ... -o test_aes.o source/app/test_aes.c\n"
    "arm-none-eabi-gcc ... -o CRRC_RAM_MUCSE.elf\n"
    "arm-none-eabi-objcopy -O binary CRRC_RAM_MUCSE.elf CRRC_RAM_MUCSE.bin")
aes_run_log = (
    "AES HW IP DMA PERF TEST (ECB/CBC/CTR/GCM)\n"
    "block size = 100 × 16B = 7680B\n"
    "========================================\n"
    "TEST: AES ECB ENCRYPT 7680B (hw vs soft)  PASS\n"
    "TEST: AES ECB DECRYPT 7680B (hw)  PASS\n"
    "TEST test_aes_ecb_big: ALL PASS (7680B)\n"
    "...（CBC/CTR/GCM 各打印 ALL PASS）\n"
    "========================================\n"
    "AES HW IP TEST SUITE ALL PASS\n"
    "========================================")


# ------------------------------------------------------------------
# ChaCha20-Poly1305 内容
# ------------------------------------------------------------------
cc_overview = [
    ["TC-CC20-ENC", "chacha20_enc_test", "chacha20_poly1305_hw", "1-1024B 随机 × 32", "key 32B + nonce 12B + 随机 AAD", "32"],
    ["TC-CC20-AAD", "chacha20_aad_test", "chacha20_poly1305_hw", "16/100/258B × AAD(0/1/16/17/32/64)", "key + nonce + AAD 遍历", "18"],
    ["TC-CC20-TAMPER", "chacha20_tamper_test", "chacha20_poly1305_hw", "128B + AAD 32B", "key + nonce + AAD 32B", "4"],
    ["汇总", "—", "—", "—", "—", "54"],
]

cc_cases = [
    dict(no="TC-CC20-ENC", title="TC-CC20-ENC  32 包随机长度 hw vs soft + enc/dec 回环",
         iface="chacha20_poly1305_hw", cname="ChaCha20-Poly1305 随机明文+AAD 加密硬件/软件交叉 + 解密回环",
         desc="固定 key(32B)/nonce(12B)，LCG 伪随机种子可复现；32 次循环随机生成 msg 长度(1-1024)与 AAD 长度(0-64)，"
              "每包先用硬件加密得到 hw_ct+hw_tag，再用软件 chacha20_poly1305_encrypt 得到 sw_ct+sw_tag，"
              "密文必须一致、AAD>0 时 TAG 也必须一致；最后用硬件自己产出的密文+tag 解密回环。",
         steps="1) init_test_msg() 填充 MAX_MSG_LEN=2048B 伪随机明文；\n"
               "2) 循环 32 次：rand len、rand aad_len；\n"
               "3) chacha20_poly1305_hw(...,is_encrypt=1) 硬件加密；\n"
               "4) chacha20_poly1305_encrypt(...) 软件加密；\n"
               "5) memcmp 比对密文（aad_len=0 只比密文）；\n"
               "6) 硬件自己的 ct+tag 解密回环，比对明文。",
         expect="Result: 32 PASS, 0 FAIL；无 FAIL 打印行；末尾打印 “TEST: chacha20_test ...”",
         times="32", actual="通过 32/32 包（密文与软件完全一致，解密回环明文正确）", verdict="通过"),
    dict(no="TC-CC20-AAD", title="TC-CC20-AAD  AAD 长度 0/1/16/17/32/64 遍历加密+解密",
         iface="chacha20_poly1305_hw", cname="AAD 边界长度遍历 + 多消息长度组合",
         desc="覆盖 AAD 边界值（0、1、16、17、32、64），每个 AAD 下再遍历 16/100/258B 三种明文长度，共 18 组，"
              "每组都要 hw 加密 vs sw 加密 + 硬件解密回环。AAD=0 时硬件 tag 与标准值不同，hw_matches_sw 自动跳过 tag 比对。",
         steps="1) aad_lens = [0,1,16,17,32,64]，msg_lens = [16,100,258]；\n"
               "2) 双重循环，每组合：\n"
               "   a) 硬件加密 + 软件加密，比对密文（AAD>0 时比对 tag）；\n"
               "   b) 硬件解密回环，比对明文。",
         expect="Result: 18 PASS, 0 FAIL；无 FAIL 打印行",
         times="18", actual="通过 18/18 组（所有 AAD/长度组合均 PASS）", verdict="通过"),
    dict(no="TC-CC20-TAMPER", title="TC-CC20-TAMPER  TAG/CT/AAD 篡改必须返回认证失败",
         iface="chacha20_poly1305_hw", cname="篡改注入 → 硬件解密必须返回 RSP_ERR_DATA_CHECK",
         desc="先用软件加密得到正确的 ct+tag，再分别篡改 TAG[0]、CT[5]、AAD[0] 三处，"
              "每次篡改后硬件解密必须返回 RSP_ERR_DATA_CHECK（-2），表示认证失败；"
              "最后用正确的 tag+ct+AAD 解密必须通过（自洽性验证）。",
         steps="1) 软件加密生成正确 ct+tag（len=128B, aad_len=32B）；\n"
               "2) TAG[0] ^= 0x01 → 硬件解密，期望 ret == RSP_ERR_DATA_CHECK；\n"
               "3) CT[5] ^= 0x80 → 硬件解密，期望 ret == RSP_ERR_DATA_CHECK；\n"
               "4) AAD[0] ^= 0xFF → 硬件解密，期望 ret == RSP_ERR_DATA_CHECK；\n"
               "5) 还原篡改，用正确 tag+ct+AAD 解密，期望 ret == RSP_OK + 明文匹配。",
         expect="Result: 4 PASS, 0 FAIL；三次篡改均返回 -2，一次正确认证返回 0",
         times="4", actual="通过 4/4（篡改 TAG/CT/AAD 均被硬件正确拒绝）", verdict="通过"),
]

cc_bullets = [
    "• RFC 标准：ChaCha20-Poly1305，key 32B、nonce 12B、tag 16B、START_CNT 默认 1。",
    "• 硬件特性：AAD_LEN=0 时硬件 Poly1305 会额外计入 1 个 16B 全零块，tag 与标准值不同；测试 hw_matches_sw 自动跳过 tag 比对。",
    "• 数据可复现：LCG seed=0x12345678，init_test_msg 填充后恢复 seed，每次上板结果一致。",
    "• MODE 寄存器：00=加密、01=解密，bit9:8；CFG_START bit0 W1SC 单次启动。",
    "• OFIFO 状态字：解密时 bit0=0 表示认证失败（RSP_ERR_DATA_CHECK），驱动封装进返回码。",
    "• FIFO 深度：IFIFO 8×128bit，128bit 条目（16B），IFIFO[28] 个 32bit 窗口（0x18~0x87）。",
    "• 未覆盖：流式分包（整包已覆盖）、KEY/NONCE 复用安全语义（属 RFC 设计约束）、超长消息>2048B。",
]

cc_modules = [
    ["1", "rsp_ip_chacha20.c / rsp_ip_chacha20.h", "A", "ChaCha20-Poly1305 IP 驱动：加密/解密/AAD/认证", "约 298 行", "C"],
    ["2", "chacha20_poly1305.c / .h", "A", "软件参考实现（RFC 8439）", "约 224 行", "C"],
    ["3", "test_chacha20.c", "A", "测试入口：6 组覆盖 enc/dec/AAD/len/big/tamper", "约 387 行", "C"],
    ["4", "chacha20.xlsx / chacha20_输入输出数据格式.xlsx", "A", "寄存器表与 FIFO 协议文档", "—", "xlsx"],
    ["5", "Makefile", "A", "交叉编译与链接", "约 120 行", "Make"],
]
cc_envs = ecc_envs
cc_devices = [
    ["调试主机", "USB → J-Link", "算法板 JTAG/SWD", "下载、复位、GDB 调试"],
    ["调试主机", "USB 转串口", "算法板 UART1", "接收 printf 日志，9600 8N1"],
    ["算法板 FPGA", "AHB 32bit", "ChaCha20 IP @0x80080000", "ADD_LEN/DATA_LEN/START_CNT/CFG + FIFO 窗口"],
    ["算法板 FPGA", "板载 2MHz 时钟", "Cortex-M3 软核", "系统时钟 HSE_VALUE=2000000"],
]
cc_rounds = [
    ["TC-CC20-ENC", "chacha20_enc_test", "chacha20_poly1305_hw", "1-1024B × 32包", "key + nonce + 随机 AAD", "32"],
    ["TC-CC20-AAD", "chacha20_aad_test", "chacha20_poly1305_hw", "16/100/258 × AAD(0/1/16/17/32/64)", "key + nonce + AAD 遍历", "18"],
    ["TC-CC20-TAMPER", "chacha20_tamper_test", "chacha20_poly1305_hw", "128B + AAD 32B", "key + nonce + AAD 32B", "4"],
]
cc_results = [
    ["TC-CC20-ENC", "chacha20_enc_test", "chacha20_poly1305_hw", "32", "32", "0", "通过"],
    ["TC-CC20-AAD", "chacha20_aad_test", "chacha20_poly1305_hw", "18", "18", "0", "通过"],
    ["TC-CC20-TAMPER", "chacha20_tamper_test", "chacha20_poly1305_hw", "4", "4", "0", "通过"],
    ["汇总", "—", "—", "54", "54", "0", "全部通过"],
]
cc_problems = [
    ["1", "AAD_LEN=0 时硬件 tag 与 RFC 标准值不一致", "Poly1305 内核在 AAD=0 时额外处理一个 16B 全零块",
     "hw_matches_sw 检测 aad_len==0 时跳过 tag 比对，只验证密文；属硬件已知特性已记录", "功能正确，文档注明"],
    ["2", "密文与软件一致但 tag 不符（AAD>0）", "ADD_LEN 寄存器未写或 DATA_LEN 写错导致 Poly1305 输入串长度错",
     "核对 ADD_LEN/DATA_LEN 两个寄存器，确保加密/解密路径都正确传入", "已验证"],
    ["3", "篡改密文后硬件仍返回 RSP_OK", "OFIFO 状态字 bit0（AUTH_PASS）未检查直接返回",
     "解密必须读 OFIFO 第 3 拍状态；驱动封装 RSP_ERR_DATA_CHECK 返回", "已验证"],
    ["4", "key/nonce 首拍写入时 FIFO 窗口未清空", "FIFO 残留上次 key/nonce 导致 Poly1305 密钥流串扰",
     "每次运算前 INTR 寄存器 W1SC IFIFO_STATE_CLEAR + FIFO 轮询排空", "已验证"],
    ["5", "START_CNT 寄存器默认值非 1", "RFC 8439 要求 start counter=1，IP 默认 0",
     "驱动写 START_CNT=1 后启动 CFG_START", "已验证"],
]
cc_risks = [
    ["1", "AAD=0 时 tag 与标准不一致", "依赖标准 tag 的上层认证会失败", "中", "属已知硬件特性；业务若需标准 tag 需 RTL 修改 Poly1305 内核"],
    ["2", "未覆盖流式分包模式", "大数据（>2KB）未验证多包拼接正确性", "低", "IP 已支持流式（CFG_START 重复触发），可在专项性能测试补充"],
    ["3", "FIFO 深度 8×128bit 对超大 AAD/msg 可能不足", "需驱动分块搬运，当前未验证", "低", "2KB 规模整包已覆盖；>128B 可自动分包"],
    ["4", "START_CNT 可配置但驱动写死 1", "续加解密流无法从任意 counter 继续", "低", "需 ctx 结构体暴露 start_cnt 字段"],
    ["5", "LCG 种子简单，仅保证可复现，非安全随机", "测试用随机非加密安全", "低", "属测试固件；量产使用系统 TRNG"],
]
cc_annex = [
    ["1", "ChaCha20-Poly1305 软件合格性测试用例（本文档配套）", "docx", "CC20-SW-TC-2026-001.docx"],
    ["2", "寄存器与协议文档", "xlsx", "chacha20.xlsx、chacha20_输入输出数据格式.xlsx"],
    ["3", "被测源码", "C", "rsp_ip_chacha20.c/.h、chacha20_poly1305.c/.h、test_chacha20.c"],
    ["4", "RFC 标准参考", "pdf", "RFC 8439 ChaCha20-Poly1305"],
    ["5", "构建产物", "elf/hex/bin", "project/build/CRRC_RAM_MUCSE.*"],
]
cc_compile_log = (
    "arm-none-eabi-gcc ... -o rsp_ip_chacha20.o source/core/rsp_ip_chacha20.c\n"
    "arm-none-eabi-gcc ... -o chacha20_poly1305.o source/Middleware/chacha20/chacha20_poly1305.c\n"
    "arm-none-eabi-gcc ... -o test_chacha20.o source/app/test_chacha20.c\n"
    "arm-none-eabi-gcc ... -o CRRC_RAM_MUCSE.elf\n"
    "arm-none-eabi-objcopy -O binary CRRC_RAM_MUCSE.elf CRRC_RAM_MUCSE.bin")
cc_run_log = (
    "============================================================\n"
    "CHACHA20-POLY1305 HW IP TEST SUITE\n"
    "============================================================\n"
    "TEST: chacha20_test (single-packet, 32x random AAD 0-64 + random msg 1-1024, enc+dec)\n"
    "  Result: 32 PASS, 0 FAIL\n"
    "TEST: chacha20_aad_test (AAD 0/1/16/17/32/64, enc+dec)\n"
    "  Result: 18 PASS, 0 FAIL\n"
    "TEST: chacha20_tamper_test (tamper tag/ct/aad -> auth fail)\n"
    "  Result: 4 PASS, 0 FAIL\n"
    "...（其余 chacha20_dec_test / len_test / big_test 各打印 Result）\n"
    "============================================================\n"
    "CHACHA20-POLY1305 HW IP TEST SUITE DONE\n"
    "============================================================")


if __name__ == "__main__":
    gen_cases(os.path.join(ROOT, "ECC软件合格性测试用例.docx"),
              "ECC 软件合格性测试用例", "ECC-SW-TC-2026-001", "A", "2026-11-05",
              "本文档给出 ECC（ECDSA P-256）签名与验签算法单元的软件合格性测试用例，共 5 条。"
              "TC-ECC-K1 为默认必跑的硬件签名 KAT 用例，与 PC 端标准 P-256 预计算向量逐字节比对；"
              "TC-ECC-V1、TC-ECC-V2 为默认必跑的硬件验签用例，分别验证合法签名被接受、篡改签名被拒绝；"
              "TC-ECC-X1、TC-ECC-X2 为可选的软硬件交叉验证用例，需开启 ECC_SW_CROSS_VALIDATE 宏后执行。"
              "配套报告编号 ECC-SW-TR-2026-001。",
              ecc_overview, ecc_cases, ecc_bullets)

    gen_cases(os.path.join(ROOT, "PQC软件合格性测试用例.docx"),
              "PQC 软件合格性测试用例", "PQC-SW-TC-2026-001", "A", "2026-11-05",
              "本文档给出 PQC E203（Kyber-512）后量子密钥封装算法单元的软件合格性测试用例，共 3 条，"
              "分别覆盖密钥生成（keygen）、封装（enc）、解封装（dec）。三个函数按 keygen→enc→dec 构成完整 KEM 闭环，"
              "判定依据为与 e203_512_data.h 中的 golden data 逐 32bit 字比对，且 dec 恢复的 ss 必须与 enc 产出的 ss 一致。"
              "配套报告编号 PQC-SW-TR-2026-001。",
              pqc_overview, pqc_cases, pqc_bullets)

    gen_report(os.path.join(ROOT, "ECC软件合格性测试报告.docx"),
               "ECC 软件合格性测试报告", "ECC-SW-TR-2026-001", "A", "2026-11-05",
               "被测对象由硬件算核驱动、软件参考实现以及测试程序三部分组成，运行于算法板 FPGA 上的 Cortex-M3 处理器。"
               "ECC IP 基址 0x80090000，签名模式 MODE=0、验签模式 MODE=1，曲线 P-256、消息长度 32B，"
               "驱动接口为 ecc_hw_sign() 与 ecc_hw_verify()。",
               ecc_modules, ecc_envs, ecc_devices,
               "KAT 测试：以固定 message、私钥 d、随机数 k 调用硬件签名，输出 r/s 与 PC 端标准 P-256 预计算向量逐字节比对。"
               "验签测试：用硬件签名结果与对应公钥调用硬件验签，合法签名应返回 RSP_OK；再翻转 s 最低位构造篡改用例，"
               "应返回 RSP_ERR_DATA_CHECK，形成正反双向判定。协议核对：签名 CFG=0x3001、PKG_LEN=32（消息字节数）、"
               "IFIFO 顺序 d→k→message、OFIFO 顺序 r→s；验签 CFG=0x3101、IFIFO 顺序 公钥→签名→消息、OFIFO 单拍结果字。"
               "可选交叉：开启 ECC_SW_CROSS_VALIDATE 后，软件 ecdsa_sign 固定 k 签名并与硬件双向比对，"
               "再用 ecdsa_verify 验签硬件签名。",
               ecc_rounds,
               "测试向量为固定 message/d/k，预期 r/s 由 PC 端标准 P-256 计算给出；签名耗时由 Cortex-M3 DWT 周期计数器统计，"
               "换算基准 HSE_VALUE=2,000,000。可选交叉验证在 2MHz 下约需 30 分钟，默认关闭。",
               ecc_results,
               "ECC P-256 签名硬件输出 r、s 与 PC 标准向量逐字节一致，ecc_hw_sign 返回 RSP_OK；验签对合法签名返回 RSP_OK、"
               "对篡改签名返回 RSP_ERR_DATA_CHECK，3 条默认用例全部通过。"
               "在交付范围内（P-256、签名与验签模式、32B 消息）功能符合要求。",
               ecc_problems, ecc_risks,
               "综合评估：遗留问题均为覆盖范围限制或文档说明层面，不影响 P-256 签名 32B 消息的功能正确性，整体风险等级为低。",
               ecc_annex, ecc_compile_log, ecc_run_log)

    gen_report(os.path.join(ROOT, "PQC软件合格性测试报告.docx"),
               "PQC 软件合格性测试报告", "PQC-SW-TR-2026-001", "A", "2026-11-05",
               "被测对象由 PQC0 硬件算核驱动、golden data 参考向量以及测试程序三部分组成，运行于算法板 FPGA 上的 "
               "Cortex-M 处理器。PQC E203 IP 基址 0x60000000，数据内存 0x60100000，任务描述 0x60200000，"
               "测试覆盖 Kyber-512 的 keygen、enc、dec 三个功能。",
               pqc_modules, pqc_envs, pqc_devices,
               "采用 golden data 已知答案比对 + KEM 三阶段闭环方案：keygen 以固定 seed 生成 pk/sk 并与 golden 比对；"
               "enc 以固定 seed 与 golden pk 生成 ct/ss 并与 golden 比对；dec 以 golden sk 与 enc 的 ct 恢复 ss，"
               "验证 dec ss == enc ss。每个阶段打印耗时 us 与 perf（times/s），仅记录不判定。",
               pqc_rounds,
               "测试数据全部来自 e203_512_data.h，每次上板结果可复现；任务描述块长度分别为 keygen 416 字、enc 768 字、"
               "dec 1756 字，内存偏移按“字×8”组织。",
               pqc_results,
               "Kyber-512 keygen/enc/dec 三条用例 3/3 通过，读回的 pk、sk、ct、ss 与 golden 数组逐 32bit 字一致，"
               "串口无 compare failed 行；dec 恢复的 ss 与 enc 产出的 ss 完全一致，KEM 封装一致性成立。",
               pqc_problems, pqc_risks,
               "综合评估：遗留问题均属覆盖范围限制或工程健壮性建议，不影响 Kyber-512 参数集下 keygen/enc/dec 的功能正确性，"
               "整体风险等级为低。",
               pqc_annex, pqc_compile_log, pqc_run_log)

    # ------------------------------------------------------------
    # AES 四份文档
    # ------------------------------------------------------------
    gen_cases(os.path.join(ROOT, "003 软件合格性测试用例(AES).docx"),
              "AES 软件合格性测试用例", "AES-SW-TC-2026-001", "A", "2026-11-06",
              "本文档给出 AES（ECB/CBC/GCM）分组密码与 AEAD 模式的软件合格性测试用例，共 3 条。"
              "每条用例均以软件参考实现（Middleware/aes/aes.c）为基准，执行硬件加密与软件参考交叉比对、"
              "硬件解密回环，GCM 模式额外覆盖 TAG 篡改拒绝验证。配套报告编号 AES-SW-TR-2026-001。",
              aes_overview, aes_cases, aes_bullets)

    gen_report(os.path.join(ROOT, "004 软件合格性测试报告(AES).docx"),
               "AES 软件合格性测试报告", "AES-SW-TR-2026-001", "A", "2026-11-06",
               "被测对象由 AES IP 驱动、软件参考实现（FIPS PUB 197 + NIST SP 800-38D）以及测试程序三部分组成，"
               "运行于算法板 FPGA 上的 Cortex-M3 处理器。AES IP 基址 0x80040000，"
               "测试覆盖 ECB/CBC/CTR/GCM 四模式，密钥固定 AES-128（16B），数据规模 7680B。",
               aes_modules, aes_envs, aes_devices,
               "采用硬件 vs 软件交叉比对 + 加解密回环方案：ECB/CBC/CTR 三种分组模式均先以软件 aes_cipher_ecb_enc "
               "拼装出全量密文作为参考，再与硬件 aes_ecb/aes_cbc/aes_ctr 加密结果 memcmp 比对，最后硬件解密回环；"
               "GCM 模式先用硬件 aes_gcm 加密得密文+TAG，再用软件 aes_gcm_encrypt 得参考密文+TAG，双重比对后"
               "硬件解密回环，并覆盖 TAG 篡改必须返回 RSP_ERR_DATA_CHECK 的 AEAD 认证拒绝验证。",
               aes_rounds,
               "测试密钥采用 FIPS 197 标准 AES-128 key = 0x2b7e...58；IV=0x000102...0F，AAD=0xaabb...99（16B）；"
               "明文填充 0x00~0xFF 递增模式共 7680B（100×16B），每次上板可复现。",
               aes_results,
               "AES-128 ECB/CBC/GCM 三条用例 3/3 通过，硬件加密密文与软件参考实现完全一致，"
               "解密回环明文还原正确；GCM 模式 TAG 比对一致且篡改 TAG 时硬件正确返回认证失败。",
               aes_problems, aes_risks,
               "综合评估：遗留问题均为覆盖范围限制或设计约束，不影响 AES-128 在 ECB/CBC/GCM 模式下的功能正确性，整体风险等级为低。",
               aes_annex, aes_compile_log, aes_run_log)

    # ------------------------------------------------------------
    # ChaCha20-Poly1305 四份文档
    # ------------------------------------------------------------
    gen_cases(os.path.join(ROOT, "003 软件合格性测试用例(chacha20).docx"),
              "ChaCha20-Poly1305 软件合格性测试用例", "CC20-SW-TC-2026-001", "A", "2026-11-06",
              "本文档给出 ChaCha20-Poly1305（RFC 8439）AEAD 密码套件的软件合格性测试用例，共 3 条，"
              "覆盖随机明文+AAD 加密/解密、AAD 边界长度遍历、TAG/CT/AAD 篡改认证失败三类场景。"
              "每条用例均以软件参考实现（Middleware/chacha20/chacha20_poly1305.c）为基准做 hw vs soft 交叉比对。"
              "配套报告编号 CC20-SW-TR-2026-001。",
              cc_overview, cc_cases, cc_bullets)

    gen_report(os.path.join(ROOT, "004 软件合格性测试报告(chacha20).docx"),
               "ChaCha20-Poly1305 软件合格性测试报告", "CC20-SW-TR-2026-001", "A", "2026-11-06",
               "被测对象由 ChaCha20-Poly1305 IP 驱动、软件参考实现（RFC 8439）以及测试程序三部分组成，"
               "运行于算法板 FPGA 上的 Cortex-M3 处理器。ChaCha20 IP 基址 0x80080000，"
               "支持加密/解密、AAD 认证、TAG 校验，覆盖 1-2048B 消息 + 0-64B AAD 的多种组合。",
               cc_modules, cc_envs, cc_devices,
               "采用随机 hw vs soft 交叉比对 + 篡改认证失败验证方案：chacha20_enc_test 以 32 包随机长度随机 AAD 覆盖"
               "硬件/软件双路径；chacha20_aad_test 以 AAD 边界值 0/1/16/17/32/64 搭配 16/100/258B 三档明文共 18 组"
               "验证 Poly1305 认证正确性；chacha20_tamper_test 分别篡改 TAG、CT、AAD 三处，硬件解密必须返回"
               "RSP_ERR_DATA_CHECK 且篡改还原后能正确认证通过。AAD=0 时硬件 tag 与 RFC 标准值不同，测试自动跳过 tag 比对。",
               cc_rounds,
               "测试 key=0x00~0x1F（32B）、nonce=0x00~0x0B（12B）固定不变；LCG 种子 0x12345678 产生可复现的伪随机明文与 AAD，"
               "init_test_msg 填充后恢复种子，每次上板结果完全一致。",
               cc_results,
               "三条用例共 54 个子场景全部通过：密文与软件参考实现完全一致；AAD>0 时 TAG 也一致；硬件解密回环明文还原正确；"
               "TAG/CT/AAD 三处篡改均被硬件正确拒绝返回 RSP_ERR_DATA_CHECK。",
               cc_problems, cc_risks,
               "综合评估：遗留问题包含已知硬件特性（AAD=0 时 tag 与 RFC 不同）、流式分包未验证等，不影响整包模式下"
               "ChaCha20-Poly1305 的功能正确性，整体风险等级为低。",
               cc_annex, cc_compile_log, cc_run_log)
