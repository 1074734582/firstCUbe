# -*- coding: utf-8 -*-
# Compute golden SM2 ciphertext for test_sm2_enc (standard GM/T 0003,
# matches middleware sm2_encrypt_message with fixed random k).
import struct

IV = [0x7380166F,0x4914B2B9,0x172442D7,0xDA8A0600,0xA96F30BC,0x163138AA,0xE38DEE4D,0xB0FB0E4E]
T = [0x79CC4519,0x7A879D8A]

def rotl(x,n): return ((x<<n)|(x>>(32-n)))&0xFFFFFFFF

def p0(x): return x ^ rotl(x,9) ^ rotl(x,17)
def p1(x): return x ^ rotl(x,15) ^ rotl(x,23)

def sm3(data: bytes) -> bytes:
    l = len(data)*8
    msg = bytearray(data); msg.append(0x80)
    while len(msg)%64 != 56: msg.append(0)
    msg += struct.pack(">Q", l)
    V = IV[:]
    for off in range(0,len(msg),64):
        B = msg[off:off+64]
        W = list(struct.unpack(">16I", B))
        for j in range(16,68):
            W.append(p1(W[j-16]^W[j-9]^rotl(W[j-3],15)) ^ rotl(W[j-13],7) ^ W[j-6])
        Wp = [W[j]^W[j+4] for j in range(64)]
        A,Bv,C,D,E,F,G,H = V
        for j in range(64):
            tj = T[0] if j<16 else T[1]
            SS1 = rotl((rotl(A,12)+E+rotl(tj,j%32))&0xFFFFFFFF,7)
            SS2 = SS1 ^ rotl(A,12)
            FF = (A^Bv^C) if j<16 else ((A&Bv)|(A&C)|(Bv&C))
            GG = (E^F^G) if j<16 else ((E&F)|((~E)&G))
            TT1 = (FF + D + SS2 + Wp[j])&0xFFFFFFFF
            TT2 = (GG + H + SS1 + W[j])&0xFFFFFFFF
            D=C; C=rotl(Bv,9); Bv=A; A=TT1
            H=G; G=rotl(F,19); F=E; E=p0(TT2)
        V = [a^b for a,b in zip(V,[A,Bv,C,D,E,F,G,H])]
    return struct.pack(">8I", *V)

def kdf(z: bytes, klen: int) -> bytes:
    out = b""; ct = 1
    while len(out) < klen:
        out += sm3(z + struct.pack(">I", ct)); ct += 1
    return out[:klen]

# SM2 curve
P  = 0xFFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFF
A  = 0xFFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFC
B  = 0x28E9FA9E9D9F5E344D5A9E4BCF6509A7F39789F515AB8F92DDBCBD414D940E93
N  = 0xFFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFF7203DF6B21C6052B53BBF40939D54123
GX = 0x32C4AE2C1F1981195F9904466A39C9948FE30BBFF2660BE1715A4589334C74C7
GY = 0xBC3736A2F4F6779C59BDCEE36B692153D0A9877CC62A474002DF32E52139F0A0

def add(Pt, Qt):
    if P_ := Pt_is_inf(Pt): return Qt
    if Pt_is_inf(Qt): return Pt
    (x1,y1),(x2,y2) = Pt, Qt
    if x1==x2 and (y1+y2)%P==0: return None
    if x1==x2 and y1==y2:
        l = (3*x1*x1 + A) * pow(2*y1, P-2, P) % P
    else:
        l = (y2-y1) * pow((x2-x1)%P, P-2, P) % P
    x3 = (l*l - x1 - x2) % P
    y3 = (l*(x1-x3) - y1) % P
    return (x3,y3)

def Pt_is_inf(Pt): return Pt is None
Qt=None

def mul(k, Pt):
    R = None; Q = Pt
    while k:
        if k & 1:
            if R is None: R = Q
            else:
                (x1,y1),(x2,y2) = R,Q
                if x1==x2 and (y1+y2)%P==0: R=None
                elif x1==x2 and y1==y2:
                    l=(3*x1*x1+A)*pow(2*y1,P-2,P)%P
                    x3=(l*l-x1-x2)%P; y3=(l*(x1-x3)-y1)%P; R=(x3,y3)
                else:
                    l=(y2-y1)*pow((x2-x1)%P,P-2,P)%P
                    x3=(l*l-x1-x2)%P; y3=(l*(x1-x3)-y1)%P; R=(x3,y3)
        (x1,y1)=Q; l=(3*x1*x1+A)*pow(2*y1,P-2,P)%P
        x3=(l*l-2*x1)%P; y3=(l*(x1-x3)-y1)%P; Q=(x3,y3)
        k >>= 1
    return R

VK = bytes([0x59,0x27,0x6E,0x27,0xD5,0x06,0x86,0x1A,0x16,0x68,0x0F,0x3A,0xD9,0xC0,0x2D,0xCC,
            0xEF,0x3C,0xC1,0xFA,0x3C,0xDB,0xE4,0xCE,0x6D,0x54,0xB8,0x0D,0xEA,0xC1,0xBC,0x21])
VPUB = bytes([0x09,0xF9,0xDF,0x31,0x1E,0x54,0x21,0xA1,0x50,0xDD,0x7D,0x16,0x1E,0x4B,0xC5,0xC6,
              0x72,0x17,0x9F,0xAD,0x18,0x33,0xFC,0x07,0x6B,0xB0,0x8F,0xF3,0x56,0xF3,0x50,0x20,
              0xCC,0xEA,0x49,0x0C,0xE2,0x67,0x75,0xA5,0x2D,0xC6,0xEA,0x71,0x8C,0xC1,0xAA,0x60,
              0x0A,0xED,0x05,0xFB,0xF3,0x5E,0x08,0x4A,0x66,0x32,0xF6,0x07,0x2D,0xA9,0xAD,0x13])
MSG = b"0123456789ABCDEF0123456789ABCDEF"

k = int.from_bytes(VK,"big")
PB = (int.from_bytes(VPUB[:32],"big"), int.from_bytes(VPUB[32:],"big"))

x1,y1 = mul(k,(GX,GY))
x2,y2 = mul(k,PB)
x2b = x2.to_bytes(32,"big"); y2b = y2.to_bytes(32,"big")
t = kdf(x2b+y2b, len(MSG))
c2 = bytes(m^tt for m,tt in zip(MSG,t))
c3 = sm3(x2b + MSG + y2b)
golden = x1.to_bytes(32,"big") + y1.to_bytes(32,"big") + c2 + c3

def cfmt(name, b):
    s = f"static const uint8_t {name}[{len(b)}] = {{\n    "
    for i,x in enumerate(b):
        s += f"0x{x:02X},"
        s += "\n    " if (i+1)%8==0 and i+1<len(b) else ("," if i+1<len(b) else "")
    s += "\n};"
    return s

print("C1(x1||y1):", golden[:64].hex().upper())
print("C2        :", golden[64:96].hex().upper())
print("C3        :", golden[96:].hex().upper())
print()
print(cfmt("GOLDEN_SM2_ENC_CT", golden))
