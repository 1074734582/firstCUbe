# ChaCha20-Poly1305 IP — AAD=0 时 Tag 异常缺陷报告

**日期**：2026-11-10
**发现模块**：ChaCha20-Poly1305 硬件 IP
**严重程度**：功能缺陷（密文正确，仅认证 tag 偏离标准）
**影响范围**：仅 ADD_LEN=0（无 AAD）场景；AAD>0 完全正常

---

## 1. 缺陷现象

当 **ADD_LEN=0**（无附加认证数据 AAD）时，硬件 IP 输出的 Poly1305 tag 与 RFC 8439 标准值不一致。

- 密文（ciphertext）：**正确**，与软件参考一致
- 认证 tag（16B）：**错误**，与标准值不同
- AAD>0 时（1/16/17/32/64 字节）：密文与 tag 均完全正确

## 2. 复现条件

| 项 | 值 |
|---|---|
| key (32B) | `00 01 02 ... 1E 1F`（0x00..0x1F） |
| nonce (12B) | `00 01 02 ... 0A 0B`（0x00..0x0B） |
| AAD 长度 | 0 |
| 明文长度 | 任意（已验证 1/16/100/256/1024 等） |

## 3. 实测证据

同一 key/nonce/明文下，软件（RFC 8439 标准）与硬件 tag 对比：

| 场景 | 标准 tag（软件） | 硬件 tag |
|---|---|---|
| AAD=0, len=16 | `81 19 D0 A9 9C FA 52 67 69 69 E2 8F 3B 38 E0 39` | `F7 FC D7 CA BB 36 C7 E9 09 FE 11 F3 AD A6 48 AC` |
| AAD=0, len=100 | `EB B9 1D D9 66 68 E4 B3 49 CE 27 28 80 77 8D A3` | `9D 96 7D 20 DD 77 54 DD 59 CE DD 3F 25 C5 C4 E6` |
| AAD=0, len=258 | `24 C9 F7 87 AF C7 5F B1 0A FD AF 21 94 62 9D 03` | `06 BE 61 EC FC 48 EE 94 64 AD 58 94 D4 41 6F 3D` |

**交叉验证**：用软件生成的密文 + 标准 tag 喂硬件做解密（AAD=0），硬件返回认证失败（`RSP_ERR_DATA_CHECK`），证明硬件无法识别标准 tag。

## 4. 根因分析

RFC 8439 规定 Poly1305 MAC 的输入为：

```
pad16(AAD) || pad16(Ciphertext) || LE64(len(AAD)) || LE64(len(Ciphertext))
```

其中 `pad16(x)` 是将 `x` 用零填充至 16 字节整数倍。

**关键**：当 AAD 为空（长度 0）时，`pad16(空) = 空`（0 本身就是 16 的倍数），即 MAC 输入中**不应包含任何 AAD 块**。

**疑似 RTL 问题**：算核在 `ADD_LEN=0` 时，仍然向 Poly1305 送入了一个 16B 的全零 AAD 块，导致 MAC 输入多了一拍，tag 计算结果偏离标准。

该假设能解释"AAD=0 错、AAD>0 对"的现象：
- AAD=0：多出来的零块直接改变 MAC 输入 → tag 错误
- AAD>0：本来就有 AAD 块，无额外零块 → tag 正确

## 5. 驱动侧确认

驱动代码中已确认：
- `ADD_LEN=0` 时，**不往 IFIFO 写任何 AAD 拍**（[rsp_ip_chacha20.c:110-114](file:///z:/ccrc/test_i2c_not_offical/firmware/source/core/rsp_ip_chacha20.c#L110-L114)）
- 因此多出来的全零 AAD 块是**内核内部产生**的，并非驱动误写

## 6. 对 FPGA 同事的建议

请检查 ChaCha20-Poly1305 算核中 Poly1305 模块的 AAD padding 逻辑：

- 确认 `aad_len == 0` 时，`pad16(AAD)` 的输出应为 **0 字节**（不产生任何 AAD 拍），而非一拍 16B 零
- 可在 RTL 仿真中观测 Poly1305 的数据输入，对比 AAD=0 与 AAD=16 时输入拍数是否差 1

## 7. 当前规避措施

- 驱动侧无法规避（零块由内核内部产生）
- 测试中对 AAD=0 场景只校验密文、不校验 tag，并用 `chacha20_swref_test` 固化"标准 tag 认证必然失败"的缺陷行为
- 待 RTL 修复后，取消 AAD=0 的 tag 跳过逻辑即可全量通过
