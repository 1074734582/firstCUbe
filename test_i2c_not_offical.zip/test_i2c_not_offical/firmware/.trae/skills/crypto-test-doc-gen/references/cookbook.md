# Cookbook — 模板改写细节

本文件记录甲方 003/004 模板的结构、python-docx 改写要点、以及几轮踩过的坑。
正文见 `SKILL.md` 的工作流；这里是"当你需要改脚本 / 调试时"查的手册。

## 模板结构

### 003 软件合格性测试用例.docx

页面：A4 21.0×29.7cm，L/R 边距 2.5 / 1.0，正文宽 **17.5 cm**。

表格索引（0-based）：

| 索引 | 用途 | 行数 | 列数 | 布局 |
|------|------|------|------|------|
| T0 | 封面（名称/编号/版本 3×2） | 3 | 2 | fixed, 宽 7140dxa |
| T1 | 签署（编制/工艺/校核/标准化 3×4） | 3 | 4 | fixed, 宽 9854dxa |
| T2 | 版本历史（26×5） | 26 | 5 | fixed, 宽 9854dxa |
| T3 | 用例总览（4×6，最后一行为"汇总"） | 4 | 6 | autofit |
| T4 / T5 | 两条模板用例详情（10×2，"项/内容"两列） | 10 | 2 | autofit |

正文段落样式：

| 样式 | 用途 |
|------|------|
| `ZS_A目次、标准名称标题` | "目   次" 那一行 |
| `toc 1` / `toc 2` | 自动生成的 TOC 条目（域） |
| `ZS_C标题1级` | "引言"、"用例总览"、"测试用例详情"、"边界值与覆盖说明"（自动编号） |
| `ZS_C标题2级` | 每条用例的标题，如 "TC-DES-K1  DES-ECB KAT..."（自动编号） |
| `ZS_D表标题` | 表格上方的表标题，如 "用例总览"、"ecc_hw_sign" |
| `ZS_D图标题` | 图片下方的图标题（003 没有，004 有） |
| Normal | 引言段、被测接口段、用例描述/步骤/预期段、边界 bullets |

**关键域**：TOC 是 `w:instrText` 域（不是 fldSimple），包含 `TOC \o "1-2" ...` 指令。
生成脚本会在 doc settings 里注入 `<w:updateFields w:val="true"/>`，
让 Word 打开时自动刷新。也可在 Word COM 里主动 `Fields.Update()` + `TablesOfContents(1).Update()`。

### 004 软件合格性测试报告.docx

同页面规格。**3 张图片**（连接总图 / J-Link 连接线 / 串口连接）位于"设备连线"章节，
对应段落索引约 60 / 62 / 64，图标题 61 / 63 / 65。脚本不会触碰这些图片，
只改图标题文字（如"连接总图"保留不变）。

表格索引：

| 索引 | 用途 | 模板行数 | 备注 |
|------|------|----------|------|
| T0 | 封面 | 3 | |
| T1 | 签署 | 3 | |
| T2 | 版本历史 | 26 | |
| T3 | 被测软件组成 | 6 | 12pt 字体（与正文其他 10.5pt 不同） |
| T4 | 开发与运行环境 | 6 | 同 12pt |
| T5 | 设备连线 | 5 | 4 列 |
| T6 | 测试轮次 | 3 | 6 列，脚本把首列表头改成"用例编号" |
| T7 | 测试结果汇总 | 4 | 7 列 |
| T8 | 典型问题分析 | 3 | 5 列 |
| T9 | 遗留风险 | 2 | 5 列 |
| T10 | 附件清单 | 6 | 4 列 |

**章节段位置与前缀**（脚本用 `find_par(doc, 前缀)` 定位）：

| 前缀 | 对应正文 |
|------|----------|
| "被测对象由硬件算核驱动" | 1 章引言 |
| "KAT 测试" | 3.1 测试方案 |
| "测试数据由 32 位 LCG" | 3.2 测试轮次说明 |
| "DES-ECB KAT 标准向量" | 4.1 结论 |
| "综合评估：DES" | 5 遗留风险总结 |
| "arm-none-eabi-gcc ... -o des.o" | 6.1 编译日志 |
| "DES HARDWARE IP TEST SUITE" | 6.2 运行日志 |

前缀匹配到后，`set_par` 会替换整段。如果将来模板改版，
把新的前缀写在 `gen_report` 调用处即可。

## python-docx 改写要点

### 保留样式 & 重建 run

模板表格单元格里的 run 有正确的字体/字号/bold，`set_cell` 的做法是：

```python
def set_cell(cell, text, size=None):
    name, sz, bold = font_of(cell)          # capture 首 run 的 (name, size, bold)
    for p in cell.paragraphs[1:]:            # 删多段落
        p._p.getparent().remove(p._p)
    p = cell.paragraphs[0]
    clear_para(p)                            # 保留 w:pPr 样式属性，删内容
    for i, line in enumerate(str(text).split("\n")):
        if i: p.add_run().add_break(WD_BREAK.LINE)
        r = p.add_run(line)
        apply_font(r, name, size or sz, bold)
```

关键点：**只删 w:p 里除 w:pPr 之外的子节点**，这样段落样式（ZS_C标题2级、ZS_D表标题等）保留，自动编号不会丢。

### 标题自动编号

`ZS_C标题1级` / `ZS_C标题2级` 的编号（"1 "、"3.1 "）来自段落的 `w:pPr/w:numPr`。
`set_par` 只修改 run 文本，不碰 numPr，所以脚本跑完后再打开 Word，编号会自动重新计算。

### 表格行增删

模板 T3 / T4 / T5 都是 autofit，`set_rows` 按最后一行模板行 deepcopy，不够加、多了删：

```python
def set_rows(tbl, data):
    need = len(data); cur = len(tbl.rows) - 1
    while cur < need:
        tbl._tbl.append(copy.deepcopy(tbl.rows[-1]._tr)); cur += 1
    while cur > need:
        tbl._tbl.remove(tbl.rows[-1]._tr); cur -= 1
    for i, row in enumerate(data, 1):
        for c, val in enumerate(row):
            set_cell(tbl.rows[i].cells[c], val)
```

表头行 `rows[0]` 不碰；数据从 `rows[1]` 开始。

### 003 用例从 2 条扩展到 3 条

`gen_cases` 里的关键逻辑：

```python
# 1) 找到所有 TC- 开头的二级标题段落
heads = [p for p in d.paragraphs
         if p.style.name == "ZS_C标题2级" and p.text.strip().startswith("TC-")]

# 2) 找到页分隔段落（在"边界值"章前）
pb_idx = None
for i, ch in enumerate(d.element.body.iterchildren()):
    if ch.tag == qn("w:p") and 'w:type="page"' in ch.xml:
        pb_idx = i; break

# 3) deepcopy 第二块的所有元素，插到页分隔之前
if len(heads) == 2 and len(cases) == 3:
    second = heads[1]._p
    block = []
    el = second
    while el is not None and not (el.tag == qn("w:p") and 'w:type="page"' in el.xml):
        block.append(el)
        el = el.getnext()
        if el is not None and el.tag == qn("w:tbl"):
            block.append(el); el = el.getnext(); break
    for e in copy.deepcopy(block):
        d.element.body[pb_idx].addprevious(e)
```

注意 `lxml` 的 `addprevious(e1)` 把 e1 插在 ref 之前，连续多次调用会保持调用顺序——所以上述循环里先收集 block 再逐个 insert 是对的；
如果将来模板把表格放在段落之间，那个 `if el.tag == qn("w:tbl")` break 逻辑需要调整。

### 注入 updateFields

```python
def update_fields(doc):
    settings = doc.settings.element
    if settings.find(qn("w:updateFields")) is None:
        settings.append(parse_xml('<w:updateFields w:val="true"/>'))
```

settings.xml 原本没有这个元素；加在最后即可。Word 2007+ 打开时会重新计算所有域（包括 TOC）。

## 算法常量的收集套路

### 1) 测试入口 & 模式

grep `int \w+_test\s*\(` 找主入口；测试日志里每个子 TEST 的 PASS/FAIL 打印是用例期望的依据。
比如 AES 4 个子模式（ECB/CBC/CTR/GCM）、ChaCha20 6 组测试、ECC 2 个宏开关路径。
选哪 3 条进用例文档？按"覆盖广度 × 代码行数 × 功能重要性"排序，把最重要的 3 条放进去，其他放 bullets 的"未覆盖"里。

### 2) IP 基址 & CFG 位域

`#define XXX_IP_BASE 0x...` 直接抄；CFG 寄存器的 `SER_TYPE` / `KEY_LEN` / `AAD_LEN` / `TAG_LEN` / `ENCDEC` 位域写进用例描述的"寄存器协议"段落。

### 3) golden data 数组名字 & 长度

```python
import re
s = open("e203_512_data.h", encoding='utf-8').read()
for name in ['e203_512_pk', 'e203_512_sk', ...]:
    m = re.search(r'\b'+name+r'\s*\[\s*\]\s*=\s*\{', s)
    # 从首个 '{' 走到深度 0 的 '}'，数逗号 = 元素数
```

### 4) 任务描述块 / 偏移

PQC 这种是"字×8"组织（硬件按 64bit 读）；其他密码算核可能是"字×4"。直接抄 `rsp_writel(PQC0_MEM_ADDR + 4736 * 8 + 4*i, ...)` 里的偏移，别自己算。

### 5) 日志关键字

用例"预期结果"栏必须包含测试代码里实际会打印的关键字。比如：

| 算法 | 关键字 |
|------|--------|
| ECC 硬件签名 | `FINAL: ALL PASS (HW quick verify)` |
| PQC keygen | `pkpu_e203_keygen_512_test ALGO_FUN done` |
| AES | `TEST test_aes_ecb_big: ALL PASS` |
| ChaCha20 | `Result: 32 PASS, 0 FAIL` |

如果测试代码里用的是"compare faild"（d 拼错），用例里就写 `compare failed`（代码里是两种写法都有）。
**别修正代码再改用例**——要反映真实固件状态。

### 6) 典型问题 & 遗留风险

这两张表要填真实的问题，别瞎编。从代码注释、测试代码顶部的 HW PROTOCOL 段落、
设计说明书（若仓库有 .xlsx）里挖。真实问题举几个：

- AES：`AES_CFG_ENCDEC` 极性与 SM4 相反，容易写错
- PQC：MEM 偏移误按 ×4 导致全量不匹配（实际是 ×8）
- ECC：RTL 对 k=2/3 计算错误、bit14 注释与实测相反
- ChaCha20：AAD=0 时 tag 与 RFC 不同

## 校验 checklist（每次生成后跑一遍）

```python
import docx

def verify(path, algos_expected):
    d = docx.Document(path)
    txt = "\n".join(p.text for p in d.paragraphs)
    for t in d.tables:
        for r in t.rows:
            for c in r.cells: txt += "\n" + c.text

    # 1) DES 模板残留（任何新算法都不能有 DES-ECB / LCG / "AES HW IP" 这类旧词）
    old_words = ["DES-ECB KAT", "DES HARDWARE IP", "32 位 LCG", "DES-ECB KAT 标准向量"]
    hit = [w for w in old_words if w in txt]
    assert not hit, "LEFTOVER: " + str(hit)

    # 2) 空单元格（签署表、版本历史表的预留位可以空；其他不行）
    for ti, t in enumerate(d.tables):
        if ti in (1, 2): continue  # 签署/版本历史允许空
        empty = [(ri, ci) for ri, r in enumerate(t.rows)
                 for ci, c in enumerate(r.cells) if not c.text.strip()]
        assert not empty, f"T{ti} has empties: {empty}"

    # 3) 报告保留 3 张图（004 才需要检查）
    if "报告" in path:
        assert len(d.inline_shapes) >= 3, "inline shapes missing"

    # 4) 用例 3 条
    if "用例" in path:
        heads = [p for p in d.paragraphs
                 if p.style.name == "ZS_C标题2级" and p.text.strip().startswith("TC-")]
        assert len(heads) == 3, f"expected 3 case heads, got {len(heads)}"
```
