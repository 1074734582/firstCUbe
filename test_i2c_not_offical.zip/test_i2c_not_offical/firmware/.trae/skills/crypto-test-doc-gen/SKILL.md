---
name: crypto-test-doc-gen
description: Generate crypto-qualification test cases and reports from workspace templates. Use when the user asks for software qualification test cases or report for any algorithm, referencing the 003 and 004 templates in the firmware root.
---

# Crypto Test Doc Generator

基于固件仓库根目录的甲方模板 **003 软件合格性测试用例.docx** 和 **004 软件合格性测试报告.docx**，
为某个密码算法（ECC、PQC、AES、ChaCha20、SM3、SM4、RSA 等）生成两份文档——用例和报告。
本 skill 已配套脚本 `scripts/gen_tpl_docs.py`，内含 ECC / PQC / AES / ChaCha20 四套内容作为样板。

## 什么时候触发

用户说类似以下任一种即可进入本 skill：

- "以 003/004 模板，写一下 XX 算法的软件合格性测试用例/报告"
- "给 XX 算法补一套合格性测试文档"
- "参考 003 用例模板 / 004 报告模板，写 XX 的文档"
- "XX 算法的测试用例 / 测试报告"

不要在用户只想要一段算法说明、或要从零写一份不依赖模板的文档时触发。

## 模板位置与保留规则

- 模板：`<workspace>/003 软件合格性测试用例.docx`、`<workspace>/004 软件合格性测试报告.docx`
- 模板中的样式（`ZS_C标题1级`、`ZS_C标题2级`、`ZS_D表标题`、`ZS_D图标题`、Normal、toc 1/2）全部保留
- 模板自带的图片（004 报告中的连接总图 / J-Link / 串口 共 3 张）必须完整保留，
  不要覆盖它们所在段落，也不要重写图片关系
- 003 默认 2 条用例；gen_cases 会复制第 2 块用例插入分页段之前，扩展到 3 条

## 输出文件命名

- 用例：`003 软件合格性测试用例(<算法英文名>.docx)` —— 中文模板名 + 英文算法标识，如
  `003 软件合格性测试用例(AES).docx`、`003 软件合格性测试用例(chacha20).docx`
- 报告：`004 软件合格性测试报告(<算法英文名>.docx)`
- 或按用户要求的纯中文名：`<算法>软件合格性测试用例.docx` / `<算法>软件合格性测试报告.docx`

## 工作流

### 1. 扫描算法代码

用 Glob + Read 定位算法相关文件并抽取信息：

| 要找的东西 | 常见位置 |
|------------|----------|
| 测试入口函数名 | `source/app/test_<algo>.c` 的主入口 `xxx_test(void)` |
| 驱动接口签名 | `source/core/rsp_ip_<algo>.h` 的公开 API |
| IP 基址 / 寄存器 CFG 位域 | 同 .h 文件 |
| 中间件软件参考 | `source/Middleware/<algo>/xxx.c`（如 `aes.c`、`ecdsa.c`） |
| golden data 数组 | `source/app/e203/512/e203_512_data.h` 这类 |
| 算法模块行数 | 统计 .c 文件行数填入"被测软件组成"表 |
| IP 基址 | 头文件 `#define XXX_IP_BASE 0x...` |

用 Grep 搜 `int .*_test\s*\(`、`[a-zA-Z0-9_]+\s*\[\s*\]\s*=` 抽 golden 数组名字和长度，
用 `re.findall` 数逗号得出"多少 32bit 字"。

### 2. 组织内容常量

在 `scripts/gen_tpl_docs.py` 里新增一组数据，命名约定：

| 常量 | 说明 |
|------|------|
| `<algo>_overview` | 用例总览表（4~5 行，含"汇总"） |
| `<algo>_cases` | 3 条用例详情 dict 列表 |
| `<algo>_bullets` | 边界值与覆盖说明 bullet 列表 |
| `<algo>_modules` | 被测软件组成表（5~6 行） |
| `<algo>_envs` | 开发与运行环境（默认沿用 `ecc_envs`） |
| `<algo>_devices` | 设备连线表（IP 基址那行要改） |
| `<algo>_rounds` | 测试轮次表（3 行） |
| `<algo>_results` | 测试结果汇总（3~4 行，末行"汇总"） |
| `<algo>_problems` | 典型问题分析（5 行） |
| `<algo>_risks` | 遗留风险（5 行） |
| `<algo>_annex` | 附件清单（5~6 行） |
| `<algo>_compile_log` | 编译输出（多行字符串，`\n` 分隔） |
| `<algo>_run_log` | 板端运行日志（片段多行字符串） |

参考 ECC / PQC / AES / ChaCha20 已有的常量，照搬结构替换内容即可。

### 3. 在 `__main__` 里追加两次调用

```python
# 用例
gen_cases(os.path.join(ROOT, "003 软件合格性测试用例(<algo>).docx"),
          "<算法中文名> 软件合格性测试用例", "<算法缩写>-SW-TC-2026-001",
          "A", "YYYY-MM-DD", intro_para,
          <algo>_overview, <algo>_cases, <algo>_bullets)

# 报告
gen_report(os.path.join(ROOT, "004 软件合格性测试报告(<algo>).docx"),
           "<算法中文名> 软件合格性测试报告", "<算法缩写>-SW-TR-2026-001",
           "A", "YYYY-MM-DD", intro_para,
           <algo>_modules, <algo>_envs, <algo>_devices,
           plan_para, <algo>_rounds, round_note_para,
           <algo>_results, conclusion_para,
           <algo>_problems, <algo>_risks, risk_summary_para,
           <algo>_annex, <algo>_compile_log, <algo>_run_log)
```

### 4. 运行脚本生成

```
python scripts\gen_tpl_docs.py
```

成功时脚本会为每份文档打印 `OK  <路径>`。脚本内部已：

- 注入 `<w:updateFields w:val="true"/>`（让 Word 打开时自动刷新 TOC 页码）
- 调用 `shutil.copy(TPL_*, out)` 保留模板全部样式和图片
- 自动扩展 003 默认 2 条用例 → 3 条

### 5. 可选：用 Word 刷新域后另存（推荐）

如果目标环境能跑 Word COM，把生成的 docx 复制到本地临时目录（避开网络/Zone.Identifier 锁），让 Word 打开、`Fields.Update()` + `TablesOfContents().Update()` + `Repaginate()` + `Save()`，再复制回工作区。
TOC 页码只有在 Word 打开并刷新后才准确。

若 Word 打不开（报"文档可能损坏"），先确认文件路径短且 ASCII（临时目录用 `doc1.docx` 这类）再试；
若 Word 卡死在 `SaveAs2`，改用 `ExportAsFixedFormat` 只导 PDF、不回写 docx。

### 6. 生成后检查

用 python-docx 快速核验四项：

```python
d = docx.Document(path)
# 1) DES/AES/SM4 等模板残留词是否清零
# 2) tables[1]/[2]（签署/版本历史）是否空单元格在预留位即可，T3~T10 不得空
# 3) 004 报告 inline_shapes 应为 3（或 5，含连线+局部放大）
# 4) 段落 ZS_C标题2级 应以"TC-" 或 "TC-XX-" 开头，数量 == 3
```

更详尽的实现细节、常见坑和模板结构见 `references/cookbook.md`。

## 常见坑速查

| 问题 | 解决 |
|------|------|
| 生成的 docx Word 打不开 | 路径过长或含中文 + Zone.Identifier 锁。复制到 `$TEMP\chk_docx\docN.docx` 再让 Word 打开 |
| TOC 全是 DES-ECB 或其他旧标题 | 模板域未刷新。脚本已注入 `<w:updateFields w:val="true"/>`，Word 打开时会自动刷新；也可用 Word COM 主动 `Fields.Update()` |
| 表格写不进去、写进去显示旧内容 | 模板表格是 autofit（tblLayout=autofit, tblW=auto），宽由列内容撑开，`set_cell` 覆盖即可 |
| 004 报告表格索引混乱 | 报告表索引：T0 封面 / T1 签署 / T2 版本历史 / T3 被测软件组成 / T4 环境 / T5 设备 / T6 轮次 / T7 结果 / T8 典型问题 / T9 风险 / T10 附件。脚本里写死了，扩展算法时表数不变 |
| 用例扩展到 3 条失败、只看到 2 条 | 检查"页分隔段落"是否是 `w:type="page"` 的段落；若模板改版，把 `pb_idx` 查找条件改成新标识 |
| 标题自动编号被覆盖 | `ZS_C标题2级` 的编号来自 numPr，`set_par` 只替换文本、不破坏 numPr，保持编号自动更新 |
| 中文字体变 Times New Roman | `apply_font` 在每个 run 上设置了 `w:eastAsia=宋体`，不要去掉 |
| PowerShell 里 `&&` / `||` 报错 | 当前是 PowerShell 5，用分号 `;` 串联，条件判断 `if ($LASTEXITCODE -eq 0)` |
| Cygwin/MinGW Python 下 Word COM 找不到 | 必须在 Windows 原生命令行或 PowerShell 里 `python xxx.py`；COM 只在原生 CPython 上可用 |
