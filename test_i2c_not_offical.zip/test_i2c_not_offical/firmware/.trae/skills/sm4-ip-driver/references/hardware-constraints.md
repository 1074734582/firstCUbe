# SM4 IP 硬件约束清单（实测确认）

每条均在本项目硬件上实测验证。违反通常无编译错误，表现为全零输出、RSP_ERR_FIFO(-3)、TAG 不生成或验证失败。

## 寄存器与配置口径

- 基址 SM4_IP_BASE=0x80030000。STATE(0x00) / INTR(0x04) / CFG(0x08) / PKG_LEN_ALL(0x0C) / PKG_LEN_CUR(0x10) / AAD_LEN(0x14) / PKG_POS(0x18) / ENABLE(0x1C, W1SC) / IFIFO 0x20~0x9F / OFIFO 0xA0~0x11F。
- **所有模式必须配置 INTR**：PROG_FULL=7、PROG_EMPTY=1（IFIFO_PROG_FULL_THRESH/IFIFO_PROG_EMPTY_THRESH）。即使整包模式不配置硬件也可能不启动处理（XTS/CMAC/CBC-MAC/CCM/GCM 均踩过）。
- ENABLE 是 W1SC；CFG 配好 + PKG_LEN 配好后再 ENABLE，ENABLE 后流式写数据。
- 复位：先关 IP（0x1C=0），清各寄存器，FIFO 状态清零用 CFG bit28（W1SC）。
- HEADER（CFG bit[26:24]）：101=整包，001=首包，010=中间包，100=尾包。
- GCM_TAG_HEARD（CFG bit27）仅分包模式认证标签标识；**整包下设 1 会导致 TAG 错误（N=1 解密即失败）**。
- KEY_LENGTH 单位 BYTE；TAG_LEN（bit[19:16]）CCM/GCM 配 16。

## PKG_LEN 口径

**整包模式（101）—— PKG_LEN_ALL = PKG_LEN_CUR = IFIFO 总字节数（含全部头部）：**

| 模式 | 值 |
|---|---|
| ECB | 16 + len |
| CBC/CTR/CFB/OFB | 32 + len |
| XTS | 48 + len（key1+key2+TEAK+msg） |
| CMAC/CBC-MAC | 48 + in_len（key+IV+TAG+msg） |
| CCM | 64 + aad_padded + len（key+IV+MID_TAG+TAG2+AAD+msg） |
| GCM（整包） | 64 + aad_blk×16 + msg_blk×16 |

xlsx 中 PKG_LEN_ALL "只包含数据长度"、PKG_LEN_CUR "包含 KEY 跟 IV" 的描述在整包路径实测必须两者相等且为全 IFIFO 字节数。

**分段包（首/中/尾，CCM/GCM 大数据）：**

- PKG_LEN_ALL = **整个 message 总长度**（每段固定相同值，msg_blk×16）。
- PKG_LEN_CUR = **本段 IFIFO 字节数** = 64 +（首包含 AAD：aad_blk×16）+ chunk_blk×16。
- AAD_LEN：中间/尾包无 AAD 数据，但仍必须设为首包的 aad_len 值（xlsx 明确）。
- PKG_POS（仅 GCM）：本段 chunk 首块在总 message 中的序号，单位 16B，用于 CTR 计数器续接；首包为 0，中间/尾包为已发送块数。CCM 分段不设置 PKG_POS。

## IFIFO/OFIFO 访问

- 深度均为 8（8×128bit=128B）。
- 任意地址写 0x20~0x9F / 读 0xA0~0x11F 都会推入/弹出一个条目；但**必须固定 base 地址 IFIFO[0..3]/OFIFO[0..3] 访问**。索引式寻址 (blk%8)*4 会使第 9 块回绕到 slot 0 读旧数据。
- 硬件要求 INCR4 突发：ARM 用 stmia/ldmia，非 ARM 用连续 4×32bit；独立 32bit 写会拆分条目。
- 预加载阶段（ENABLE 前）用 IFIFO_FULL（真满 8）；流式阶段（ENABLE 后）用 PROG_FULL=7 提前 1 条目停写，避免标志竞态。
- **交替读防死锁**：结果数 > OFIFO 深度 8 时，OFIFO 满→硬件停消费 IFIFO→PROG_FULL 死锁。在等 IFIFO 可写期间检查 OFIFO_CNT，有数据先读出。
- CCM/GCM 交替读必须加 rd_cnt 上限（rd_cnt < blk_cnt/msg_blk），超出后读到的是 TAG，缓存进 tag_buf（tag_cached）；不加限制会把 TAG 当 result 读掉导致后续 OFIFO 超时。

## 各模式 IFIFO/OFIFO 格式

- **ECB**：in=key+msg；out=result。
- **CBC/OFB/CTR/CFB**：in=key+IV+msg；out=result。CFB 加解密用 ENCDEC 区分；OFB XOR 对称不设 ENCDEC。
- **XTS**：in=key1(16)+key2(16)+TEAK(16)+msg。**KEY_LEN 必须设 32**（两把 key 总长）；设 16 会使硬件把 key2 当 TEAK、TEAK 当 msg，PKG_LEN 不匹配、OFIFO 超时。分包时中/尾包 TEAK 字段为上一包 mid_value。out=result（+头/中包 mid_value α^j，整包/尾包无）。
- **CMAC/CBC-MAC**：in=key+IV(整包填全0)+TAG(加密任意/验证填待比MAC)+msg。out=MAC + pass/fail（全FF 通过）。共用 sm4_mac_hw_internal。
- **CCM**：in=key+IV+MID_TAG+TAG2+AAD(M×16补0)+msg。IV 必须 nonce(7-13B)+0填充+**末字节=nonce 长度**（12B nonce 时末字节 0x0C；填 0xFF 会 TAG 错误）。out=result+TAG（解密时 TAG 槽位为 pass/fail）。
- **GCM**：IFIFO 布局同 CCM；IV 为 12B nonce 补 0 到 16B（无 CCM 那种末字节长度约束）。out=result+TAG。
- AAD 一律按 16B 补 0 对齐，AAD_LEN 填真实字节数。

## GCM 整包深度硬限制（关键坑）

- 整包 HEADER=101 下，总条目（4 头部+AAD+msg）≤8 完全正常（1 块 AAD 时 N≤8）。
- 超过后即使流式写 + PROG_FULL + 交替读全部正确（N 个 result 都正确），硬件处理完也**不生成最终 TAG**：STATE=0xAA（bit1 IFIFO_EMPTY、bit5 OFIFO_EMPTY，CNT 全 0），read-tag 超时。
- 已验证无效的尝试：PKG_LEN_ALL 改 message-only、设 PKG_POS、置 GCM_TAG_HEARD（bit27 反而破坏 N=1）。
- 唯一解：首/中/尾分段包（sm4_gcm_send_seg / sm4_ccm_send_seg），每段 IFIFO≤8、OFIFO≤5，无需流式反压。
- 分段链：首包 MID_TAG/TAG2 任意填 0；中间包 MID_TAG 填上一段输出的 TAG，TAG2 任意；尾包 MID_TAG 链上一段，加密 TAG2 任意，解密 TAG2 填待验证 TAG。尾包输出：加密=最终 TAG，解密=pass/fail。
- 切分（1 块 AAD）：首包 3 块 → 中间包每段 4 块（剩余 >4 才继续中间包）→ 尾包 1~4 块。N=32=首3+7×中4+尾1。
- 入口判定 `4+aad_blk+msg_blk<=8` 走整包；`4+aad_blk>8` 的大 AAD 暂不支持（返回 RSP_ERR_INVALID_PARAM）。

## 其他教训

- 128bit 访问用固定 base 地址，不要索引式寻址。
- FIFO 清零、复位时序与 SM3 一致，禁止 BUSY/ENABLE 期间清 FIFO。
- 工程不链接 RT-Thread libc shim，只用标准 memcpy/memset/memcmp。
- 仅单编译单元使用的函数加 static inline，避免 -O0 下 undefined reference。
- 测试向量用固定 key/IV + 规律填充明文，N=1..32 全扫；MAC/AEAD 必须含篡改拒绝用例；函数返回 -1/0。
