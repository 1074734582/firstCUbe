---
name: sm4-ip-driver
description: 开发或调试本固件仓库的 SM4 硬件 IP 驱动（ECB/CBC/CFB/OFB/CTR/XTS/CMAC/CBC-MAC/CCM/GCM，含大数据流式与分段包）。当用户要求新增 SM4 模式、排查 FIFO 超时/TAG 不生成/加解密结果错误或编写 SM4 硬件对比测试时使用。不适用于纯软件 SM4 算法实现。
---

# SM4 硬件 IP 驱动开发

驱动文件 [source/core/rsp_ip_sm4.c](../../source/core/rsp_ip_sm4.c)、寄存器定义 [source/core/rsp_ip_sm4.h](../../source/core/rsp_ip_sm4.h)、数据格式权威依据 source/core 下的 sm4.xlsx（寄存器）与 sm4_输入输出数据格式.xlsx（各模式 IFIFO/OFIFO 布局），软件参考在 source/Middleware/sm4。改动前先读 rsp_ip_sm4.c 中已实现的同模式函数与 xlsx 对应行。

## 模式编码（CFG.SER_TYPE bit[7:4]）

0=ECB 1=CBC 2=CFB 3=OFB 4=CTR 5=XTS 6=CMAC 7=CBC_MAC 8=CCM 9=GCM。ENCDEC=bit0（GCM/CCM/CBC 解密或验证时置 1；OFB 加解密 XOR 对称不置位）。

## 通用驱动骨架

复位（关 IP → 清寄存器 → FIFO_STATE_CLEAR bit28 W1SC）→ 配 INTR 阈值 → 配 CFG → 配 PKG_LEN_ALL/PKG_LEN_CUR（及 AAD_LEN/PKG_POS）→ 写头部与预加载数据 → ENABLE（W1SC）→ PROG_FULL 反压流式写并交替读 OFIFO → 收尾读剩余输出。

## 动手前必读

[references/hardware-constraints.md](references/hardware-constraints.md) 含全部实测寄存器口径与模式格式。最易致命的约束：

1. **INTR 必须配置** PROG_FULL=7、PROG_EMPTY=1（每个模式、包括整包），否则硬件可能不启动。
2. **ENABLE 时序**：先 CFG+PKG_LEN，后 ENABLE，再流式写数据；预加载阶段用 IFIFO_FULL（真满 8），ENABLE 后用 PROG_FULL（阈满 7）。
3. **IFIFO/OFIFO 深度都是 8**，128bit 固定 base 地址访问（写 IFIFO[0..3]/读 OFIFO[0..3]），禁止索引式寻址（第 9 块会回绕读旧数据）。
4. **流式写必须交替读 OFIFO**：结果数 >8 时 OFIFO 填满会反压死锁；等待 IFIFO 可写期间有 OFIFO 数据就先读出，且 CCM/GCM 必须用 rd_cnt 限制防止把 TAG 当 result 读掉。
5. **PKG_LEN_ALL/PKG_LEN_CUR 口径**：ECB/CBC/CTR/XTS/CMAC/CBC-MAC/CCM 整包设为 IFIFO 总字节数（含 key/IV/头部）；GCM/CCM **分段包**口径不同（见下）。
6. **GCM 整包模式有深度硬限制**：key+IV+MID_TAG+TAG2+AAD+message 总条目 >8 时硬件不出最终 TAG（STATE=0xAA 两 FIFO 空），任何寄存器调整都无效，大数据必须分段。
7. pass/fail（CMAC/CBC-MAC/CCM/GCM 验证）：全 0xFF=通过，全 0x00=不通过。

## 大数据路径选择（CCM/GCM）

入口按 `4 + aad_blk + msg_blk <= 8` 分流（1 块 AAD 时即 msg≤3 走整包）：

- ≤8：整包 HEADER=101，预加载到 IFIFO_FULL 后 ENABLE，PROG_FULL 流式 + 交替读（CCM 用 sm4_ccm_hw_full，GCM 在 sm4_hw_process）。
- >8：首包 001（含 AAD，≤3 块）→ 中间包 010（≤4 块，MID_TAG 链接上一段 TAG）→ 尾包 100（1~4 块，解密时 TAG2 填待验 TAG）。见 sm4_ccm_send_seg / sm4_gcm_send_seg。
- CCM 与 GCM 分段唯一差异：**GCM 每段设 PKG_POS=本段首块在总 message 的块偏移（CTR 计数续接），CCM 不设 PKG_POS**。
- 禁止在整包模式设置 GCM_TAG_HEARD（CFG bit27），会导致 TAG 错误；它仅用于分包标识。

## 测试约定

- 固定 16B key、16B IV（CCM IV 为 nonce12B+3B 零+末字节 0x0C），message=N×16，N=1..32 全扫。
- AEAD/MAC 测试包含 round-trip（加密→解密逐字节对比明文）+ 篡改 TAG 必须被拒绝。
- 测试函数失败返回 -1、成功返回 0。只用标准 C 库，禁止 rt_* 变体。
