---
name: sm3-ip-driver
description: 开发或调试本固件仓库的 SM3 硬件 IP 驱动（摘要/HMAC-SM3、IFIFO/OFIFO、DMA 传输）。当用户要求新增 SM3 模式、排查 SM3 结果错误/FIFO 超时/硬件 padding 异常或编写 SM3 硬件对比测试时使用。不适用于纯软件 SM3 算法实现。
---

# SM3 硬件 IP 驱动开发

本仓库 SM3 硬件 IP 驱动位于 [source/core/rsp_ip_sm3.c](../../source/core/rsp_ip_sm3.c) 与 [source/core/rsp_ip_sm3.h](../../source/core/rsp_ip_sm3.h)，软件参考实现在 Middleware 下（sm3.h，作为硬件验证 oracle）。开始改动前先读这两个文件中已实现的同类函数。

## 驱动骨架（每个公开 API 自包含）

参数检查 → 复位 IP → 配置 CFG/PKG_LEN → ENABLE → `while(IFIFO_FULL)` 反压写数据（128bit 突发）→ 等待完成 → `while(OFIFO_EMPTY)` 读摘要 → 关闭 IP。

## 必须遵守的硬件约束

写代码前完整阅读 [references/hardware-constraints.md](references/hardware-constraints.md)，其中每条均经实测确认，违反会导致静默错误（结果错、丢数、算核卡死），编译器不报错。最关键的几条：

1. **单算模式 padding 必须用软件方案**（CFG.PADDING=SOFT）：硬件 padding 对非 64 整数倍长度有 bug；HMAC 模式例外（保持硬件 padding）。
2. **IFIFO 深度仅 8×16B=128B**：DMA 单次传输超过 128B 必丢数，必须分块（≤64B）并轮询 `IFIFO_WR_CNT[15:8]` 反压。
3. **128bit 突发访问**：IFIFO/OFIFO 必须 stmia/ldmia 或 4×32bit 连续写，禁止独立 32bit 读写。
4. **FIFO_STATE_CLEAR 是持续清零型不是脉冲**：关 IP → 写 1 → 等约 100 周期 → 写 0，禁止 ENABLE/BUSY 期间操作。
5. **非 NULL 指针要求**：即使零长度输入，SM3 IP 函数也不接受 NULL 指针；HMAC 不接受 NULL key 或 keyByteLen=0。
6. **OFIFO 读摘要固定 32B**（SM3_DIGEST_BYTE_LEN），多读会导致后续操作异常。
7. 非 16 字节对齐长度回退 CPU 流式写 IFIFO，尾条目补 0，由硬件按 PKG_LEN padding。

## 测试约定

- 测试函数失败返回 -1，成功返回 0；硬件结果与软件 sm3 实现逐字节对比。
- 不要用全 0xAA 向量（均匀字节会掩盖 IFIFO 突发写错误），用随机 16B 输入。
- 小消息函数（如 TestOnePackage）缺 IFIFO 满检查，不可用于大数据验证。
- 工程不链接 RT-Thread libc shim，只用标准库 memcpy/memset/memcmp，禁止 rt_* 变体。

## 排查顺序（结果错误时）

1. 核对 padding 路径（单算软 padding vs HMAC 硬 padding）是否用对。
2. 核对 IFIFO 写入是否 128bit 突发、DMA 是否分块反压。
3. 核对 PKG_LEN/TOTAL_LEN 是否等于 padded_len。
4. 核对复位时序，尤其 FIFO_STATE_CLEAR 后是否等够周期且 IP 已关闭。
5. 用 1B、112B、128B、129B 边界长度分别复现。
