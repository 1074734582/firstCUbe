# SM3 IP 硬件约束清单（实测确认）

以下每条均在本项目硬件上实测复现/验证，违反通常不产生编译错误，而是静默的错误摘要、丢数或算核挂死。

## PADDING

- **单算模式必须软件 padding**：CFG.PADDING=SOFT（bit5=0）。CPU 在 IFIFO 写完原始数据后追加 SM3 padding（0x80 + 全 0 + 8 字节大端 bit 长度），PKG_LEN/TOTAL_LEN 设为 padded_len（原始长度 + padding 字节数）。
- 硬件 padding 对非 64 整数倍长度有 bug：112B 输入复现，128B 正常。
- 软件 padding 连续流写入时，数据尾部不足 16 字节的残片必须与 padding 首字节 0x80 拼在**同一个 128bit 条目**内（SM3_WriteMsgPadStream）。若零填充尾条目，硬件会把填充当消息字节，流错位，1B 输入即复现。
- **HMAC 模式例外**：数据包格式 3（64B key 前缀 + message），key=64B、message=1~255 实测全部正确（含 112 这类非 64 倍数长度），因为 message 始终从 64B 分组边界开始。SM3_IP_HMAC_SM3 保持硬件 padding，不需要软件 padding。
- HMAC 软件实现遵循 RFC 2104 / GM/T 0042-2012。

## IFIFO / OFIFO

- IFIFO 深度仅 8×16B=128B。
- DMA 软握手（TT_M2M_DFC + HANDSHANKE_SOFT）不感知 FIFO 满，单次传输超过 128B 必定丢数。DMA 写 IFIFO 必须分块反压：每块 ≤64B（4 条目，一个 SM3 分组），每块发送前轮询 IFIFO_WR_CNT[15:8] 确保有足够空闲条目。DMA 通道 0 预留给 OFIFO 读（可用 SM3_OFIFO_DMA_CH 宏改）。
- 128bit 数据必须突发访问：ARM 平台用 stmia/ldmia 汇编，非 ARM 平台用连续 4×32bit 写。独立 32bit 写会拆分数据条目，导致指针错位/部分写入。
- DMA 单次传输必须 16B 对齐；1~15B 等非对齐输入回退 CPU 流式写（SM3_WriteIFIFO_Stream），尾条目补 0，由硬件按 PKG_LEN padding。
- OFIFO 读摘要必须固定 32B（SM3_DIGEST_BYTE_LEN），多读会导致后续操作异常。

## 复位与时序

- FIFO_STATE_CLEAR（CFG bit6）是 **RW 持续清零型，不是脉冲**：写 1 持续清零 FIFO 数据和 CNT，写 0 恢复。
- 正确顺序：关 IP → 写 1 → 等约 100 周期 → 写 0。禁止在 ENABLE 或 BUSY=1 期间操作，否则算核卡死（BUSY 永不撤销，超时）。
- 公开 API 自包含流程：参数检查 → 复位 → 配置 → 使能 → `while(IFIFO_FULL)` + 128bit 写 → WaitDone → `while(OFIFO_EMPTY_N)` + 128bit 读 → 关闭 IP。

## 指针与库

- SM3 IP 函数要求输入指针非 NULL，即使数据长度为 0。
- 硬件 HMAC（SM3_IP_HMAC_SM3）不支持 NULL pKey，也不支持 keyByteLen=0。
- 固件不链接 RT-Thread libc shim：只用标准 C 库 memcpy/memset/memcmp，禁止 rt_memcpy 等变体。
- 仅在单个编译单元内使用的函数必须声明 static inline；C99 纯 inline（无 static/extern）在 -O0 不内联时会产生 undefined reference。

## 测试与验证

- 测试函数返回 -1 失败、0 成功。
- 软件 SM3（sm3.h）作为硬件验证 oracle，逐字节对比摘要。
- 不要用全 0xAA 测试向量：均匀字节值会掩盖 IFIFO 写入问题；必须用随机 16B 输入验证突发写正确性。
- SM3_IP_TestOnePackage 缺 IFIFO 满检查，只适用于小消息，禁止用于大数据路径验证。
- 边界长度集：1B、112B（触发硬件 padding bug）、128B（分组边界）、129B（跨分组）。
