# SM2 硬件 IP 测试归档报告

**日期**：2026-11-17
**平台**：CRRC_RAM_MUCSE
**模块**：SM2 硬件 IP（IP base `0x80010000`）
**测试代码**：`source/app/test_sm2.c`
**寄存器定义**：`source/core/rsp_ip_sm2.h`
**对照向量**：GB/T 32918.5-2017（ID = `1234567812345678`，d/k/P/r/s/e 均为标准值）

---

## 0. 结论摘要

| 项目 | 结果 |
|---|---|
| 摘要类基础运算（KG / KP / sign(digest) / verify(digest)） | **PASS**，与标准向量逐字节一致 |
| 加解密（ENC / DEC / 长消息 128/512/1024B 往返） | **PASS** |
| 硬件“原始消息”签名/验签通路（CFG.bit14=1） | **不可用**：引擎不消费输入，无输出（硬件未实现） |
| 原始消息签名/验签（替代方案：软件 SM3 + 硬件摘要签名/验签） | **PASS**，与标准向量一致 |
| 同一上电周期内 DEC 之后再启动任何模式 | **挂死**：算核未回 idle，总线访问锁死（硬件缺陷，见第 4 节） |

当前测试套件在**一次上电周期内**可全部通过：`SM2 test done, fail=0`（共 9 个用例）。

---

## 1. 测试套件结构

每个 TEST 完全内联：自行完成寄存器配置、FIFO 读写、等待与清理，不调用公共 `sm2_hw_*` 驱动，不依赖其他用例现场。

执行顺序（`sm2_test()`）：

| 序号 | 用例 | 内容 | 关键配置 |
|---|---|---|---|
| 1 | `test_sm2_kg` | kG：d → 公钥 | `PKG_LEN=32`，`CFG=0x301`（MODE 3 KG） |
| 2 | `test_sm2_kp` | kP：k·P | `PKG_LEN=32`，`CFG=0x201`（MODE 2 KP），输入 96B |
| 3 | `test_sm2_sign` | 摘要签名 | `PKG_LEN=96`，`CFG=0x001`（MODE 0 SIGN），输入 `e+d+k` |
| 4 | `test_sm2_enc` | 加密 + 解密闭环（32B） | `PKG_LEN=32`，`CFG=0x501`（MODE 5 ENC） |
| 6 | `test_sm2_enc_dec_len` | 长消息 128/512/1024B 往返 | 同上，边写边读避免 FIFO 双满 |
| 8 | `test_sm2_verify` | 摘要验签（正向 + 篡改） | `PKG_LEN=160`，`CFG=0x101`（MODE 1 VERIFY） |
| 7 | `test_sm2_sign_msg` | 原始消息签名（替代方案） | 软件 SM3 算 ZA/e + `PKG_LEN=96` 摘要签名 |
| 9 | `test_sm2_verify_msg` | 原始消息验签（替代方案） | 软件 SM3 算 ZA/e + `PKG_LEN=160` 摘要验签 |
| 5 | `test_sm2_dec` | golden 密文解密（14B 明文） | `PKG_LEN=16`（按 16B 补零长度），`CFG=0x601`（MODE 6 DEC） |

> DEC 固定放在最后：其完成态会让算核无法再启动其他模式（见第 4 节）。

---

## 2. 关键实现约定

### 2.1 CFG 寄存器

依据寄存器规范，SM2 实际使用的位均已覆盖，无遗漏：

```
bit0      ENABLE（W1SC，写 1 启动后自清）
bit[11:8] MODE（0 签名 / 1 验签 / 2 KP / 3 KG / 5 加密 / 6 解密 / 15 SM3 ...）
bit12     INPUT_SWAP
bit13     OUTPUT_SWAP
bit14     SING_VERIFY_MODE（0 摘要，1 原始消息）
bit15     KEY_EXCHA_MODE_I
bit16     TEMP_PUBLIC_OUT_EN
bit17     KEY_AGREE_EN
```

- `ID_LEN`（bit[27:16]）在规范表中被划掉，实测写不进去，驱动不使用；原始消息模式的 ID 长度由数据流中的 `ENTL` 前缀给出。
- `bit16/17` 在本比特流中为临时公钥输出/密钥确认位，不能挪作 ID_LEN。

### 2.2 PKG_LEN 取值规律（本 RTL 实测）

| 模式 | PKG_LEN |
|---|---|
| sign / verify（摘要） | **整个输入包长度**（96 / 160），不是摘要长度 |
| sign / verify（原始消息） | 消息原始字节数（该通路不可用） |
| KG / KP | 32 |
| 加密 | 明文长度 n |
| 解密 | C2 长度；若 C2 已补零到 16B 倍数，**必须用补零后的长度**（14B 用例取 16），否则最后一条 FIFO 条目会残留 |

### 2.3 FIFO 时序

- 128bit 条目 = 16 字节，深度 8 条；写 IFIFO 需 16B 对齐。
- 等待输出时**不能在轮询循环里反复写 ENABLE**，否则会重复启动（曾导致 DEC 变成“重放 ENC”）。
- 旧驱动语义：完整等待一个输出窗口 → 若仍无输出、`got==0` 且 IFIFO 有残留，补踢一次 → 再等一个完整窗口。
- 大包必须“OFIFO 有数据就读、IFIFO 未满就继续写”，否则双向满导致死锁。

---

## 3. 原始消息签名/验签：硬件通路不可用及替代方案

### 3.1 硬件现象

按规范填写 `CFG.bit14=1`，输入按 `ENTL || ID || Px || Py || message || d || k` 组织，`PKG_LEN` 依次尝试 14 / 160 / 176，ENTL 大小端、有无 reset、逐条写与按段等待、4 段/6 段布局、补写 `ID_LEN` 均试过：

- 引擎零消费：`IFIFO_CNT` 只增不减（2→4→6→7→8），`OFIFO_CNT` 恒 0；
- 结论：**本 bitstream 未实现原始消息通路**（硬件/比特流问题，非驱动问题）。

### 3.2 替代方案（已实现并通过）

用软件 SM3 计算 `ZA` 与 `e`，再走已验证的硬件摘要签名/验签：

```
ZA = SM3(ENTL(0x0080) || ID(16B) || a || b || Gx || Gy || Px || Py)   // 210B
e  = SM3(ZA || M)                                                       // 32B
签名：硬件 MODE=0，PKG_LEN=96，输入 e(32) + d(32) + k(32)
验签：硬件 MODE=1，PKG_LEN=160，输入 e(32) + r(32) + s(32) + Px(32) + Py(32)
```

置换量（标准向量，`M = "message digest"`）：

```
ZA = B2 E1 4C 5C 79 C6 DF 5B 85 F4 FE 7E D8 DB 7A 26
     2B 9D A7 E0 7C CB 0E A9 F4 74 7B 8C CD A8 A4 F3
e  = F0 B4 3E 94 BA 45 AC CA AC E6 92 ED 53 43 82 EB
     17 E6 AB 5A 19 CE 7B 31 F4 48 6F DF C0 D2 86 40
```

- 签名输出 `r||s` 与标准向量 `V_R||V_S` 一致；
- 验签正向 `valid=1`，篡改消息（`"message digesT"`）`valid=0`；
- 软件 SM3 使用 `source/Middleware/sm3/sm3.c`（纯软件实现，不依赖 SM3 IP）。

---

## 4. DEC 完成后算核锁死（硬件缺陷）

### 4.1 现象

同一上电周期内，**只要执行过一次 DEC，之后再启动任何模式都会挂死**：

- 最后一次打印停在下一个用例的启动阶段，之后无任何输出；
- 复位（CPU 重新运行）后第一次读 `STATE` 仍正常（`0x000000AA`），但下一个用例仍挂死；
- 只有断电/整芯片复位后才能恢复。

### 4.2 逐步定位证据

在 `test_sm2_kg` 中插入 dbg1~dbg7 进度点（定位后已移除），第二遍运行结果：

```
probe STATE=0x000000AA          ← 复位后寄存器读正常
TEST 1: kg
  kg dbg1                       ← 进入用例
  kg dbg2                       ← CFG=0 / INTR=0 / PKG_LEN=0 写完成
  kg dbg3 STATE=0x000000AA      ← FIFO_STATE_CLEAR + 延时完成
  kg dbg4                       ← 排空 OFIFO 完成
  kg dbg5                       ← PKG_LEN=32 写完成
  kg dbg6                       ← CFG=KG|ENABLE 启动写返回
  kg dbg7 STATE=0x000000AA      ← 32B 输入写完成，IFIFO_CNT=0（已被消费）
（之后无输出，挂死）
```

推论：

| 观察 | 结论 |
|---|---|
| `probe`/`dbg3` 读 STATE 正常 | 寄存器读通路可用 |
| `dbg6` 启动写返回 | 启动写被接受 |
| `dbg7` 时 `IFIFO_CNT=0` | 算核已消费输入 |
| 之后不再产出、读 `STATE` 挂死 | 算核 FSM 停在非 idle 态，最终锁死总线 |
| TEST 5 结束时 `STATE=0xAA`、`IFIFO_CNT=0` | 残留不在 FIFO/寄存器层 |

### 4.3 已尝试但无效的软件手段

1. `CFG=0`、`PKG_LEN=0`、`INTR=0`；
2. `INTR.FIFO_STATE_CLEAR`；
3. `INTR.CLRER` 清中断；
4. 排空 OFIFO；
5. DEC 的 `PKG_LEN` 由 14 改为 16（消除最后一条 FIFO 条目 2B 残留，结束时 `IFIFO_CNT=0`）。

以上全部执行后，下一次启动仍然锁死，说明是算核内部状态机的硬锁存，寄存器级无法清除。

### 4.4 给 RTL/硬件的最小复现步骤

1. 上电复位；
2. 执行一次 DEC：输入 `d(32) + C1(64) + C3(32) + C2(16)`，`PKG_LEN=16`，`CFG=0x601`；
3. 读取 16B 明文（结果正确）；
4. 立即发起 KG：`PKG_LEN=32`，`CFG=0x301`，写入 `d(32)`；
5. 现象：输入被消费（`IFIFO_CNT=0`），但不产出结果，随后对 `STATE` 的访问挂死总线；
6. 只有断电/整芯片复位恢复。

### 4.5 影响与当前规避

- 影响：DEC 之后不能在同一上电周期内继续使用 SM2 IP；
- 规避：DEC 固定为套件最后一个用例；每次运行前需上电或整芯片复位；
- 彻底解决：需要 SoC 提供 SM2 模块级软复位位（复位位地址待硬件确认），或在 RTL 中修复 DEC 完成后 FSM 未回 idle 的问题。

---

## 5. 复现方式

```
# 编译烧录 current firmware（TARGET: CRRC_RAM_MUCSE），串口观察
SM2 HARDWARE IP TEST SUITE (all tests standalone)
...
SM2 test done, fail=0
```

语法自检（本机无 ARM 工具链时使用）：

```
gcc -fsyntax-only -std=gnu99 -Wall -Wextra -Werror \
    -Isource/core -Isource/app -Isource/Middleware/sm3 source/app/test_sm2.c
```

## 6. 已知限制

| 项 | 状态 |
|---|---|
| 硬件原始消息签名/验签（CFG.bit14=1） | 硬件未实现，已用“软件 SM3 + 硬件摘要”替代 |
| DEC 后同一上电周期内继续使用 | 硬件锁死，需上电/整芯片复位 |
| SM2 IP 模块级软复位 | SoC 未提供，待硬件确认 |
