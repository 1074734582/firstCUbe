import re

with open(r'z:\ccrc\test_i2c_not_offical\firmware\source\app\rsa_test_vectors.h', 'r', encoding='utf-8-sig') as f:
    src = f.read()

def extract_array(name):
    m = re.search(rf'static const uint8_t {name}\[\d+\] = \{{([^}}]+)\}};', src)
    vals = re.findall(r'0x([0-9A-Fa-f]+)', m.group(1))
    return bytes(int(v,16) for v in vals)

N = extract_array('TEST_N_256')
D = extract_array('TEST_D_256')
N_int = int.from_bytes(N, 'big')
E_int = 65537

# From FPGA run (Build Nov 17 16:24:05)
# Test A: sign_pkcs_hw (put_rev, CFG=0x501) - sig already in big-endian from driver after rev_bytes
sig_A_hex = (
    "60ACE48DB52B45D3A645EA374B1218D9"
    "BDCA70F15E51FA69AB2683C295FD0376"
    "DDB492F57C107C8E8337AE9688B21B6B"
    "BB885E876C125C7FB702CAF6871B5E84"
    "983CBDE7DB62167DA7DC8F6481299276"
    "BF4FE4A4ABFC7FA24E4AEA638E37CF96"
    "64BF9C3D72213CE6166C22B3E41C0B93"
    "C13045D7F0CB12E2DCA7BB6269107CBA"
    "73BA2E3EECBD5F8AD8CE711D1D2E3EE3"
    "F32590A520B1AB4C44344F448B41761D"
    "BB5E9D39C380597A58349FA371B67428"
    "E8873D8734869541EDD6F97B0B9E0FCF"
    "A2E4D03AED719C0FD4D78D3D9A8F33E5"
    "673F6142FB156E517D839C836B17A421"
    "86700D983BFFA97DD9BD7544E39622D6"
    "D6273FD5D255AA2FD748889350EDFE49"
)
sig_A = bytes.fromhex(sig_A_hex)

# Test B: sign_pkcs_swap_hw (memcpy, CFG=0x3501) - output NOT reversed (out_rev=0)
# Need to check... driver rsa_ip_run_ex with out_rev=0 means output is NOT reversed by software
# But the driver already printed sig head: 1B 79 48 AD 32 7B E3 4A
# Let me get sig_B from the swap_hw path - it was NOT fully printed
# Actually let me re-examine: sign_pkcs_swap_hw calls rsa_ip_run_ex(..., 0) - out_rev=0
# So the hardware output (little-endian words) was stored directly, NOT reversed
# But sign_pkcs_hw calls rsa_ip_run() which calls rsa_ip_run_ex(..., 1) - out_rev=1, reversed

# From Test B log output: "Layer4 head [0..7]: 1B 79 48 AD 32 7B E3 4A"
# Let me reconstruct... we don't have full Test B sig in logs from 16:24 run
# Wait - the 16:12 run had the SHA-256 probe section with Test B EM

# Actually, let me look at what we DO have:
# From the most recent run (ULTIMATE PROBE output), we have Test A EM recovered already
# But we want the full picture

import hashlib

msg_aa = bytes([0xAA] * 256)
golden_sha256 = hashlib.sha256(msg_aa).digest()

# Correct pkcs1v15 EM
em_correct = bytearray(256)
em_correct[0] = 0x00
em_correct[1] = 0x01
em_correct[2:203] = bytes([0xFF] * 201)
em_correct[203] = 0x00
em_correct[204:224] = bytes.fromhex('3031300D060960864801650304020105000420')
em_correct[224:256] = golden_sha256

sig_golden_int = pow(int.from_bytes(bytes(em_correct), 'big'), int.from_bytes(D, 'big'), N_int)
sig_golden = sig_golden_int.to_bytes(256, 'big')

# === Test A: recover EM from sig_A ===
EM_A_int = pow(int.from_bytes(sig_A, 'big'), E_int, N_int)
EM_A = EM_A_int.to_bytes(256, 'big')

print("=" * 70)
print("FPGA vs Golden (msg=256*0xAA)")
print("=" * 70)

def print_hex(label, data, per_line=16):
    print(f"\n{label}:")
    for i in range(0, len(data), per_line):
        chunk = data[i:i+per_line]
        print(f"  [{i:03d}] {' '.join(f'{b:02X}' for b in chunk)}")

def check_pkcs1v15(em, name):
    print(f"\n--- {name} pkcs1v15 check ---")
    print(f"  EM[0:1] = {em[0]:02X} {em[1]:02X}  (expect 00 01)  {'OK' if em[0]==0 and em[1]==1 else 'FAIL'}")
    ff_count = sum(1 for b in em[2:203] if b == 0xFF)
    print(f"  FF padding = {ff_count}/201                              {'OK' if ff_count==201 else 'FAIL'}")
    print(f"  EM[203]   = {em[203]:02X}  (expect 00)                    {'OK' if em[203]==0 else 'FAIL'}")
    tlv = bytes.fromhex('3031300D060960864801650304020105000420')
    tlv_ok = (em[204:224] == tlv)
    print(f"  TLV match = {'YES' if tlv_ok else 'NO'}")
    digest = em[224:256]
    digest_ok = (digest == golden_sha256)
    print(f"  digest match = {'YES' if digest_ok else 'NO'}")
    if not digest_ok:
        print(f"  HW    digest = {digest.hex().upper()}")
        print(f"  Golden SHA256= {golden_sha256.hex().upper()}")

print_hex("Golden Signature (expected)", sig_golden)
print_hex("Test A sig: sign_pkcs_hw (put_rev, CFG=0x501)", sig_A)
print_hex("Golden pkcs1v15 EM (expected)", bytes(em_correct))
print_hex("Test A recovered EM = modpow(sig_A, E, N)", EM_A)

check_pkcs1v15(bytes(em_correct), "Golden")
check_pkcs1v15(EM_A, "Test A")

# Now let's also check: what if sign_pkcs_swap_hw output was NOT reversed by driver?
# The driver sets out_rev=0, so OFIFO words stored directly in buffer
# Hardware outputs little-endian words...
# Actually let me just compute it properly. The full Test B sig was not printed in earlier runs.
# But wait - the previous ULTIMATE PROBE output had EM[224:256] = C48814395F5E5D1D25CCFDC5C6701ED36E7E2C2F24F45C7C202AEE886E2D104D for Test B
# Let me use that to reconstruct sig_B... or better yet, let's not guess.
# Let's just show what we HAVE (Test A recovered EM + golden) and note that both tests FAIL

print("\n" + "=" * 70)
print("KEY FINDING: HW digest comparison")
print("=" * 70)
print(f"Golden SHA256(msg=256*0xAA)  = {golden_sha256.hex().upper()}")
print(f"Test A HW EM[224:256] digest = {EM_A[224:256].hex().upper()}")
print(f"Test A HW digest == golden?   {'YES' if EM_A[224:256]==golden_sha256 else 'NO'}")
print()
print(f"Both Test A (put_rev, CFG=0x501) and Test B (memcpy, CFG=0x3501+swap) FAIL")
print(f"PADDING_EN=0 prefill path: ALL PASS (modpow block OK)")
