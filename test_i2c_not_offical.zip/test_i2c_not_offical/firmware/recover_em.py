import re, hashlib

with open(r'z:\ccrc\test_i2c_not_offical\firmware\source\app\rsa_test_vectors.h', 'r', encoding='utf-8-sig') as f:
    src = f.read()

def extract_array(name):
    m = re.search(rf'static const uint8_t {name}\[\d+\] = \{{([^}}]+)\}};', src)
    vals = re.findall(r'0x([0-9A-Fa-f]+)', m.group(1))
    return bytes(int(v,16) for v in vals)

N = extract_array('TEST_N_256')
N_int = int.from_bytes(N, 'big')
E_int = 65537

hw_ramp_hex = (
    '60ACE48DB52B45D3A645EA374B1218D9'
    'BDCA70F15E51FA69AB2683C295FD0376'
    'DDB492F57C107C8E8337AE9688B21B6B'
    'BB885E876C125C7FB702CAF6871B5E84'
    '983CBDE7DB62167DA7DC8F6481299276'
    'BF4FE4A4ABFC7FA24E4AEA638E37CF96'
    '64BF9C3D72213CE6166C22B3E41C0B93'
    'C13045D7F0CB12E2DCA7BB6269107CBA'
    '73BA2E3EECBD5F8AD8CE711D1D2E3EE3'
    'F32590A520B1AB4C44344F448B41761D'
    'BB5E9D39C380597A58349FA371B67428'
    'E8873D8734869541EDD6F97B0B9E0FCF'
    'A2E4D03AED719C0FD4D78D3D9A8F33E5'
    '673F6142FB156E517D839C836B17A421'
    '86700D983BFFA97DD9BD7544E39622D6'
    'D6273FD5D255AA2FD748889350EDFE49'
)
sig_ramp = bytes.fromhex(hw_ramp_hex)

hw_zero_hex = (
    'BF92E42B528B726F9DB3A43119C9A334'
    'B5D5FB6B7FEEB514F2A680E93ADD6297'
    'DABC0046D0FFEAD85C63D73ADE6A99A6'
    '4BF8DA63F65BF1BD6D02E3CE2B378F40'
    'F0645070A77BFB14E1BA3B097B703252'
    'A4CB57E77EB318714620CAC69BBA700C'
    '9519DE882C8E432A7B2DAB59CB0A90E4'
    'F01D5E9463025E37232A0360A6641681'
    '1E4F3946DAD8B0D50D10E4E7CA786062'
    'A6FAFE08562D2E9DB5FA2B8AE392E101'
    'CBAFC28EBC6BA256716207EEE2343023'
    'F6BCCDF8C4A14A57208FE1BCB098DBAD'
    'FFECCCD2586D56BAA806D0B91ACF1045'
    '677799D58BE4C01C2E9BF22C6C397C12'
    '853AFA4BAA5E3E69BD88BA2B180B86C3'
    '0CFAABFF7D546098CE9E6962DF288640'
)
sig_zero = bytes.fromhex(hw_zero_hex)

print('=== Step 1: Verify math on known TEST_SIG_256 ===')
TEST_SIG_256 = extract_array('TEST_SIG_256')
TEST_EM_256 = extract_array('TEST_EM_256')
EM_verify = pow(int.from_bytes(TEST_SIG_256,'big'), E_int, N_int).to_bytes(256,'big')
print(f'Math OK: EM_recover(TEST_SIG) == TEST_EM_256? {EM_verify == TEST_EM_256}')

print()
print('=== Step 2: Recover EM from HW ramp sig ===')
EM_ramp = pow(int.from_bytes(sig_ramp,'big'), E_int, N_int).to_bytes(256,'big')
print(f'EM_hw_ramp head 20B = {EM_ramp[:20].hex().upper()}')
print(f'EM_hw_ramp tail 36B = {EM_ramp[220:256].hex().upper()}')
print()
print('  Parse pkcs1v15 structure:')
print(f'    EM[0]   = 0x{EM_ramp[0]:02X} (expect 0x00)')
print(f'    EM[1]   = 0x{EM_ramp[1]:02X} (expect 0x01)')
print(f'    EM[203] = 0x{EM_ramp[203]:02X} (expect 0x00 - separator)')
print(f'    EM[204:223] = {EM_ramp[204:223].hex().upper()} (SHA256 TLV)')
print(f'    EM[224:256] = {EM_ramp[224:256].hex().upper()} <<<< HW DIGEST')

print()
print('=== Step 3: Recover EM from HW zero sig ===')
EM_zero = pow(int.from_bytes(sig_zero,'big'), E_int, N_int).to_bytes(256,'big')
print(f'EM_hw_zero head 20B = {EM_zero[:20].hex().upper()}')
print(f'EM_hw_zero tail 36B = {EM_zero[220:256].hex().upper()}')
print()
print('  Parse pkcs1v15 structure:')
print(f'    EM[0]   = 0x{EM_zero[0]:02X} (expect 0x00)')
print(f'    EM[1]   = 0x{EM_zero[1]:02X} (expect 0x01)')
print(f'    EM[203] = 0x{EM_zero[203]:02X} (expect 0x00 - separator)')
print(f'    EM[204:223] = {EM_zero[204:223].hex().upper()} (SHA256 TLV)')
print(f'    EM[224:256] = {EM_zero[224:256].hex().upper()} <<<< HW DIGEST')

print()
print('=== Step 4: Digest comparison ===')
digest_ramp = EM_ramp[224:256]
digest_zero = EM_zero[224:256]
msg = bytes(range(256))
zero_256 = b'\x00' * 256

print(f'HW ramp digest       = {digest_ramp.hex().upper()}')
print(f'Expected SHA256(ramp) = {hashlib.sha256(msg).hexdigest().upper()}')
print(f'  Match? {digest_ramp == hashlib.sha256(msg).digest()}')

print(f'HW zero digest       = {digest_zero.hex().upper()}')
print(f'Expected SHA256(zero) = {hashlib.sha256(zero_256).hexdigest().upper()}')
print(f'  Match? {digest_zero == hashlib.sha256(zero_256).digest()}')

# 现在穷举所有 byte-order 变体, 看 HW digest 到底对应哪个输入
print()
print('=== Step 5: Brute-force byte-order hypotheses ===')
def swap32(b):
    out = bytearray()
    for i in range(0, len(b), 4):
        out += b[i:i+4][::-1]
    return bytes(out)

def swap_blk(b, bs):
    out = bytearray()
    for i in range(0, len(b), bs):
        out += b[i:i+bs][::-1]
    return bytes(out)

hypotheses = [
    ('msg (raw big-endian)', msg),
    ('rev(msg)', msg[::-1]),
    ('msg swap32', swap32(msg)),
    ('rev(msg) swap32', swap32(msg[::-1])),
    ('msg swap16', swap_blk(msg, 16)),
    ('msg swap8', swap_blk(msg, 8)),
    ('msg swap32 + rev', swap32(msg)[::-1]),
    ('rev + swap32 + rev', swap32(msg[::-1])[::-1]),
]

for name, data in hypotheses:
    h = hashlib.sha256(data).digest()
    match_ramp = (h == digest_ramp)
    match_zero = (h == digest_zero)  # zero 任何 byte-order 都是 zero, 跳过
    tag_ramp = ' <<<< MATCH RAMP!' if match_ramp else ''
    print(f'  SHA256({name:30s}) = {h.hex().upper()}{tag_ramp}')

# 也试 N 的各种变体
N = extract_array('TEST_N_256')
for name, data in [('N', N), ('rev(N)', N[::-1]), ('N swap32', swap32(N)), ('rev(N) swap32', swap32(N[::-1]))]:
    h = hashlib.sha256(data).digest()
    if h == digest_ramp:
        print(f'  MATCH! SHA256({name}) == HW ramp digest!')

# 也试 D 的各种变体
D = extract_array('TEST_D_256')
for name, data in [('D', D), ('rev(D)', D[::-1]), ('D swap32', swap32(D)), ('rev(D) swap32', swap32(D[::-1]))]:
    h = hashlib.sha256(data).digest()
    if h == digest_ramp:
        print(f'  MATCH! SHA256({name}) == HW ramp digest!')
