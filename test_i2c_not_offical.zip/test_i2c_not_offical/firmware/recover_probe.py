import re, hashlib

with open(r'z:\ccrc\test_i2c_not_offical\firmware\source\app\rsa_test_vectors.h', 'r', encoding='utf-8-sig') as f:
    src = f.read()

def extract_array(name):
    m = re.search(rf'static const uint8_t {name}\[\d+\] = \{{([^}}]+)\}};', src)
    vals = re.findall(r'0x([0-9A-Fa-f]+)', m.group(1))
    return bytes(int(v,16) for v in vals)

N = extract_array('TEST_N_256')
N_int = int.from_bytes(N, 'big')
E_int = 65537

def recover_em(sig_hex, label):
    sig = bytes.fromhex(sig_hex.replace(' ',''))
    em = pow(int.from_bytes(sig,'big'), E_int, N_int).to_bytes(256,'big')
    print(f"===== {label} =====")
    print(f"  sig[0..7]: {sig[:8].hex().upper()}")
    print(f"  EM[0..1]:  {em[0]:02X} {em[1]:02X}  (expect 00 01)")
    print(f"  EM[2..203]: FF count = {sum(1 for b in em[2:204] if b==0xFF)} / 202")
    print(f"  EM[203]:   {em[203]:02X}  (expect 00)")
    print(f"  EM[204:223] = {em[204:223].hex().upper()}")
    print(f"    SHA256 TLV = 3031300D060960864801650304020105000420")
    print(f"  EM[224:256] = {em[224:256].hex().upper()} <<<< HW digest")
    print()
    # 也打印 EM 完整 dump
    print(f"  EM full dump:")
    for i in range(0, 256, 16):
        print(f"    {i:03X}: {em[i:i+16].hex().upper()}")
    print()
    return em

# ====== 0xAA pattern ======
aa_sig_hex = (
    'FFFFFFFFFFFFFFFF0100FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    'FFFFFFFFFFFFFFFF30313000FFFFFFFF650148866009060D2004000501020403'
    'A16F7B9A3DF3AFF6D871AC12FD9BC1DE80ADA7B718145960ACD88F4E34276CCD'
)
em_aa = recover_em(aa_sig_hex, "0xAA pattern")

# ====== 0x55 pattern ======
p55_sig_hex = (
    '95550E9F9D8E7A0A698516C91E73930A961B4F5F6ADCFDB9F3DC7A0C1D9137F8'
    '1B61A8EF2F255AE44F47755775BCFE3439B07D7D317755B18CD4DE779E3634EF'
    'D4FC3B6EA9F2AD6DF40F2FF6A6E91A3C99A88D2282EF5872CC5A0F8FC91A0A600'
    'D9EE4FBB1FBB81FB396217418FF04C2FF3904E4FDC943002D191D310067C0187'
    'AD4A4F4FF546D6897D5B44C47ED2E11F67A68B2D090EAB282B2ECB7F99666F3C'
    'FB775F7FC26D973EB1830B01BD01EC8B1C740BE0E24F32E8EBF1576FE9CD228'
    '391DB7F2152B49AE65314BC645E5DEA364C97EFF4D21DDC111690B5078DA787B'
    'A0406792942175661BDC7271B50A8379C38D187C8D41706E64C4A98A6966ADD3'
)
em_55 = recover_em(p55_sig_hex, "0x55 pattern")

# ====== 0xFF pattern ======
ff_sig_hex = (
    '7B6151B56C38170C89F09CB4C3EB8777FE815287E8733C75177C2416448CE355'
    '1F743065B501A67F7EE3D41A8BFE9B785ABCCB16A4D4E55EAAACE69F89005EAB'
    'AF106BA9E26EAB382CA854628CA67769A25F2B13903F3BA3B3F06BED62BAEEB5'
    '0589BDF74976F7A1EB6FF5BD305C05F16F1E4CC915B23BC6DB2C0F3415A48ADB'
    '527BBBBDFA54CB49EF334597432997CCF8F651C9BE2A12328F2FED375781B0EC'
    'DAF33CD3A3BF263B68235B5584EB46E56F9A9C0C4D47726589DA17360111ACB7'
    '721E76464404B2F365A78733C230D8C7A14771702343C4677B604C32B5CEA017'
    '7C778ACAD8920FF4AF7C24C1AF44BB7D1F90C25519AF47C3DF0290E9625BCE8A'
)
em_ff = recover_em(ff_sig_hex, "0xFF pattern")

# ====== Layer 1 ramp sig (known) ======
ramp_sig_hex = (
    '60ACE48DB52B45D3A645EA374B1218D9BDCA70F15E51FA69AB2683C295FD0376'
    'DDB492F57C107C8E8337AE9688B21B6BBB885E876C125C7FB702CAF6871B5E84'
    '983CBDE7DB62167DA7DC8F6481299276BF4FE4A4ABFC7FA24E4AEA638E37CF96'
    '64BF9C3D72213CE6166C22B3E41C0B93C13045D7F0CB12E2DCA7BB6269107CBA'
    '73BA2E3EECBD5F8AD8CE711D1D2E3EE3F32590A520B1AB4C44344F448B41761D'
    'BB5E9D39C380597A58349FA371B67428E8873D8734869541EDD6F97B0B9E0FCF'
    'A2E4D03AED719C0FD4D78D3D9A8F33E5673F6142FB156E517D839C836B17A421'
    '86700D983BFFA97DD9BD7544E39622D6D6273FD5D255AA2FD748889350EDFE49'
)
em_ramp = recover_em(ramp_sig_hex, "Layer1 ramp")

# ====== Golden digest comparison ======
print("===== Golden SHA-256 digests =====")
for p, name in [(0x00, "zero"), (0x55, "0x55"), (0xAA, "0xAA"), (0xFF, "0xFF")]:
    msg = bytes([p]*256)
    print(f"  SHA256(256*0x{p:02X}) = {hashlib.sha256(msg).hexdigest().upper()}")
print(f"  SHA256(ramp 00..FF)   = {hashlib.sha256(bytes(range(256))).hexdigest().upper()}")

# ====== CRITICAL OBSERVATION: 0xAA EM 的 TLV 区域 ======
print("\n===== EM[204:223] analysis =====")
print(f"Expected SHA256 TLV: 3031300D060960864801650304020105000420")
print(f"0xAA EM[204:223]:   {em_aa[204:223].hex().upper()}")
print(f"0x55 EM[204:223]:   {em_55[204:223].hex().upper()}")
print(f"0xFF EM[204:223]:   {em_ff[204:223].hex().upper()}")
print(f"ramp EM[204:223]:   {em_ramp[204:223].hex().upper()}")

# ====== 0xAA 的 EM 非常有价值! ======
# EM[0..1] = FF FF  (expect 00 01)
# EM[203] = 00? let me check
print(f"\n===== 0xAA EM bytes around pkcs1v15 structure =====")
# 已知 pkcs1v15 格式: 00 01 [0xFF padding 202 bytes] 00 [TLV 19B] [digest 32B]
# 0xAA EM head = FF FF ... 
# 0xAA EM tail around 204: 30313000FFFFFFFF650148866009060D2004000501020403
# 这看起来像是 SHA256 TLV 被严重 byte-swap 了!
# Correct TLV: 3031300D 060960864801650304 0201 0500 0420
# AA EM[204:223]: 30313000 FFFFFFFF 650148866009060D 20040005 0102 0403
# 让我仔细对比
correct_tlv = bytes.fromhex('3031300D060960864801650304020105000420')
aa_tlv_area = em_aa[204:223]
print(f"Correct TLV:  {correct_tlv.hex().upper()}")
print(f"AA EM[204:223]: {aa_tlv_area.hex().upper()}")

# 如果 32-bit word swap?
import struct
aa_words = struct.unpack('>5I', aa_tlv_area)
aa_le_words = struct.unpack('<5I', aa_tlv_area)
print(f"AA as 5xBE words: {[hex(w) for w in aa_words]}")
print(f"AA as 5xLE words: {[hex(w) for w in aa_le_words]}")
correct_words = struct.unpack('>5I', correct_tlv)
print(f"Correct as 5xBE words: {[hex(w) for w in correct_words]}")

# 如果把 correct TLV 按 32-bit word swap?
correct_byteswap = b''.join(correct_tlv[i:i+4][::-1] for i in range(0, 20, 4))
print(f"Correct TLV word-swapped: {correct_byteswap.hex().upper()}")
