import re, hashlib

with open(r'z:\ccrc\test_i2c_not_offical\firmware\source\app\rsa_test_vectors.h', 'r', encoding='utf-8-sig') as f:
    src = f.read()

def extract_array(name):
    m = re.search(rf'static const uint8_t {name}\[\d+\] = \{{([^}}]+)\}};', src)
    vals = re.findall(r'0x([0-9A-Fa-f]+)', m.group(1))
    return bytes(int(v,16) for v in vals)

N = extract_array('TEST_N_256')
D = extract_array('TEST_D_256')
N_int = int.from_bytes(N, 'big')
D_int = int.from_bytes(D, 'big')

msg = bytes(range(256))
msg_rev = msg[::-1]
zero = b'\x00' * 256

sig_ramp_hex = (
    '60ACE48DB52B45D3A645EA374B1218D9BDCA70F15E51FA69AB2683C295FD0376'
    'DDB492F57C107C8E8337AE9688B21B6BBB885E876C125C7FB702CAF6871B5E84'
    '983CBDE7DB62167DA7DC8F6481299276BF4FE4A4ABFC7FA24E4AEA638E37CF96'
    '64BF9C3D72213CE6166C22B3E41C0B93C13045D7F0CB12E2DCA7BB6269107CBA'
    '73BA2E3EECBD5F8AD8CE711D1D2E3EE3F32590A520B1AB4C44344F448B41761D'
    'BB5E9D39C380597A58349FA371B67428E8873D8734869541EDD6F97B0B9E0FCF'
    'A2E4D03AED719C0FD4D78D3D9A8F33E5673F6142FB156E517D839C836B17A421'
    '86700D983BFFA97DD9BD7544E39622D6D6273FD5D255AA2FD748889350EDFE49'
)
sig_zero_hex = (
    'BF92E42B528B726F9DB3A43119C9A334B5D5FB6B7FEEB514F2A680E93ADD6297'
    'DABC0046D0FFEAD85C63D73ADE6A99A64BF8DA63F65BF1BD6D02E3CE2B378F40'
    'F0645070A77BFB14E1BA3B097B703252A4CB57E77EB318714620CAC69BBA700C'
    '9519DE882C8E432A7B2DAB59CB0A90E4F01D5E9463025E37232A0360A6641681'
    '1E4F3946DAD8B0D50D10E4E7CA786062A6FAFE08562D2E9DB5FA2B8AE392E101'
    'CBAFC28EBC6BA256716207EEE2343023F6BCCDF8C4A14A57208FE1BCB098DBAD'
    'FFECCCD2586D56BAA806D0B91ACF1045677799D58BE4C01C2E9BF22C6C397C12'
    '853AFA4BAA5E3E69BD88BA2B180B86C30CFAABFF7D546098CE9E6962DF288640'
)
sig_ramp = bytes.fromhex(sig_ramp_hex)
sig_zero = bytes.fromhex(sig_zero_hex)

print("===== Direct modpow test =====")
print(f'HW ramp sig = {sig_ramp.hex()}')
print(f'HW zero sig = {sig_zero.hex()}')
print()

# Test 1: pow(msg_rev, D, N) == sig_ramp? 
s1 = pow(int.from_bytes(msg_rev,'big'), D_int, N_int).to_bytes(256,'big')
print(f'Test1 pow(msg_rev, D, N) = {s1.hex()}')
print(f'  Match HW ramp? {s1 == sig_ramp}')
print(f'  Head: {s1[:8].hex()} (HW: {sig_ramp[:8].hex()})')

# Test 2: pow(msg, D, N)
s2 = pow(int.from_bytes(msg,'big'), D_int, N_int).to_bytes(256,'big')
print(f'Test2 pow(msg, D, N) = {s2.hex()}')
print(f'  Match HW ramp? {s2 == sig_ramp}')

# Test 3: pow(zero_rev, D, N) = pow(zero, D, N)
s3 = pow(int.from_bytes(zero,'big'), D_int, N_int).to_bytes(256,'big')
print(f'Test3 pow(zero, D, N) = {s3.hex()}')
print(f'  Match HW zero? {s3 == sig_zero}')

# Test 4: pow(msg_rev, E, N) -> should recover msg_rev (since sig = msg_rev^D, sig^E = msg_rev)
# 但我们已经验签恢复了 EM, EM ≠ msg_rev
# 让我看看 EM 是不是 N_rev^something...

# 换个思路: 硬件 SHA-256 块输出 diget, padding 块加了某种非标准 padding
# 或者... hardware CFG.PADDING_EN 其实是 0 但我们以为是 1?
# 不对, 我们设了 CFG=0x0500, bit8 是 PADDING_EN

# 等等, 让我看硬件 CFG 是不是我理解的那样
# rsa_ip_rsa.c 里 rsa_ip_cfg_set() 写的是什么

print("\n===== NIST test: 是不是 SHA-256 块本身坏了? =====")
# 如果 SHA-256 块正确, padding 块有 bug, 那至少 SHA-256(msg) 应该在 EM 的某处能找到
# 但我找不到... 让我试 SHA-256(msg) + 某种错误 padding

# 比如 padding 块只加了 00 01, 没加 0xFF padding 和 separator 和 TLV
em_bug1 = bytearray(256)
em_bug1[0] = 0x00; em_bug1[1] = 0x01
em_bug1[224:256] = hashlib.sha256(msg).digest()
s_bug1 = pow(int.from_bytes(bytes(em_bug1),'big'), D_int, N_int).to_bytes(256,'big')
print(f'Bug padding (00 01 + digest): {s_bug1[:8].hex()} (HW: {sig_ramp[:8].hex()})')

# 只有 00 开头, 没有 01
em_bug2 = bytearray(256)
em_bug2[0] = 0x00
em_bug2[224:256] = hashlib.sha256(msg).digest()
s_bug2 = pow(int.from_bytes(bytes(em_bug2),'big'), D_int, N_int).to_bytes(256,'big')
print(f'Bug padding (00 + digest): {s_bug2[:8].hex()}')

# 完全没有 padding, SHA-256 块输出直接当 EM
em_bug3 = bytearray(256)
em_bug3[224:256] = hashlib.sha256(msg).digest()
s_bug3 = pow(int.from_bytes(bytes(em_bug3),'big'), D_int, N_int).to_bytes(256,'big')
print(f'No padding (digest@224): {s_bug3[:8].hex()}')

print("\n===== 让我看 HW EM 整体反转后 ===")
EM_ramp = pow(int.from_bytes(sig_ramp,'big'), 65537, N_int).to_bytes(256,'big')
EM_zero = pow(int.from_bytes(sig_zero,'big'), 65537, N_int).to_bytes(256,'big')

print(f'EM_ramp_rev[0..1] = {EM_ramp[::-1][0]:02X} {EM_ramp[::-1][1]:02X}')
print(f'EM_ramp_rev[254..255] = {EM_ramp[::-1][254]:02X} {EM_ramp[::-1][255]:02X}')

# 等等! 让我换个角度
# 如果 PADDING_EN=1 时, 硬件期望的 IFIFO 布局变了?
# 比如: 只有 N 和 msg, 没有 D? 那 modpow 会坏
# 或者 N 在另一个位置?

# 让我看看有没有可能硬件 SHA-256 块处理的是 PKG_LEN=256 字节
# 但取的是 IFIFO offset 0 处的数据 (N_rev)
# 然后 padding 块把它拼成 pkcs1v15
# 然后 modpow((N_rev 的 pkcs1v15), D, N)
# 这个之前测过了, 不匹配

# 让我看看 PADDING_EN=1 时 modpow 是不是可能用了不同的指数?
# 比如硬件内部自动选了 E? 那就是 verify 不是 sign

# 如果硬件 PADDING_EN=1 其实走的是 verify 路径 (用 E 而不是 D)?
# pow(EM, E, N) 不应该是 sig... 但让我试 pow(EM, E, N) == sig?

# 不对, EM_ramp = pow(sig_ramp, E, N), 所以 pow(EM_ramp, D, N) 一定 = sig_ramp
# 数学上是对的

print("\n===== 如果 modpow 块用 E=65537 而不是 D? =====")
s_verify = pow(int.from_bytes(EM_ramp,'big'), 65537, N_int).to_bytes(256,'big')
print(f'pow(EM_ramp, E, N) = {s_verify.hex()}')
print(f'  == sig_ramp? {s_verify == sig_ramp}')
# 这应该就是 sig_ramp 本身, 因为 EM_ramp = sig_ramp^E

# 让我看看 HW EM 有没有可能是 PSS 格式
# PSS 格式是随机掩码 + salt + digest + trailer

print("\n===== PSS hypothesis =====")
# PSS trailer 固定是 0xBC
# 如果是 PSS, EM 最后一个字节应该是 0xBC
print(f'EM_ramp[255] = 0x{EM_ramp[255]:02X} (PSS expect 0xBC)')
print(f'EM_zero[255] = 0x{EM_zero[255]:02X} (PSS expect 0xBC)')

# 如果硬件 PADDING_MODE 不是我们设的 0, 而是被错误设成了 1?
# 那我们得生成 PSS EM 再算 pow(EM, D, N)
# 但先确认 CFG 里 PADDING_MODE 是不是确实为 0

print("\n===== 让我直接对比: 正确的 TEST_EM_256 vs HW EM =====")
TEST_EM_256 = extract_array('TEST_EM_256')
print(f'TEST_EM_256[0..1] = {TEST_EM_256[0]:02X} {TEST_EM_256[1]:02X}')
print(f'EM_ramp[0..1]     = {EM_ramp[0]:02X} {EM_ramp[1]:02X}')
print()

# 我有个疯狂的想法: 
# 也许硬件 CFG bit8 不是 PADDING_EN, bit9 才是!
# 或者 bit8 是 PADDING_MODE, bit9 是 PADDING_EN!

# 如果我们把 bit9 (不是 bit8) 设成 PADDING_EN=1
# 或者 CFG = 0x0600 (bit9 + bit10)?

# 等等, 让我查 rsa_cfg 的具体 bit 定义
print("===== Done =====")
