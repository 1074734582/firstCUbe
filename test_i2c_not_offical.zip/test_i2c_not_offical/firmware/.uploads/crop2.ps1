Add-Type -AssemblyName System.Drawing
$srcPath = 'c:\Users\2304026\AppData\Roaming\Trae CN\User\workspaceStorage\1822bf66f246c2b73f3a88095cd6cfe8\paste-files\eeee6070-7fb9-44c2-a804-2e5ad000e359_image.png'
$src = [System.Drawing.Image]::FromFile($srcPath)
Write-Output ("size: {0}x{1}" -f $src.Width, $src.Height)
function CropScale($src, $x, $y, $w, $h, $scale, $out) {
    $rect = New-Object System.Drawing.Rectangle -ArgumentList ([int]$x), ([int]$y), ([int]$w), ([int]$h)
    $bw = [int]($w * $scale); $bh = [int]($h * $scale)
    $bmp = New-Object System.Drawing.Bitmap -ArgumentList $bw, $bh
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
    $dest = New-Object System.Drawing.Rectangle -ArgumentList 0, 0, $bw, $bh
    $g.DrawImage($src, $dest, $rect, [System.Drawing.GraphicsUnit]::Pixel)
    $bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose(); $bmp.Dispose()
}
$base = 'z:\ccrc\test_i2c_not_offical\firmware\.uploads\'
CropScale $src ($src.Width * 0.63) 0 ($src.Width * 0.37) $src.Height 3 ($base + 'gdb.png')
CropScale $src ($src.Width * 0.20) 0 ($src.Width * 0.43) $src.Height 3 ($base + 'serial.png')
$src.Dispose()
