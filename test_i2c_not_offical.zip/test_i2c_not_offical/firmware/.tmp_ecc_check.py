"""Verify the ECC test vectors offline and find byte-order convention."""
from tinyec import registry
from tinyec.ec import Point, SubGroup
import hashlib

curve = registry.get_curve('secp256r1')
G = curve.g
n = curve.field.n

msg = bytes(range(0x00, 0xFF+1, 1))[:32]  # 00 11 22 33 ... ee ff (doubled pattern 16x2=32)
# Actually from test_ecc.c it's a repeated pattern: 00 11 22 ... ff * 2
msg = bytes([i % 256 for i in range(0, 256, 16)]) * 2  # but that gives 2 cycles of 16 = 32
# Let me just read directly
msg = bytes([0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff,
             0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff])
d   = bytes([0x12,0x34,0x56,0x78,0x90,0xab,0xcd,0xef,0x12,0x34,0x56,0x78,0x90,0xab,0xcd,0xef,
             0x12,0x34,0x56,0x78,0x90,0xab,0xcd,0xef,0x12,0x34,0x56,0x78,0x90,0xab,0xcd,0xef])
k   = bytes([0xfe,0xdc,0xba,0x09,0x87,0x65,0x43,0x21,0xfe,0xdc,0xba,0x09,0x87,0x65,0x43,0x21,
             0xfe,0xdc,0xba,0x09,0x87,0x65,0x43,0x21,0xfe,0xdc,0xba,0x09,0x87,0x65,0x43,0x21])
exp_r = bytes.fromhex("58893cc65cc5c0da46a14c5a42878d877003623cdceec62cb9a9069fa2c02ea4")
exp_s = bytes.fromhex("87d4570cb12a0426b94b7dee35601fc301cdea329a7767541b6c6911927a2439")
exp_qx = bytes.fromhex("471c3e758c4904285bba7e53118ed0f524adeb0757d25bd2f8e7b0d76dfa714c")
exp_qy = bytes.fromhex("dd520f7aca8a8b917acc37f51de8f0c9bbe3ad858382e702dc25a12d09f7a858")

# 1. Verify keygen Q
D = int.from_bytes(d, "big")
Q = D * G
assert Q.x.to_bytes(32, "big") == exp_qx, f"Qx mismatch: Q={Q.x.to_bytes(32,'big').hex()}"
assert Q.y.to_bytes(32, "big") == exp_qy, f"Qy mismatch: Q={Q.y.to_bytes(32,'big').hex()}"
print("Vector Q OK")

# 2. Verify sign
z = int.from_bytes(msg, "big")
K = int.from_bytes(k, "big")
R = (K * G).x % n
S = pow(K, -1, n) * (z + R * D) % n
assert R.to_bytes(32,"big") == exp_r, f"R mismatch: {R.to_bytes(32,'big').hex()}"
assert S.to_bytes(32,"big") == exp_s, f"S mismatch: {S.to_bytes(32,'big').hex()}"
print("Vector sign OK")

# 3. Now try all byte-order variants for d/k/msg and see if hw values match
hw_r = bytes.fromhex("3ee7da24e53d9ad32506e87dbf3bb5c5b33b910e510b0eb7fb2a03bb27b58900")
hw_s = bytes.fromhex("52f1d41b1ecee4bde3a55594a8fb63008daf543f94c34aaeaa299841f39d2ba0")
hw_qx = bytes.fromhex("aad83260c08a156dce611b3cdfce17076f28fc663c8a5f74b82e910595e2d6b5")
hw_qy = bytes.fromhex("0ee52add3b9ab0387e96efb2ccfae6da6b81128990b1a142c2bfc26119801766")

def rev(b): return b[::-1]
def rev8(b):
    o = bytearray()
    for i in range(0, len(b), 8):
        o += b[i:i+8][::-1]
    return bytes(o)
def rev32(b):
    o = bytearray()
    for i in range(0, len(b), 4):
        o += b[i:i+4][::-1]
    return bytes(o)

# Keygen: hw_Q = scalar * G, scalar in some byte order
for name, df in [("plain", lambda x: x), ("rev", rev), ("rev32", rev32), ("rev8", rev8)]:
    scalar = int.from_bytes(df(d), "big")
    try:
        Qh = scalar * G
        if Qh.x.to_bytes(32,"big") == hw_qx and Qh.y.to_bytes(32,"big") == hw_qy:
            print(f"KEYGEN MATCH d_order={name}")
        if Qh.x.to_bytes(32,"big") == hw_qx: print(f"KEYGEN Qx match d_order={name}")
    except Exception as e:
        pass

# Sign: try all 4^3 = 64 combos of d,k,msg byte orders
orders = [("plain", lambda x: x), ("rev", rev), ("rev32", rev32), ("rev8", rev8)]
for dn, df in orders:
  for kn, kf in orders:
    for mn, mf in orders:
        Dv = int.from_bytes(df(d), "big")
        Kv = int.from_bytes(kf(k), "big")
        zv = int.from_bytes(mf(msg), "big")
        Rv = (Kv * G).x % n
        Sv = pow(Kv, -1, n) * (zv + Rv * Dv) % n
        if Rv.to_bytes(32,"big") == hw_r and Sv.to_bytes(32,"big") == hw_s:
            print(f"SIGN MATCH d={dn} k={kn} msg={mn}")
            break
    else: continue
    break
else:
    print("No sign order match found")
