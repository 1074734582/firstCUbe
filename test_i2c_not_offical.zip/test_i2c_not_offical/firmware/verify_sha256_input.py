import re, hashlib, struct

with open(r'z:\ccrc\test_i2c_not_offical\firmware\source\app\rsa_test_vectors.h', 'r', encoding='utf-8-sig') as f:
    src = f.read()

def extract_array(name):
    m = re.search(rf'static const uint8_t {name}\[\d+\] = \{{([^}}]+)\}};', src)
    vals = re.findall(r'0x([0-9A-Fa-f]+)', m.group(1))
    return bytes(int(v,16) for v in vals)

N = extract_array('TEST_N_256')
D = extract_array('TEST_D_256')
E_int = 65537

# msg patterns
msg_aa = bytes([0xAA]*256)
msg_00 = bytes([0x00]*256)
msg_ramp = bytes(range(256))

# HW digest recovered from Test B EM[224:256]
HW_DIGEST_TESTB = bytes.fromhex('C48814395F5E5D1D25CCFDC5C6701ED36E7E2C2F24F45C7C202AEE886E2D104D')
# HW digest from Test A EM[224:256] (from previous ULTIMATE PROBE output)
HW_DIGEST_TESTA = bytes.fromhex('AEEF2ABA2DE5A906321F723F58044FA502991A16A0A3CF5BDBF9E91731AEA668')

# === Compute SHA256 of various inputs ===
def check(label, data, hw_digest, hw_name):
    d = hashlib.sha256(data).digest()
    match = (d == hw_digest)
    print(f"  SHA256({label}) = {d.hex().upper()}  [{hw_name}]  {'MATCH!' if match else 'no'}")
    return match

print("=" * 70)
print("SHA256 of various inputs vs HW digests")
print("=" * 70)

for hw_name, hw_digest in [("Test B swap", HW_DIGEST_TESTB), ("Test A legacy", HW_DIGEST_TESTA)]:
    print(f"\n--- vs HW digest [{hw_name}] ---")
    print(f"  HW digest = {hw_digest.hex().upper()}")
    found = False

    # Basic candidates
    if check("msg_aa (raw BE)", msg_aa, hw_digest, hw_name): found = True
    if check("msg_00 (raw BE)", msg_00, hw_digest, hw_name): found = True
    if check("N (raw BE)", N, hw_digest, hw_name): found = True
    if check("D (raw BE)", D, hw_digest, hw_name): found = True

    # Combined candidates
    if check("N || D", N + D, hw_digest, hw_name): found = True
    if check("N || D || msg_aa", N + D + msg_aa, hw_digest, hw_name): found = True
    if check("D || msg_aa", D + msg_aa, hw_digest, hw_name): found = True
    if check("msg_aa || N", msg_aa + N, hw_digest, hw_name): found = True
    if check("msg_aa || D", msg_aa + D, hw_digest, hw_name): found = True

    # Reversed byte order candidates (little-endian)
    N_le = N[::-1]
    D_le = D[::-1]
    msg_aa_le = msg_aa[::-1]
    if check("msg_aa (rev LE)", msg_aa_le, hw_digest, hw_name): found = True
    if check("N (rev LE)", N_le, hw_digest, hw_name): found = True
    if check("D (rev LE)", D_le, hw_digest, hw_name): found = True
    if check("N_le || D_le || msg_aa_le", N_le + D_le + msg_aa_le, hw_digest, hw_name): found = True

    # What if SHA256 takes a specific offset from IFIFO buffer?
    # IFIFO layout = N[256] || D[256] || msg[256] = 768 bytes
    # Hardware might take wrong offset
    if check("IFIFO[256:512] = D (but SHA-256 takes as 'msg')", D, hw_digest, hw_name): found = True
    if check("IFIFO[0:256] = N (but SHA-256 takes as 'msg')", N, hw_digest, hw_name): found = True

    # What if SHA-256 input is only PKG_LEN bytes from some offset?
    # PKG_LEN = 256
    # What if offset is wrong? e.g., starts at 256 instead of 512
    if check("D only (offset 256, PKG_LEN=256)", D, hw_digest, hw_name): found = True
    if check("IFIFO[256:512] + IFIFO[0:0] (wrong)", D, hw_digest, hw_name): found = True

    # What if SHA-256 is word-swapped (32-bit word byte-swap)?
    def wordswap32(b):
        out = bytearray()
        for i in range(0, len(b), 4):
            out += b[i:i+4][::-1]
        return bytes(out)
    if check("msg_aa word-swapped", wordswap32(msg_aa), hw_digest, hw_name): found = True
    if check("N word-swapped", wordswap32(N), hw_digest, hw_name): found = True

    # N/D only first 64 bytes? SHA-256 block size = 64B
    if check("N[0:64] first block", N[0:64], hw_digest, hw_name): found = True
    if check("D[0:64] first block", D[0:64], hw_digest, hw_name): found = True

    # msg but only first 64 bytes?
    if check("msg_aa[0:64] only", msg_aa[0:64], hw_digest, hw_name): found = True

    # Maybe SHA256(N || msg) ?
    if check("N || msg_aa", N + msg_aa, hw_digest, hw_name): found = True
    if check("msg_aa || N[0:256]", msg_aa + N, hw_digest, hw_name): found = True

    print(f"  => FOUND MATCH: {found}")

# === Also print golden values for reference ===
print("\n" + "=" * 70)
print("Golden SHA256 values (reference)")
print("=" * 70)
for label, data in [("msg_aa 256*0xAA", msg_aa), ("msg_00 256*0x00", msg_00),
                     ("msg_ramp 00..FF", msg_ramp), ("N (BE)", N), ("D (BE)", D)]:
    print(f"  SHA256({label}) = {hashlib.sha256(data).hexdigest().upper()}")
