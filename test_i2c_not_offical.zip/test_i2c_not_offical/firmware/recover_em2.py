import re, hashlib

with open(r'z:\ccrc\test_i2c_not_offical\firmware\source\app\rsa_test_vectors.h', 'r', encoding='utf-8-sig') as f:
    src = f.read()

def extract_array(name):
    m = re.search(rf'static const uint8_t {name}\[\d+\] = \{{([^}}]+)\}};', src)
    vals = re.findall(r'0x([0-9A-Fa-f]+)', m.group(1))
    return bytes(int(v,16) for v in vals)

N = extract_array('TEST_N_256')
D = extract_array('TEST_D_256')
msg = bytes(range(256))          # 0x00..0xFF big-endian (原始大端)
msg_rev = msg[::-1]              # 0xFF..0x00 (小端反转)
zero = b'\x00' * 256

N_int = int.from_bytes(N, 'big')
E_int = 65537

# IFIFO 实际布局 (驱动 put_rev 后的内容)
# offset 0..255  -> N_rev  (N 小端反转)
# offset 256..511 -> D_rev  (D 小端反转)
# offset 512..767 -> msg_rev (msg 小端反转)

def swap32(b):
    out = bytearray()
    for i in range(0, len(b), 4):
        out += b[i:i+4][::-1]
    return bytes(out)

# ====== 恢复的 HW EM 和 digest ======
hw_ramp_hex = (
    '60ACE48DB52B45D3A645EA374B1218D9BDCA70F15E51FA69AB2683C295FD0376'
    'DDB492F57C107C8E8337AE9688B21B6BBB885E876C125C7FB702CAF6871B5E84'
    '983CBDE7DB62167DA7DC8F6481299276BF4FE4A4ABFC7FA24E4AEA638E37CF96'
    '64BF9C3D72213CE6166C22B3E41C0B93C13045D7F0CB12E2DCA7BB6269107CBA'
    '73BA2E3EECBD5F8AD8CE711D1D2E3EE3F32590A520B1AB4C44344F448B41761D'
    'BB5E9D39C380597A58349FA371B67428E8873D8734869541EDD6F97B0B9E0FCF'
    'A2E4D03AED719C0FD4D78D3D9A8F33E5673F6142FB156E517D839C836B17A421'
    '86700D983BFFA97DD9BD7544E39622D6D6273FD5D255AA2FD748889350EDFE49'
)
sig_ramp = bytes.fromhex(hw_ramp_hex)
EM_ramp = pow(int.from_bytes(sig_ramp,'big'), E_int, N_int).to_bytes(256,'big')

hw_zero_hex = (
    'BF92E42B528B726F9DB3A43119C9A334B5D5FB6B7FEEB514F2A680E93ADD6297'
    'DABC0046D0FFEAD85C63D73ADE6A99A64BF8DA63F65BF1BD6D02E3CE2B378F40'
    'F0645070A77BFB14E1BA3B097B703252A4CB57E77EB318714620CAC69BBA700C'
    '9519DE882C8E432A7B2DAB59CB0A90E4F01D5E9463025E37232A0360A6641681'
    '1E4F3946DAD8B0D50D10E4E7CA786062A6FAFE08562D2E9DB5FA2B8AE392E101'
    'CBAFC28EBC6BA256716207EEE2343023F6BCCDF8C4A14A57208FE1BCB098DBAD'
    'FFECCCD2586D56BAA806D0B91ACF1045677799D58BE4C01C2E9BF22C6C397C12'
    '853AFA4BAA5E3E69BD88BA2B180B86C30CFAABFF7D546098CE9E6962DF288640'
)
sig_zero = bytes.fromhex(hw_zero_hex)
EM_zero = pow(int.from_bytes(sig_zero,'big'), E_int, N_int).to_bytes(256,'big')

print("===== HW EM Analysis =====")
print(f"EM_ramp[0..31] = {EM_ramp[:32].hex().upper()}")
print(f"EM_ramp[32..63] = {EM_ramp[32:64].hex().upper()}")
print(f"EM_zero[0..31] = {EM_zero[:32].hex().upper()}")
print(f"EM_zero[32..63] = {EM_zero[32:64].hex().upper()}")

# 关键观察: EM_ramp 和 EM_zero 的前几个字节完全不同, 说明 SHA-256 块确实处理了不同的输入
# 但它们都不是 pkcs1v15 格式 -> padding 块有问题

# 我注意到 EM_ramp[0..15]  = 05889F90B2B6B1B737E1441438E4594F6
# 也许硬件 SHA-256 块输出的是一个 32B digest, 然后 padding 块把它放到了 EM 的某个位置,
# 但没有加 pkcs1v15 的 TLV 和 padding 字节?

# 让我穷举: 假设 SHA-256 块的输入是 IFIFO 的某个 256B 窗口,
# 那它输出的 digest 就是 HW 某个地方的 32B.
# 如果 padding 块有 bug 只是 raw digest, 那 EM 的某个 32B 窗口应该匹配某个 SHA-256 digest.

# 让我穷举所有可能的 SHA-256 输入 + 所有可能的 EM 位置, 看能不能匹配
print("\n===== Brute force: SHA-256 input + EM position =====")

# 所有可能的 SHA-256 输入 (256B blocks)
inputs = {
    'msg (big-endian)': msg,
    'msg_rev (LE in IFIFO)': msg_rev,
    'msg swap32': swap32(msg),
    'msg_rev swap32': swap32(msg_rev),
    'N': N,
    'N_rev': N[::-1],
    'N swap32': swap32(N),
    'N_rev swap32': swap32(N[::-1]),
    'D': D,
    'D_rev': D[::-1],
    'zero': zero,
    'zero swap32': swap32(zero),
}

# 计算所有输入的 digest
digests = {}
for name, data in inputs.items():
    digests[name] = hashlib.sha256(data).digest()

# 在 EM_ramp 的每个 32B 窗口里找是否匹配某个 digest
print("\nEM_ramp: find SHA-256 digest at each offset (256B total):")
for offset in range(0, 225, 16):  # 32B windows at 16B granularity
    window = EM_ramp[offset:offset+32]
    for name, d in digests.items():
        if window == d:
            print(f"  OFFSET {offset:3d}: MATCH! EM_ramp[{offset}:{offset+32}] == SHA256({name})")

print("\nEM_zero: find SHA-256 digest at each offset:")
for offset in range(0, 225, 16):
    window = EM_zero[offset:offset+32]
    for name, d in digests.items():
        if window == d:
            print(f"  OFFSET {offset:3d}: MATCH! EM_zero[{offset}:{offset+32}] == SHA256({name})")

# 如果没找到, 也试 EM 整体反转后的窗口
print("\nEM_ramp_rev (整体反转) + 32B 窗口:")
EM_ramp_rev = EM_ramp[::-1]
for offset in range(0, 225, 16):
    window = EM_ramp_rev[offset:offset+32]
    for name, d in digests.items():
        if window == d:
            print(f"  OFFSET {offset:3d}: MATCH! rev(EM_ramp)[{offset}:{offset+32}] == SHA256({name})")

print("\nEM_zero_rev + 32B 窗口:")
EM_zero_rev = EM_zero[::-1]
for offset in range(0, 225, 16):
    window = EM_zero_rev[offset:offset+32]
    for name, d in digests.items():
        if window == d:
            print(f"  OFFSET {offset:3d}: MATCH! rev(EM_zero)[{offset}:{offset+32}] == SHA256({name})")

# 也试: SHA-256 输入不是 256B, 而是 msg_len 字节 (任意长度)?
# 内部 padding 通路 PKG_LEN=msg_len=256, 所以硬件 SHA-256 应该处理 256B
# 但如果 SHA-256 块从 IFIFO 取的不是完整 256B, 而是部分数据...?

print("\n===== More inputs: shorter msg (like original TEST_MSGRAW_0 = 23B) =====")
msg0 = b'Hello RSA2048 Hardware!'  # 23B
for name, data in [
    ('msg0 23B', msg0),
    ('msg0 rev', msg0[::-1]),
    ('msg0 rev + pad_zero to 256', (msg0[::-1] + b'\x00'*233)),
]:
    d = hashlib.sha256(data).digest()
    for offset in range(0, 225, 16):
        if EM_ramp[offset:offset+32] == d:
            print(f"  EM_ramp offset {offset}: SHA256({name})")
        if EM_zero[offset:offset+32] == d:
            print(f"  EM_zero offset {offset}: SHA256({name})")
