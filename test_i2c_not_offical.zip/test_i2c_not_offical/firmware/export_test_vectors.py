import re

with open(r'z:\ccrc\test_i2c_not_offical\firmware\source\app\rsa_test_vectors.h', 'r', encoding='utf-8-sig') as f:
    src = f.read()

def extract_array(name):
    m = re.search(rf'static const uint8_t {name}\[\d+\] = \{{([^}}]+)\}};', src)
    vals = re.findall(r'0x([0-9A-Fa-f]+)', m.group(1))
    return bytes(int(v,16) for v in vals)

def print_hex_block(label, data, per_line=16):
    print(f"\n// ===== {label} ({len(data)} bytes, BIG-ENDIAN) =====")
    for i in range(0, len(data), per_line):
        chunk = data[i:i+per_line]
        hex_str = ' '.join(f'{b:02X}' for b in chunk)
        print(f'  // [{i:03d}] {hex_str}')

N = extract_array('TEST_N_256')
D = extract_array('TEST_D_256')
E_int = 65537
E = E_int.to_bytes(256, 'big')

msg_aa = bytes([0xAA] * 256)

print("=" * 70)
print("RSA2048 PADDING_EN=1 Test Vectors (for HW colleague)")
print("=" * 70)
print(f"E (public exponent) = {E_int} = 0x{E_int:X}")
print(f"E (256B BE)         = {E_int:064X}")

print_hex_block("N (modulus, 256B BE)", N)
print_hex_block("D (private exponent, 256B BE)", D)
print_hex_block("msg = 256 * 0xAA", msg_aa)

print(f"\n// IFIFO layout: N[256] || D[256] || msg[256] = 768 bytes")
print(f"// PKG_LEN = msg_len = 256")
print(f"// CFG = SIGN_EN(bit10) | PADDING_EN(bit8) | ENABLE(bit0) = 0x00000501")
print(f"//       or with swap: + INPUT_SWAP(bit12) | OUTPUT_SWAP(bit13) = 0x00003501")

print("\n" + "=" * 70)
print("Expected golden values (software reference)")
print("=" * 70)

import hashlib
golden_sha256 = hashlib.sha256(msg_aa).hexdigest().upper()
print(f"SHA256(256*0xAA) = {golden_sha256}")
print(f"SHA256 TLV       = 3031300D060960864801650304020105000420")

# Correct pkcs1v15 EM
em = bytearray(256)
em[0] = 0x00
em[1] = 0x01
em[2:203] = bytes([0xFF] * 201)
em[203] = 0x00
em[204:224] = bytes.fromhex('3031300D060960864801650304020105000420')
em[224:256] = bytes.fromhex(golden_sha256)
print_hex_block("Correct pkcs1v15 EM (modpow input, 256B BE)", bytes(em))

# Now compute expected signature: sig = modpow(EM, D, N)
N_int = int.from_bytes(N, 'big')
D_int = int.from_bytes(D, 'big')
EM_int = int.from_bytes(bytes(em), 'big')
sig_int = pow(EM_int, D_int, N_int)
sig = sig_int.to_bytes(256, 'big')
print_hex_block("Expected golden signature (modpow(EM, D, N), 256B BE)", sig)

print("\n" + "=" * 70)
print("What we got from FPGA (PADDING_EN=1, recovered EM)")
print("=" * 70)
print("Test A (put_rev, CFG=0x501) EM[0:1] = 5C A7   ← FAIL (expect 00 01)")
print("Test B (memcpy, CFG=0x3501+swap) EM[0:1] = 48 18  ← FAIL (expect 00 01)")
print("Both HW digests ≠ SHA256(msg/N/D/any combo)  ← FAIL")
