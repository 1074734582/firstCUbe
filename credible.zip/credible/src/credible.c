#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <unistd.h>
#include <sys/time.h>
#include <dlfcn.h>
#include <pthread.h>
#include "norflash.h"
#include "libcall.h"

#define ROM_ADDR 0xfffff000
#define ROM_MAP_SIZE 0x1000
#define KERNEL_ADDR 0x80000000
#define KERNEL_MAP_SIZE 0x10000000

#define FLASH_MAX 4096

#define PROM_FLAG 0x77770000
#define FLASH_UPGRADE_FLAG 0x77777777
#define GROUND_UPGRADE_FLAG 0x77775555

#define FAILD -1
#define SUCCESS 0
#define TAMPER_RECOVER 1
#define NO_POLICY_DATE 2
#define NO_NEED_COVER 3
#define BCC_FAILD -2
#define REV_FAILD -3

#define HASH_SIZE 32
#define FILEINFO_SIZE 52
#define REMARK_SIZE 20

#define BCC_SIZE 2
#define UART_FLAG_SIZE 2

#define DEBUG 1
#define NO_DEBUG 2

#define TIME_POLICY_ADDR 0

#define CHECK_EFFECTIVE_PROM_FLASH_GROUND 1
#define CHECK_EFFECTIVE_GROUND 2

#define REV_COVER_INFO 1
#define REV_NORMAL_INFO 2

#define SHM_SAFE_NODE_LEN 6

int log_level = DEBUG;

#define LOG_PRINT(level,info,len,format,args...) \
{ \
    if(level>=log_level) \
    { \
        printf(format, ##args); \
        printf("\n"); \
        print_date(info,len);\
    } \
}

#define LOG_INFO_PRINT(level,info,format,args...) \
{ \
    if(level>=log_level) \
    { \
        printf(format, ##args); \
        printf("\n"); \
        print_info(info); \
    } \
}

typedef enum upgrade_flag
{
    NO_UPGRADE=0,
    NEED_UPGRADE,
} upgrade_flag_e;

typedef enum uart_algo_
{
    UART_TO_SPACE_POLICY=1,
    UART_COVER_SPACE_POLICY,
    UART_SPACE_REV_GROUND,
    UART_SPACE_GETINFO_POLICY,
} uart_algo_e;

typedef struct uart_signal_head {
    uint32_t type;
    uint32_t upgrade_flag;
    uint32_t machine_number;
    uint32_t flash_addr;
    uint32_t size;
}uart_signal_head_t;

typedef struct uart_signal {
    uart_signal_head_t head;
    uint8_t *date;
    uint8_t bcc[BCC_SIZE];
}uart_signal_t;

typedef struct uart_policy_head {
    uint32_t update_flag;
    uint32_t machine_number;
    uint32_t flash_target;
    uint32_t medium;
    uint32_t target;
    uint32_t size;
    char remarks[REMARK_SIZE];
    char fileinfo[FILEINFO_SIZE];
    uint8_t hash[HASH_SIZE];
}uart_policy_head_t;

typedef struct uart_policy{
    uart_policy_head_t policy_head;
    uint8_t *original_data;
}uart_policy_t;

typedef struct shm_list_node
{
    uint8_t machine_number;
    uint32_t flash_target;
    uint8_t status;
}shm_list_node_t;

typedef struct shm_list{
    shm_list_node_t node;
    struct shm_list *next;
}shm_list_t;

typedef struct shm_info{
    uint32_t number;
    shm_list_t list;
}shm_info_t;

typedef enum policy_lib_machine_
{
    POLICY_LIB_NATIVE=1,
} policy_lib_machine_e;

typedef enum native_policy_lib_type
{
    POLICY_LIB_SPI_KERNEL=0,
    POLICY_LIB_SPI_ROM,
    POLICY_LIB_SPI_SYS,
} native_policy_lib_type_e;

typedef struct {
    uint32_t machine_num;
    uint32_t flash_addr;
}MACHINE_RCU;

uint32_t check_time = 3600;
uint8_t uart_falg[UART_FLAG_SIZE]={0xeb,0x90};
int shmid;
int shmid1;
pthread_t heart_thread; // ��ȡ���ݵ��߳�
int fifo_read,fifo_write;

MACHINE_RCU ma_rcu[] = {
    {POLICY_LIB_NATIVE,0x00000000},
};

int32_t print_date(uint8_t *message, int32_t len){
    int i;

    for(i =0;i<len;i++){
        printf("0x%02x ",message[i]);
    }
    printf("\n");
    return SUCCESS;
}

int32_t print_info(uart_signal_t *info){
    uint8_t *tmp;
    int32_t len=sizeof(uart_signal_head_t)+BCC_SIZE;

    if(info->head.type >= UART_TO_SPACE_POLICY && info->head.type <= UART_COVER_SPACE_POLICY){
        len += info->head.size;
        tmp = malloc(len);
        memcpy(tmp,&info->head,sizeof(uart_signal_head_t));
        memcpy(tmp+sizeof(uart_signal_head_t),info->date,info->head.size);
        memcpy(tmp+sizeof(uart_signal_head_t)+info->head.size,info->bcc,BCC_SIZE);
    }else{
        tmp = malloc(len);
        memcpy(tmp,&info->head,sizeof(uart_signal_head_t));
        memcpy(tmp+sizeof(uart_signal_head_t),info->bcc,BCC_SIZE);
    }

    print_date(tmp,len);

    free(tmp);
    return SUCCESS;
}

int32_t libso_call_sm3(void *so_handler,char *name,const uint8_t *in, uint32_t inlen, uint8_t *hash)
{
    int32_t (*sub_fun)(const uint8_t *in, uint32_t inlen, uint8_t *hash);
    int32_t ret;

    sub_fun = dlsym(so_handler, name);
    if (!sub_fun) {
        fprintf(stderr, "%s \n",dlerror());
        return -1;
    }
    ret = sub_fun(in,inlen,hash);

    return ret;
}

void *shm_safe_attach(void)
{
    void *shmptr;

    if((shmptr = shmat(shmid, 0, 0)) == (void *)-1)
    {
        printf("ERROR: shm_safe_attach: shmat failed. errno=%d.\n", errno);
        return NULL;
    }

    return shmptr;
}

void *shm_safe_attach1(void)
{
    void *shmptr1;

    if((shmptr1 = shmat(shmid1, 0, 0)) == (void *)-1)
    {
        printf("ERROR: shm_safe_attach: shmat1 failed. errno=%d.\n", errno);
        return NULL;
    }

    return shmptr1;
}

int32_t shm_safe_detach(void *shmptr)
{
    if(shmdt(shmptr) == -1)
    {
        printf("ERROR: shm_safe_detach: shmat failed. errno=%d.\n", errno);
        return -1;
    }
}

int32_t shm_safe_detach1(void *shmptr1)
{
    if(shmdt(shmptr1) == -1)
    {
        printf("ERROR: shm_safe_detach: shmat1 failed. errno=%d.\n", errno);
        return -1;
    }
}

int32_t shm_safe_init(void)
{
    int shm_safe_key;
    int shm_safe_key1;

    shm_safe_key = ftok(PATHNAME, IPC_EXCL);
    shmid = shmget(shm_safe_key, 0, 0);
    if(shmid < 0)
    {
        printf("ERROR: shm_safe_init: shmget failed. errno=%d.\n", errno);
        return -1;
    }

    shm_safe_key1 = ftok(PATHNAME1, IPC_EXCL);
    shmid1 = shmget(shm_safe_key1, 0, 0);
    printf("shm_safe_init1 shmid =%d shmid1=%d\n",shmid,shmid1);
    printf("shm_safe_init1 shm_safe_key1 =%d shm_safe_key=%d\n",shm_safe_key1,shm_safe_key);
 //   shmid1 = shmget(123, sizeof(shm_safe_data_t1), 0666|IPC_CREAT);

    if(shmid1 < 0)
    {
        printf("ERROR: shm_safe_init: shmget1 failed. errno=%d.\n", errno);
        return -1;
    }

    return 0;
}
void*  send_heart_beat(void* arg)
{
    printf("enter send_heart_beat\n");
    shm_safe_data_t1 *shm_data1;

    uint32_t shm_flag=0;
    uint32_t n_byte;
    uint32_t heart_count=1;
    while(1){
    shm_data1 = (shm_safe_data_t1 *)shm_safe_attach1();
    shm_data1->action_flag=6;
    shm_data1->heart_count=heart_count++;

    printf("shm_data1->action_flag=%d\n",shm_data1->action_flag);
    printf("shm_data1->heart_count=%d\n",shm_data1->heart_count);
    shm_safe_detach1((void *)shm_data1);
    shm_flag = SHM_HEART_BEAT;
    n_byte = write(fifo_write,&shm_flag,sizeof(uint32_t));
    sleep(5);
    }
    printf("enter while5\n");
     printf("enter send_heart_beat done\n");
}
int fifo_open(char *pathname_read,char *pathname_write, int *fd_read,int *fd_write)
{
    if((*fd_write = open(pathname_write,O_WRONLY)) < 0)
    {
        fprintf(stderr,"Fail to open %s : %s.\n",pathname_write,strerror(errno));
        return -1;
    }
    if((*fd_read = open(pathname_read,O_RDONLY)) < 0)
    {
        fprintf(stderr,"Fail to open %s : %s.\n",pathname_read,strerror(errno));
        return -1;
    }

    return 0;
}

int32_t CreatListNumber(shm_info_t *head, shm_list_node_t *date) {
    shm_list_t * r, * newNode;

    r = &head->list;
    while (r->next != NULL) {
        r = r->next;
    }

    head->number++;
    newNode = (shm_list_t * )malloc(sizeof(shm_list_t));
    memcpy(&newNode->node,date,sizeof(shm_list_node_t));
    r->next = newNode;
    newNode->next = NULL;
    return 0;
}

void GetAllListNumber(shm_info_t *head, uint8_t*mess) {
    shm_list_t *p = head->list.next;

    while (p != NULL) {
        memcpy(mess,&p->node.machine_number,sizeof(uint8_t));
        memcpy(mess+sizeof(uint8_t),&p->node.flash_target,sizeof(uint32_t));
        memcpy(mess+sizeof(uint8_t)+sizeof(uint32_t),&p->node.status,sizeof(uint8_t));
        p = p->next;
        mess += SHM_SAFE_NODE_LEN;
    }
}

void DestoryList(shm_info_t *head) {
    shm_list_t *p = head->list.next;
    shm_list_t *q = p;
    while (p != NULL) {
        p = p->next;
        free(q);
        q = p;
    }
    head->list.next = NULL;
}

int32_t getdate_form_flash(char *sys_name, uint32_t addr, uint32_t len, uint8_t *date)
{
    int32_t fd;
    int32_t ret;

    if((fd = open(sys_name, O_RDONLY)) == -1)
        return FAILD;

    ret = lseek(fd,addr,SEEK_SET);
    if(ret < 0){
        return ret;
    }

    ret = read(fd,date,len);
    if(ret < 0){
        return ret;
    }

    close(fd);
    return SUCCESS;
}

int32_t setdate_to_flash(char *sys_name, uint32_t addr, uint32_t len, uint8_t *date)
{
    int32_t fd;
    int32_t ret;

    if((fd = open(sys_name, O_WRONLY | O_CREAT | O_TRUNC)) == -1)
        return FAILD;

    ret = lseek(fd,addr,SEEK_SET);
    if(ret < 0){
        return ret;
    }

    ret = write(fd,date,len);
    if(ret < 0){
        return ret;
    }

    close(fd);
    return SUCCESS;
}
uint8_t register_kernel[] = {0x25,0x65,0x35,0x35,0x26,0x32,0x52,0x55,0x24,0x53,0x25,0x54,0x42,0x36,0x62,0x55,0x45,0x56,0x58,0x62,0x56,0x53,0x53,0x52,0x63,0x25,0x25,0x52,0x45,0x32,0x55,0x44,0x23,0x66,0x25,0x54,0x55,0x65,0x86,0x25,0x65,0x35,0x35,0x26,0x32,0x52,0x55,0x24,0x53,0x25,0x54,0x42,0x36,0x62,0x55,0x45,0x56,0x58,0x64,0x58,0x72,0x54,0x65,0x28,0x25,0x15,0x56,0x66,0x22,0x55,0x42,0x22,0x25,0x65,0x35,0x35,0x26,0x32,0x52,0x55,0x24,0x53,0x25,0x54,0x42,0x36,0x62,0x55,0x45,0x56,0x58,0x64,0x58,0x72,0x54,0x65,0x28,0x25,0x15,0x56,0x66,0x22,0x55,0x42,0x22,0x25,0x65,0x35,0x35,0x26,0x32,0x52,0x55,0x22,0x56,0x53,0x53,0x52,0x63,0x25,0x25,0x52,0x25,0x65,0x35,0x35,0x26,0x32,0x52,0x55,0x22,0x56,0x53,0x53,0x52,0x63,0x25,0x25,0x52,0x25,0x65,0x35,0x35,0x26,0x32,0x52,0x55,0x22,0x56,0x53,0x53,0x52,0x63,0x25,0x25,0x52,0x25,0x65,0x35,0x35,0x26,0x32,0x52,0x55,0x22,0x56,0x53,0x53,0x52,0x63,0x25,0x25,0x52,0x25,0x65,0x35,0x35,0x26,0x32,0x52,0x55,0x22,0x56,0x53,0x53,0x52,0x63,0x25,0x25,0x52,0x25,0x65,0x35,0x35,0x26,0x32,0x52,0x55,0x22,0x56,0x53,0x53,0x52,0x63,0x25,0x25,0x52,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45,0x53,0x25,0x00,0x00,0x00,0x00,0x02,0x41,0x55,0x27,0x62,0x22,0x55,0x54,0x55,0x32,0x50,0x00,0x00,0x00,0x00,0x24,0x15,0x52,0x76,0x22,0x25,0x55,0x45};
int32_t read_date(uint32_t flag, char *name, uint32_t addr, uint32_t len, uint8_t *date)
{
#if 0
    char* date_register;

    if(flag == POLICY_LIB_SPI_KERNEL){
        if(addr <= KERNEL_MAP_SIZE && (addr+len) <= KERNEL_MAP_SIZE){
            date_register = (char*)(addr+KERNEL_ADDR);
            memcpy(date, date_register, len);
        }else{
            return FAILD;
        }
    }else if(flag == POLICY_LIB_SPI_ROM){
        if(addr <= ROM_MAP_SIZE && (addr+len) <= ROM_MAP_SIZE){
            date_register = (char*)(addr+ROM_ADDR);
            m6xNorRead(*(addr_t *)date_register, len, (void *)date);
        }else{
            return FAILD;
        }
    }else if(flag == POLICY_LIB_SPI_SYS){
        getdate_form_flash(name,addr, len, date);
    }
#else
    if(flag == POLICY_LIB_SPI_KERNEL){
        memcpy(date,register_kernel+addr,len);
    }else if(flag == POLICY_LIB_SPI_SYS){
        getdate_form_flash(name,addr, len, date);
    }
    printf("read date:\n");
    int i;
    for(i =0;i<len;i++){
        printf("0x%x ",date[i]);
    }
    printf("\n");
#endif
    return SUCCESS;
}

int32_t write_date(uint32_t flag, char *name,uint32_t addr, uint32_t len, uint8_t *date)
{
#if 0
    char* date_register;

    if(flag == POLICY_LIB_SPI_KERNEL){
        if(addr <= KERNEL_MAP_SIZE && (addr+len) <= KERNEL_MAP_SIZE){
            date_register = (char*)(addr+KERNEL_ADDR);
            memcpy(date_register, date, len);
        }else{
            return FAILD;
        }
    }else if(flag == POLICY_LIB_SPI_ROM){
        if(addr <= ROM_MAP_SIZE && (addr+len) <= ROM_MAP_SIZE){
            date_register = (char*)(addr+ROM_ADDR);
            m6xNorWrite(*(addr_t *)date_register, len, (void *)date);
        }else{
            return FAILD;
        }
    }else if(flag == POLICY_LIB_SPI_SYS){
        setdate_to_flash(name,addr, len, date);
    }
#else
    if(flag == POLICY_LIB_SPI_KERNEL){
        memcpy(register_kernel+addr,date,len);
    }else if(flag == POLICY_LIB_SPI_SYS){
        setdate_to_flash(name,addr, len, date);
    }
#endif
    return SUCCESS;
}

void getBcc(uint8_t *data, uint16_t length, uint8_t *bcc)
{
    uint8_t i;

    memset(bcc,0,2);
    for ( i = 0; i < (length/2); i++ )
    {
        bcc[0] ^= data[i*2];
        bcc[1] ^= data[i*2+1];
    }

    if(length % 2 > 0){
        bcc[0] ^= data[i*2];
    }
}

int32_t check_date_effective(uart_signal_t *info,uint32_t type)
{
    int32_t ret=NO_POLICY_DATE;
    uint32_t flag;

    memcpy(&flag, info->date, sizeof(uint32_t));
    if(type == CHECK_EFFECTIVE_PROM_FLASH_GROUND){
        if(flag == PROM_FLAG || flag == FLASH_UPGRADE_FLAG || flag == GROUND_UPGRADE_FLAG){
            ret = SUCCESS;
        }else{
            ret = NO_POLICY_DATE;
        }
    }else if(type == CHECK_EFFECTIVE_GROUND){
        if(flag == GROUND_UPGRADE_FLAG){
            ret = SUCCESS;
        }else if(flag == PROM_FLAG || flag == FLASH_UPGRADE_FLAG){
            ret = FAILD;
        }else{
            ret = NO_POLICY_DATE;
        }
    }
    return ret;
}

int shm_send_credible_data(shm_info_t *shm)
{
    uint32_t send_len,shm_flag;
    uint8_t *message=NULL;
    uint32_t len=0;
    shm_safe_data_t *shm_data;
    int32_t n_byte=0;

    if(shm->number > 0)
    {
        len = shm->number * SHM_SAFE_NODE_LEN;
        message = malloc(len);
        GetAllListNumber(shm,message);
        LOG_PRINT(DEBUG,message,len,"shm_date:");
        DestoryList(shm);
        shm->number = 0;

        shm_data = (shm_safe_data_t *)shm_safe_attach();
        send_len = 0;
        while(send_len < len){
            if((len-send_len) > SEND_CREDIBLE_LEN_MAX){
                memcpy(shm_data->shm_data,message+send_len,SEND_CREDIBLE_LEN_MAX);
                shm_data->shm_len = SEND_CREDIBLE_LEN_MAX;
                send_len += SEND_CREDIBLE_LEN_MAX;
            }else{
                memcpy(shm_data->shm_data,message+send_len,len-send_len);
                shm_data->shm_len = len-send_len;
                send_len += (len-send_len);
            }
            shm_data->action_flag = SHM_SEND_CREDIBLE;
            n_byte = write(fifo_write,&shm_data->action_flag,sizeof(uint32_t));
            if(n_byte > 0){
                n_byte = read(fifo_read,&shm_flag,sizeof(uint32_t));
                if(n_byte > 0){
                    if(shm_data->action_flag == SHM_REST_FLAG)
                        continue;
                }
            }
        }
        shm_safe_detach((void *)shm_data);
        if(message != NULL)
            free(message);
    }

    return 0;
}

int32_t handle_date(uart_signal_t *info)
{
    int32_t ret=FAILD;
    uint8_t *buf;
    uint8_t hash[HASH_SIZE];
    uart_policy_t date;
    uint32_t flag,time_date,machineNum,flash_target;
    void *so_call;

    so_call = dlopen("libuart.so", RTLD_GLOBAL);
    if (!so_call) {
        fprintf(stderr, "%s \n",dlerror());
        return -1;
    }

    memcpy(&flag, info->date, sizeof(uint32_t));
    memcpy(&machineNum, info->date+sizeof(uint32_t), sizeof(uint32_t));
    memcpy(&flash_target, info->date+sizeof(uint32_t)*2, sizeof(uint32_t));
    if(flag == PROM_FLAG || flag == FLASH_UPGRADE_FLAG || flag == GROUND_UPGRADE_FLAG){
        if(info->head.machine_number == machineNum && info->head.flash_addr == flash_target){
            if(info->head.type == UART_TO_SPACE_POLICY || info->head.type == UART_COVER_SPACE_POLICY){
                if(info->head.machine_number == POLICY_LIB_NATIVE && info->head.flash_addr == TIME_POLICY_ADDR){
                    memcpy(&time_date, info->date+sizeof(uint32_t)*3, sizeof(uint32_t));
                    if(check_time != time_date){
                        check_time = time_date;
                        ret = SUCCESS;
                    }
                    else
                        ret = NO_NEED_COVER;
                }else{
                    memcpy(&date.policy_head, info->date, sizeof(uart_policy_head_t));
                    buf = malloc(date.policy_head.size);
                    if(buf != NULL){
                        if(info->head.type == UART_TO_SPACE_POLICY){
                            if(date.policy_head.machine_number == POLICY_LIB_NATIVE){
                                ret = read_date(date.policy_head.medium,date.policy_head.fileinfo,date.policy_head.target, date.policy_head.size, buf);
                                if(ret == SUCCESS){
                                    libso_call_sm3(so_call,"sm3",buf, date.policy_head.size, hash);
                                    if(memcmp(hash, date.policy_head.hash, HASH_SIZE) != 0){
                                        ret = TAMPER_RECOVER;
                                    }else{
                                        ret = SUCCESS;
                                    }
                                }
                            }
                        }else if(info->head.type == UART_COVER_SPACE_POLICY)
                        {
                            date.original_data = malloc(date.policy_head.size);
                            if(date.original_data != NULL){
                                memcpy(date.original_data, info->date+sizeof(uart_policy_head_t), date.policy_head.size);
                                if(date.policy_head.machine_number == POLICY_LIB_NATIVE){
                                    ret = read_date(date.policy_head.medium,date.policy_head.fileinfo,date.policy_head.target, date.policy_head.size, buf);
                                    if(ret == SUCCESS){
                                        libso_call_sm3(so_call,"sm3",date.original_data, date.policy_head.size, hash);
                                        if(memcmp(date.policy_head.hash, hash, HASH_SIZE) == 0)
                                        {
                                            if(memcmp(buf, date.original_data, date.policy_head.size) != 0){
                                                ret = write_date(date.policy_head.medium,date.policy_head.fileinfo,date.policy_head.target, date.policy_head.size, date.original_data);
                                            }else{
                                                ret = NO_NEED_COVER;
                                            }
                                        }
                                    }
                                }
                                free(date.original_data);
                            }
                        }
                        free(buf);
                    }
                }
            }
        }
    }else{
        ret = NO_POLICY_DATE;
    }

    dlclose(so_call);
    return ret;
}

int32_t send_uart_info(uart_signal_t *info){
    int32_t ret=FAILD;
    uint8_t *send_msg=NULL;
    int32_t len=0;
    uint32_t shm_flag=0;
    int32_t n_byte;
    shm_safe_data_t *shm_data;
    printf("enter send_uart_info\n");
    memset(info->bcc,0,BCC_SIZE);
    if(info->head.type >= UART_SPACE_REV_GROUND && info->head.type <= UART_SPACE_GETINFO_POLICY){
        len = sizeof(uart_signal_head_t)+BCC_SIZE+UART_FLAG_SIZE;
        send_msg = malloc(len);
        if(send_msg != NULL){
            memcpy(send_msg,uart_falg,UART_FLAG_SIZE);
            memcpy(send_msg+UART_FLAG_SIZE,&info->head,sizeof(uart_signal_head_t));
            getBcc(send_msg+UART_FLAG_SIZE, sizeof(uart_signal_head_t),info->bcc);
            memcpy(send_msg+sizeof(uart_signal_head_t)+UART_FLAG_SIZE,info->bcc,BCC_SIZE);
            LOG_PRINT(DEBUG,send_msg,len,"lkb cre send:");

            shm_data = (shm_safe_data_t *)shm_safe_attach();
            memcpy(shm_data->shm_data,send_msg, len);
            shm_data->shm_len = len;
            shm_data->action_flag = SHM_REQUST_FLAG;
            shm_safe_detach((void *)shm_data);
            shm_flag = SHM_REQUST_FLAG;
            n_byte = write(fifo_write,&shm_flag,sizeof(uint32_t));
            if(n_byte > 0)
                ret = SUCCESS;
        }
    }

    if(send_msg != NULL)
        free(send_msg);
    return ret;
}

int32_t check_bcc(uart_signal_t *info){
    int32_t ret=FAILD;
    uint8_t bcc[BCC_SIZE];
    uint8_t *bcc_msg=NULL;
    int32_t msg_len=sizeof(uart_signal_head_t);

    memset(bcc,0,BCC_SIZE);
    if(info->head.type >= UART_TO_SPACE_POLICY && info->head.type <= UART_COVER_SPACE_POLICY)
    {
        msg_len += info->head.size;
        bcc_msg = malloc(msg_len);
        if(bcc_msg != NULL){
            memcpy(bcc_msg,&info->head,sizeof(uart_signal_head_t));
            memcpy(bcc_msg+sizeof(uart_signal_head_t),info->date,info->head.size);
        }
    }else{
        bcc_msg = malloc(msg_len);
        if(bcc_msg != NULL){
            memcpy(bcc_msg,&info->head,sizeof(uart_signal_head_t));
        }
    }
    if(bcc_msg != NULL && msg_len > 0)
        getBcc(bcc_msg, msg_len,bcc);

    if (memcmp(bcc,info->bcc,BCC_SIZE) == 0)
    {
        ret=SUCCESS;
    }

    if(bcc_msg != NULL)
        free(bcc_msg);
    return ret;
}

int32_t find_start_form_uart(uint8_t *rev_msg,uint32_t len,uint8_t *data_msg){
    int32_t ret = FAILD;
    uint32_t i;

    if(len >= (sizeof(uart_signal_head_t)+sizeof(uart_policy_head_t)+BCC_SIZE)){
        return ret;
    }
    for(i=0; i<(len-1); i++){
        if(rev_msg[i] == uart_falg[0]){
again:
            if(rev_msg[i+1] == uart_falg[0]){
                goto again;
            }else if(rev_msg[i+1] == uart_falg[1]){
                data_msg = rev_msg+i+2;
                ret = SUCCESS;
                break;
            }
        }
    }

    return ret;
}

uint32_t rev_mem_info(uint32_t flag, uart_signal_t *info, shm_info_t *shm)
{
    uint32_t shm_flag,n_byte;
    uint8_t *rev_msg=NULL;
    int32_t ret;
    shm_list_node_t node;
    shm_safe_data_t *shm_data;

    n_byte=read(fifo_read,&shm_flag,sizeof(uint32_t));
    if(n_byte > 0){
        shm_data = (shm_safe_data_t *)shm_safe_attach();
        if(shm_flag == SHM_RESPONSE_FLAG && shm_data->action_flag == SHM_RESPONSE_FLAG){
            if(flag == REV_NORMAL_INFO){
                if(shm_data->shm_len > 0){
                    memcpy(&info->head, shm_data->shm_data, sizeof(uart_signal_head_t));
                    info->date = malloc(info->head.size);
                    memcpy(info->date,shm_data->shm_data+sizeof(uart_signal_head_t),info->head.size);
                    memcpy(info->bcc,shm_data->shm_data+sizeof(uart_signal_head_t)+info->head.size,BCC_SIZE);
                    LOG_INFO_PRINT(DEBUG,info,"receive info:");
                }
            }else if(flag == REV_COVER_INFO){
                rev_msg = shm_data->shm_data;
                while(shm_data->shm_len > 0){
                    memcpy(&info->head, rev_msg, sizeof(uart_signal_head_t));
                    info->date = malloc(info->head.size);
                    memcpy(info->date,rev_msg+sizeof(uart_signal_head_t),info->head.size);
                    memcpy(info->bcc,rev_msg+sizeof(uart_signal_head_t)+info->head.size,BCC_SIZE);

                    LOG_INFO_PRINT(DEBUG,info,"receive cover info:");
                    node.machine_number = (uint8_t)info->head.machine_number;
                    node.flash_target = info->head.flash_addr;
                    if(info->head.type == UART_COVER_SPACE_POLICY)
                    {
                        ret = check_date_effective(info,CHECK_EFFECTIVE_GROUND);
                        if(ret == SUCCESS){
                            if(check_bcc(info) == SUCCESS){
                                ret = handle_date(info);
                                if (ret < 0){
                                    node.status = UPGRADE_ERROR;
                                }else{
                                    if(ret == NO_NEED_COVER)
                                        node.status = UPGRADE_NO_NEED_RECOVER;
                                    else
                                        node.status = UPGRADE_OK;
                                }
                            }else{
                                node.status = UPGRADE_BCC_ERROR;
                            }
                        }
                        if(shm != NULL){
                            CreatListNumber(shm,&node);
                        }
                        free(info->date);
                    }

                    shm_data->shm_len -= (sizeof(uart_signal_head_t)+info->head.size+BCC_SIZE);
                    if(shm_data->shm_len > 0)
                        rev_msg += (sizeof(uart_signal_head_t)+info->head.size+BCC_SIZE);
                }
            }
        }
        shm_data->action_flag = SHM_REST_FLAG;
        shm_safe_detach((void *)shm_data);
    }
    return shm_flag;
}

int32_t rev_cover_uart_info(uart_signal_t *info, shm_info_t *shm){
    int32_t ret=SUCCESS;
    memset(info,0x0,sizeof(uart_signal_t));
    rev_mem_info(REV_COVER_INFO,info,shm);
    return ret;
}

uint32_t get_type_form_send_type(uint32_t type)
{
    uint32_t val=0;

    if(type == UART_SPACE_GETINFO_POLICY){
        val = UART_TO_SPACE_POLICY;
    }

    return val;
}

int32_t rev_uart_info(uart_signal_t *info){
    int32_t ret=FAILD;
    int32_t rev_type = get_type_form_send_type(info->head.type);
    uint32_t shm_flag;

    memset(info,0x0,sizeof(uart_signal_t));
    shm_flag = rev_mem_info(REV_NORMAL_INFO,info,NULL);
    if(shm_flag == SHM_RESPONSE_FLAG){
        if(rev_type == info->head.type)
        {
            ret = check_date_effective(info,CHECK_EFFECTIVE_PROM_FLASH_GROUND);
            if(ret == SUCCESS){
                ret = check_bcc(info);
                if(ret == SUCCESS){
                    ret = handle_date(info);
                }else{
                    ret = BCC_FAILD;
                }
            }
            free(info->date);
        }else{
            ret = REV_FAILD;
        }
    }else if(shm_flag == SHM_NO_RESPONSE_FLAG){
        ret = REV_FAILD;
    }

    return ret;
}

int32_t send_rev_uart_info(uart_signal_t *info, shm_info_t *shm){
    int32_t ret=SUCCESS;

    if(info->head.type == UART_SPACE_GETINFO_POLICY){
        ret = send_uart_info(info);
        if(ret < 0)
            goto exit;
        ret = rev_uart_info(info);
        if(ret < 0)
            goto exit;
    }else if(info->head.type == UART_SPACE_REV_GROUND){
        ret = send_uart_info(info);
        if(ret < 0)
            goto exit;
        ret = rev_cover_uart_info(info,shm);
        if(ret < 0)
            goto exit;
    }
exit:
    return ret;
}

int32_t handle_equipment_status(uart_signal_t *info,uint32_t type,uint32_t machine_number,uint32_t flash_addr, uint32_t size, shm_info_t *shm){
    int32_t ret=SUCCESS;

    memset(info,0x0,sizeof(uart_signal_t));
    if(type >= UART_SPACE_REV_GROUND && type <= UART_SPACE_GETINFO_POLICY){
        info->head.type = type;
        info->head.machine_number = machine_number;
        info->head.flash_addr = flash_addr;
        info->head.size = size;
        ret = send_rev_uart_info(info, shm);
        if(ret < 0){
            goto exit;
        }
    }
exit:
    return ret;
}

int32_t check_equipment_status(uart_signal_t *info, shm_info_t *shm){
    int32_t ret=SUCCESS;
    int32_t upgrade=NO_UPGRADE;
    int32_t i,flash_count;
    shm_list_node_t safe_node;
    uint32_t rev_errcount=0;

    for (i=0;i<sizeof(ma_rcu)/sizeof(MACHINE_RCU); i++)
    {
        if(ma_rcu[i].machine_num == POLICY_LIB_NATIVE){
            flash_count = 1;
        }else{
            flash_count = 0;
        }
        rev_errcount=0;
        while(1)
        {
            safe_node.machine_number = (uint8_t)ma_rcu[i].machine_num;
            safe_node.flash_target = ma_rcu[i].flash_addr + flash_count * FLASH_MAX;
            ret = handle_equipment_status(info, UART_SPACE_GETINFO_POLICY, ma_rcu[i].machine_num, safe_node.flash_target, 0, NULL);
            if(ret < 0){
                if(ret == BCC_FAILD){
                    safe_node.status = STATUS_BCC_ERROR;
                }else if(ret == REV_FAILD){
                    safe_node.status = STATUS_REV_ERROR;
                    if(rev_errcount >= 3){
                        if(shm != NULL){
                            CreatListNumber(shm,&safe_node);
                        }
                        break;
                    }else{
                        rev_errcount++;
                    }
                }else{
                    safe_node.status = STATUS_ERROR;
                }
            }else {
                if(info->head.upgrade_flag == NEED_UPGRADE){
                    upgrade = info->head.upgrade_flag;
                }
                if(ret == TAMPER_RECOVER){
                    safe_node.status = STATUS_TAMPER_RECOVER;
                }else if(ret == NO_POLICY_DATE){
                    if(upgrade == NEED_UPGRADE){
                        handle_equipment_status(info, UART_SPACE_REV_GROUND, 0, 0, 0, shm);
                        upgrade = NO_UPGRADE;
                    }
                    break;
                }else{
                    safe_node.status = STATUS_OK;
                }
            }
            if(shm != NULL){
                CreatListNumber(shm,&safe_node);
            }

            if(upgrade == NEED_UPGRADE){
                handle_equipment_status(info, UART_SPACE_REV_GROUND, 0, 0, 0, shm);
                upgrade = NO_UPGRADE;
            }
            flash_count++;
        }
    }
    return ret;
}

int main (int argc, char **argv)
{
    struct timeval time_start,time_end;
    int32_t ret=SUCCESS;
    uart_signal_t info;
    uint32_t timer=0;
    shm_info_t shm;
    uint32_t loop_time = 2;
    uint32_t pthread_status =0;
    ret = shm_safe_init();
    if(ret < 0){
        return -1;
    }
    shm.number = 0;
    shm.list.next = NULL;

    ret = fifo_open(FIFO_WRITE,FIFO_READ,&fifo_read,&fifo_write);
    if(ret < 0){
        return -1;
    }
    pthread_create(&heart_thread, NULL, send_heart_beat, NULL);

    while(1){
        sleep(3);
    };

    handle_equipment_status(&info, UART_SPACE_GETINFO_POLICY, 1, 0, 0, NULL);

    gettimeofday(&time_start, NULL);

    //while(1)
    {
        handle_equipment_status(&info, UART_SPACE_REV_GROUND, 0, 0, 0, &shm);

        gettimeofday(&time_end, NULL);
        timer = time_end.tv_sec - time_start.tv_sec;
        printf("cre timer=%d\n",timer);
        //if((timer > 0 && timer >= check_time) || timer == 0)
        {
            check_equipment_status(&info, &shm);
            //gettimeofday(&time_start, NULL);
        }

        shm_send_credible_data(&shm);

        timer += loop_time;
    }

    int shm_flag = 10;
    write(fifo_write,&shm_flag,sizeof(uint32_t));

    close(fifo_read);
    close(fifo_write);

    return ret;
}
