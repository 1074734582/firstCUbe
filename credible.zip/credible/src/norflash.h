/*
 * norflash.h
 *
 *  Created on: Dec 1, 2022
 *      Author: lidp
 */

#ifndef SRC_NORFLASH_H_
#define SRC_NORFLASH_H_

/*********************************************************************************************************
   SPI �Ĵ���
*********************************************************************************************************/
#define REG_SPI_CAPABILITY                0x0000                        /*  SPI �����Ĵ���              */
#define REG_SPI_MODE                      0x0020                        /*  SPI ģʽ�Ĵ���              */
#define REG_SPI_EVENT                     0x0024                        /*  SPI �¼��Ĵ���              */
#define REG_SPI_COMMAND                   0x002c                        /*  SPI ָ��Ĵ���              */
#define REG_SPI_TRANSMIT                  0x0030                        /*  SPI ���ͼĴ���              */
#define REG_SPI_RECEIVE                   0x0034                        /*  SPI ���ռĴ���              */
#define REG_SPI_SLAVE_SELECT              0x0038                        /*  SPI ��ѡ�Ĵ���              */
#define REG_SPI_AUTO_SELECT               0x003c                        /*  SPI �Զ���ѡ�Ĵ���          */
#define REG_SPI_PROTOCOL_SELECT           0x0060                        /*  SPI Э��ѡ��Ĵ���          */
#define REG_SPI_DATELINE_CONTROL          0x0064                        /*  SPI �����߿��ƼĴ���        */
#define REG_SPI_SPIINT0                   0x0600                        /*  SPI SPIINT0�Ĵ���           */
#define REG_SPI_SPIIVL                    0x0604                        /*  SPI SPIIVL�Ĵ���            */
#define SPI_EVENT_RECV_NMPTY              (1 << 9)                      /*  ���շǿ�                    */
#define SPI_EVENT_SEND_FINISH             (1 << 14)                     /*  �������                    */

#define NORFLASH_SPI_CS                   (0)                           /*  SPI Ƭѡ                    */
#define NORFLASH_SECTION_SIZE             (0x10000)                     /*  ������С                    */
#define NORFLASH_SECTION_COUNT            (0x38)                        /*  ��������                    */
#define YAFFS_BEGIN_OFFSET                (0x480000)                    /*                              */
#define TRANSMIT_PER_TIME                 (0x100)                       /*  ���δ�����ֽ���            */
#define SPI_CS0                           0xE
#define SPI_CS1                           0xD
#define SPI_CS2                           0xB
#define SPI_CS3                           0x7
#define SPI_CSDISABLE                     0xF
#define Flash_CS_Enable                   SPI_CS0                       // flashƬѡʹ��
#define Flash_CS_Disable                  SPI_CSDISABLE                 // flashƬѡ����

#define SPI_PTC_Half_Duplex               0x0     //��˫��
#define SPI_PTC_Full_Duplex               0x1     //ȫ˫��
#define SPI_PTC_Dual                      0x2     //˫��
#define SPI_PTC_Qual                      0x3     //����
                                                  //MODE CPOL CPHA
#define SPI_MODE_0                        0       // 0    0    0
#define SPI_MODE_1                        1       // 1    0    1
#define SPI_MODE_2                        2       // 2    1    0
#define SPI_MODE_3                        3       // 3    1    1

int  m6xNorErase (addr_t addr, size_t len);
int  m6xNorRead  (addr_t addr, size_t len, void *data);
int  m6xNorWrite (addr_t addr, size_t len, const void *data);

#endif /* SRC_NORFLASH_H_ */
