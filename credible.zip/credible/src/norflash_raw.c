#define  __SYLIXOS_KERNEL
#define BSP_CFG_DEV_NORFLASH 1
/*********************************************************************************************************
  �ü�����
*********************************************************************************************************/
#if (BSP_CFG_DEV_NORFLASH > 0)
#include <linux/compat.h>
#include "norflash.h"
/*********************************************************************************************************
  �궨��
*********************************************************************************************************/
/*  ��ʱʱ�� 2 ��                  */
#define  SPI_TIMEROUT     (0x2000000000)
/*  20BCFFFF  64K   ���� SPI0                                   */
#define SPI0_BASE           (0x20BC0000)

#define REG_GET(base, reg) read32_le((base) + (reg))
#define REG_SET(base, reg, value) write32_le((value),(base) + (reg))
/*
static VOID write32(UINT32  uiData, addr_t ulAddr)
{
    *(volatile UINT32 *)ulAddr = uiData;
}
static UINT32 read32(addr_t ulAddr)
{
    UINT32  uiData;
    uiData = *(volatile UINT32 *)ulAddr;
    return uiData;
}
*/
/*********************************************************************************************************
** ��������: FlashCS_Disable
** ��������: SPI ��ɣ��ر�Ƭѡ
** ��  ��  : NONE
** ��  ��  : NONE
** ��  ��  : NONE
*********************************************************************************************************/
static VOID FlashCS_Disable(VOID)
{
    REG_SET(SPI0_BASE, REG_SPI_SLAVE_SELECT, Flash_CS_Disable);
}
/*********************************************************************************************************
** ��������: FlashCS_Enable
** ��������: SPI ����������Ƭѡ
** ��  ��  : uiCs   Ƭѡ
** ��  ��  : NONE
** ��  ��  : NONE
*********************************************************************************************************/
static void FlashCS_Enable(UINT32  uiCs)
{
    REG_SET(SPI0_BASE, REG_SPI_SLAVE_SELECT,  uiCs);
}
/*********************************************************************************************************
** ��������: __clearRecvFifo
** ��������: ��ս��� FIFO
** ��  ��  : NONE
** ��  ��  : NONE
** ��  ��  : NONE
*********************************************************************************************************/
static UINT32  spi_recvFIFO_clear(VOID)
{
    UINT32 uiInvalid = 0;
    while(REG_GET(SPI0_BASE, REG_SPI_EVENT) & SPI_EVENT_RECV_NMPTY)
    {
        uiInvalid = REG_GET(SPI0_BASE, REG_SPI_RECEIVE);
    }
    return uiInvalid;
}

void SPI_Transmit_Dummy()
{
    REG_SET(SPI0_BASE, REG_SPI_DATELINE_CONTROL, 0x00000000);
    REG_SET(SPI0_BASE, REG_SPI_TRANSMIT, 0x00000000);
    REG_SET(SPI0_BASE, REG_SPI_COMMAND, REG_GET(SPI0_BASE, REG_SPI_COMMAND) | (1<<22));

    while(((REG_GET(SPI0_BASE, REG_SPI_EVENT) >> 14) & 0x1) == 0);                 //0�ǵȴ��������
    REG_SET(SPI0_BASE, REG_SPI_EVENT, REG_GET(SPI0_BASE, REG_SPI_EVENT) | (1<<14));//�����־λLTд1����
}

void SPI_Receive_Byte(uint8_t *dat)
{
    uint32_t dat_temp = 0;

    spi_recvFIFO_clear();             // ��ȡǰ��һ��FIFO
    SPI_Transmit_Dummy();             // ����һ�����������ڲ���ʱ��
    while(((REG_GET(SPI0_BASE, REG_SPI_EVENT) >> 9) & 0x1) == 0);
    dat_temp = REG_GET(SPI0_BASE, REG_SPI_RECEIVE);
    dat_temp >>= 16;
    *dat = dat_temp;
}
/*********************************************************************************************************
** ��������: __readOneByte
** ��������: ��һ���ֽ�
** ��  ��  : NONE
** ��  ��  : NONE
** ��  ��  : ����
*********************************************************************************************************/
void SPI_Transmit_Byte(uint8_t dat)
{
    REG_SET(SPI0_BASE, REG_SPI_DATELINE_CONTROL, 0xff000000);
    REG_SET(SPI0_BASE, REG_SPI_TRANSMIT, dat << 24);
    REG_SET(SPI0_BASE, REG_SPI_COMMAND, REG_GET(SPI0_BASE, REG_SPI_COMMAND) | (1<<22));

    while(((REG_GET(SPI0_BASE, REG_SPI_EVENT) >> 14) & 0x1) == 0);                  // �ȴ��������
    REG_SET(SPI0_BASE, REG_SPI_EVENT, REG_GET(SPI0_BASE, REG_SPI_EVENT) | (1<<14)); // �����־λLT д1����
}


void Flash_Send(uint8_t dat)
{
    SPI_Transmit_Byte(dat);
}

uint8_t Flash_Receive(void)
{
    uint8_t dat_temp = 0;
    SPI_Receive_Byte(&dat_temp);
    return dat_temp;
}

static uint8_t Flag_Status_Check(uint8_t cmd)
{
    uint8_t sta = 0;
    FlashCS_Enable(Flash_CS_Enable);
    Flash_Send(cmd);
    sta = Flash_Receive();
    FlashCS_Disable();
    return sta;
}

void FlashWrite_Enable(void)
{
    volatile unsigned char Status_WEL = 0;
    FlashCS_Enable(Flash_CS_Enable);
    Flash_Send(0x06);               //��дʹ��
    FlashCS_Disable();

    do {
        Status_WEL = Flag_Status_Check(0x05); //��ѯдʹ��WEL�Ƿ���Ч
    } while(!(Status_WEL & 0x02));
}

void FlashWrite_Disable(void)
{
    volatile unsigned char Status_WEL = 0;
    FlashCS_Enable(Flash_CS_Enable);
    Flash_Send(0x04);               //��дʹ��
    FlashCS_Disable();
    do {
        Status_WEL = Flag_Status_Check(0x05); //��ѯдʹ��WEL�Ƿ���Ч
    } while(Status_WEL & 0x02);
}
/*********************************************************************************************************
** ��������: m6xNorErase
** ��������: оƬ�����ײ㷽��
** ��  ��  : addr
**           len
** ��  ��  : ERROR CODE
** ȫ�ֱ���:
** ����ģ��:
*********************************************************************************************************/
void FlashErase_Sector(unsigned int sector_num)
{
    volatile unsigned char Status_P_E = 0;
    volatile unsigned int sector_addr = 0;
    sector_addr = sector_num * NORFLASH_SECTION_SIZE;
    if(sector_addr > 0xffffff) {
        printf("��Ҫ�����ĵ�ַ����оƬ�ռ�Ĵ�С������\n");
        return;
    }
    FlashWrite_Enable();                    //��дʹ��
    FlashCS_Enable(Flash_CS_Enable);
    Flash_Send(0xd8);
    Flash_Send(sector_addr>>16);
    Flash_Send(sector_addr>>8);
    Flash_Send(sector_addr);
    FlashCS_Disable();
    do {
        Status_P_E = Flag_Status_Check(0x05); //��ѯ�����Ƿ����
    } while(Status_P_E & 0x1);
}

int m6xNorErase (addr_t addr, size_t len)
{
    uint32_t num = 0;
    addr -= NORFLASH_SECTION_SIZE;
    for(num = addr / NORFLASH_SECTION_SIZE; num < (addr + len) / NORFLASH_SECTION_SIZE; num++)
    {
//        printf(" erase addr is %08x, len is %08x\n", num * NORFLASH_SECTION_SIZE, len);
        FlashErase_Sector(num);
    }

    return  ERROR_NONE;
}
/*********************************************************************************************************
** ��������: m6xNorRead
** ��������: оƬ��ȡ�ײ㷽��
** ��  ��  : addr
**           len
**           data
** ��  ��  : ERROR CODE
** ȫ�ֱ���:
** ����ģ��:
*********************************************************************************************************/
int  m6xNorRead (addr_t addr, size_t len, void *data)
{
    uint32_t i = 0;
    addr -= NORFLASH_SECTION_SIZE;
    addr &= 0xFFFFFF;   //ȡ��3�ֽ�ss
    FlashCS_Enable(Flash_CS_Enable);
    Flash_Send(0x03);
    Flash_Send(addr>>16);
    Flash_Send(addr>>8);
    Flash_Send(addr);
    for(i = 0; i < len; i++)
    {
        ((uint8_t*)data)[i] = Flash_Receive();
    }
    FlashCS_Disable();

    return  ERROR_NONE;
}

/*********************************************************************************************************
** ��������: m6xNorWrite
** ��������: оƬд��ײ㷽��
** ��  ��  : addr
**           len
**           data
** ��  ��  : ERROR CODE
** ȫ�ֱ���:
** ����ģ��:
*********************************************************************************************************/
void FlashWrite_Dat(uint32_t addr, uint8_t *dat, uint16_t len)
{
    uint16_t i = 0;
    uint8_t sta = 0;
    FlashWrite_Enable();                    //��дʹ��

    FlashCS_Enable(Flash_CS_Enable);
    Flash_Send(0x02);
    Flash_Send(addr>>16);
    Flash_Send(addr>>8);
    Flash_Send(addr);
    for(i=0;i<len;i++)
    {
        Flash_Send(dat[i]);
    }
    FlashCS_Disable();

    do {
        sta = Flag_Status_Check(0x05); //��ѯ�����Ƿ����
    } while(sta & 0x1);
}

int m6xNorWrite (addr_t dat_addr,  size_t len, const void *dat)
{
    uint32_t page_cnt = 0;
    uint32_t i = 0;
    uint32_t ptr_temp = dat_addr;
    uint32_t ex_cnt = 0;
    dat_addr -= NORFLASH_SECTION_SIZE;
    /* ��ҳ  */
    if((ptr_temp&0xff) != 0x00)
    {
        ex_cnt = 256 - dat_addr%256;
        FlashWrite_Dat(dat_addr, (uint8_t *)dat, ex_cnt);
    }

    /* ����ҳ */
    page_cnt = (len-ex_cnt)/256;
    dat_addr += ex_cnt;
    dat += ex_cnt;
    for(i=0; i<page_cnt; i++)
    {
        FlashWrite_Dat(dat_addr, (uint8_t *)dat, 256);
        dat_addr += 256;
        dat += 256;
    }
    /* βҳ */
    if((len-ex_cnt)%256 != 0)
    {
        FlashWrite_Dat(dat_addr, (uint8_t *)dat, (len-ex_cnt)%256);
    }

    return  ERROR_NONE;
}

#endif
